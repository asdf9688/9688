#!/bin/bash
./admin.sh stop
echo "waiting..."
sleep 150

echo "start server..."
./admin.sh start

