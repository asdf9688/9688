#/bin/bash
from=`pwd`/hotswap
paths=("/root/game/")
path=""
for i in {1..10}; do
  path="/root/game${i}/" 
  if [ -d ${path} ] ; then
    paths[${#paths[@]}]=$path    
 fi
done

for ele in ${paths[@]}; do 
  echo "复制文件到"$ele
  rm -rf $ele/hotswap/
  cp -rp $from $ele
done
