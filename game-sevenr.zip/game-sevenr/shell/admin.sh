serverName='GameServer-2.0'
GAME_PID=`pwd`/var/game.pid
#echo "pid="$GAME_PID
JMX_IP="47.99.51.190"
JMX_PORT="10081"

JVM_ARGS="$JVM_ARGS"" -Djava.rmi.server.hostname="$JMX_IP
JVM_ARGS="$JVM_ARGS"" -Dcom.sun.management.jmxremote.port="$JMX_PORT
JVM_ARGS="$JVM_ARGS"" -Dcom.sun.management.jmxremote.authenticate=true"
JVM_ARGS="$JVM_ARGS"" -Dcom.sun.management.jmxremote.remote=true"
JVM_ARGS="$JVM_ARGS"" -Dcom.sun.management.jmxremote.ssl=false"
JVM_ARGS="$JVM_ARGS"" -Dcom.sun.management.jmxremote.access.file=/usr/java/jdk1.8.0_221/jre/lib/management/jmxremote.access"
JVM_ARGS="$JVM_ARGS"" -Dcom.sun.management.jmxremote.password.file=/usr/java/jdk1.8.0_221/jre/lib/management/jmxremote.password"
JVM_ARGS="$JVM_ARGS"" -Xms8g -Xmx8g"

if [ ! -d "var" ]; then
  mkdir "var"
fi
if [ ! -f ${GAME_PID} ]; then 
    touch ${GAME_PID}
fi

if [ $1 == "start" ]; then
  pid=`cat ${GAME_PID}`
  if [ $pid > 0 ]; then  
    echo "server had started"
    exit 0
  fi

  java  -server $JVM_ARGS \
  -Dfile.encoding=UTF-8 -jar $serverName.jar > /dev/null &
         echo $! > ${GAME_PID}  
elif [ $1 == "stop" ]; then 
  pid=`cat ${GAME_PID}`
  if [ $pid > 0 ]; then   
    echo "get ready to close server"
    kill 15 $pid
    rm -f ${GAME_PID}    
    echo "server closed successfully"
  else
    echo "server had not started"
  fi
fi