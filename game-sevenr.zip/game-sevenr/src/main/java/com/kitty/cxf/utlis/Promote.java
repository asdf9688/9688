package com.kitty.cxf.utlis;

import com.alibaba.fastjson.JSONObject;
import com.kitty.common.spring.SpringUtils;
import com.kitty.cxf.common.MapStringUtil;
import com.kitty.game.FieldValuePosConst;
import com.kitty.game.attribute.AttrService;
import com.kitty.game.attribute.config.Attribute;
import com.kitty.game.bag.message.RespIconCartoon;
import com.kitty.game.base.service.BagService;
import com.kitty.game.config.Equip;
import com.kitty.game.enter.FiedValue;
import com.kitty.game.equip.EquipDataPool;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.equip.model.EquipBox;
import com.kitty.game.equip.model.RoleEquip;
import com.kitty.game.equip.model.RoleEquipField;
import com.kitty.game.equip.service.EquipService;
import com.kitty.game.onlinemall.service.MallService;
import com.kitty.game.role.model.Role;
import com.kitty.listener.EventDispatcher;
import com.kitty.listener.EventType;
import com.kitty.listener.event.EquipUpgradeLevelChangeEvent;
import com.kitty.mina.message.MessagePusher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;


@Slf4j
@Component
public class Promote {

    @Autowired
    MallService mallService;

    @Autowired
    AttrService attrService;

    @Autowired
    BagService bagService;

    /**
     * 生产装备
     * VT 蓝 粉 黄 绿 暗 共 属性值
     */
    public RoleEquip sendEquip(Role role, short pos, Map<String, Object> toMap) {
        try {
            // 装备主键
            int id = mallService.getRoleEquipId();
            // 装备名称
            String equipName = String.valueOf(toMap.get("goodsName"));
            String color = "蓝色";
            // 蓝色属性
            Map<String, Object> blue = null;
            if (!"".equals(toMap.get("blue"))) {
                blue = MapStringUtil.resolution(String.valueOf(toMap.get("blue")), " ", "-");
            }
            // 粉色属性
            Map<String, Object> pink = null;
            if (!"".equals(toMap.get("pink"))) {
                pink = MapStringUtil.resolution(String.valueOf(toMap.get("pink")), " ", "-");
                color = "粉色";
            }
            // 黄色属性
            Map<String, Object> yellow = null;
            if (!"".equals(toMap.get("yellow"))) {
                color = "金色";
                yellow = MapStringUtil.resolution(String.valueOf(toMap.get("yellow")), " ", "-");
            }
            // 绿色属性
            Map<String, Object> green = null;
            if (!"".equals(toMap.get("green"))) {
                green = MapStringUtil.resolution(String.valueOf(toMap.get("green")), " ", "-");
                color = "绿色";
            }

            // 绿色暗属性
            Map<String, Object> green_dark = null;
            if (!"".equals(toMap.get("green_dark"))) {
                green_dark = MapStringUtil.resolution(String.valueOf(toMap.get("green_dark")), " ", "-");
            }


            // 共鸣属性（改造12属性）
            Map<String, Object> resonance = null;
            if (!"".equals(toMap.get("resonance"))) {
                resonance = MapStringUtil.resolution(String.valueOf(toMap.get("resonance")), " ", "-");
            }
            // 改造等级
            Integer remouldLevel = Integer.valueOf(String.valueOf(toMap.get("remouldLevel")));

            // 五行相性
            Integer polarity = Integer.valueOf(String.valueOf(toMap.get("polarity")));

            // 获取装备
            Equip equip = EquipDataPool.getByName(equipName);

            RoleEquip roleEquip = new RoleEquip();
            roleEquip.setType("装备");
            roleEquip.setId(id);
            roleEquip.setName(equipName);
            roleEquip.setRoleId(role.getRoleId());
            roleEquip.setPosition(pos);
            // 添加物品信息
            {
                RoleEquipField roleEquipField = new RoleEquipField();
                roleEquipField.setType((short) 1);

                LinkedHashMap<Short, FiedValue> basicAttrNew = SpringUtils.getBean(EquipService.class).getBasicAttrNew(equip, roleEquip, color, true);
                roleEquipField.setField(basicAttrNew);
                roleEquip.getFields().put(roleEquipField.getType(), roleEquipField);
                RoleEquipField basicAttNew = SpringUtils.getBean(EquipService.class).getBasicAttNew(equip);
                roleEquip.getFields().put(basicAttNew.getType(), basicAttNew);
            }


            //蓝色属性  根据属性条数来添加蓝色属性
            if (blue != null) {
                RoleEquipField roleEquipField = new RoleEquipField();
                roleEquipField.setType((short) 514);
                LinkedHashMap<Short, FiedValue> blue_map = new LinkedHashMap<>();
                for (String key : blue.keySet()) {
                    Integer k = Integer.parseInt(key);
                    Integer v = Integer.parseInt(String.valueOf(blue.get(key)));
                    FiedValue fiedValue = new FiedValue();
                    fiedValue.setType(k);
                    Attribute attribute = attrService.getAttr(k);
                    fiedValue.setVT(attribute.getType());
                    fiedValue.setValue(v);
                    blue_map.put(fiedValue.getType(), fiedValue);
                }
                roleEquipField.setField(blue_map);
                roleEquip.getFields().put(roleEquipField.getType(), roleEquipField);
            }

            // 粉色属性
            if (pink != null) {
                for (String key : pink.keySet()) {
                    Integer k = Integer.parseInt(key);
                    Integer v = Integer.parseInt(String.valueOf(pink.get(key)));
                    RoleEquipField equipField = new RoleEquipField();
                    equipField.setType((short) 770);
                    LinkedHashMap<Short, FiedValue> linkedHashMap = new LinkedHashMap<>();
                    FiedValue fiedValue = new FiedValue();
                    fiedValue.setType(k);
                    Attribute attribute = attrService.getAttr(k);
                    fiedValue.setVT(attribute.getType());
                    fiedValue.setValue(v);
                    linkedHashMap.put(fiedValue.getType(), fiedValue);
                    equipField.setField(linkedHashMap);
                    roleEquip.getFields().put(equipField.getType(), equipField);
                    break;
                }
            }

            // 黄色属性
            if (yellow != null) {
                for (String key : yellow.keySet()) {
                    Integer k = Integer.parseInt(key);
                    Integer v = Integer.parseInt(String.valueOf(yellow.get(key)));
                    RoleEquipField yellow_equip_field = new RoleEquipField();
                    yellow_equip_field.setType((short) 1026);
                    LinkedHashMap<Short, FiedValue> yellow_linked_map = new LinkedHashMap<>();
                    FiedValue fiedValue = new FiedValue();
                    fiedValue.setType(k);
                    Attribute attribute = attrService.getAttr(k);
                    fiedValue.setVT(attribute.getType());
                    fiedValue.setValue(v);
                    yellow_linked_map.put(fiedValue.getType(), fiedValue);
                    yellow_equip_field.setField(yellow_linked_map);
                    roleEquip.getFields().put(yellow_equip_field.getType(), yellow_equip_field);
                    break;
                }
            }

            if (green != null) {
                //  绿色属性
                for (String key : green.keySet()) {
                    Integer k = Integer.parseInt(key);
                    Integer v = Integer.parseInt(String.valueOf(green.get(key)));
                    RoleEquipField green_field = new RoleEquipField();
                    green_field.setType((short) 3074);
                    LinkedHashMap<Short, FiedValue> green_map = new LinkedHashMap<>();
                    FiedValue green_value = new FiedValue();
                    green_value.setType(k);
                    Attribute green_attribute = attrService.getAttr(k);
                    green_value.setVT(green_attribute.getType());
                    green_value.setValue(v);
                    green_map.put(green_value.getType(), green_value);
                    green_field.setField(green_map);
                    roleEquip.getFields().put(green_field.getType(), green_field);
                    break;
                }

                // 绿色暗属性
                if (green_dark != null) {
                    for (String key : green_dark.keySet()) {
                        Integer k = Integer.parseInt(key);
                        Integer v = Integer.parseInt(String.valueOf(green_dark.get(key)));
                        RoleEquipField green_dark_field = new RoleEquipField();
                        green_dark_field.setType((short) 2050);
                        LinkedHashMap<Short, FiedValue> green_dark_map = new LinkedHashMap<>();
                        FiedValue green_dark_value = new FiedValue();
                        green_dark_value.setType(k);
                        Attribute attribute = attrService.getAttr(k);
                        green_dark_value.setVT(attribute.getType());
                        green_dark_value.setValue(v);
                        green_dark_map.put(green_dark_value.getType(), green_dark_value);
                        green_dark_field.setField(green_dark_map);
                        roleEquip.getFields().put(green_dark_field.getType(), green_dark_field);
                    }
                }

                // 相性
                FiedValue fiedValue = roleEquip.getFields().get((short) 1).getField().get((short) 268);
                if (fiedValue != null) {
                    fiedValue.setValue(polarity);
                }
            }

            // 改造
            if (remouldLevel != null) {
                // 改造等级
                roleEquip.alterUpgradeLevel(remouldLevel);
                // 生成改造属性
                SpringUtils.getBean(EquipService.class).addUpgradeField(equip, roleEquip);
            }

            // 共鸣属性
            if (resonance != null) {
                for (String key : resonance.keySet()) {
                    Integer value = Integer.parseInt(String.valueOf(resonance.get(key)));
                    RoleEquipField resonance_field = new RoleEquipField();
                    resonance_field.setType((short) 6914);
                    LinkedHashMap<Short, FiedValue> resonancHashMap = new LinkedHashMap<>();
                    resonance_field.setField(resonancHashMap);
                    resonance_field.getField().put((short) 8, new FiedValue(Integer.parseInt(key), value));
                    roleEquip.getFields().put(resonance_field.getType(), resonance_field);
                    break;
                }
            }

            RespIconCartoon respIconCartoon = new RespIconCartoon();
            respIconCartoon.setName(roleEquip.getName());
            respIconCartoon.setParam(roleEquip.getId() + "");
            MessagePusher.pushMessage(role, respIconCartoon);
            SpringUtils.getBean(EquipService.class).refreshRoleEquip(role, roleEquip);
            // 添加装备到背包
            SpringUtils.getBean(EquipService.class).add(role, roleEquip);
             /**产生一个装备改造等级改变事件*/
            EventDispatcher.getInstance().fireEvent(new EquipUpgradeLevelChangeEvent(EventType.EQUIP_UPGRADE_LEVEL_CHANGE, role, roleEquip, roleEquip.queryUpgradeLevel()));
            return roleEquip;
        } catch (Exception e) {
            return null;
        }
    }

    public RoleEquip sendOrnaments(Role role, short pos, Map<String, Object> toMap){
        // 装备名称
        String equipName = String.valueOf(toMap.get("goodsName"));
        // 获取装备
        Equip equip = EquipDataPool.getByName(equipName);
        Integer num = 1;
        String color = "蓝色";
        if (equip.getReq_level() >= 70){
            color = "金色";
        }
//        return   SpringUtils.getBean(EquipService.class).getJewelry(role, equipName, false, 1, true);

        /**小于80的首饰可以叠加10个*/
        if (equip.getReq_level() < 80) {
            EquipBox equipBox = role.getEquipBox();
            Set<RoleEquip> equips = new HashSet<>(equipBox.getEquips().values());
            for (RoleEquip roleEquip : equips) {
                if (roleEquip == null) {
                    continue;
                }
                if (!roleEquip.getName().equals(equip.getKey_name())) {
                    continue;
                }
                if (roleEquip.getPosition() < 41 || roleEquip.getPosition() > 165) {
                    continue;
                }
                /**物品限制相同的才让叠加*/
                if (roleEquip.isEverLimit()) {
                    num =  bagService.mergeItem(role, roleEquip, 10, 1);
                }
                if (num <= 0) {
                    return roleEquip;
                }
            }
        }


        RoleEquip roleEquip = new RoleEquip();
        roleEquip.setId(mallService.getRoleEquipId());

        roleEquip.setName(equip.getKey_name());
        roleEquip.setRoleId(role.getRoleId());
        roleEquip.setPosition(pos);

        RoleEquipField roleEquipField = new RoleEquipField();
        roleEquipField.setType((short) 1);
        LinkedHashMap<Short, FiedValue> basicAttrNew = SpringUtils.getBean(EquipService.class).getBasicAttrNew(equip, roleEquip, color, true);
        roleEquipField.setField(basicAttrNew);
        roleEquip.getFields().put(roleEquipField.getType(), roleEquipField);
        RoleEquipField basicAttNew = SpringUtils.getBean(EquipService.class).getBasicAttNew(equip);
        roleEquip.getFields().put(basicAttNew.getType(), basicAttNew);

        FiedValue fiedValue = roleEquip.getFields().get((short) 1).getField().get((short) 203);

        fiedValue.setValue(num);
        if (equip.getReq_level() >= 80) {
            roleEquip.setType("高级首饰");
            // 设置属性
            LinkedHashMap<Short, FiedValue> map = new LinkedHashMap<>();
            RoleEquipField equip_field_514 = new RoleEquipField();
            equip_field_514.setType((short) 514);
            Integer arr[] = {45,46,47,48,221};
            for (int i = 0; i < 5; i++) {
                FiedValue fied_514 = new FiedValue();
            fied_514.setType(arr[i]);
            Attribute attribute_514 = attrService.getAttr(arr[i]);
            fied_514.setVT(attribute_514.getType());
            fied_514.setValue(10);
            map.put(fied_514.getType(), fied_514);
            }
            equip_field_514.setField(map);
            roleEquip.getFields().put(equip_field_514.getType(), equip_field_514);

/*            LinkedHashMap<Short, FiedValue> map_770 = new LinkedHashMap<>();
            RoleEquipField equip_field_770 = new RoleEquipField();
            equip_field_770.setType((short) 770);
            FiedValue fied_770 = new FiedValue();
            fied_770.setType(46);
            Attribute attribute_770 = attrService.getAttr(46);
            fied_770.setVT(attribute_770.getType());
            fied_770.setValue(10);
            map_770.put(fied_770.getType(), fied_770);
            equip_field_770.setField(map_770);
            roleEquip.getFields().put(equip_field_770.getType(), equip_field_770);
*/

            LinkedHashMap<Short, FiedValue> map_5378 = new LinkedHashMap<>();
            RoleEquipField equip_field_5378 = new RoleEquipField();
            equip_field_5378.setType((short) 5378);
            for (int i = 0; i < 5; i++) {
                FiedValue fied_5378 = new FiedValue();
                fied_5378.setType(arr[i]);
                Attribute attribute_221 = attrService.getAttr(arr[i]);
                fied_5378.setVT(attribute_221.getType());
                fied_5378.setValue(10);
                map_5378.put(fied_5378.getType(), fied_5378);
            }
            equip_field_5378.setField(map_5378);
            roleEquip.getFields().put(equip_field_5378.getType(), equip_field_5378);
        } else {
            roleEquip.setType("低级首饰");
        }

        SpringUtils.getBean(EquipService.class).add(role, roleEquip);
        SpringUtils.getBean(EquipService.class). refreshRoleEquip(role, roleEquip);
        RespIconCartoon respIconCartoon = new RespIconCartoon();
        respIconCartoon.setName(roleEquip.getName());
        respIconCartoon.setParam(roleEquip.getId() + "");
        MessagePusher.pushMessage(role, respIconCartoon);
        return roleEquip;
    }
	
    /**
     * NPC 按钮兑换装备
     * @param role
     * @param content
     * @return
     */
    public boolean swapNpcEquip(Role role, String content) {
        try {
            String json = JSONObject.toJSONString(content);
            String obj = JSONObject.parseObject(json, String.class);
            List<String> list = JSONObject.parseArray(obj, String.class);
            for (String equip : list) {
                Map<String, Object> toMap = MapStringUtil.getStringToMap(equip);
                short pos = bagService.getPos(role, false);
                if (pos <= 0) {
                    MessagePusher.pushMessage(role, new RespNotifyMiscEx("背包空间不足"));
                    break;
                }
                Integer position = Integer.parseInt(String.valueOf(toMap.get("position")).trim());
                List<String> strings = EquipDataPool.getNamesBy(Integer.parseInt(String.valueOf(toMap.get("level")).trim()), position);

                //----------------------------------根据角色取出装备名称------------------------------------------
                String goodsName;
                Equip equip_;
                Random random = new Random();
                if (position != 1) {
                    do {
                        int index = random.nextInt(strings.size());
                        goodsName = strings.get(index);
                        equip_ = EquipDataPool.getByName(goodsName);
                    } while (equip_.getGender() != role.getGender() && equip_.getGender() != 0);
                } else {
                    do {
                        int index = random.nextInt(strings.size());
                        goodsName = strings.get(index);
                        equip_ = EquipDataPool.getByName(goodsName);
                    } while (equip_.getMenpai() != role.getPolar());
                }
                toMap.put("goodsName", goodsName);
                // 发送装备
                sendEquip(role, pos, toMap);
                // 获取map字段consume 扣取道具/积分
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
