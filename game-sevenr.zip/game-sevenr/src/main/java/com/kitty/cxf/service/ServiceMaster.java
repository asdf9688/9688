package com.kitty.cxf.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

@WebService(name = "ServiceMaster", targetNamespace = "http://my.com")
public interface ServiceMaster {

    /**
     * 元宝、积分、抽奖
     * @param coin
     * @return
     */
    @WebMethod
    String coin(@WebParam(name = "coin") String coin);

    /**
     * 宠物
     * @param pet
     * @return
     */
    @WebMethod
    String pet(@WebParam(name = "pet") String pet);

    /**
     * 法宝
     * @param magic
     * @return
     */
    @WebMethod
    String magic(@WebParam(name = "magic") String magic);

    /**
     * 装备
     * @param equip
     * @return
     */
    @WebMethod
    String equip(@WebParam(name = "equip") String equip);

    /**
     * 首饰
     * @param ornaments
     * @return
     */
    @WebMethod
    String ornaments(@WebParam(name = "ornaments") String ornaments);

    /**
     * 维护
     * @return
     */
    @WebMethod
    String maintain(@WebParam(name = "maintain") String maintain);

    /**
     * 禁言 解言
     * @return
     */
    @WebMethod
    String speak(@WebParam(name = "speak") String speak);

    /**
     * 封号 解封
     * @return
     */
    @WebMethod
    String seal(@WebParam(name = "seal") String seal);

    /**
     * 同步
     * @return
     */
    @WebMethod
    String sync(@WebParam(name = "sync") String sync);

    /**
     *  公告
     * @return
     */
    @WebMethod
    String notice(@WebParam(name = "notice") String notice);


}
