package com.kitty.cxf.service.Impl;

import com.kitty.common.spring.SpringUtils;
import com.kitty.common.start.MyApplicationRunner;
import com.kitty.cxf.common.MapStringUtil;
import com.kitty.cxf.service.ServiceMaster;
import com.kitty.cxf.utlis.Promote;
import com.kitty.game.ServerService;
import com.kitty.game.admin.service.AdminService;
import com.kitty.game.base.service.BagService;
import com.kitty.game.chat.service.ChatService;
import com.kitty.game.config.Server;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.equip.model.RoleEquip;
import com.kitty.game.equip.service.FabaoService;
import com.kitty.game.pet.PetDataPool;
import com.kitty.game.pet.PetType;
import com.kitty.game.pet.bean.PetObject;
import com.kitty.game.pet.model.Pet;
import com.kitty.game.pet.service.PetService;
import com.kitty.game.player.PlayerService;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.PayService;
import com.kitty.game.team.message.RespMsg;
import com.kitty.game.utils.TimeUtil;
import com.kitty.game.welfare.service.RechargeScoreRewardHandler;
import com.kitty.logs.Reason;
import com.kitty.mina.cache.SessionUtils;
import com.kitty.mina.message.MessagePusher;
import com.kitty.mina.session.SessionManager;
import org.apache.mina.core.session.IoSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.jws.WebService;
import java.util.HashMap;
import java.util.Map;

@Component
@WebService(serviceName = "ServiceMaster", targetNamespace = "http://my.com", endpointInterface = "com.kitty.cxf.service.ServiceMaster")
public class ServiceMasterImpl implements ServiceMaster {

    private final String SUCCESS = "0";
    private final String ERROR = "500";

    @Autowired
    BagService bagService;

    @Autowired
    AdminService adminService;

    @Autowired
    private ChatService chatService;

    @Autowired
    private PlayerService playerService;

    @Override
    public String coin(String coin) {
        try {
            if (coin != null) {
                Map<String, Object> toMap = MapStringUtil.getStringToMap(coin);
                String name = String.valueOf(toMap.get("name"));
                int money = Integer.parseInt(String.valueOf(toMap.get("money")));
                Role role = SpringUtils.getRoleService().getOnlinePlayer(name);
                if (role == null) {
                    return result(ERROR, "角色不在线");
                }

                if ("0".equals(toMap.get("type"))) {
                    SpringUtils.getRoleService().addGold(role, money, Reason.GM_ADD_GOLD);
                    SpringUtils.getRoleService().updateRoleGoldAndSiver(role);
                    MessagePusher.pushMessage(role, new RespNotifyMiscEx("获得金元宝：" + money));
                    return result(SUCCESS, "发送金元宝成功");
                } else if ("1".equals(toMap.get("type"))) {

                    SpringUtils.getRoleService().addRechargeScore(role, money);
                    MessagePusher.pushMessage(role, new RespMsg("获得积分" + money));
                    return result(SUCCESS, "发送积分成功");
                } else if ("2".equals(toMap.get("type"))) {
                    SpringUtils.getBean(PayService.class).choujiang(role, money);
                    MessagePusher.pushMessage(role, new RespMsg("获得抽奖次数" + money));
                    return result(SUCCESS, "发送抽奖成功");
                }
            }
            return result(ERROR, "未知操作");
        } catch (Exception e) {
            return result(ERROR, "操作异常");
        }
    }

    @Override
    public String pet(String pet) {
        try {
            if (pet != null) {
                Map<String, Object> toMap = MapStringUtil.getStringToMap(pet);
                String name = String.valueOf(toMap.get("name"));
                String goodsName = String.valueOf(toMap.get("goodsName"));

                Role role = SpringUtils.getRoleService().getOnlinePlayer(name);
                if (role == null) {
                    return result(ERROR, "角色不在线");
                }
                PetObject petObject = PetDataPool.getPetObject(goodsName);
                if (petObject == null) {
                    return result(ERROR, "宠物不存在");
                }

                if (petObject.getPetType() == PetType.ghost ? !SpringUtils.getPetService().isEquippedGhostFull(role) : !SpringUtils.getPetService().isEquippedFull(role)) {
                    petObject.setPolar(String.valueOf(toMap.get("polar")));
                    petObject.setMana(Short.valueOf(String.valueOf(toMap.get("mana"))));
                    petObject.setIcon(Short.valueOf(String.valueOf(toMap.get("icon"))));
                    petObject.setLife(Short.valueOf(String.valueOf(toMap.get("life"))));
                    petObject.setSpeed(Short.valueOf(String.valueOf(toMap.get("speed"))));
                    petObject.setLevel_req(Short.valueOf(String.valueOf(toMap.get("levelReq"))));
                    petObject.setPhy_attack(Short.valueOf(String.valueOf(toMap.get("phyAttack"))));
                    if ("1".equals(toMap.get("type"))) {
                        petObject.setCapacity_level(Byte.valueOf(String.valueOf(toMap.get("degree"))));
                    }
                    Pet pet_ = SpringUtils.getBean(PetService.class).addPet(petObject, role, false);
                    SpringUtils.getBean(PetService.class).loadPet(role, pet_);
                    MessagePusher.pushMessage(role, new RespNotifyMiscEx("获得宠物：" + goodsName));
                    return result(SUCCESS, "发送成功");
                } else {
                    return result(ERROR, "玩家宠物包裹已满");
                }

            }
            return result(ERROR, "未知操作");
        } catch (Exception e) {
            return result(ERROR, "操作异常");
        }
    }

    @Override
    public String magic(String magic) {
        try {
            if (magic != null) {
                Map<String, Object> toMap = MapStringUtil.getStringToMap(magic);
                String name = String.valueOf(toMap.get("name"));
                String goodsName = String.valueOf(toMap.get("magicWeapon"));
                Integer level = Integer.valueOf(String.valueOf(toMap.get("level")));

                Role role = SpringUtils.getRoleService().getOnlinePlayer(name);
                if (role == null) {
                    return result(ERROR, "角色不在线");
                }
                SpringUtils.getBean(FabaoService.class).getArtifact(role, goodsName, Integer.valueOf(String.valueOf(toMap.get("polarity"))), level);
                MessagePusher.pushMessage(role, new RespNotifyMiscEx("获得" + level + "阶法宝：" + goodsName));
                return result(SUCCESS, "发送成功");

            }
            return result(ERROR, "未知操作");
        } catch (Exception e) {
            return result(ERROR, "操作异常");
        }
    }

    @Override
    public String equip(String equip) {
        try {
            if (equip != null) {
                Map<String, Object> toMap = MapStringUtil.getStringToMap(equip);
                String name = String.valueOf(toMap.get("name"));
                Role role = SpringUtils.getRoleService().getOnlinePlayer(name);
                if (role == null) {
                    return result(ERROR, "角色不在线");
                }
                short pos = bagService.getPos(role, false);
                if (pos <= 0) {
                    return result(ERROR, "玩家包裹已满");
                }
                RoleEquip roleEquip = SpringUtils.getBean(Promote.class).sendEquip(role, pos, toMap);
                if (roleEquip != null) {
                    return result(SUCCESS, "发送成功");
                } else {
                    return result(ERROR, "操作失败");
                }
            }
            return result(ERROR, "未知操作");
        } catch (Exception e) {
            return result(ERROR, "操作异常");
        }
    }

    /**
     * 首饰发送
     * @param ornaments
     * @return
     */
    @Override
    public String ornaments(String ornaments) {
        try {
            if (ornaments != null) {
                Map<String, Object> toMap = MapStringUtil.getStringToMap(ornaments);
                String name = String.valueOf(toMap.get("name"));
                Role role = SpringUtils.getRoleService().getOnlinePlayer(name);
                if (role == null) {
                    return result(ERROR, "角色不在线");
                }
                short pos = bagService.getPos(role, false);
                if (pos <= 0) {
                    return result(ERROR, "玩家包裹已满");
                }
                RoleEquip roleEquip = SpringUtils.getBean(Promote.class).sendOrnaments(role, pos, toMap);
                if (roleEquip != null) {
                    return result(SUCCESS, "发送成功");
                } else {
                    return result(ERROR, "操作失败");
                }
            }
            return result(ERROR, "未知操作");
        } catch (Exception e) {
            return result(ERROR, "操作异常");
        }
    }

    /**
     * 维护
     * @return
     */
    @Override
     public String maintain(String maintain){
        try {
            if (maintain != null) {
                Map<String, Object> toMap = MapStringUtil.getStringToMap(maintain);
                Integer type = Integer.valueOf(String.valueOf(toMap.get("type")));
                if (type == 0) {
                    boolean flag = SessionManager.INSTANCE.killAllPlayers();
                    if (flag) {
                        Server server = SpringUtils.getBean(ServerService.class).getServer();
                        server.setState(0);
                        return result(SUCCESS, "操作成功");
                    } else {
                        return result(ERROR, "操作异常");
                    }
                } else {
                    Server server = SpringUtils.getBean(ServerService.class).getServer();
                    server.setState(1);
                    return result(SUCCESS, "操作成功");
                }
            }
            return result(ERROR, "未知操作");
        } catch (Exception e) {
            return result(ERROR, "操作异常");
        }
    }

    /**
     * 禁言 解言
     * @return
     */
    @Override
    public String speak(String speak) {
        try {
            if (speak != null) {
                Map<String, Object> toMap = MapStringUtil.getStringToMap(speak);
                Integer name = Integer.valueOf(String.valueOf(toMap.get("name")));
                Integer type = Integer.valueOf(String.valueOf(toMap.get("type")));
                if (type == 0) {
                    IoSession ioSession = SessionUtils.getSession(name);
                    Role target = SessionUtils.getRoleBySession(ioSession);
                    adminService.shutChannel(target, System.currentTimeMillis() + 24 * 60 * 60 * TimeUtil.ONE_SECOND);
                    MessagePusher.pushMessage(target, new RespNotifyMiscEx("你已被禁言!"));
                    return result(SUCCESS, "操作成功");
                } else {
                    IoSession ioSession = SessionUtils.getSession(name);
                    Role target = SessionUtils.getRoleBySession(ioSession);
                    adminService.shutChannel(target, 0);
                    MessagePusher.pushMessage(target, new RespNotifyMiscEx("你可以畅所欲言了!"));
                    return result(SUCCESS, "操作成功");
                }
            }
            return result(ERROR, "未知操作");
        } catch (Exception e) {
            return result(ERROR, "操作异常");
        }
    }

    /**
     * 封号 解封
     * @return
     */
    @Override
    public String seal(String seal) {
        try {
            if (seal != null) {
                Map<String, Object> toMap = MapStringUtil.getStringToMap(seal);
                Integer name = Integer.valueOf(String.valueOf(toMap.get("name")));
                Integer type = Integer.valueOf(String.valueOf(toMap.get("type")));
                if (type == 0) {
                    IoSession ioSession = SessionUtils.getSession(name);
                    Role target = SessionUtils.getRoleBySession(ioSession);
                    adminService.blockPlayer(target, System.currentTimeMillis() +  24 * 60 * 60 * TimeUtil.ONE_SECOND);
                    MessagePusher.pushMessage(target, new RespNotifyMiscEx("你已被封禁!"));
                    return result(SUCCESS, "操作成功");
                } else {
                    long uid = SpringUtils.getPlayerService().getUidBy(name);
                    Role role = playerService.getPlayerBy(uid);
                    adminService.blockPlayer(role, 0);
                    MessagePusher.pushMessage(role, new RespNotifyMiscEx("你已被封禁!"));
                    return result(SUCCESS, "操作成功");
                }
            }
            return result(ERROR, "未知操作");
        } catch (Exception e) {
            return result(ERROR, "操作异常");
        }
    }

    /**
     * 同步
     * @return
     */
    @Override
    public String sync(String sync) {
        try {
            if (sync != null) {
                Map<String, Object> toMap = MapStringUtil.getStringToMap(sync);
                String type = String.valueOf(toMap.get("type"));
                if ("scorecard".equals(type)) {
                    SpringUtils.getBean(RechargeScoreRewardHandler.class).loadProduct();
                    return result(SUCCESS, "操作成功");
                }else if ("onlinemall".equals(type)){
                    SpringUtils.getBean(MyApplicationRunner.class).initOnlineMall();
                    return result(SUCCESS, "操作成功");
                }
            }
            return result(ERROR, "未知操作");
        } catch (Exception e) {
            return result(ERROR, "操作异常");
        }
    }
    /**
     *  公告
     * @return
     */
    @Override
    public String notice(String notice) {
        try {
            if (notice != null) {
                Map<String, Object> toMap = MapStringUtil.getStringToMap(notice);
                String msg = String.valueOf(toMap.get("msg"));
                chatService.sendAdnotice(msg);
                return result(SUCCESS, "操作成功");
            }
            return result(ERROR, "未知操作");
        } catch (Exception e) {
            return result(ERROR, "操作异常");
        }
    }

    /**
     * @param code
     * @param msg
     * @return
     */
    private String result(String code, String msg) {
        Map<String, Object> map = new HashMap<>();
        map.put("code", code);
        map.put("msg", msg);
        return MapStringUtil.getMapToString(map);
    }
}
