package com.kitty.cxf;

import com.kitty.cxf.common.AuthInterceptor;
import com.kitty.cxf.service.ServiceMaster;
import org.apache.cxf.Bus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.apache.cxf.transport.servlet.CXFServlet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.xml.ws.Endpoint;

/**
 * CXF 配置
 */
@Configuration
public class CxfConfig {

    @Autowired
    private Bus bus;

    @Autowired
    private ServiceMaster serviceMaster;

    @Autowired
    AuthInterceptor authInterceptor;

    //------------------------------------------  默认是services ------------------------------------------
    @Bean
    public ServletRegistrationBean cxfServlet() {
        return new ServletRegistrationBean(new CXFServlet(), "/services/*");
    }


    @Bean
    public Endpoint endpoint() {
        EndpointImpl endpoint = new EndpointImpl(bus, serviceMaster);
        endpoint.publish("/ServiceMaster");
        endpoint.getInInterceptors().add(authInterceptor);

        return endpoint;
    }

}
