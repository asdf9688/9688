package com.kitty;

//import com.kitty.cache.RedisDao;
import com.kitty.common.mysql.DynamicDataSourceRegister;
import com.kitty.common.spring.SpringUtils;
import com.kitty.core.SchedulerManager;
import com.kitty.game.market.MarketService;
import com.kitty.game.merge.MergeService;
import com.kitty.game.player.PlayerService;
import com.kitty.game.zhenbao.ZhenbaoService;
import com.kitty.logs.LoggerUtils;
import com.kitty.mina.session.SessionManager;
import com.kitty.mina.task.TaskHandlerContext;
import org.apache.commons.lang3.time.StopWatch;
import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.Banner;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;
//import org.springframework.boot.Mode;

@SpringBootApplication
@EntityScan(basePackages = "com.kitty")
@MapperScan({"com.kitty.common.dao"})
@EnableTransactionManagement
@EnableScheduling
@EnableAsync
@EnableCaching
@Import({DynamicDataSourceRegister.class})
@ServletComponentScan
public class GameServerStartup extends SpringBootServletInitializer {

    private static Logger logger = LoggerFactory.getLogger(GameServerStartup.class);

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(GameServerStartup.class);
    }

    public static void main(String[] args) {
         int b=9966390;
        int a =((( b & 0xFF00) >> 8) ^ b )& 0xFFFF;


        logger.warn("启动成功，耗時{}毫秒",  a );


     //eturn

        StopWatch stopWatch = new StopWatch();

        stopWatch.start();

        try {

            SpringApplicationBuilder applicationBuilder = new SpringApplicationBuilder(GameServerStartup.class);
            applicationBuilder.bannerMode(Banner.Mode.OFF);/**关闭Banner*/
            applicationBuilder.run(args);

            // id生成器
            SpringUtils.getIdentityService().init();

            SpringUtils.getBean(PlayerService.class).loadAllPlayerProfiles();

    
            SpringUtils.getBean(MarketService.class).init();

            SpringUtils.getBean(ZhenbaoService.class).init();
            SpringUtils.getBean(MergeService.class).init();
//            SpringUtils.getBean(RedisDao.class).flushDB();
        } catch (Exception e) {
            LoggerUtils.error("", e);
            System.exit(-1);
        }

        stopWatch.stop();

        logger.warn("启动成功，耗時{}毫秒", stopWatch.getTime());

        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                onServerShutDown();
            }
        });
    }

    private static void onServerShutDown() {
        logger.error("服务准备关闭");
        try {
            // 踢人下线
            SessionManager.INSTANCE.killAllPlayers();
        } catch (Exception e) {
            LoggerUtils.error("", e);
        }
        TaskHandlerContext.INSTANCE.shutDown();
        SchedulerManager.getInstance().shutDown();

        logger.error("服务准备关闭结束");
    }
}
