package com.kitty.common.dao;

import com.kitty.common.config.SysConfig;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

public interface SysConfigMapper
{
    @Select({ "select * from sys_config where parentKey = #{parentKey}" })
    List<SysConfig> getSysConfigByParentKey(final String parentKey);
    
    @Select({ "<script>select * from sys_config where 1 = 1 <if test='parentKey !=null and parentKey !=&apos;&apos;'>and parentKey=#{parentKey} </if></script>" })
    List<SysConfig> getSysConfigs(final Map<String, String> params);
    
    @Update({ "update sys_config set value = #{value} where id = #{id}" })
    Integer editSys(final Map<String, String> params);
}
