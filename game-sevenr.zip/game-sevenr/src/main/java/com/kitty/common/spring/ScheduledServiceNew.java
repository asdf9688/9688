package com.kitty.common.spring;


import com.kitty.common.start.GameServer;
import com.kitty.game.ServerService;
import com.kitty.game.boss.service.NewBossService;
import com.kitty.game.chat.service.ChatService;
import com.kitty.game.equip.service.ChargeActivityService;
import com.kitty.game.equip.service.EquipService;
import com.kitty.game.fight.service.FightService;
import com.kitty.game.pay.model.PayOrder;
import com.kitty.game.player.PlayerService;
import com.kitty.game.player.model.PlayerProfile;
import com.kitty.game.role.model.Account;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.AccountService;
import com.kitty.game.role.service.RoleService;
import com.kitty.game.utils.TimeUtil;
import com.kitty.game.welfare.service.WelfareService;
import com.kitty.mina.cache.DataCache;
import com.kitty.mina.cache.SessionUtils;

import org.apache.mina.core.session.IoSession;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.json.Json;
import org.nutz.lang.util.NutMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.TimeUnit;

import com.kitty.common.spring.SpringUtils;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;

@Component
public class ScheduledServiceNew {
    private final Logger logger = LoggerFactory.getLogger(ScheduledServiceNew.class);
    @Autowired
    Dao dao;
    @Autowired
    ServerService serverService;
    @Autowired
    EquipService equipService;
    @Autowired
    GameServer gameServer;
    @Autowired
    RoleService roleService;
    @Autowired
    FightService fightService;
    @Autowired
    NewBossService bossService;
    @Autowired
    AccountService accountService;
    @Autowired
    PlayerService playerService;
    @Autowired
    ChatService chatService;
    @Autowired
    ChargeActivityService chargeActivityService;


    @Scheduled(cron = "0 0 5 * * ?")
    public void dailyFiveReset() {
        /*刷新道行盒子*/
        ArrayList<Byte> arrayList = new ArrayList<>(DataCache.RECHARGE_REWARD_HISTORYS.keySet());
        for (byte bb: arrayList){
            DataCache.RECHARGE_REWARD_HISTORYS.put(bb, (short) 0);
        }
    }

    @Scheduled(cron = "0 0/1 * * * ?")
    public void randomActivity() {
        WelfareService welfareService = SpringUtils.getBean(WelfareService.class);
        String content = welfareService.getRandomData().getData();
        NutMap nutMap = Json.fromJson(NutMap.class, content);
        if (nutMap.size() <= 0) {
            return;
        }
        if (nutMap.getInt("end", 0) == 1) {
            return;
        }
        content = nutMap.getString("content");
        /* @@@randomChoujiang=648##3##16:00##16:15*/
        String[] strings = content.split("##");
        String start = TimeUtil.formatDate(new Date());
        String end = start + " " + strings[3];
        start = start + " " + strings[2];
        Date starttime = TimeUtil.parse(start, "yyyy-MM-dd HH:mm");
        Date endtime = TimeUtil.parse(end, "yyyy-MM-dd HH:mm");
        if (new Date().before(endtime)) {
            return;
        }
        List<PayOrder> list = dao.query(PayOrder.class,
                Cnd.where("createTime", ">=", starttime).and("createTime", "<=", endtime).and("money", ">=", Integer.parseInt(strings[0])));
        List<PayOrder> results = new ArrayList<>();
        int size = Integer.parseInt(strings[1]);
        if (size >= list.size()) {
            Set<String> set = new HashSet<>();
            for (PayOrder payOrder:list){
                if (set.contains(payOrder.getOderId())) {
                    continue;
                }
                set.add(payOrder.getOderId());
                results.add(payOrder);
            }
        } else {
            Set<String> set1 = new HashSet<>();
            Set<Integer> set = new HashSet<>();
            while (true) {
                if (results.size() >= size) {
                    break;
                }
                int index = new Random().nextInt(list.size());
                if (set.contains(index)) {
                    continue;
                }
                if (set1.contains(list.get(index).getOderId())) {
                    continue;
                }
                set1.add(list.get(index).getOderId());
                set.add(index);
                results.add(list.get(index));
            }
        }
        StringBuilder stringBuilder = new StringBuilder();
        for (PayOrder payOrder : results) {
            long uid = Long.parseLong(payOrder.getOderId());
            Role role = playerService.getPlayerBy(uid);
            if (role != null) {
                stringBuilder.append(role.getName());
                stringBuilder.append("，");
            }
        }
        nutMap.setv("end", 1);
        welfareService.getRandomData().setData(Json.toJson(nutMap));
        dao.insertOrUpdate(welfareService.getRandomData());
        String notice = stringBuilder.toString();
        notice = notice.substring(0, notice.length() - 1);
        String msg = "本次充值活动时间为#R" + start + "到" + end + "#n，中奖名单为：#R" + notice+"#n，一小时内发放奖品，请保证背包有足够的空余位置，否则发放失败，不予补偿。";
        for (int i=1;i<=4;i++){
            serverService.getScheduledExecutorService().schedule(new Runnable() {
                @Override
                public void run() {
                    Account account = dao.fetch(Account.class, Cnd.where("privilege", "=", 200));
                    if (account == null){
                        account = dao.fetch(Account.class, Cnd.where("privilege", "=", 1000));
                    }
                    if (account != null) {
                        List<PlayerProfile> list = playerService.getPlayersBy(account.getId());
                        if (list != null && list.size() > 0) {
                            long uid = playerService.getUidBy(list.get(0).getRoleId());
                            Role role = playerService.getPlayerBy(uid);
                            if (role != null) {
                                chatService.sendLaba(msg, role);
                                return;
                            }
                        }
                    }
                    chatService.sendAdnotice(msg);
                }
            },i*60, TimeUnit.SECONDS);
        }

    }

    @Scheduled(cron = "0 0/59 * * * ?")
    public void randomActivity1() {
        WelfareService welfareService = SpringUtils.getBean(WelfareService.class);
        String content = welfareService.getRandomData().getData();
        NutMap nutMap = Json.fromJson(NutMap.class, content);
        if (nutMap.size() <= 0) {
            return;
        }
        if (nutMap.getInt("end", 0) == 1) {
            return;
        }
        content = nutMap.getString("content");
        /* 随机抽奖=648##3##20:30##21:30*/
        String[] strings = content.split("##");
        String start = TimeUtil.formatDate(new Date());
        String end = start + " " + strings[3];
        start = start + " " + strings[2];
        Date starttime = TimeUtil.parse(start, "yyyy-MM-dd HH:mm");
        Date endtime = TimeUtil.parse(end, "yyyy-MM-dd HH:mm");
        if (new Date().after(endtime)) {
            return;
        }
        /* 开启随机抽奖活动：时间为xx开始-xx结束 凡事充值XX金额.本区随机抽取X名玩家指定奖品.单笔充值XX金额，中奖几率越高.活动结束公布中奖名单*/
        String msg = "开启随机抽奖活动：时间为#R" + start + "开始-" + end + "结束#n，凡事充值#R"+strings[0]+"以上的玩家#n，本区随机抽取#R"
                + strings[1] + "名#n玩家获得指定奖品，单笔充值#R"+strings[0]+"次数越多#n，中奖几率越高，活动结束后公布中奖名单。";
        Account account = dao.fetch(Account.class, Cnd.where("privilege", "=", 200));
        if (account == null){
            account = dao.fetch(Account.class, Cnd.where("privilege", "=", 1000));
        }
        if (account != null) {
            List<PlayerProfile> list = playerService.getPlayersBy(account.getId());
            if (list != null && list.size() > 0) {
                long uid = playerService.getUidBy(list.get(0).getRoleId());
                Role role = playerService.getPlayerBy(uid);
                if (role != null) {
                    chatService.sendLaba(msg, role);
                    return;
                }
            }
        }
        chatService.sendAdnotice(msg);
    }



    @Scheduled(cron = "0 0/1 * * * ?")
    public void randomLeijiActivity() {
        WelfareService welfareService = SpringUtils.getBean(WelfareService.class);
        String content = welfareService.getRandomDataLeiji().getData();
        NutMap nutMap = Json.fromJson(NutMap.class, content);
        if (nutMap.size() <= 0) {
            return;
        }
        if (nutMap.getInt("end", 0) == 1) {
            return;
        }
        content = nutMap.getString("content");
        /* @@@leijiChoujiang==58##1##13:00##23:59*/
        String[] strings = content.split("##");
        String start = TimeUtil.formatDate(new Date());
        String end = start + " " + strings[3];
        start = start + " " + strings[2];
        Date starttime = TimeUtil.parse(start, "yyyy-MM-dd HH:mm");
        Date endtime = TimeUtil.parse(end, "yyyy-MM-dd HH:mm");
        if (new Date().before(endtime)) {
            return;
        }
        int minMoney = Integer.parseInt(strings[0]);
        List<PayOrder> list = dao.query(PayOrder.class,
                Cnd.where("createTime", ">=", starttime).and("createTime", "<=", endtime).and("money", ">=", minMoney));
        HashMap<String,Integer> uid_leiji = new HashMap<>();
        for (PayOrder payOrder : list){
            if (uid_leiji.get(payOrder.getOderId()) == null){
                uid_leiji.put(payOrder.getOderId(),payOrder.getMoney());
            }else {
                uid_leiji.put(payOrder.getOderId(),uid_leiji.get(payOrder.getOderId())+payOrder.getMoney());
            }
        }
        int size = Integer.parseInt(strings[1]);
        logger.error("累计充值结果数据=={}",Json.toJson(uid_leiji));
        List<String> results = new ArrayList<>();
        if (size >= uid_leiji.size()){
            results.addAll(uid_leiji.keySet());
        }else {
            ArrayList<String> uids = new ArrayList<>();
            for (String uid: uid_leiji.keySet()){
                int money = uid_leiji.get(uid);
                int count = money/minMoney;
                for (int i=0;i<count;i++){
                    uids.add(uid);
                }
            }
            logger.error("最后结果=={}",Json.toJson(uids));
            while (true){
                if (results.size() >= size){
                    break;
                }
                int index = new Random().nextInt(uids.size());
                if (results.contains(uids.get(index))){
                    continue;
                }
                results.add(uids.get(index));
            }

        }
        StringBuilder stringBuilder = new StringBuilder();
        for (String uidstr : results) {
            long uid = Long.parseLong(uidstr);
            Role role = playerService.getPlayerBy(uid);
            if (role != null) {
                stringBuilder.append(role.getName());
                stringBuilder.append("，");
            }
        }
        nutMap.setv("end", 1);
        welfareService.getRandomDataLeiji().setData(Json.toJson(nutMap));
        dao.insertOrUpdate(welfareService.getRandomDataLeiji());
        String notice = stringBuilder.toString();
        notice = notice.substring(0, notice.length() - 1);
        String msg = "本次#R累计充值活动#n时间为#R" + start + "到" + end + "#n，中奖名单为：#R" + notice+"#n，一小时内发放奖品，请保证背包有足够的#R空余位置#n，否则发放失败，不予补偿。";
        for (int i=1;i<=4;i++){
            serverService.getScheduledExecutorService().schedule(new Runnable() {
                @Override
                public void run() {
                    Account account = dao.fetch(Account.class, Cnd.where("privilege", "=", 200));
                    if (account == null){
                        account = dao.fetch(Account.class, Cnd.where("privilege", "=", 1000));
                    }
                    if (account != null) {
                        List<PlayerProfile> list = playerService.getPlayersBy(account.getId());
                        if (list != null && list.size() > 0) {
                            long uid = playerService.getUidBy(list.get(0).getRoleId());
                            Role role = playerService.getPlayerBy(uid);
                            if (role != null) {
                                chatService.sendLaba(msg, role);
                                return;
                            }
                        }
                    }
                    chatService.sendAdnotice(msg);
                }
            },i*60, TimeUnit.SECONDS);
        }

    }

    @Scheduled(cron = "0 0/59 * * * ?")
    public void randomLeijiActivity1() {
        WelfareService welfareService = SpringUtils.getBean(WelfareService.class);
        String content = welfareService.getRandomDataLeiji().getData();
        NutMap nutMap = Json.fromJson(NutMap.class, content);
        if (nutMap.size() <= 0) {
            return;
        }
        if (nutMap.getInt("end", 0) == 1) {
            return;
        }
        content = nutMap.getString("content");
        /* 随机抽奖=648##3##20:30##21:30*/
        String[] strings = content.split("##");
        String start = TimeUtil.formatDate(new Date());
        String end = start + " " + strings[3];
        start = start + " " + strings[2];
        Date starttime = TimeUtil.parse(start, "yyyy-MM-dd HH:mm");
        Date endtime = TimeUtil.parse(end, "yyyy-MM-dd HH:mm");
        if (new Date().after(endtime)) {
            return;
        }
        /* 开启随机抽奖活动：时间为xx开始-xx结束 凡事充值XX金额.本区随机抽取X名玩家指定奖品.单笔充值XX金额，中奖几率越高.活动结束公布中奖名单*/
        String msg = "开启随机抽奖活动：时间为#R" + start + "开始-" + end + "结束#n，凡事充值#R"+strings[0]+"以上的玩家#n，本区随机抽取#R"
                + strings[1] + "名#n玩家获得指定奖品，指定时间内累计充值为#R"+strings[0]+"的倍数#n越多，中奖几率越高，活动结束后公布中奖名单。";
        Account account = dao.fetch(Account.class, Cnd.where("privilege", "=", 200));
        if (account == null){
            account = dao.fetch(Account.class, Cnd.where("privilege", "=", 1000));
        }
        if (account != null) {
            List<PlayerProfile> list = playerService.getPlayersBy(account.getId());
            if (list != null && list.size() > 0) {
                long uid = playerService.getUidBy(list.get(0).getRoleId());
                Role role = playerService.getPlayerBy(uid);
                if (role != null) {
                    chatService.sendLaba(msg, role);
                    return;
                }
            }
        }
        chatService.sendAdnotice(msg);
    }
}
