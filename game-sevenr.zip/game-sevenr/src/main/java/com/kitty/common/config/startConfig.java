package com.kitty.common.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component("startConfig")
@ConfigurationProperties(prefix = "start-config")
public class startConfig
{
    private Integer lineNum;
    private boolean isOpenJs;
    private boolean cmdDebug;
    private boolean moveDebug;
    private boolean lenDebug;
    private boolean msgDebug;
    private boolean getDebug;
    
    public Integer getLineNum() {
        return this.lineNum;
    }
    
    public boolean isOpenJs() {
        return this.isOpenJs;
    }
    
    public boolean isCmdDebug() {
        return this.cmdDebug;
    }
    
    public boolean isMoveDebug() {
        return this.moveDebug;
    }
    
    public boolean isLenDebug() {
        return this.lenDebug;
    }
    
    public boolean isMsgDebug() {
        return this.msgDebug;
    }
    
    public boolean isGetDebug() {
        return this.getDebug;
    }
    
    public void setLineNum(final Integer lineNum) {
        this.lineNum = lineNum;
    }
    
    public void setOpenJs(final boolean isOpenJs) {
        this.isOpenJs = isOpenJs;
    }
    
    public void setCmdDebug(final boolean cmdDebug) {
        this.cmdDebug = cmdDebug;
    }
    
    public void setMoveDebug(final boolean moveDebug) {
        this.moveDebug = moveDebug;
    }
    
    public void setLenDebug(final boolean lenDebug) {
        this.lenDebug = lenDebug;
    }
    
    public void setMsgDebug(final boolean msgDebug) {
        this.msgDebug = msgDebug;
    }
    
    public void setGetDebug(final boolean getDebug) {
        this.getDebug = getDebug;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof startConfig)) {
            return false;
        }
        final startConfig other = (startConfig)o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$lineNum = this.getLineNum();
        final Object other$lineNum = other.getLineNum();
        if (this$lineNum == null) {
            if (other$lineNum == null) {
                return this.isOpenJs() == other.isOpenJs() && this.isCmdDebug() == other.isCmdDebug() && this.isMoveDebug() == other.isMoveDebug() && this.isLenDebug() == other.isLenDebug() && this.isMsgDebug() == other.isMsgDebug() && this.isGetDebug() == other.isGetDebug();
            }
        }
        else if (this$lineNum.equals(other$lineNum)) {
            return this.isOpenJs() == other.isOpenJs() && this.isCmdDebug() == other.isCmdDebug() && this.isMoveDebug() == other.isMoveDebug() && this.isLenDebug() == other.isLenDebug() && this.isMsgDebug() == other.isMsgDebug() && this.isGetDebug() == other.isGetDebug();
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof startConfig;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $lineNum = this.getLineNum();
        result = result * 59 + (($lineNum == null) ? 43 : $lineNum.hashCode());
        result = result * 59 + (this.isOpenJs() ? 79 : 97);
        result = result * 59 + (this.isCmdDebug() ? 79 : 97);
        result = result * 59 + (this.isMoveDebug() ? 79 : 97);
        result = result * 59 + (this.isLenDebug() ? 79 : 97);
        result = result * 59 + (this.isMsgDebug() ? 79 : 97);
        result = result * 59 + (this.isGetDebug() ? 79 : 97);
        return result;
    }
    
    @Override
    public String toString() {
        return "startConfig(lineNum=" + this.getLineNum() + ", isOpenJs=" + this.isOpenJs() + ", cmdDebug=" + this.isCmdDebug() + ", moveDebug=" + this.isMoveDebug() + ", lenDebug=" + this.isLenDebug() + ", msgDebug=" + this.isMsgDebug() + ", getDebug=" + this.isGetDebug() + ")";
    }
}
