package com.kitty.common.db;


import com.kitty.game.party.model.Party;
import org.nutz.dao.Cnd;
import org.nutz.dao.Condition;
import org.nutz.dao.Dao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

/**缓存Service
 *
 * */
@Service
public class CacheService {

    @Autowired
    Dao dao;

    @Cacheable(value = "party",key = "#partyId")
    public Party getPartyBy(long partyId){
        Party party =dao.fetch(Party.class, Cnd.where("id","=",partyId));
        return party;
    }

    @Cacheable(value = "party", key = "#party.id")
    public Party addNewParty(Party party) {
        return party;
    }
}
