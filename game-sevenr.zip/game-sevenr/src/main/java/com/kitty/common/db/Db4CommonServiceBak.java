//package com.kitty.common.db;
//
//
//import com.kitty.common.thread.NamedThreadFactory;
//import com.kitty.common.utils.BlockingUniqueQueue;
//import com.kitty.logs.LoggerUtils;
//import org.nutz.dao.Dao;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import javax.annotation.PostConstruct;
//import javax.annotation.PreDestroy;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.concurrent.BlockingQueue;
//
///**
// * 公共数据(排查玩家数据)持久化队列
// */
//@Component
//public class Db4CommonServiceBak {
//
//
//    private static volatile Db4CommonServiceBak instance;
//    @Autowired
//    private Dao dao;
//
//    public static Db4CommonServiceBak getInstance() {
//        return instance;
//    }
//    private final List<Db4CommonServiceBak.Worker> workerPool = new ArrayList<>();
//    private long count =0;
//    /**
//     * start consumer thread
//     */
//    @PostConstruct
//    private void init() {
////        new NamedThreadFactory("db-common-save-service").newThread(new Worker()).start();
//        int size = 8;
//        for (int i = 1; i <= size; i++) {
//            Db4CommonServiceBak.Worker worker = new Db4CommonServiceBak.Worker();
//            workerPool.add(worker);
//            new NamedThreadFactory("db-common-save-service_" + i).newThread(worker).start();
//        }
//        instance = this;
//    }
//
//
//
//    public void add2Queue(BaseEntity entity) {
//        if (entity == null) {
//            return;
//        }
//        this.count++;
//        int index = (int) (this.count%workerPool.size());
//        workerPool.get(index).add(entity);
//    }
//
//    private class Worker implements Runnable {
//        private BlockingQueue<BaseEntity> queue = new BlockingUniqueQueue<>();
//
//
//        public void add(BaseEntity entity){
//            this.queue.add(entity);
//        }
//        @Override
//        public void run() {
//            while (true) {
//                if (queue.size() <= 0){
//                    continue;
//                }
//                BaseEntity entity = null;
//                try {
//                    entity = queue.take();
//                    saveToDb(entity);
//                } catch (Exception e) {
//                    LoggerUtils.error("", e);
//                    // 有可能是并发抛错，重新放入队列
//                    add2Queue(entity);
//                }
//            }
//        }
//    }
//
//    /**
//     * 数据真正持久化
//     *
//     * @param entity
//     */
//    private void saveToDb(BaseEntity entity) {
//        entity.doBeforeSave();
//        if (entity.isDelete()) {
//            dao.delete(entity);
//        } else {
//            dao.insertOrUpdate(entity);
//        }
//    }
//
//    @PreDestroy
//    public void shutDown() {
////        run.getAndSet(false);
////        for (; ;) {
////            if (! queue.isEmpty()) {
////                saveAllBeforeShutDown();
////            } else {
////                break;
////            }
////        }
//        LoggerUtils.error("[Db4Common] 执行全部命令后关闭");
//    }
//
////    private void saveAllBeforeShutDown() {
////        while (!queue.isEmpty()) {
////            Iterator<BaseEntity> it = queue.iterator();
////            while (it.hasNext()) {
////                BaseEntity next = it.next();
////                it.remove();
////                saveToDb(next);
////            }
////        }
////    }
//
//}