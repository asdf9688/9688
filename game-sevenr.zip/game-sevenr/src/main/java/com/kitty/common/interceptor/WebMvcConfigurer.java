package com.kitty.common.interceptor;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import org.springframework.web.servlet.HandlerInterceptor;
import com.kitty.common.interceptor.MyInterceptor;

@Configuration
public class WebMvcConfigurer extends WebMvcConfigurerAdapter {

    /*增加拦截器*/
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new MyInterceptor())    /*指定拦截器类*/
                .addPathPatterns("/*");        /*指定该类拦截的url*/
    }

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**").allowedHeaders("*")
                .allowedMethods("*")
                .allowedOrigins("*")
                .allowCredentials(true);
    }
}
