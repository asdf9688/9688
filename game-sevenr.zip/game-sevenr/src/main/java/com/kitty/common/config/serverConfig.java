package com.kitty.common.config;

public interface serverConfig
{
    public static final String SERVER = "http://192.168.1.101";
}
