package com.kitty.common.db;

import java.io.Serializable;

@SuppressWarnings("serial")
public abstract class BaseEntity<PK extends Comparable<PK> & Serializable> implements Serializable {

    protected boolean delete = false;

    /**
     * entity id
     * @return
     */
    public abstract PK getId() ;

    /**
     * init hook
     */
    public void doAfterInit() {}

    /**
     * save hook
     */
    public void doBeforeSave() {}

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + getId().hashCode();
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        BaseEntity other = (BaseEntity) obj;
        if (getId() != other.getId()) {
            return false;
        }
        return true;
    }

    public boolean isDelete() {
        return delete;
    }

    public void setDelete(boolean delete) {
        this.delete = delete;
    }

}