package com.kitty.common.start;

import com.kitty.common.dao.SysConfigMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

@Service
public class GameData
{
    public static GameData that;

    @Autowired
    public SysConfigMapper sysConfig;

    @PostConstruct
    public void initAfter() {
        GameData.that = this;
    }
}
