package com.kitty.common.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component("rewardConfig")
@ConfigurationProperties(prefix = "reward-config")
@Data
public class rewardConfig
{
    private double shimen_timesJingyan;
    private int tttTimes;
    private int fbTimes;
    private double timesJingyan;
    private double timesDaohang;
    private String tttReward;
    private String tttgtReward;
    private String tttSuccessReward;
    private String fubenReward;
    private String bossReward;
    private String qishaReward;
    private String shidao_one_reward;
    private String shidao_two_reward;
    private String shidao_three_reward;
    private String lc_charge_text;
    private String one_charge_reward;
    private String charge_98_reward;
    private String charge_328_reward;
    private String charge_648_reward;
    private String charge_1000_reward;
    private String charge_2000_reward;
    private String charge_3000_reward;
    private String charge_5000_reward;
    private String charge_10000_reward;
    private int charge_addCjNum;
    private String wabao_tedeng_reward;
    private String wabao_yideng_reward;
    private String wabao_erdeng_reward;
    private String wabao_sandeng_reward;
    private double wabao_te_gailv;
    private double wabao_yi_gailv;
    private double wabao_er_gailv;
    private double wabao_san_gailv;
    private int yaowang_max_num;
    private String sg_reward;
    private int sg_exp_ten;
    private double sg_out_gailv;
    private String yuanmo_reward;
    private String duihuanchenghao;
    private String duihuanjingguai;
    private int qiangsha_increase_nuqizhi;
    private int qiangsha_reduce_nuqizhi;
    private int qiangsha_taopao_jifen;
    private int qiangsha_baoshi_reduce;
    private String zhashenlong_xiaobailong;
    private String zhashenlong_honglong;


    private String leitai_2000_reward;
    private String leitai_4000_reward;
    private String leitai_7000_reward;
    private String leitai_13000_reward;
    private String leitai_11_100_reward;
    private String leitai_1_10_reward;

    private int leitai_jifen;

    private int leitai_pk_reduce_jifen;
    private int leitai_pk_increase_jifen;

    private int TodayChallengeNum;

    private int yuanyqiehuan;

    private String moren_chenhao;

    private int jingyanbaishu;

    private int qiannengbeishu;

    private int daohangbeishu;

    private int sg_mial_date;

    private int diyibo_haidao_num;

    private int dierbo_haidao_num;

    private int disanbo_haidao_num;

    private int dierbo_haidao_date;

    private int disanbo_haidao_date;

    private int haidao_duiwu_renshu;


    private String haidao_60_jiangli;
    private String haidao_70_jiangli;
    private String haidao_80_jiangli;
    private String haidao_90_jiangli;
    private String haidao_100_jiangli;
    private String haidao_110_jiangli;
    private String haidao_120_jiangli;
    private String haidao_130_jiangli;
    private String haidao_140_jiangli;


    private int haidao_siw_chengfa_jingy;
    private int haidao_siw_chengfa_daoh;
    private int haidao_siw_chengfa_qiann;


    private String jiangli_qiegao;
/*
* 仙魔
*/
    private int XIANMO_XIAOHAO;

    public int getXIANMO_XIAOHAO() {
        return XIANMO_XIAOHAO;
    }

    public void setXIANMO_XIAOHAO(int XIANMO_XIAOHAO) {
        this.XIANMO_XIAOHAO = XIANMO_XIAOHAO;
    }

    public int getTttTimes() {
        return this.tttTimes;
    }

    public int getFbTimes() {
        return this.fbTimes;
    }

    public double getTimesJingyan() {
        return this.timesJingyan;
    }

    public double getTimesDaohang() {
        return this.timesDaohang;
    }

    public String getTttReward() {
        return this.tttReward;
    }

    public String getTttgtReward() {
        return this.tttgtReward;
    }

    public String getTttSuccessReward() {
        return this.tttSuccessReward;
    }

    public String getFubenReward() {
        return this.fubenReward;
    }

    public String getBossReward() {
        return this.bossReward;
    }

    public String getQishaReward() {
        return this.qishaReward;
    }

    public double getShimen_timesJingyan() {
        return this.shimen_timesJingyan;
    }

    public String getShidao_one_reward() {
        return this.shidao_one_reward;
    }

    public String getShidao_two_reward() {
        return this.shidao_two_reward;
    }

    public String getShidao_three_reward() {
        return this.shidao_three_reward;
    }

    public String getLc_charge_text() {
        return this.lc_charge_text;
    }

    public String getOne_charge_reward() {
        return this.one_charge_reward;
    }

    public String getCharge_98_reward() {
        return this.charge_98_reward;
    }

    public String getCharge_328_reward() {
        return this.charge_328_reward;
    }

    public String getCharge_648_reward() {
        return this.charge_648_reward;
    }

    public String getCharge_1000_reward() {
        return this.charge_1000_reward;
    }

    public String getCharge_2000_reward() {
        return this.charge_2000_reward;
    }

    public String getCharge_3000_reward() {
        return this.charge_3000_reward;
    }

    public String getCharge_5000_reward() {
        return this.charge_5000_reward;
    }

    public int getCharge_addCjNum() {
        return this.charge_addCjNum;
    }

    public String getWabao_tedeng_reward() {
        return this.wabao_tedeng_reward;
    }

    public String getWabao_yideng_reward() {
        return this.wabao_yideng_reward;
    }

    public String getWabao_erdeng_reward() {
        return this.wabao_erdeng_reward;
    }

    public String getWabao_sandeng_reward() {
        return this.wabao_sandeng_reward;
    }

    public double getWabao_te_gailv() {
        return this.wabao_te_gailv;
    }

    public double getWabao_yi_gailv() {
        return this.wabao_yi_gailv;
    }

    public double getWabao_er_gailv() {
        return this.wabao_er_gailv;
    }

    public double getWabao_san_gailv() {
        return this.wabao_san_gailv;
    }

    public int getYaowang_max_num() {
        return this.yaowang_max_num;
    }

    public String getSg_reward() {
        return this.sg_reward;
    }

    public int getSg_exp_ten() {
        return this.sg_exp_ten;
    }

    public double getSg_out_gailv() {
        return this.sg_out_gailv;
    }

    public String getYuanmo_reward() {
        return this.yuanmo_reward;
    }

    public void setTttTimes(final int tttTimes) {
        this.tttTimes = tttTimes;
    }

    public void setFbTimes(final int fbTimes) {
        this.fbTimes = fbTimes;
    }

    public void setTimesJingyan(final double timesJingyan) {
        this.timesJingyan = timesJingyan;
    }

    public void setTimesDaohang(final double timesDaohang) {
        this.timesDaohang = timesDaohang;
    }

    public void setTttReward(final String tttReward) {
        this.tttReward = tttReward;
    }

    public void setTttgtReward(final String tttgtReward) {
        this.tttgtReward = tttgtReward;
    }

    public void setTttSuccessReward(final String tttSuccessReward) {
        this.tttSuccessReward = tttSuccessReward;
    }

    public void setFubenReward(final String fubenReward) {
        this.fubenReward = fubenReward;
    }

    public void setBossReward(final String bossReward) {
        this.bossReward = bossReward;
    }

    public void setQishaReward(final String qishaReward) {
        this.qishaReward = qishaReward;
    }

    public void setShimen_timesJingyan(final double shimen_timesJingyan) {
        this.shimen_timesJingyan = shimen_timesJingyan;
    }

    public void setShidao_one_reward(final String shidao_one_reward) {
        this.shidao_one_reward = shidao_one_reward;
    }

    public void setShidao_two_reward(final String shidao_two_reward) {
        this.shidao_two_reward = shidao_two_reward;
    }

    public void setShidao_three_reward(final String shidao_three_reward) {
        this.shidao_three_reward = shidao_three_reward;
    }

    public void setLc_charge_text(final String lc_charge_text) {
        this.lc_charge_text = lc_charge_text;
    }

    public void setOne_charge_reward(final String one_charge_reward) {
        this.one_charge_reward = one_charge_reward;
    }

    public void setCharge_98_reward(final String charge_98_reward) {
        this.charge_98_reward = charge_98_reward;
    }

    public void setCharge_328_reward(final String charge_328_reward) {
        this.charge_328_reward = charge_328_reward;
    }

    public void setCharge_648_reward(final String charge_648_reward) {
        this.charge_648_reward = charge_648_reward;
    }

    public void setCharge_1000_reward(final String charge_1000_reward) {
        this.charge_1000_reward = charge_1000_reward;
    }

    public void setCharge_2000_reward(final String charge_2000_reward) {
        this.charge_2000_reward = charge_2000_reward;
    }

    public void setCharge_3000_reward(final String charge_3000_reward) {
        this.charge_3000_reward = charge_3000_reward;
    }

    public void setCharge_5000_reward(final String charge_5000_reward) {
        this.charge_5000_reward = charge_5000_reward;
    }

    public void setCharge_addCjNum(final int charge_addCjNum) {
        this.charge_addCjNum = charge_addCjNum;
    }

    public void setWabao_tedeng_reward(final String wabao_tedeng_reward) {
        this.wabao_tedeng_reward = wabao_tedeng_reward;
    }

    public void setWabao_yideng_reward(final String wabao_yideng_reward) {
        this.wabao_yideng_reward = wabao_yideng_reward;
    }

    public void setWabao_erdeng_reward(final String wabao_erdeng_reward) {
        this.wabao_erdeng_reward = wabao_erdeng_reward;
    }

    public void setWabao_sandeng_reward(final String wabao_sandeng_reward) {
        this.wabao_sandeng_reward = wabao_sandeng_reward;
    }

    public void setWabao_te_gailv(final double wabao_te_gailv) {
        this.wabao_te_gailv = wabao_te_gailv;
    }

    public void setWabao_yi_gailv(final double wabao_yi_gailv) {
        this.wabao_yi_gailv = wabao_yi_gailv;
    }

    public void setWabao_er_gailv(final double wabao_er_gailv) {
        this.wabao_er_gailv = wabao_er_gailv;
    }

    public void setWabao_san_gailv(final double wabao_san_gailv) {
        this.wabao_san_gailv = wabao_san_gailv;
    }

    public void setYaowang_max_num(final int yaowang_max_num) {
        this.yaowang_max_num = yaowang_max_num;
    }

    public void setSg_reward(final String sg_reward) {
        this.sg_reward = sg_reward;
    }

    public void setSg_exp_ten(final int sg_exp_ten) {
        this.sg_exp_ten = sg_exp_ten;
    }

    public void setSg_out_gailv(final double sg_out_gailv) {
        this.sg_out_gailv = sg_out_gailv;
    }

    public void setYuanmo_reward(final String yuanmo_reward) {
        this.yuanmo_reward = yuanmo_reward;
    }

    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof rewardConfig)) {
            return false;
        }
        final rewardConfig other = (rewardConfig)o;
        if (!other.canEqual(this)) {
            return false;
        }
        if (this.getTttTimes() != other.getTttTimes()) {
            return false;
        }
        if (this.getFbTimes() != other.getFbTimes()) {
            return false;
        }
        if (Double.compare(this.getTimesJingyan(), other.getTimesJingyan()) != 0) {
            return false;
        }
        if (Double.compare(this.getTimesDaohang(), other.getTimesDaohang()) != 0) {
            return false;
        }
        final Object this$tttReward = this.getTttReward();
        final Object other$tttReward = other.getTttReward();
        Label_0123: {
            if (this$tttReward == null) {
                if (other$tttReward == null) {
                    break Label_0123;
                }
            }
            else if (this$tttReward.equals(other$tttReward)) {
                break Label_0123;
            }
            return false;
        }
        final Object this$tttgtReward = this.getTttgtReward();
        final Object other$tttgtReward = other.getTttgtReward();
        Label_0160: {
            if (this$tttgtReward == null) {
                if (other$tttgtReward == null) {
                    break Label_0160;
                }
            }
            else if (this$tttgtReward.equals(other$tttgtReward)) {
                break Label_0160;
            }
            return false;
        }
        final Object this$tttSuccessReward = this.getTttSuccessReward();
        final Object other$tttSuccessReward = other.getTttSuccessReward();
        Label_0197: {
            if (this$tttSuccessReward == null) {
                if (other$tttSuccessReward == null) {
                    break Label_0197;
                }
            }
            else if (this$tttSuccessReward.equals(other$tttSuccessReward)) {
                break Label_0197;
            }
            return false;
        }
        final Object this$fubenReward = this.getFubenReward();
        final Object other$fubenReward = other.getFubenReward();
        Label_0234: {
            if (this$fubenReward == null) {
                if (other$fubenReward == null) {
                    break Label_0234;
                }
            }
            else if (this$fubenReward.equals(other$fubenReward)) {
                break Label_0234;
            }
            return false;
        }
        final Object this$bossReward = this.getBossReward();
        final Object other$bossReward = other.getBossReward();
        Label_0271: {
            if (this$bossReward == null) {
                if (other$bossReward == null) {
                    break Label_0271;
                }
            }
            else if (this$bossReward.equals(other$bossReward)) {
                break Label_0271;
            }
            return false;
        }
        final Object this$qishaReward = this.getQishaReward();
        final Object other$qishaReward = other.getQishaReward();
        Label_0308: {
            if (this$qishaReward == null) {
                if (other$qishaReward == null) {
                    break Label_0308;
                }
            }
            else if (this$qishaReward.equals(other$qishaReward)) {
                break Label_0308;
            }
            return false;
        }
        if (Double.compare(this.getShimen_timesJingyan(), other.getShimen_timesJingyan()) != 0) {
            return false;
        }
        final Object this$shidao_one_reward = this.getShidao_one_reward();
        final Object other$shidao_one_reward = other.getShidao_one_reward();
        Label_0361: {
            if (this$shidao_one_reward == null) {
                if (other$shidao_one_reward == null) {
                    break Label_0361;
                }
            }
            else if (this$shidao_one_reward.equals(other$shidao_one_reward)) {
                break Label_0361;
            }
            return false;
        }
        final Object this$shidao_two_reward = this.getShidao_two_reward();
        final Object other$shidao_two_reward = other.getShidao_two_reward();
        Label_0398: {
            if (this$shidao_two_reward == null) {
                if (other$shidao_two_reward == null) {
                    break Label_0398;
                }
            }
            else if (this$shidao_two_reward.equals(other$shidao_two_reward)) {
                break Label_0398;
            }
            return false;
        }
        final Object this$shidao_three_reward = this.getShidao_three_reward();
        final Object other$shidao_three_reward = other.getShidao_three_reward();
        Label_0435: {
            if (this$shidao_three_reward == null) {
                if (other$shidao_three_reward == null) {
                    break Label_0435;
                }
            }
            else if (this$shidao_three_reward.equals(other$shidao_three_reward)) {
                break Label_0435;
            }
            return false;
        }
        final Object this$lc_charge_text = this.getLc_charge_text();
        final Object other$lc_charge_text = other.getLc_charge_text();
        Label_0472: {
            if (this$lc_charge_text == null) {
                if (other$lc_charge_text == null) {
                    break Label_0472;
                }
            }
            else if (this$lc_charge_text.equals(other$lc_charge_text)) {
                break Label_0472;
            }
            return false;
        }
        final Object this$one_charge_reward = this.getOne_charge_reward();
        final Object other$one_charge_reward = other.getOne_charge_reward();
        Label_0509: {
            if (this$one_charge_reward == null) {
                if (other$one_charge_reward == null) {
                    break Label_0509;
                }
            }
            else if (this$one_charge_reward.equals(other$one_charge_reward)) {
                break Label_0509;
            }
            return false;
        }
        final Object this$charge_98_reward = this.getCharge_98_reward();
        final Object other$charge_98_reward = other.getCharge_98_reward();
        Label_0546: {
            if (this$charge_98_reward == null) {
                if (other$charge_98_reward == null) {
                    break Label_0546;
                }
            }
            else if (this$charge_98_reward.equals(other$charge_98_reward)) {
                break Label_0546;
            }
            return false;
        }
        final Object this$charge_328_reward = this.getCharge_328_reward();
        final Object other$charge_328_reward = other.getCharge_328_reward();
        Label_0583: {
            if (this$charge_328_reward == null) {
                if (other$charge_328_reward == null) {
                    break Label_0583;
                }
            }
            else if (this$charge_328_reward.equals(other$charge_328_reward)) {
                break Label_0583;
            }
            return false;
        }
        final Object this$charge_648_reward = this.getCharge_648_reward();
        final Object other$charge_648_reward = other.getCharge_648_reward();
        Label_0620: {
            if (this$charge_648_reward == null) {
                if (other$charge_648_reward == null) {
                    break Label_0620;
                }
            }
            else if (this$charge_648_reward.equals(other$charge_648_reward)) {
                break Label_0620;
            }
            return false;
        }
        final Object this$charge_1000_reward = this.getCharge_1000_reward();
        final Object other$charge_1000_reward = other.getCharge_1000_reward();
        Label_0657: {
            if (this$charge_1000_reward == null) {
                if (other$charge_1000_reward == null) {
                    break Label_0657;
                }
            }
            else if (this$charge_1000_reward.equals(other$charge_1000_reward)) {
                break Label_0657;
            }
            return false;
        }
        final Object this$charge_2000_reward = this.getCharge_2000_reward();
        final Object other$charge_2000_reward = other.getCharge_2000_reward();
        Label_0694: {
            if (this$charge_2000_reward == null) {
                if (other$charge_2000_reward == null) {
                    break Label_0694;
                }
            }
            else if (this$charge_2000_reward.equals(other$charge_2000_reward)) {
                break Label_0694;
            }
            return false;
        }
        final Object this$charge_3000_reward = this.getCharge_3000_reward();
        final Object other$charge_3000_reward = other.getCharge_3000_reward();
        Label_0731: {
            if (this$charge_3000_reward == null) {
                if (other$charge_3000_reward == null) {
                    break Label_0731;
                }
            }
            else if (this$charge_3000_reward.equals(other$charge_3000_reward)) {
                break Label_0731;
            }
            return false;
        }
        final Object this$charge_5000_reward = this.getCharge_5000_reward();
        final Object other$charge_5000_reward = other.getCharge_5000_reward();
        Label_0768: {
            if (this$charge_5000_reward == null) {
                if (other$charge_5000_reward == null) {
                    break Label_0768;
                }
            }
            else if (this$charge_5000_reward.equals(other$charge_5000_reward)) {
                break Label_0768;
            }
            return false;
        }

        final Object this$charge_10000_reward = this.getCharge_10000_reward();
        final Object other$charge_10000_reward = other.getCharge_10000_reward();
        Label_0100: {
            if (this$charge_10000_reward == null) {
                if (other$charge_10000_reward == null) {
                    break Label_0100;
                }
            }
            else if (this$charge_10000_reward.equals(other$charge_10000_reward)) {
                break Label_0100;
            }
            return false;
        }
        if (this.getCharge_addCjNum() != other.getCharge_addCjNum()) {
            return false;
        }
        final Object this$wabao_tedeng_reward = this.getWabao_tedeng_reward();
        final Object other$wabao_tedeng_reward = other.getWabao_tedeng_reward();
        Label_0818: {
            if (this$wabao_tedeng_reward == null) {
                if (other$wabao_tedeng_reward == null) {
                    break Label_0818;
                }
            }
            else if (this$wabao_tedeng_reward.equals(other$wabao_tedeng_reward)) {
                break Label_0818;
            }
            return false;
        }
        final Object this$wabao_yideng_reward = this.getWabao_yideng_reward();
        final Object other$wabao_yideng_reward = other.getWabao_yideng_reward();
        Label_0855: {
            if (this$wabao_yideng_reward == null) {
                if (other$wabao_yideng_reward == null) {
                    break Label_0855;
                }
            }
            else if (this$wabao_yideng_reward.equals(other$wabao_yideng_reward)) {
                break Label_0855;
            }
            return false;
        }
        final Object this$wabao_erdeng_reward = this.getWabao_erdeng_reward();
        final Object other$wabao_erdeng_reward = other.getWabao_erdeng_reward();
        Label_0892: {
            if (this$wabao_erdeng_reward == null) {
                if (other$wabao_erdeng_reward == null) {
                    break Label_0892;
                }
            }
            else if (this$wabao_erdeng_reward.equals(other$wabao_erdeng_reward)) {
                break Label_0892;
            }
            return false;
        }
        final Object this$wabao_sandeng_reward = this.getWabao_sandeng_reward();
        final Object other$wabao_sandeng_reward = other.getWabao_sandeng_reward();
        Label_0929: {
            if (this$wabao_sandeng_reward == null) {
                if (other$wabao_sandeng_reward == null) {
                    break Label_0929;
                }
            }
            else if (this$wabao_sandeng_reward.equals(other$wabao_sandeng_reward)) {
                break Label_0929;
            }
            return false;
        }
        if (Double.compare(this.getWabao_te_gailv(), other.getWabao_te_gailv()) != 0) {
            return false;
        }
        if (Double.compare(this.getWabao_yi_gailv(), other.getWabao_yi_gailv()) != 0) {
            return false;
        }
        if (Double.compare(this.getWabao_er_gailv(), other.getWabao_er_gailv()) != 0) {
            return false;
        }
        if (Double.compare(this.getWabao_san_gailv(), other.getWabao_san_gailv()) != 0) {
            return false;
        }
        if (this.getYaowang_max_num() != other.getYaowang_max_num()) {
            return false;
        }
        final Object this$sg_reward = this.getSg_reward();
        final Object other$sg_reward = other.getSg_reward();
        Label_1043: {
            if (this$sg_reward == null) {
                if (other$sg_reward == null) {
                    break Label_1043;
                }
            }
            else if (this$sg_reward.equals(other$sg_reward)) {
                break Label_1043;
            }
            return false;
        }
        if (this.getSg_exp_ten() != other.getSg_exp_ten()) {
            return false;
        }
        if (Double.compare(this.getSg_out_gailv(), other.getSg_out_gailv()) != 0) {
            return false;
        }
        final Object this$yuanmo_reward = this.getYuanmo_reward();
        final Object other$yuanmo_reward = other.getYuanmo_reward();
        if (this$yuanmo_reward == null) {
            if (other$yuanmo_reward == null) {
                return true;
            }
        }
        else if (this$yuanmo_reward.equals(other$yuanmo_reward)) {
            return true;
        }
        return false;
    }

    protected boolean canEqual(final Object other) {
        return other instanceof rewardConfig;
    }

    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        result = result * 59 + this.getTttTimes();
        result = result * 59 + this.getFbTimes();
        final long $timesJingyan = Double.doubleToLongBits(this.getTimesJingyan());
        result = result * 59 + (int)($timesJingyan >>> 32 ^ $timesJingyan);
        final long $timesDaohang = Double.doubleToLongBits(this.getTimesDaohang());
        result = result * 59 + (int)($timesDaohang >>> 32 ^ $timesDaohang);
        final Object $tttReward = this.getTttReward();
        result = result * 59 + (($tttReward == null) ? 43 : $tttReward.hashCode());
        final Object $tttgtReward = this.getTttgtReward();
        result = result * 59 + (($tttgtReward == null) ? 43 : $tttgtReward.hashCode());
        final Object $tttSuccessReward = this.getTttSuccessReward();
        result = result * 59 + (($tttSuccessReward == null) ? 43 : $tttSuccessReward.hashCode());
        final Object $fubenReward = this.getFubenReward();
        result = result * 59 + (($fubenReward == null) ? 43 : $fubenReward.hashCode());
        final Object $bossReward = this.getBossReward();
        result = result * 59 + (($bossReward == null) ? 43 : $bossReward.hashCode());
        final Object $qishaReward = this.getQishaReward();
        result = result * 59 + (($qishaReward == null) ? 43 : $qishaReward.hashCode());
        final long $shimen_timesJingyan = Double.doubleToLongBits(this.getShimen_timesJingyan());
        result = result * 59 + (int)($shimen_timesJingyan >>> 32 ^ $shimen_timesJingyan);
        final Object $shidao_one_reward = this.getShidao_one_reward();
        result = result * 59 + (($shidao_one_reward == null) ? 43 : $shidao_one_reward.hashCode());
        final Object $shidao_two_reward = this.getShidao_two_reward();
        result = result * 59 + (($shidao_two_reward == null) ? 43 : $shidao_two_reward.hashCode());
        final Object $shidao_three_reward = this.getShidao_three_reward();
        result = result * 59 + (($shidao_three_reward == null) ? 43 : $shidao_three_reward.hashCode());
        final Object $lc_charge_text = this.getLc_charge_text();
        result = result * 59 + (($lc_charge_text == null) ? 43 : $lc_charge_text.hashCode());
        final Object $one_charge_reward = this.getOne_charge_reward();
        result = result * 59 + (($one_charge_reward == null) ? 43 : $one_charge_reward.hashCode());
        final Object $charge_98_reward = this.getCharge_98_reward();
        result = result * 59 + (($charge_98_reward == null) ? 43 : $charge_98_reward.hashCode());
        final Object $charge_328_reward = this.getCharge_328_reward();
        result = result * 59 + (($charge_328_reward == null) ? 43 : $charge_328_reward.hashCode());
        final Object $charge_648_reward = this.getCharge_648_reward();
        result = result * 59 + (($charge_648_reward == null) ? 43 : $charge_648_reward.hashCode());
        final Object $charge_1000_reward = this.getCharge_1000_reward();
        result = result * 59 + (($charge_1000_reward == null) ? 43 : $charge_1000_reward.hashCode());
        final Object $charge_2000_reward = this.getCharge_2000_reward();
        result = result * 59 + (($charge_2000_reward == null) ? 43 : $charge_2000_reward.hashCode());
        final Object $charge_3000_reward = this.getCharge_3000_reward();
        result = result * 59 + (($charge_3000_reward == null) ? 43 : $charge_3000_reward.hashCode());
        final Object $charge_5000_reward = this.getCharge_5000_reward();
        result = result * 59 + (($charge_5000_reward == null) ? 43 : $charge_5000_reward.hashCode());
        final Object $charge_10000_reward = this.getCharge_10000_reward();
        result = result * 59 + (($charge_10000_reward == null) ? 43 : $charge_10000_reward.hashCode());
        result = result * 59 + this.getCharge_addCjNum();
        final Object $wabao_tedeng_reward = this.getWabao_tedeng_reward();
        result = result * 59 + (($wabao_tedeng_reward == null) ? 43 : $wabao_tedeng_reward.hashCode());
        final Object $wabao_yideng_reward = this.getWabao_yideng_reward();
        result = result * 59 + (($wabao_yideng_reward == null) ? 43 : $wabao_yideng_reward.hashCode());
        final Object $wabao_erdeng_reward = this.getWabao_erdeng_reward();
        result = result * 59 + (($wabao_erdeng_reward == null) ? 43 : $wabao_erdeng_reward.hashCode());
        final Object $wabao_sandeng_reward = this.getWabao_sandeng_reward();
        result = result * 59 + (($wabao_sandeng_reward == null) ? 43 : $wabao_sandeng_reward.hashCode());
        final long $wabao_te_gailv = Double.doubleToLongBits(this.getWabao_te_gailv());
        result = result * 59 + (int)($wabao_te_gailv >>> 32 ^ $wabao_te_gailv);
        final long $wabao_yi_gailv = Double.doubleToLongBits(this.getWabao_yi_gailv());
        result = result * 59 + (int)($wabao_yi_gailv >>> 32 ^ $wabao_yi_gailv);
        final long $wabao_er_gailv = Double.doubleToLongBits(this.getWabao_er_gailv());
        result = result * 59 + (int)($wabao_er_gailv >>> 32 ^ $wabao_er_gailv);
        final long $wabao_san_gailv = Double.doubleToLongBits(this.getWabao_san_gailv());
        result = result * 59 + (int)($wabao_san_gailv >>> 32 ^ $wabao_san_gailv);
        result = result * 59 + this.getYaowang_max_num();
        final Object $sg_reward = this.getSg_reward();
        result = result * 59 + (($sg_reward == null) ? 43 : $sg_reward.hashCode());
        result = result * 59 + this.getSg_exp_ten();
        final long $sg_out_gailv = Double.doubleToLongBits(this.getSg_out_gailv());
        result = result * 59 + (int)($sg_out_gailv >>> 32 ^ $sg_out_gailv);
        final Object $yuanmo_reward = this.getYuanmo_reward();
        result = result * 59 + (($yuanmo_reward == null) ? 43 : $yuanmo_reward.hashCode());
        return result;
    }

    @Override
    public String toString() {
        return "rewardConfig(tttTimes=" + this.getTttTimes() + ", fbTimes=" + this.getFbTimes() + ", timesJingyan=" + this.getTimesJingyan() + ", timesDaohang=" + this.getTimesDaohang() + ", tttReward=" + this.getTttReward() + ", tttgtReward=" + this.getTttgtReward() + ", tttSuccessReward=" + this.getTttSuccessReward() + ", fubenReward=" + this.getFubenReward() + ", bossReward=" + this.getBossReward() + ", qishaReward=" + this.getQishaReward() + ", shimen_timesJingyan=" + this.getShimen_timesJingyan() + ", shidao_one_reward=" + this.getShidao_one_reward() + ", shidao_two_reward=" + this.getShidao_two_reward() + ", shidao_three_reward=" + this.getShidao_three_reward() + ", lc_charge_text=" + this.getLc_charge_text() + ", one_charge_reward=" + this.getOne_charge_reward() + ", charge_98_reward=" + this.getCharge_98_reward() + ", charge_328_reward=" + this.getCharge_328_reward() + ", charge_648_reward=" + this.getCharge_648_reward() + ", charge_1000_reward=" + this.getCharge_1000_reward() + ", charge_2000_reward=" + this.getCharge_2000_reward() + ", charge_3000_reward=" + this.getCharge_3000_reward() + ", charge_5000_reward=" + this.getCharge_5000_reward() + ", charge_10000_reward=" + this.getCharge_10000_reward() + ", charge_addCjNum=" + this.getCharge_addCjNum() + ", wabao_tedeng_reward=" + this.getWabao_tedeng_reward() + ", wabao_yideng_reward=" + this.getWabao_yideng_reward() + ", wabao_erdeng_reward=" + this.getWabao_erdeng_reward() + ", wabao_sandeng_reward=" + this.getWabao_sandeng_reward() + ", wabao_te_gailv=" + this.getWabao_te_gailv() + ", wabao_yi_gailv=" + this.getWabao_yi_gailv() + ", wabao_er_gailv=" + this.getWabao_er_gailv() + ", wabao_san_gailv=" + this.getWabao_san_gailv() + ", yaowang_max_num=" + this.getYaowang_max_num() + ", sg_reward=" + this.getSg_reward() + ", sg_exp_ten=" + this.getSg_exp_ten() + ", sg_out_gailv=" + this.getSg_out_gailv() + ", yuanmo_reward=" + this.getYuanmo_reward() + ")";
    }
}
