package com.kitty.common.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component("regConfig")
@ConfigurationProperties(prefix = "reg-config")
public class regConfig
{
    private Integer extra_life;
    private Integer gold_coin;
    private Integer shadow_self;
    private Integer reg_length;
    private Integer reg_jifen;
    
    public Integer getExtra_life() {
        return this.extra_life;
    }
    
    public Integer getGold_coin() {
        return this.gold_coin;
    }
    
    public Integer getShadow_self() {
        return this.shadow_self;
    }
    
    public Integer getReg_length() {
        return this.reg_length;
    }
    
    public Integer getReg_jifen() {
        return this.reg_jifen;
    }
    
    public void setExtra_life(final Integer extra_life) {
        this.extra_life = extra_life;
    }
    
    public void setGold_coin(final Integer gold_coin) {
        this.gold_coin = gold_coin;
    }
    
    public void setShadow_self(final Integer shadow_self) {
        this.shadow_self = shadow_self;
    }
    
    public void setReg_length(final Integer reg_length) {
        this.reg_length = reg_length;
    }
    
    public void setReg_jifen(final Integer reg_jifen) {
        this.reg_jifen = reg_jifen;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof regConfig)) {
            return false;
        }
        final regConfig other = (regConfig)o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$extra_life = this.getExtra_life();
        final Object other$extra_life = other.getExtra_life();
        Label_0065: {
            if (this$extra_life == null) {
                if (other$extra_life == null) {
                    break Label_0065;
                }
            }
            else if (this$extra_life.equals(other$extra_life)) {
                break Label_0065;
            }
            return false;
        }
        final Object this$gold_coin = this.getGold_coin();
        final Object other$gold_coin = other.getGold_coin();
        Label_0102: {
            if (this$gold_coin == null) {
                if (other$gold_coin == null) {
                    break Label_0102;
                }
            }
            else if (this$gold_coin.equals(other$gold_coin)) {
                break Label_0102;
            }
            return false;
        }
        final Object this$shadow_self = this.getShadow_self();
        final Object other$shadow_self = other.getShadow_self();
        Label_0139: {
            if (this$shadow_self == null) {
                if (other$shadow_self == null) {
                    break Label_0139;
                }
            }
            else if (this$shadow_self.equals(other$shadow_self)) {
                break Label_0139;
            }
            return false;
        }
        final Object this$reg_length = this.getReg_length();
        final Object other$reg_length = other.getReg_length();
        Label_0176: {
            if (this$reg_length == null) {
                if (other$reg_length == null) {
                    break Label_0176;
                }
            }
            else if (this$reg_length.equals(other$reg_length)) {
                break Label_0176;
            }
            return false;
        }
        final Object this$reg_jifen = this.getReg_jifen();
        final Object other$reg_jifen = other.getReg_jifen();
        if (this$reg_jifen == null) {
            if (other$reg_jifen == null) {
                return true;
            }
        }
        else if (this$reg_jifen.equals(other$reg_jifen)) {
            return true;
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof regConfig;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $extra_life = this.getExtra_life();
        result = result * 59 + (($extra_life == null) ? 43 : $extra_life.hashCode());
        final Object $gold_coin = this.getGold_coin();
        result = result * 59 + (($gold_coin == null) ? 43 : $gold_coin.hashCode());
        final Object $shadow_self = this.getShadow_self();
        result = result * 59 + (($shadow_self == null) ? 43 : $shadow_self.hashCode());
        final Object $reg_length = this.getReg_length();
        result = result * 59 + (($reg_length == null) ? 43 : $reg_length.hashCode());
        final Object $reg_jifen = this.getReg_jifen();
        result = result * 59 + (($reg_jifen == null) ? 43 : $reg_jifen.hashCode());
        return result;
    }
    
    @Override
    public String toString() {
        return "regConfig(extra_life=" + this.getExtra_life() + ", gold_coin=" + this.getGold_coin() + ", shadow_self=" + this.getShadow_self() + ", reg_length=" + this.getReg_length() + ", reg_jifen=" + this.getReg_jifen() + ")";
    }
}
