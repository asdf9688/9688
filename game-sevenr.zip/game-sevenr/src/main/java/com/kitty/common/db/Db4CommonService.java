package com.kitty.common.db;


import com.kitty.common.thread.NamedThreadFactory;
import com.kitty.common.utils.BlockingUniqueQueue;
import com.kitty.logs.LoggerUtils;
import org.nutz.dao.Dao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.util.Iterator;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 公共数据(排查玩家数据)持久化队列
 */
@Component
public class Db4CommonService {


    private static volatile Db4CommonService instance;

    @Autowired
    private Dao dao;

    public static Db4CommonService getInstance() {
        return instance;
    }

    /**
     * start consumer thread
     */
    @PostConstruct
    private void init() {
        new NamedThreadFactory("db-common-save-service").newThread(new Worker()).start();
        instance = this;
    }

    private BlockingQueue<BaseEntity> queue = new BlockingUniqueQueue<>();

    private final AtomicBoolean run = new AtomicBoolean(true);

    public void add2Queue(BaseEntity entity) {
        if (entity == null) {
            return;
        }
        this.queue.add(entity);
//        logger.error("入库队列大小==={}",queue.size());
    }

    private class Worker implements Runnable {
        @Override
        public void run() {
            while (run.get()) {
                BaseEntity entity = null;
                try {
                    entity = queue.take();
                    saveToDb(entity);
                } catch (Exception e) {
                    LoggerUtils.error("", e);
                    // 有可能是并发抛错，重新放入队列
                    add2Queue(entity);
                }
            }
        }
    }

    /**
     * 数据真正持久化
     *
     * @param entity
     */
    private void saveToDb(BaseEntity entity) {
        entity.doBeforeSave();
        if (entity.isDelete()) {
            dao.delete(entity);
        } else {
            dao.insertOrUpdate(entity);
        }
    }

    @PreDestroy
    public void shutDown() {
        run.getAndSet(false);
        for (; ;) {
            if (! queue.isEmpty()) {
                saveAllBeforeShutDown();
            } else {
                break;
            }
        }
        LoggerUtils.error("[Db4Common] 执行全部命令后关闭");
    }

    private void saveAllBeforeShutDown() {
        while (!queue.isEmpty()) {
            Iterator<BaseEntity> it = queue.iterator();
            while (it.hasNext()) {
                BaseEntity next = it.next();
                it.remove();
                saveToDb(next);
            }
        }
    }

}