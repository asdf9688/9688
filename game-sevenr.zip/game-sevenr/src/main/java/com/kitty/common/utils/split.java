package com.kitty.common.utils;

import java.util.ArrayList;
import java.util.List;

public class split {
    public List<String> StringSplit(String str){
        String resu[]=str.split("\\|");
        List list = new ArrayList();
        for(String k: resu){
            list.add(k);
        }
        return list;
    }
}
