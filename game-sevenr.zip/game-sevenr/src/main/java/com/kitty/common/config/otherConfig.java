package com.kitty.common.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component("otherConfig")
@ConfigurationProperties(prefix = "other-config")
public class otherConfig
{
    private Integer pet_max_level;
    private Integer persion_max_level;
    private Integer yy_max_level;
    private Integer fy_length;
    private String fy_char;
    private String fy_replace;
    private Integer fy_level;
    private double cj_time;
    private String wudao_xiaohaos;
    private String wudao_shuxings;
    private boolean openRank;
    private boolean openWuxing;
    private String wuxing_gailv;
    private String menpai_tab_xiaohao;
    private int max_menpai_tab_num;
    private int max_request_count;
    private int goods_jinhua_max;
    private double fs_bs_bei;
    private double fa_panel_bei;
    private double wu_panel_bei;
    private double xue_panel_bei;
    private double lan_panel_bei;
    private double su_panel_bei;
    private double fang_panel_bei;
    private double pet_fa_panel_bei;
    private double pet_wu_panel_bei;
    private double pet_xue_panel_bei;
    private double pet_lan_panel_bei;
    private double pet_su_panel_bei;
    private double pet_fang_panel_bei;
    private int ss_qh_addvalue;
    private int card_time;
    private boolean zb_gz_success;
    private boolean is_open_chargefy;
    private int pet_max_qh;
    private int charge_money_fy;
    
    public Integer getPet_max_level() {
        return this.pet_max_level;
    }
    
    public Integer getPersion_max_level() {
        return this.persion_max_level;
    }
    
    public Integer getYy_max_level() {
        return this.yy_max_level;
    }
    
    public Integer getFy_length() {
        return this.fy_length;
    }
    
    public String getFy_char() {
        return this.fy_char;
    }
    
    public String getFy_replace() {
        return this.fy_replace;
    }
    
    public Integer getFy_level() {
        return this.fy_level;
    }
    
    public double getCj_time() {
        return this.cj_time;
    }
    
    public String getWudao_xiaohaos() {
        return this.wudao_xiaohaos;
    }
    
    public String getWudao_shuxings() {
        return this.wudao_shuxings;
    }
    
    public boolean isOpenRank() {
        return this.openRank;
    }
    
    public boolean isOpenWuxing() {
        return this.openWuxing;
    }
    
    public String getWuxing_gailv() {
        return this.wuxing_gailv;
    }
    
    public String getMenpai_tab_xiaohao() {
        return this.menpai_tab_xiaohao;
    }
    
    public int getMax_menpai_tab_num() {
        return this.max_menpai_tab_num;
    }
    
    public int getMax_request_count() {
        return this.max_request_count;
    }
    
    public int getGoods_jinhua_max() {
        return this.goods_jinhua_max;
    }
    
    public double getFs_bs_bei() {
        return this.fs_bs_bei;
    }
    
    public double getFa_panel_bei() {
        return this.fa_panel_bei;
    }
    
    public double getWu_panel_bei() {
        return this.wu_panel_bei;
    }
    
    public double getXue_panel_bei() {
        return this.xue_panel_bei;
    }
    
    public double getLan_panel_bei() {
        return this.lan_panel_bei;
    }
    
    public double getSu_panel_bei() {
        return this.su_panel_bei;
    }
    
    public double getFang_panel_bei() {
        return this.fang_panel_bei;
    }
    
    public double getPet_fa_panel_bei() {
        return this.pet_fa_panel_bei;
    }
    
    public double getPet_wu_panel_bei() {
        return this.pet_wu_panel_bei;
    }
    
    public double getPet_xue_panel_bei() {
        return this.pet_xue_panel_bei;
    }
    
    public double getPet_lan_panel_bei() {
        return this.pet_lan_panel_bei;
    }
    
    public double getPet_su_panel_bei() {
        return this.pet_su_panel_bei;
    }
    
    public double getPet_fang_panel_bei() {
        return this.pet_fang_panel_bei;
    }
    
    public int getSs_qh_addvalue() {
        return this.ss_qh_addvalue;
    }
    
    public int getCard_time() {
        return this.card_time;
    }
    
    public boolean isZb_gz_success() {
        return this.zb_gz_success;
    }
    
    public boolean is_open_chargefy() {
        return this.is_open_chargefy;
    }
    
    public int getPet_max_qh() {
        return this.pet_max_qh;
    }
    
    public int getCharge_money_fy() {
        return this.charge_money_fy;
    }
    
    public void setPet_max_level(final Integer pet_max_level) {
        this.pet_max_level = pet_max_level;
    }
    
    public void setPersion_max_level(final Integer persion_max_level) {
        this.persion_max_level = persion_max_level;
    }
    
    public void setYy_max_level(final Integer yy_max_level) {
        this.yy_max_level = yy_max_level;
    }
    
    public void setFy_length(final Integer fy_length) {
        this.fy_length = fy_length;
    }
    
    public void setFy_char(final String fy_char) {
        this.fy_char = fy_char;
    }
    
    public void setFy_replace(final String fy_replace) {
        this.fy_replace = fy_replace;
    }
    
    public void setFy_level(final Integer fy_level) {
        this.fy_level = fy_level;
    }
    
    public void setCj_time(final double cj_time) {
        this.cj_time = cj_time;
    }
    
    public void setWudao_xiaohaos(final String wudao_xiaohaos) {
        this.wudao_xiaohaos = wudao_xiaohaos;
    }
    
    public void setWudao_shuxings(final String wudao_shuxings) {
        this.wudao_shuxings = wudao_shuxings;
    }
    
    public void setOpenRank(final boolean openRank) {
        this.openRank = openRank;
    }
    
    public void setOpenWuxing(final boolean openWuxing) {
        this.openWuxing = openWuxing;
    }
    
    public void setWuxing_gailv(final String wuxing_gailv) {
        this.wuxing_gailv = wuxing_gailv;
    }
    
    public void setMenpai_tab_xiaohao(final String menpai_tab_xiaohao) {
        this.menpai_tab_xiaohao = menpai_tab_xiaohao;
    }
    
    public void setMax_menpai_tab_num(final int max_menpai_tab_num) {
        this.max_menpai_tab_num = max_menpai_tab_num;
    }
    
    public void setMax_request_count(final int max_request_count) {
        this.max_request_count = max_request_count;
    }
    
    public void setGoods_jinhua_max(final int goods_jinhua_max) {
        this.goods_jinhua_max = goods_jinhua_max;
    }
    
    public void setFs_bs_bei(final double fs_bs_bei) {
        this.fs_bs_bei = fs_bs_bei;
    }
    
    public void setFa_panel_bei(final double fa_panel_bei) {
        this.fa_panel_bei = fa_panel_bei;
    }
    
    public void setWu_panel_bei(final double wu_panel_bei) {
        this.wu_panel_bei = wu_panel_bei;
    }
    
    public void setXue_panel_bei(final double xue_panel_bei) {
        this.xue_panel_bei = xue_panel_bei;
    }
    
    public void setLan_panel_bei(final double lan_panel_bei) {
        this.lan_panel_bei = lan_panel_bei;
    }
    
    public void setSu_panel_bei(final double su_panel_bei) {
        this.su_panel_bei = su_panel_bei;
    }
    
    public void setFang_panel_bei(final double fang_panel_bei) {
        this.fang_panel_bei = fang_panel_bei;
    }
    
    public void setPet_fa_panel_bei(final double pet_fa_panel_bei) {
        this.pet_fa_panel_bei = pet_fa_panel_bei;
    }
    
    public void setPet_wu_panel_bei(final double pet_wu_panel_bei) {
        this.pet_wu_panel_bei = pet_wu_panel_bei;
    }
    
    public void setPet_xue_panel_bei(final double pet_xue_panel_bei) {
        this.pet_xue_panel_bei = pet_xue_panel_bei;
    }
    
    public void setPet_lan_panel_bei(final double pet_lan_panel_bei) {
        this.pet_lan_panel_bei = pet_lan_panel_bei;
    }
    
    public void setPet_su_panel_bei(final double pet_su_panel_bei) {
        this.pet_su_panel_bei = pet_su_panel_bei;
    }
    
    public void setPet_fang_panel_bei(final double pet_fang_panel_bei) {
        this.pet_fang_panel_bei = pet_fang_panel_bei;
    }
    
    public void setSs_qh_addvalue(final int ss_qh_addvalue) {
        this.ss_qh_addvalue = ss_qh_addvalue;
    }
    
    public void setCard_time(final int card_time) {
        this.card_time = card_time;
    }
    
    public void setZb_gz_success(final boolean zb_gz_success) {
        this.zb_gz_success = zb_gz_success;
    }
    
    public void set_open_chargefy(final boolean is_open_chargefy) {
        this.is_open_chargefy = is_open_chargefy;
    }
    
    public void setPet_max_qh(final int pet_max_qh) {
        this.pet_max_qh = pet_max_qh;
    }
    
    public void setCharge_money_fy(final int charge_money_fy) {
        this.charge_money_fy = charge_money_fy;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof otherConfig)) {
            return false;
        }
        final otherConfig other = (otherConfig)o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$pet_max_level = this.getPet_max_level();
        final Object other$pet_max_level = other.getPet_max_level();
        Label_0065: {
            if (this$pet_max_level == null) {
                if (other$pet_max_level == null) {
                    break Label_0065;
                }
            }
            else if (this$pet_max_level.equals(other$pet_max_level)) {
                break Label_0065;
            }
            return false;
        }
        final Object this$persion_max_level = this.getPersion_max_level();
        final Object other$persion_max_level = other.getPersion_max_level();
        Label_0102: {
            if (this$persion_max_level == null) {
                if (other$persion_max_level == null) {
                    break Label_0102;
                }
            }
            else if (this$persion_max_level.equals(other$persion_max_level)) {
                break Label_0102;
            }
            return false;
        }
        final Object this$yy_max_level = this.getYy_max_level();
        final Object other$yy_max_level = other.getYy_max_level();
        Label_0139: {
            if (this$yy_max_level == null) {
                if (other$yy_max_level == null) {
                    break Label_0139;
                }
            }
            else if (this$yy_max_level.equals(other$yy_max_level)) {
                break Label_0139;
            }
            return false;
        }
        final Object this$fy_length = this.getFy_length();
        final Object other$fy_length = other.getFy_length();
        Label_0176: {
            if (this$fy_length == null) {
                if (other$fy_length == null) {
                    break Label_0176;
                }
            }
            else if (this$fy_length.equals(other$fy_length)) {
                break Label_0176;
            }
            return false;
        }
        final Object this$fy_char = this.getFy_char();
        final Object other$fy_char = other.getFy_char();
        Label_0213: {
            if (this$fy_char == null) {
                if (other$fy_char == null) {
                    break Label_0213;
                }
            }
            else if (this$fy_char.equals(other$fy_char)) {
                break Label_0213;
            }
            return false;
        }
        final Object this$fy_replace = this.getFy_replace();
        final Object other$fy_replace = other.getFy_replace();
        Label_0250: {
            if (this$fy_replace == null) {
                if (other$fy_replace == null) {
                    break Label_0250;
                }
            }
            else if (this$fy_replace.equals(other$fy_replace)) {
                break Label_0250;
            }
            return false;
        }
        final Object this$fy_level = this.getFy_level();
        final Object other$fy_level = other.getFy_level();
        Label_0287: {
            if (this$fy_level == null) {
                if (other$fy_level == null) {
                    break Label_0287;
                }
            }
            else if (this$fy_level.equals(other$fy_level)) {
                break Label_0287;
            }
            return false;
        }
        if (Double.compare(this.getCj_time(), other.getCj_time()) != 0) {
            return false;
        }
        final Object this$wudao_xiaohaos = this.getWudao_xiaohaos();
        final Object other$wudao_xiaohaos = other.getWudao_xiaohaos();
        Label_0340: {
            if (this$wudao_xiaohaos == null) {
                if (other$wudao_xiaohaos == null) {
                    break Label_0340;
                }
            }
            else if (this$wudao_xiaohaos.equals(other$wudao_xiaohaos)) {
                break Label_0340;
            }
            return false;
        }
        final Object this$wudao_shuxings = this.getWudao_shuxings();
        final Object other$wudao_shuxings = other.getWudao_shuxings();
        Label_0377: {
            if (this$wudao_shuxings == null) {
                if (other$wudao_shuxings == null) {
                    break Label_0377;
                }
            }
            else if (this$wudao_shuxings.equals(other$wudao_shuxings)) {
                break Label_0377;
            }
            return false;
        }
        if (this.isOpenRank() != other.isOpenRank()) {
            return false;
        }
        if (this.isOpenWuxing() != other.isOpenWuxing()) {
            return false;
        }
        final Object this$wuxing_gailv = this.getWuxing_gailv();
        final Object other$wuxing_gailv = other.getWuxing_gailv();
        Label_0440: {
            if (this$wuxing_gailv == null) {
                if (other$wuxing_gailv == null) {
                    break Label_0440;
                }
            }
            else if (this$wuxing_gailv.equals(other$wuxing_gailv)) {
                break Label_0440;
            }
            return false;
        }
        final Object this$menpai_tab_xiaohao = this.getMenpai_tab_xiaohao();
        final Object other$menpai_tab_xiaohao = other.getMenpai_tab_xiaohao();
        if (this$menpai_tab_xiaohao == null) {
            if (other$menpai_tab_xiaohao == null) {
                return this.getMax_menpai_tab_num() == other.getMax_menpai_tab_num() && this.getMax_request_count() == other.getMax_request_count() && this.getGoods_jinhua_max() == other.getGoods_jinhua_max() && Double.compare(this.getFs_bs_bei(), other.getFs_bs_bei()) == 0 && Double.compare(this.getFa_panel_bei(), other.getFa_panel_bei()) == 0 && Double.compare(this.getWu_panel_bei(), other.getWu_panel_bei()) == 0 && Double.compare(this.getXue_panel_bei(), other.getXue_panel_bei()) == 0 && Double.compare(this.getLan_panel_bei(), other.getLan_panel_bei()) == 0 && Double.compare(this.getSu_panel_bei(), other.getSu_panel_bei()) == 0 && Double.compare(this.getFang_panel_bei(), other.getFang_panel_bei()) == 0 && Double.compare(this.getPet_fa_panel_bei(), other.getPet_fa_panel_bei()) == 0 && Double.compare(this.getPet_wu_panel_bei(), other.getPet_wu_panel_bei()) == 0 && Double.compare(this.getPet_xue_panel_bei(), other.getPet_xue_panel_bei()) == 0 && Double.compare(this.getPet_lan_panel_bei(), other.getPet_lan_panel_bei()) == 0 && Double.compare(this.getPet_su_panel_bei(), other.getPet_su_panel_bei()) == 0 && Double.compare(this.getPet_fang_panel_bei(), other.getPet_fang_panel_bei()) == 0 && this.getSs_qh_addvalue() == other.getSs_qh_addvalue() && this.getCard_time() == other.getCard_time() && this.isZb_gz_success() == other.isZb_gz_success() && this.is_open_chargefy() == other.is_open_chargefy() && this.getPet_max_qh() == other.getPet_max_qh() && this.getCharge_money_fy() == other.getCharge_money_fy();
            }
        }
        else if (this$menpai_tab_xiaohao.equals(other$menpai_tab_xiaohao)) {
            return this.getMax_menpai_tab_num() == other.getMax_menpai_tab_num() && this.getMax_request_count() == other.getMax_request_count() && this.getGoods_jinhua_max() == other.getGoods_jinhua_max() && Double.compare(this.getFs_bs_bei(), other.getFs_bs_bei()) == 0 && Double.compare(this.getFa_panel_bei(), other.getFa_panel_bei()) == 0 && Double.compare(this.getWu_panel_bei(), other.getWu_panel_bei()) == 0 && Double.compare(this.getXue_panel_bei(), other.getXue_panel_bei()) == 0 && Double.compare(this.getLan_panel_bei(), other.getLan_panel_bei()) == 0 && Double.compare(this.getSu_panel_bei(), other.getSu_panel_bei()) == 0 && Double.compare(this.getFang_panel_bei(), other.getFang_panel_bei()) == 0 && Double.compare(this.getPet_fa_panel_bei(), other.getPet_fa_panel_bei()) == 0 && Double.compare(this.getPet_wu_panel_bei(), other.getPet_wu_panel_bei()) == 0 && Double.compare(this.getPet_xue_panel_bei(), other.getPet_xue_panel_bei()) == 0 && Double.compare(this.getPet_lan_panel_bei(), other.getPet_lan_panel_bei()) == 0 && Double.compare(this.getPet_su_panel_bei(), other.getPet_su_panel_bei()) == 0 && Double.compare(this.getPet_fang_panel_bei(), other.getPet_fang_panel_bei()) == 0 && this.getSs_qh_addvalue() == other.getSs_qh_addvalue() && this.getCard_time() == other.getCard_time() && this.isZb_gz_success() == other.isZb_gz_success() && this.is_open_chargefy() == other.is_open_chargefy() && this.getPet_max_qh() == other.getPet_max_qh() && this.getCharge_money_fy() == other.getCharge_money_fy();
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof otherConfig;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $pet_max_level = this.getPet_max_level();
        result = result * 59 + (($pet_max_level == null) ? 43 : $pet_max_level.hashCode());
        final Object $persion_max_level = this.getPersion_max_level();
        result = result * 59 + (($persion_max_level == null) ? 43 : $persion_max_level.hashCode());
        final Object $yy_max_level = this.getYy_max_level();
        result = result * 59 + (($yy_max_level == null) ? 43 : $yy_max_level.hashCode());
        final Object $fy_length = this.getFy_length();
        result = result * 59 + (($fy_length == null) ? 43 : $fy_length.hashCode());
        final Object $fy_char = this.getFy_char();
        result = result * 59 + (($fy_char == null) ? 43 : $fy_char.hashCode());
        final Object $fy_replace = this.getFy_replace();
        result = result * 59 + (($fy_replace == null) ? 43 : $fy_replace.hashCode());
        final Object $fy_level = this.getFy_level();
        result = result * 59 + (($fy_level == null) ? 43 : $fy_level.hashCode());
        final long $cj_time = Double.doubleToLongBits(this.getCj_time());
        result = result * 59 + (int)($cj_time >>> 32 ^ $cj_time);
        final Object $wudao_xiaohaos = this.getWudao_xiaohaos();
        result = result * 59 + (($wudao_xiaohaos == null) ? 43 : $wudao_xiaohaos.hashCode());
        final Object $wudao_shuxings = this.getWudao_shuxings();
        result = result * 59 + (($wudao_shuxings == null) ? 43 : $wudao_shuxings.hashCode());
        result = result * 59 + (this.isOpenRank() ? 79 : 97);
        result = result * 59 + (this.isOpenWuxing() ? 79 : 97);
        final Object $wuxing_gailv = this.getWuxing_gailv();
        result = result * 59 + (($wuxing_gailv == null) ? 43 : $wuxing_gailv.hashCode());
        final Object $menpai_tab_xiaohao = this.getMenpai_tab_xiaohao();
        result = result * 59 + (($menpai_tab_xiaohao == null) ? 43 : $menpai_tab_xiaohao.hashCode());
        result = result * 59 + this.getMax_menpai_tab_num();
        result = result * 59 + this.getMax_request_count();
        result = result * 59 + this.getGoods_jinhua_max();
        final long $fs_bs_bei = Double.doubleToLongBits(this.getFs_bs_bei());
        result = result * 59 + (int)($fs_bs_bei >>> 32 ^ $fs_bs_bei);
        final long $fa_panel_bei = Double.doubleToLongBits(this.getFa_panel_bei());
        result = result * 59 + (int)($fa_panel_bei >>> 32 ^ $fa_panel_bei);
        final long $wu_panel_bei = Double.doubleToLongBits(this.getWu_panel_bei());
        result = result * 59 + (int)($wu_panel_bei >>> 32 ^ $wu_panel_bei);
        final long $xue_panel_bei = Double.doubleToLongBits(this.getXue_panel_bei());
        result = result * 59 + (int)($xue_panel_bei >>> 32 ^ $xue_panel_bei);
        final long $lan_panel_bei = Double.doubleToLongBits(this.getLan_panel_bei());
        result = result * 59 + (int)($lan_panel_bei >>> 32 ^ $lan_panel_bei);
        final long $su_panel_bei = Double.doubleToLongBits(this.getSu_panel_bei());
        result = result * 59 + (int)($su_panel_bei >>> 32 ^ $su_panel_bei);
        final long $fang_panel_bei = Double.doubleToLongBits(this.getFang_panel_bei());
        result = result * 59 + (int)($fang_panel_bei >>> 32 ^ $fang_panel_bei);
        final long $pet_fa_panel_bei = Double.doubleToLongBits(this.getPet_fa_panel_bei());
        result = result * 59 + (int)($pet_fa_panel_bei >>> 32 ^ $pet_fa_panel_bei);
        final long $pet_wu_panel_bei = Double.doubleToLongBits(this.getPet_wu_panel_bei());
        result = result * 59 + (int)($pet_wu_panel_bei >>> 32 ^ $pet_wu_panel_bei);
        final long $pet_xue_panel_bei = Double.doubleToLongBits(this.getPet_xue_panel_bei());
        result = result * 59 + (int)($pet_xue_panel_bei >>> 32 ^ $pet_xue_panel_bei);
        final long $pet_lan_panel_bei = Double.doubleToLongBits(this.getPet_lan_panel_bei());
        result = result * 59 + (int)($pet_lan_panel_bei >>> 32 ^ $pet_lan_panel_bei);
        final long $pet_su_panel_bei = Double.doubleToLongBits(this.getPet_su_panel_bei());
        result = result * 59 + (int)($pet_su_panel_bei >>> 32 ^ $pet_su_panel_bei);
        final long $pet_fang_panel_bei = Double.doubleToLongBits(this.getPet_fang_panel_bei());
        result = result * 59 + (int)($pet_fang_panel_bei >>> 32 ^ $pet_fang_panel_bei);
        result = result * 59 + this.getSs_qh_addvalue();
        result = result * 59 + this.getCard_time();
        result = result * 59 + (this.isZb_gz_success() ? 79 : 97);
        result = result * 59 + (this.is_open_chargefy() ? 79 : 97);
        result = result * 59 + this.getPet_max_qh();
        result = result * 59 + this.getCharge_money_fy();
        return result;
    }
    
    @Override
    public String toString() {
        return "otherConfig(pet_max_level=" + this.getPet_max_level() + ", persion_max_level=" + this.getPersion_max_level() + ", yy_max_level=" + this.getYy_max_level() + ", fy_length=" + this.getFy_length() + ", fy_char=" + this.getFy_char() + ", fy_replace=" + this.getFy_replace() + ", fy_level=" + this.getFy_level() + ", cj_time=" + this.getCj_time() + ", wudao_xiaohaos=" + this.getWudao_xiaohaos() + ", wudao_shuxings=" + this.getWudao_shuxings() + ", openRank=" + this.isOpenRank() + ", openWuxing=" + this.isOpenWuxing() + ", wuxing_gailv=" + this.getWuxing_gailv() + ", menpai_tab_xiaohao=" + this.getMenpai_tab_xiaohao() + ", max_menpai_tab_num=" + this.getMax_menpai_tab_num() + ", max_request_count=" + this.getMax_request_count() + ", goods_jinhua_max=" + this.getGoods_jinhua_max() + ", fs_bs_bei=" + this.getFs_bs_bei() + ", fa_panel_bei=" + this.getFa_panel_bei() + ", wu_panel_bei=" + this.getWu_panel_bei() + ", xue_panel_bei=" + this.getXue_panel_bei() + ", lan_panel_bei=" + this.getLan_panel_bei() + ", su_panel_bei=" + this.getSu_panel_bei() + ", fang_panel_bei=" + this.getFang_panel_bei() + ", pet_fa_panel_bei=" + this.getPet_fa_panel_bei() + ", pet_wu_panel_bei=" + this.getPet_wu_panel_bei() + ", pet_xue_panel_bei=" + this.getPet_xue_panel_bei() + ", pet_lan_panel_bei=" + this.getPet_lan_panel_bei() + ", pet_su_panel_bei=" + this.getPet_su_panel_bei() + ", pet_fang_panel_bei=" + this.getPet_fang_panel_bei() + ", ss_qh_addvalue=" + this.getSs_qh_addvalue() + ", card_time=" + this.getCard_time() + ", zb_gz_success=" + this.isZb_gz_success() + ", is_open_chargefy=" + this.is_open_chargefy() + ", pet_max_qh=" + this.getPet_max_qh() + ", charge_money_fy=" + this.getCharge_money_fy() + ")";
    }
}
