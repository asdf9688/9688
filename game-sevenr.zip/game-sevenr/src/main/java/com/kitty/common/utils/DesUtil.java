package com.kitty.common.utils;


import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;

public class DesUtil {
//    public static String byteArr2HexStr(byte[] bArr) throws Exception {
//        StringBuffer stringBuffer = new StringBuffer(bArr.length * 2);
//        for (int i : bArr) {
//            int i2 = 0;
//            while (i2 < 0) {
//                i2 += 256;
//            }
//            if (i2 < 16) {
//                stringBuffer.append("0");
//            }
//            stringBuffer.append(Integer.toString(i2, 16));
//        }
//        return stringBuffer.toString();
//
//    }

    public static String byteArr2HexStr(byte[] arrB) throws Exception {
        int iLen = arrB.length;
        // 每个byte用两个字符才能表示，所以字符串的长度是数组长度的两倍
        StringBuffer sb = new StringBuffer(iLen * 2);
        for (int i = 0; i < iLen; i++) {
            int intTmp = arrB[i];
            // 把负数转换为正数
            while (intTmp < 0) {
                intTmp = intTmp + 256;
            }
            // 小于0F的数需要在前面补0
            if (intTmp < 16) {
                sb.append("0");
            }
            sb.append(Integer.toString(intTmp, 16));
        }
        return sb.toString();
    }

    public static String decrypt(String str, String str2) {
        try {
            byte[] bytes = hexStr2ByteArr(str);
            return new String(decrypt(bytes, getKey(str2.getBytes())));
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static byte[] decrypt(byte[] bArr, Key key) throws Exception {
        Cipher instance = Cipher.getInstance("DES");
        instance.init(2, key);
        return instance.doFinal(bArr);
    }

    public static String encrypt(String str, String str2) {
        try {
            byte[] bytes = encrypt(str.getBytes(), getKey(str2.getBytes()));
            return byteArr2HexStr(bytes);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static byte[] encrypt(byte[] bArr, Key key) throws Exception {
        Cipher instance = Cipher.getInstance("DES");
        instance.init(1, key);
        return instance.doFinal(bArr);
    }

    private static Key getKey(byte[] bArr) {
        byte[] bArr2 = new byte[8];
        int i = 0;
        while (i < bArr.length && i < bArr2.length) {
            bArr2[i] = bArr[i];
            i++;
        }
        return new SecretKeySpec(bArr2, "DES");
    }

    public static byte[] hexStr2ByteArr(String str) throws Exception {
        byte[] bytes = str.getBytes();
        int length = bytes.length;
        byte[] bArr = new byte[(length / 2)];
        for (int i = 0; i < length; i += 2) {
            bArr[i / 2] = (byte) Integer.parseInt(new String(bytes, i, 2), 16);
        }
        return bArr;
    }
}
