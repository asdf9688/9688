package com.kitty.common.thread;

/**
 * @Description:标识一个容器组件为线程安全的
 */
public @interface ThreadSafe {

}
