package com.kitty.common.utils;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.security.Key;

public class AndroidDesUtil {

    public static final String SDK_STR = "{\"loginUrl\":\"http://%s:85\",\"payUrl\":\"http://%s:85\",\"accountUrl\":\"http://%s:85\",\"bbsUrl\":\"http://bbs.leiting.com\",\"helpUrl\":\"http://helper.leiting.com\",\"kernelUrl\":\"http://www.leiting.com\",\"logUrl\":\"http://tplog.leiting.com\",\"urlApis\":[{\"name\":\"login\",\"value\":\"/login/login.php\"},{\"name\":\"checkLogin\",\"value\":\"/login/mobile!mobileCheckLoginV3.php\"},{\"name\":\"fastRegister\",\"value\":\"/login/mobile!fastRegisterV2.action\"},{\"name\":\"payOrder\",\"value\":\"/terrace/phone_charge!createLeitingNo.action\"},{\"name\":\"getAdultInfo\",\"value\":\"/terrace/game_api/getIdCardBindInfo.htm\"}],\"channels\":[{\"name\":\"leiting\",\"value\":\"{\\\"guestLogin\\\":\\\"0\\\",\\\"payLevel\\\":\\\"1\\\",\\\"gmPhoneNum\\\":\\\"0592-3011618\\\"}\"}],\"plugs\":[{\"name\":\"qiyukf\",\"value\":\"{\\\"appKey\\\":\\\"b8c33a8308b536dc4fde7be133fc9835\\\",\\\"groupId\\\":\\\"354781\\\",\\\"robotId\\\":\\\"83373\\\"}\"},{\"name\":\"toutiao\",\"value\":\"{\\\"appId\\\":\\\"151304\\\",\\\"appName\\\":\\\"wendao\\\"}\"},{\"name\":\"wechath5\",\"value\":\"{\\\"payResult\\\":\\\"/terrace/phone_charge!searchResultByLeitingNo.action\\\",\\\"payResultChannel\\\":\\\"/terrace/notify_back!searchResultByLeitingNo.action\\\",\\\"payLoginResult\\\":\\\"/terrace/drm_charge!queryWechatPayResult.action\\\"}\"}],\"resValues\":[{\"name\":\"lt_realname_auth_toast_msg1\",\"value\":\"根据国家法规要求，您的账号信息尚未完善，请尽快完成实名认证以保障账号安全。\"}]}";


    public static void main(String[] args) throws IOException {
      System.out.println(getSdkWd("dx00.hhhwd.com"));
       /* System.out.println(getSdkWd("ce03.hi-wd.com"));
        ClassPathResource res = new ClassPathResource("sdkConfig.properties");
        final String path = "C:\\Users\\zgd\\Desktop\\sdkConfig.properties";//res.getURL().getPath();
        FileReader reader = new FileReader(path);
        BufferedReader br = new BufferedReader(reader);
        String str = br.readLine();
        while (str != null) {
            final String[] split = str.split("=");
            if (split.length == 1) {
                str = br.readLine();
                continue;
            }
            if (split[1].length() < 50) {
                str = br.readLine();
                continue;
            }
            System.out.println(split[0]);
            final String decrypt = decrypt(split[1], "548711fdc20a2129");
            System.out.println(decrypt);
            str = br.readLine();
        }
        final String decrypt = decrypt("662a14bd16bef3c6d5ab3e907fafed5c3bf5ee5b529e58d3492d275fafdd2f01ed91452272d65bb69ec9d9b98d6efbd720aa1a1048adc7858a9862c24fe2e720caedefc6a61164c1e1dbe51c0b5de3e21738a0fe6c22c437748b7bd5217bcff0181353d9676600e9a02846b725d55037777a9af10ad26fded7b9d0ee3f509f30e27aaba790b98dc64827a053ab834371ba886168f9d3e1930e59a4299782e08438df625b987431df6dd7c6322e819b1132f49b2181daff72de28ede84446aaf204f926b6e409def1185bd09cac1f3d29bda1bf4b1baab3417f230371e0b0ef9134ec5167293d3aaba17161018c347432a575e912b64503934dee9fb0a48d70483e85a1bd7e1110c0a107335d3c76b34b29ae1ff5e5e44fb38aa4456048c2579dee006cca49c4acb5b370b23381049be3cc2f5d8b628c22bedc0ed9a40697bf3136e274ce6c22968c120854ff2317d17ae5c9103dee03c7a8512cfcd93b5ccefd74cd293f62781c5d0c4f9c354615bdca16e96da053ad097962af53197e3b71600c5e9915ca931f6fc968d5196ffb294b0799357c737eea718034d6c8402d5a596cdbeb2e6325d9a0cc2f5d8b628c22bea92057cc73b473c164b9cc195ed366852d397bc70c6aa5eb5eacda8d28680c376430a1f259796f6ffd81abf2abaca4da6e649e8285dbf9e91e06282cb6a360ab388118f1ee4c306332512246b5e2f49ecac0149de273a1f9412ccce7457ab94257be42c1ad289fd0efab02e81b32d54f43d5021d2ebdcdbf21ab04bf3ceb1c35dd40758b6d6e9ba474cd293f62781c5d6ef5db3d43371cde1564aac9551d326f5dd3ce7e5c37f2694dd1e4ed6cbe422851843187c93648d057dcc70741c4bdcbc41fe4658807cd360799357c737eea71c9ad7e1db473c621ce41ceab8b526a0415ac5883527b3849c8ceb95635bf882a5676f8c781238594f682e31f34e3b9136f1550ddc77a70e67441df8d89aba64b9582df1c329d8103ae0179bf70525476f99bdf9ef7261fba67ca1df339d7190eeceeaa10d6631fed43d5021d2ebdcdbfab16dbbd40396b2bce41ceab8b526a047affcc4dd9a800251b50ac8f0ff80c588d48c00576e162148b0c76c007cadb2ad8b09c67470a2ad368640d67199a91a548764c6f331283f97ac5dd4ab67a8146fe17a84ddf5e704e1aabec46e43ef94633520355cafc8cd2274a57479d652b9f1044a21099fb6a705b4dbb75eda27ff862dff55add15d6051c3dd01762eb9ec179251a9731166f5948dc9fc652b82b8473a91c358316d1cc6ada70b7450dbe4a615f4877be2bccea8f9f858cf7f47c23a2218ad6bb27c6601e0baaa7736e501ace41ceab8b526a04545ea21914891ca4fa9191fb6ebda8b01021501a428d541c2f6ebf9896a9717a64e42876c093e0f23b92350ec577f06a4ca5f9223b230e858041c866b70bc2cc611684efa0016165ee91dfd89cb25d62245278755853023a4bb35501a42b0d19388118f1ee4c30635d5f172677e44a67de045a04b3f0cb679e0a7a48fb5aaba69ca6220a8b39bc392466885409327b27de1c408fbfea7f6c33f6a94f262847d312ebe1aac6cc5bb59a93f787c7924dbfb4d1e17cc66a75dd275b119e75052515defe16f2558ba7fbd6f864b9665a2b7a5a53074e4087f679b590be0dba27fad2de13ddb89ebd8020c84248750eac46ac0799357c737eea71a6d216915e90fb36622dc7dba3b5430b278c9dcd9c8faa852b7c20db214c8a1d3f46085e526340332a2da511e43acfe52c1df729704745201c9c7a9e52969dda45ca7f9ee21a55a96fa86950f9a835987b90ca03ad4c16865178039ffe283f46d84776185c5a2df3a67ecb784eafc800d8c979d260a466e48214c1020af2b232ec6850304a658357191260650ce51f3236cb0df0870f7eb533bbee3b6278888c", "548711fdc20a2129");
        System.out.println(decrypt);
        final String dec = decrypt("662a14bd16bef3c6d5ab3e907fafed5c1a7de22e32b6de8f360958722191ae7dbc9e40727ab853d1ed91452272d65bb69ec9d9b98d6efbd720aa1a1048adc78534b2a2ed79e086570c36ec3497093cbe1cdb6047ebdb8e7fe1dbe51c0b5de3e21738a0fe6c22c437748b7bd5217bcff0181353d9676600e942cc24affd01d99d7e7806e9e5197dc2f5aa1eed0ce84905ed91452272d65bb66291ec485b459bea20aa1a1048adc785bea7fc44d6ca473e41df3e595ef3055ca6aafa9f69ea68314fa6ff04798621544dee9fb0a48d70481746fde8274a67fb0e59a4299782e084f91b59a2e3299d96148c8df8994d65374dee9fb0a48d7048856a749a35e4bc318c907508e93460f3351c2486f526a77f181353d9676600e96ab041df2300a762587b1a7fcf6fdf3364253bf778295bd31c03c46dd5ca1a8443d5021d2ebdcdbf644715c2ce1b17521e06282cb6a360ab736048598940baa136b398507cb4e9399144c36fff8b1206851bc86d4501ce7d329f089334a78113ce41ceab8b526a0402d593efa1c72f099232b3fe87b7b111aee9a44ea428e103083162771fff1fe1119f7e112d3e19fcb6661f981dc80c606fc8d890ace07f7770d711fc660e26a71e06282cb6a360ab736048598940baa15d6ee74de7c765d01ea6f124bc5ebab29f177ddd36691a82de9d2334270bc6c70799357c737eea71e18a703e8ddf95f319c003682442d52b8f13e776fd5ec6a52f6ebf9896a9717a64e42876c093e0f23fb5e228329efd858041c866b70bc2cc62d82209e08e0325120854ff2317d17a35ddbb181e71a3ad77cf46513279e6c0ce41ceab8b526a04c8b4cc31457a94a78bcf495a8144cda7b93abbb6b3efed0824991519cfba15535b2fb80ed036a3ebc8c485b29096c193a37546a28ceeedb55b6ca6042ea19d26ab75f1015aa8dbd9ed0ed04f90dae0fb74c57d7ed3e63bd7bdd06182469e60467cb3873dca6ac0a55e4ef90d64f2eed35d3dec221cccdae11d262dd79d3f4370912ad0f661d75fc44b10c4915ea06a9ead1797d161b3b9f07a5ed8d48ab2915d8fecddfef8ded6798e43824d3348fab657d9be3b8a715079ebba87e124962328f49b74bae499d0e1566eca76d758284c757c76b29586299d0f1cc9edf156826b8ef89db06de69fe888cc240c4fd21b8b0ae189b41ce5c1015c201d55e335ec0febaa2d0ba3b085e15a42cca4d288b396ed7b8981071dfa7ede06dbcdc197dabb3d7c2bd16b2331fcf84dd0ce22fd2f69e9ed09f9b734411b74cd293f62781c5d318d1be9715af1368222248328cbd01b5b44a50d407832b14399e05368bb93af4f36ea187674fd7fc516f6a46ffa806b43d5021d2ebdcdbf9396a4faa8ba8e2101c11d7b2bee848ddfa80d24fd3919969d189e40ce1214ff2b8046d221b8213046000eed5e15df403775f406fff33f45f767b0a13af60d3ed9142f13ec7b633fe5a7a57c11ecd087e0cbc9beb9688ccaac80fc4a86e1a31d6dbc22d96cb90bd4a4103032d38cd4a41021501a428d541ce8992e4b75c1429ea9906f215b00cfcb85ee86275ccecf42dd7601cf3859e24267a6c83a463d576ee7aa448150ca3c3b5ab8dfa82dbb19bd1f79264ffaa8ec91bb5cc17531533fc955cdbba76864c455329fc78b9a9c2951f8756ac034ca2c9613740c8dc1f63df8b2c1f7405c4323cbbe38102f776ec48db86e278009c7d64ee2c35c8cced60e5c5b6ca6042ea19d269e86018013ed896951e10bc213ae05cdf98e5545470436565070c86c9d35284b74cd293f62781c5d2466c3c4e61c59cc4efecca3ad40acb2c9d3fd49c9e967a8991e6017f996f09c9b4b34454d61843b06c468f316f69223735e851d5412930aac4bffb8dc173fc7bf03c84ea7ea4a6f04298f0c2a3a646c9837fc2d1da29a6dd2f2d7b41617d9767eccf5253deacae6e0d45cf1a4c35b314e8cb11a273c0ae0", "548711fdc20a2129");
        final String encrypt = encrypt("{\"loginUrl\":\"http://117.24.12.36:81/vip4\",\"payUrl\":\"http://117.24.12.36:81/vip4\",\"accountUrl\":\"http://117.24.12.36:81/vip4\",\"bbsUrl\":\"http://bbs.leiting.com\",\"helpUrl\":\"http://helper.leiting.com\",\"kernelUrl\":\"http://www.leiting.com\",\"logUrl\":\"http://tplog.leiting.com\",\"urlApis\":[{\"name\":\"login\",\"value\":\"/login/login.php\"},{\"name\":\"checkLogin\",\"value\":\"/login/mobile!mobileCheckLoginV3.php\"},{\"name\":\"fastRegister\",\"value\":\"/login/mobile!fastRegisterV2.action\"},{\"name\":\"payOrder\",\"value\":\"/terrace/phone_charge!createLeitingNo.action\"},{\"name\":\"getAdultInfo\",\"value\":\"/terrace/game_api/getIdCardBindInfo.htm\"}],\"channels\":[{\"name\":\"leiting\",\"value\":\"{\\\"guestLogin\\\":\\\"0\\\",\\\"payLevel\\\":\\\"1\\\",\\\"gmPhoneNum\\\":\\\"0592-3011618\\\"}\"}],\"plugs\":[{\"name\":\"qiyukf\",\"value\":\"{\\\"appKey\\\":\\\"b8c33a8308b536dc4fde7be133fc9835\\\",\\\"groupId\\\":\\\"354781\\\",\\\"robotId\\\":\\\"83373\\\"}\"},{\"name\":\"toutiao\",\"value\":\"{\\\"appId\\\":\\\"151304\\\",\\\"appName\\\":\\\"wendao\\\"}\"},{\"name\":\"wechath5\",\"value\":\"{\\\"payResult\\\":\\\"/terrace/phone_charge!searchResultByLeitingNo.action\\\",\\\"payResultChannel\\\":\\\"/terrace/notify_back!searchResultByLeitingNo.action\\\",\\\"payLoginResult\\\":\\\"/terrace/drm_charge!queryWechatPayResult.action\\\"}\"}],\"resValues\":[{\"name\":\"lt_realname_auth_toast_msg1\",\"value\":\"根据国家法规要求，您的账号信息尚未完善，请尽快完成实名认证以保障账号安全。\"}]}", "548711fdc20a2129");
        System.out.println(encrypt);
        final String encrypt = encrypt("{\"loginUrl\":\"http://117.24.12.36:81/vip4\",\"payUrl\":\"http://117.24.12.36:81/vip4\",\"accountUrl\":\"http://http://s.fiuwbjadshf.com:81/vip4\",\"bbsUrl\":\"http://bbs.leiting.com\",\"helpUrl\":\"http://helper.leiting.com\",\"kernelUrl\":\"http://www.leiting.com\",\"logUrl\":\"http://tplog.leiting.com\",\"urlApis\":[{\"name\":\"login\",\"value\":\"/login/login.php\"},{\"name\":\"checkLogin\",\"value\":\"/login/mobile!mobileCheckLoginV3.php\"},{\"name\":\"fastRegister\",\"value\":\"/login/mobile!fastRegisterV2.action\"},{\"name\":\"payOrder\",\"value\":\"/terrace/phone_charge!createLeitingNo.action\"},{\"name\":\"getAdultInfo\",\"value\":\"/terrace/game_api/getIdCardBindInfo.htm\"}],\"channels\":[{\"name\":\"leiting\",\"value\":\"{\\\"guestLogin\\\":\\\"0\\\",\\\"payLevel\\\":\\\"1\\\",\\\"gmPhoneNum\\\":\\\"0592-3011618\\\"}\"}],\"plugs\":[{\"name\":\"qiyukf\",\"value\":\"{\\\"appKey\\\":\\\"b8c33a8308b536dc4fde7be133fc9835\\\",\\\"groupId\\\":\\\"354781\\\",\\\"robotId\\\":\\\"83373\\\"}\"},{\"name\":\"toutiao\",\"value\":\"{\\\"appId\\\":\\\"151304\\\",\\\"appName\\\":\\\"wendao\\\"}\"},{\"name\":\"wechath5\",\"value\":\"{\\\"payResult\\\":\\\"/terrace/phone_charge!searchResultByLeitingNo.action\\\",\\\"payResultChannel\\\":\\\"/terrace/notify_back!searchResultByLeitingNo.action\\\",\\\"payLoginResult\\\":\\\"/terrace/drm_charge!queryWechatPayResult.action\\\"}\"}],\"resValues\":[{\"name\":\"lt_realname_auth_toast_msg1\",\"value\":\"根据国家法规要求，您的账号信息尚未完善，请尽快完成实名认证以保障账号安全。\"}]}", "548711fdc20a2129");
        System.out.println(encrypt);
        final String encrypt = encrypt("{\"loginUrl\":\"https://loginwd.leiting.com\",\"payUrl\":\"https://paywd.leiting.com\",\"accountUrl\":\"https://member.leiting.com\",\"bbsUrl\":\"http://bbs.leiting.com\",\"helpUrl\":\"http://helper.leiting.com\",\"kernelUrl\":\"http://www.leiting.com\",\"logUrl\":\"http://tplog.leiting.com\",\"urlApis\":[{\"name\":\"login\",\"value\":\"/login/mobile!sdkLogin.action\"},{\"name\":\"checkLogin\",\"value\":\"/login/mobile!sdkCheckLogin.action\"},{\"name\":\"fastRegister\",\"value\":\"/login/mobile!guestRegister.action\"},{\"name\":\"payOrder\",\"value\":\"/terrace/phone_charge!createLeitingNo.action\"},{\"name\":\"getAdultInfo\",\"value\":\"/terrace/game_api/getIdCardBindInfo.htm\"}],\"channels\":[{\"name\":\"leiting\",\"value\":\"{\\\"guestLogin\\\":\\\"1\\\",\\\"payLevel\\\":\\\"1\\\",\\\"gmPhoneNum\\\":\\\"0592-3011618\\\"}\"}],\"plugs\":[{\"name\":\"qiyukf\",\"value\":\"{\\\"appKey\\\":\\\"b8c33a8308b536dc4fde7be133fc9835\\\",\\\"groupId\\\":\\\"354781\\\",\\\"robotId\\\":\\\"83373\\\"}\"},{\"name\":\"toutiao\",\"value\":\"{\\\"appId\\\":\\\"151304\\\",\\\"appName\\\":\\\"wendao\\\"}\"},{\"name\":\"wechath5\",\"value\":\"{\\\"payResult\\\":\\\"/terrace/phone_charge!searchResultByLeitingNo.action\\\",\\\"payResultChannel\\\":\\\"/terrace/notify_back!searchResultByLeitingNo.action\\\",\\\"payLoginResult\\\":\\\"/terrace/drm_charge!queryWechatPayResult.action\\\"}\"}],\"resValues\":[{\"name\":\"lt_realname_auth_toast_msg1\",\"value\":\"根据国家法规要求，您的账号信息尚未完善，请尽快完成实名认证以保障账号安全。\"}]}\n", "548711fdc20a2129");
        System.out.println(encrypt);

        final String stararcEnc = encrypt(
                "{\"loginUrl\":\"http://117.24.12.36:81/vip4\",\"payUrl\":\"http://117.24.12.36:81/vip4\",\"accountUrl\":\"http://117.24.12.36:81/vip4\",\"bbsUrl\":\"http://bbs.leiting.com\",\"helpUrl\":\"http://helper.leiting.com\",\"kernelUrl\":\"http://www.leiting.com\",\"logUrl\":\"http://tplog.leiting.com\",\"urlApis\":[{\"name\":\"login\",\"value\":\"/login/login.php\"},{\"name\":\"checkLogin\",\"value\":\"/login/mobile!mobileCheckLoginV3.php\"},{\"name\":\"fastRegister\",\"value\":\"/login/mobile!fastRegisterV2.action\"},{\"name\":\"payOrder\",\"value\":\"/terrace/phone_charge!createLeitingNo.action\"},{\"name\":\"getAdultInfo\",\"value\":\"/terrace/game_api/getIdCardBindInfo.htm\"}],\"channels\":[{\"name\":\"leiting\",\"value\":\"{\\\"guestLogin\\\":\\\"0\\\",\\\"payLevel\\\":\\\"1\\\",\\\"gmPhoneNum\\\":\\\"0592-3011618\\\"}\"}],\"plugs\":[{\"name\":\"qiyukf\",\"value\":\"{\\\"appKey\\\":\\\"b8c33a8308b536dc4fde7be133fc9835\\\",\\\"groupId\\\":\\\"354781\\\",\\\"robotId\\\":\\\"83373\\\"}\"},{\"name\":\"toutiao\",\"value\":\"{\\\"appId\\\":\\\"151304\\\",\\\"appName\\\":\\\"wendao\\\"}\"},{\"name\":\"wechath5\",\"value\":\"{\\\"payResult\\\":\\\"/terrace/phone_charge!searchResultByLeitingNo.action\\\",\\\"payResultChannel\\\":\\\"/terrace/notify_back!searchResultByLeitingNo.action\\\",\\\"payLoginResult\\\":\\\"/terrace/drm_charge!queryWechatPayResult.action\\\"}\"}],\"resValues\":[{\"name\":\"lt_realname_auth_toast_msg1\",\"value\":\"根据国家法规要求，您的账号信息尚未完善，请尽快完成实名认证以保障账号安全。\"}]}",
                "548711fdc20a2129");
        //final String stararcEnc = encrypt("s.fiuwbjadshf.com","548711fdc20a2129");
        System.out.println(stararcEnc);*/
    }



    public static String byteArr2HexStr(byte[] paramArrayOfByte)
            throws Exception {
        int i = 0;
        int k = paramArrayOfByte.length;
        StringBuffer localStringBuffer = new StringBuffer(k * 2);
        while (i < k) {
            int j = paramArrayOfByte[i];
            while (j < 0) {
                j += 256;
            }
            if (j < 16) {
                localStringBuffer.append("0");
            }
            localStringBuffer.append(Integer.toString(j, 16));
            i += 1;
        }
        return localStringBuffer.toString();
    }

    public static String decrypt(String paramString1, String paramString2) {
        Key key = getKey(paramString2.getBytes());
        try {
            paramString1 = new String(decrypt(hexStr2ByteArr(paramString1), key));
            return paramString1;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static byte[] decrypt(byte[] paramArrayOfByte, Key paramKey)
            throws Exception {
        Cipher localCipher = Cipher.getInstance("DES");
        localCipher.init(2, paramKey);
        return localCipher.doFinal(paramArrayOfByte);
    }

    public static String encrypt(String paramString1, String paramString2) {
        Key key = getKey(paramString2.getBytes());
        try {
            paramString1 = byteArr2HexStr(encrypt(paramString1.getBytes(), key));
            return paramString1;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static byte[] encrypt(byte[] paramArrayOfByte, Key paramKey)
            throws Exception {
        Cipher localCipher = Cipher.getInstance("DES");
        localCipher.init(1, paramKey);
        return localCipher.doFinal(paramArrayOfByte);
    }

    private static Key getKey(byte[] paramArrayOfByte) {
        byte[] arrayOfByte = new byte[8];
        int i = 0;
        while ((i < paramArrayOfByte.length) && (i < arrayOfByte.length)) {
            arrayOfByte[i] = paramArrayOfByte[i];
            i += 1;
        }
        return new SecretKeySpec(arrayOfByte, "DES");
    }

    public static byte[] hexStr2ByteArr(String paramString)
            throws Exception {
        final byte[] bytes = paramString.getBytes();
        int i = 0;
        int j = bytes.length;
        byte[] arrayOfByte = new byte[j / 2];
        while (i < j) {
            String str = new String(bytes, i, 2);
            arrayOfByte[(i / 2)] = ((byte) Integer.parseInt(str, 16));
            i += 2;
        }
        return arrayOfByte;
    }

    public static String getSdkWd(String host) {
        return encrypt(String.format(SDK_STR, host, host, host), "548711fdc20a2129");
    }


}
