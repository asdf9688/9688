package com.kitty.common.utils;

import java.util.ArrayList;

public class PositionUtils {

    public static final ArrayList<Short> positions = new ArrayList<>();

    static {
        positions.add((short) 3);
        positions.add((short) 2);
        positions.add((short) 4);
        positions.add((short) 1);
        positions.add((short) 5);

        positions.add((short) 8);
        positions.add((short) 7);
        positions.add((short) 9);
        positions.add((short) 6);
        positions.add((short) 10);
    }

}
