package com.kitty.common.config;

import com.kitty.common.start.GameData;

import java.lang.reflect.Field;
import java.util.List;

public class ConfigUtil
{
    public static rewardConfig reward;
    public static startConfig start;
    public static renwuConfig renwu;
    public static regConfig reg;
    public static otherConfig other;
    
    public static void InitConfig() {
        try {
            ConfigUtil.start = LoadConfig(GameData.that.sysConfig.getSysConfigByParentKey("start-config"), startConfig.class);
            ConfigUtil.other = LoadConfig(GameData.that.sysConfig.getSysConfigByParentKey("other-config"), otherConfig.class);
            ConfigUtil.reg = LoadConfig(GameData.that.sysConfig.getSysConfigByParentKey("reg-config"), regConfig.class);
            ConfigUtil.renwu = LoadConfig(GameData.that.sysConfig.getSysConfigByParentKey("renwu-config"), renwuConfig.class);
            ConfigUtil.reward = LoadConfig(GameData.that.sysConfig.getSysConfigByParentKey("reward-config"), rewardConfig.class);
        }
        catch (Exception ex) {}
    }
    
    public static <T> T LoadConfig(List<SysConfig> sysConfigs,Class<T> toClass) throws Exception {
        final Field[] declaredFields = toClass.getDeclaredFields();
        final T config = toClass.newInstance();
        for (SysConfig sysConfig : sysConfigs) {
            for (Field field : declaredFields) {
                field.setAccessible(true);
                if (field.getName().equals(sysConfig.getKey())) {
                    String type = field.getType().toString();
                    Object value = null;
                    if (type.equals("class java.lang.String")) {
                        value = String.valueOf(sysConfig.getValue());
                    }
                    else if (type.equals("class java.lang.Integer")) {
                        value = Integer.valueOf(sysConfig.getValue());
                    }
                    else if (type.equals("int")) {
                        value = Integer.valueOf(sysConfig.getValue());
                    }
                    else if (type.equals("boolean")) {
                        value = Boolean.valueOf(sysConfig.getValue());
                    }
                    else if (type.equals("double")) {
                        value = Double.valueOf(sysConfig.getValue());
                    }
                    field.set(config, value);
                }
            }
        }
        return config;
    }
    
    public static void reloadConfig(String parentKey) {
        try {
            final List<SysConfig> sysConfigs = GameData.that.sysConfig.getSysConfigByParentKey(parentKey);
            if (parentKey.indexOf("start") != -1) {
                ConfigUtil.start = LoadConfig(sysConfigs, startConfig.class);
            }
            else if (parentKey.indexOf("other") != -1) {
                ConfigUtil.other = LoadConfig(sysConfigs, otherConfig.class);
            }
            else if (parentKey.indexOf("reg") != -1) {
                ConfigUtil.reg = LoadConfig(sysConfigs, regConfig.class);
            }
            else if (parentKey.indexOf("renwu") != -1) {
                ConfigUtil.renwu = LoadConfig(sysConfigs, renwuConfig.class);
            }
            else if (parentKey.indexOf("reward") != -1) {
                ConfigUtil.reward = LoadConfig(sysConfigs, rewardConfig.class);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
