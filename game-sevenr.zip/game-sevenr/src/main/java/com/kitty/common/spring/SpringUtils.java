package com.kitty.common.spring;

import com.kitty.cross.core.callback.CallBackService;
import com.kitty.game.activity.service.ActivityService;
import com.kitty.game.artifact.ArtifactService;
import com.kitty.game.boss.service.NewBossService;
import com.kitty.game.chat.service.ChatService;
import com.kitty.game.drop.service.DropService;
import com.kitty.game.equip.service.EquipService;
import com.kitty.game.fight.service.BroadcastService;
import com.kitty.game.fight.service.CountService;
import com.kitty.game.fight.service.FightMessageService;
import com.kitty.game.fight.service.FightService;
import com.kitty.game.friend.service.FriendService;
import com.kitty.game.guard.service.GuardService;
import com.kitty.game.identity.IdentityService;
import com.kitty.game.mail.service.MailService;
import com.kitty.game.map.service.MapService;
import com.kitty.game.mirror.service.FightMirrorService;
import com.kitty.game.npc.service.NewNpcService;
import com.kitty.game.party.service.PartyService;
import com.kitty.game.pet.service.PetService;
import com.kitty.game.player.PlayerService;
import com.kitty.game.rank.service.RankService;
import com.kitty.game.role.service.AccountService;
import com.kitty.game.role.service.RoleService;
import com.kitty.game.skill.service.SkillService;
import com.kitty.game.task.service.NewTaskService;
import com.kitty.game.team.service.TeamService;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import com.kitty.game.luoshu.service.LuoshuService;//洛书
import com.kitty.game.fuling.service.FulingService;//附灵

@Component
public class SpringUtils implements ApplicationContextAware {

    private static ApplicationContext applicationContext;


    private static SpringUtils self;


    @PostConstruct
    private void init() {
        self = this;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        SpringUtils.applicationContext = applicationContext;
    }


    /**
     * 获取applicationContext
     *
     * @return
     */
    public static ApplicationContext getApplicationContext() {
        return applicationContext;
    }


    /**
     * 通过name获取 Bean.
     *
     * @param name
     * @return
     */
    public static Object getBean(String name) {
        return getApplicationContext().getBean(name);
    }

    /**
     * 通过class获取Bean.
     *
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> T getBean(Class<T> clazz) {
        return getApplicationContext().getBean(clazz);
    }

    /**
     * 通过name,以及Clazz返回指定的Bean
     *
     * @param name
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> T getBean(String name, Class<T> clazz) {
        return getApplicationContext().getBean(name, clazz);
    }

    public static <T> Map<String, T> getBeansOfType(Class<T> var1) {
        return getApplicationContext().getBeansOfType(var1);
    }


    @Resource
    private RoleService roleService;

    public final static RoleService getRoleService() {
        return self.roleService;
    }
    
    @Resource
    private CountService countService;
    
    public final static CountService getHurtService() {
    	return self.countService;
    }

    @Resource
    private GuardService guardService;
    
    public final static GuardService getGuardService() {
    	return self.guardService;
    }
    
    @Resource
    private FightService fightService;
    
    public final static FightService getFightService() {
    	return self.fightService;
    }

    @Resource
    private EquipService equipService;
    
    public final static EquipService getEquipService() {
    	return self.equipService;
    }


    @Resource
    private PlayerService playerService;

    public final static PlayerService getPlayerService() {
        return self.playerService;
    }


    @Resource
    private PetService petService;

    public final static PetService getPetService() {
        return self.petService;
    }


    @Resource
    private SkillService skillService;

    public final static SkillService getSkillService() {
        return self.skillService;
    }

    @Resource
    private BroadcastService broadcastService;

    public final static BroadcastService getBroadcastService() {
        return self.broadcastService;
    }

    @Resource
    private MapService mapService;

    public final static MapService getMapService() {
        return self.mapService;
    }

    @Resource
    private TeamService teamService;

    public final static TeamService getTeamService() {return self.teamService; }

    @Resource
    private ChatService chatService;

    public final static ChatService getChatService() {return self.chatService; }

    @Resource
    private ActivityService activityService;

    public final static ActivityService getActivityService() {return self.activityService; }


    @Resource
    private NewNpcService npcService;

    public final static NewNpcService getNpcService() {return self.npcService; }

    @Resource
    private NewTaskService newTaskService;

    public final static NewTaskService getTaskService() {return self.newTaskService; }

    @Resource
    private FightMirrorService fightMirrorService;

    public final static FightMirrorService getMirrorService() {return self.fightMirrorService; }

    @Resource
    private IdentityService identityService;

    public final static IdentityService getIdentityService() {
        return self.identityService;
    }

    @Resource
    private FightMessageService fightMessageService;

    public final static FightMessageService getFightMessageService() {
        return self.fightMessageService;
    }

    @Resource
    private DropService dropService;

    public final static DropService getDropService() {return self.dropService; }

    @Resource
    private MailService mailService;

    public final static MailService getMailService() {return self.mailService; }

    @Resource
    private NewBossService bossService;

    public final static NewBossService getBossService() {return self.bossService; }

    @Resource
    private AccountService accountService;

    public final static AccountService getAccountService() {
        return self.accountService;
    }

    @Resource
    private RankService rankService;

    public final static RankService getRankService() {
        return self.rankService;
    }

    @Resource
    private ArtifactService artifactService;

    public final static ArtifactService getArtifactService() {
        return self.artifactService;
    }

    @Resource
    private PartyService partyService;

    public final static PartyService getPartyService() {
        return self.partyService;
    }

    @Resource
    private FriendService friendService;

    public final static FriendService getFriendService() {
        return self.friendService;
    }

    @Resource
    private CallBackService callBackService;

    public final static CallBackService getCallBackService() {
        return self.callBackService;
    }

    //附灵
    @Resource
    private FulingService fulingService;

    public static final FulingService getFulingService() {
        return self.fulingService;
    }
    //洛书
    @Resource
    private LuoshuService luoshuService;

    public static final LuoshuService getLuoshuService() {
        return self.luoshuService;
    }











}
