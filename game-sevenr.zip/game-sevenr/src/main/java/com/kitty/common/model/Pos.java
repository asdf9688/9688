package com.kitty.common.model;


/**
 * 角色位置对象
 */
public class Pos {
    private short x;
    private short y;
    private byte dir;
    private int mapId;

    public short getX() {
        return x;
    }

    public void setX(short x) {
        this.x = x;
    }

    public short getY() {
        return y;
    }

    public void setY(short y) {
        this.y = y;
    }

    public byte getDir() {
        return dir;
    }

    public void setDir(byte dir) {
        this.dir = dir;
    }

    public int getMapId() {
        return mapId;
    }

    public void setMapId(int mapId) {
        this.mapId = mapId;
    }

    public Pos(short x, short y, byte dir, int mapId) {
        this.x = x;
        this.y = y;
        this.dir = dir;
        this.mapId = mapId;
    }

    public Pos() {
        this.x = 22;
        this.y = 108;
        this.dir = 5;
        this.mapId = 1000;
    }
}
