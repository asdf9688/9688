//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.kitty.common.utils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.kitty.common.spring.SpringUtils;
import com.kitty.game.enter.TitleInfo;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.pet.model.Pet;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.PayService;
import com.kitty.game.role.service.RoleService;
import com.kitty.game.welfare.model.CommonFetchedData;
import com.kitty.mina.message.MessagePusher;
import org.nutz.dao.Chain;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;

@Service
public class GameUtil {

    @Autowired
    Dao dao;


    /** 缓存称号 **/
    private static String give_the_title ="";

    /** 初始化**/
    public void loadCommonSet() {
        CommonFetchedData commonFetchedData = dao.fetch(CommonFetchedData.class, "give_the_title");
        //初始化
        if(commonFetchedData==null){
            commonFetchedData =new CommonFetchedData("give_the_title","");
            dao.insert(commonFetchedData);
        }else {
            give_the_title = commonFetchedData.getData();
        }
    }


    public GameUtil() {
    }

    public void reward(Role role, String rewardStr, String resources) {
        if (rewardStr != null) {
            String[] rewards = rewardStr.split(",");
            String[] var4 = rewards;
            int var5 = rewards.length;

            for(int var6 = 0; var6 < var5; ++var6) {
                String reward = var4[var6];
                String[] r = reward.split("\\|");
                huodechoujiang(r, role, resources);
            }
        }
    }


    public void huodechoujiang(String[] strings, Role role, String resources) {
        RoleService roleService = SpringUtils.getRoleService();
        String[] split;
        String split3;
        if(strings.length>=1||strings.length>=4){
            if (strings[1].equals("永久称号")) {
                split = strings[0].split("#");
                TitleInfo titleInfo = new TitleInfo();
                titleInfo.setType(split[0]);
                titleInfo.setTitle(split[0]);
                SpringUtils.getRoleService().addTitle(role, titleInfo);
                if(strings.length>=4){
                    split3 = strings[2];
                    SpringUtils.getBean(PayService.class).jifen(role,Integer.parseInt(split3));
                    SpringUtils.getChatService().sendAdnotice("恭喜玩家#R" + role.getName() + "#n，获得#Y"+split[0]+"#n的称号,奖励#R"+split3+"#n积分,真是可喜可贺！！");
                }else{
                    SpringUtils.getChatService().sendAdnotice("恭喜玩家#R" + role.getName() + "#n，获得#Y"+split[0]+"#n的称号,真是可喜可贺！！");
                }
                give_the_title=give_the_title+"|"+split[0]+"|"+role.getName()+",";
                SpringUtils.getBean(GameUtil.class).updateFirstTitle();
            }
        }

        int currPetId = role.getTempCache("fight_current_pet_id", 0);
        if (strings[1].equals("经验")) {
            roleService.addExp(role, Integer.parseInt(strings[0]), role.getLevel() ,currPetId);
        }else if (strings[1].equals("积分")) {
            SpringUtils.getBean(PayService.class).jifen(role,Integer.parseInt(strings[0]));
        }else if (strings[1].equals("潜能")) {
            roleService.addPot(role, Integer.parseInt(strings[0]));
        }else if (strings[1].equals("道行")) {
            roleService.addTao(role, Integer.parseInt(strings[0]));
        }else if (strings[1].equals("武学")) {
            Pet pet = SpringUtils.getPetService().getPetById(role.getPetBox().getFightPetId()!=0?role.getPetBox().getFightPetId():currPetId, role);
            if (pet != null) {
                roleService.addPetMatiral(role, pet, Integer.parseInt(strings[0]));
            }
        }else if(strings[1].equals("代金卷")){
            roleService.addVoucher(role, Integer.parseInt(strings[0]));
            MessagePusher.pushMessage(role, new RespNotifyMiscEx("获得代金卷:#R"+strings[0]+"#n"));
        }else if(strings[1].equals("金钱")){
            roleService.addMoney(role, Integer.parseInt(strings[0]));
        }
    }


    public void updateFirstTitle(){
        dao.update(CommonFetchedData.class, Chain.make("data",give_the_title), Cnd.where("type","=","give_the_title"));
    }
}
