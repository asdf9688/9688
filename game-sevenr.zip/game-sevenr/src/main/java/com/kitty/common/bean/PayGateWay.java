package com.kitty.common.bean;

import lombok.Data;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

import java.util.Date;

@Table("pay_gateway")
@Data
public class PayGateWay {
    @Id
    private long id;
    @Column
    private String account;
    @Column
    private long money;
    @Column
    private int rmb;
    @Column
    private Date create_time;
    @Column
    private Date update_time;
    @Column
    private int state;
    @Column
    private String orderid;
}
