package com.kitty.common.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 数据库config配置 每天5点刷新
 */
@Component("renwuConfig")
@ConfigurationProperties(prefix = "renwu-config")
@Data
public class renwuConfig
{
    private Integer resetTime;
    private Integer pkguaiwuNum;
    private Integer shimenNum;
    private Integer fubenNum;
    private Integer tttNum;
    private Integer tttTp;
    private Integer chubaoNum;
    private Integer xiuxingNum;
    private Integer shuadaoNum;
    private Integer baibangmangNum;
    private Integer baxianNum;
    private Integer fabaoNum;
    private String petfly;
    private String persionfly;
    private String shidaoDays;
    private Integer shidao_min_level;
    private String shidaoTimes;
    private String shidaojdTimes;
    private boolean shidaodebug;
    private String boss_flush_time;
    private int partyNum;
    public String taskMap;
    public int licai_Sigin;
    public int partyFightNum;
    public int party_large_amount;
    public int party_small_amount;
    public int zhengdaodiancishu;//证道殿挑战次数
    public int mapguardcishu; //地图守护神
    private int pkdaohang;
    private int pkqianneng;
    private int pkjingyan;
    private int pkjifen;
    private int haidaocishu; //海盗次数
    private int shanggucishu;//上古次数
    private int leaderTodayFailNum;//掌门挑战次数
    private int xingtiaozhancishu;//星挑战次数
    private int gongchengbooscishu;//攻城boos挑战次数
    private int heropubcishu;//英雄会次数
    private int laofangtime;//坐牢结束时间

    
    public Integer getResetTime() {
        return this.resetTime;
    }
    
    public Integer getPkguaiwuNum() {
        return this.pkguaiwuNum;
    }
    
    public Integer getShimenNum() {
        return this.shimenNum;
    }
    
    public Integer getFubenNum() {
        return this.fubenNum;
    }
    
    public Integer getTttNum() {
        return this.tttNum;
    }
    
    public Integer getTttTp() {
        return this.tttTp;
    }
    
    public Integer getChubaoNum() {
        return this.chubaoNum;
    }
    
    public Integer getXiuxingNum() {
        return this.xiuxingNum;
    }
    
    public Integer getShuadaoNum() {
        return this.shuadaoNum;
    }
    
    public Integer getBaibangmangNum() {
        return this.baibangmangNum;
    }
    
    public Integer getBaxianNum() {
        return this.baxianNum;
    }
    
    public Integer getFabaoNum() {
        return this.fabaoNum;
    }
    
    public String getPetfly() {
        return this.petfly;
    }
    
    public String getPersionfly() {
        return this.persionfly;
    }
    
    public String getShidaoDays() {
        return this.shidaoDays;
    }
    
    public Integer getShidao_min_level() {
        return this.shidao_min_level;
    }
    
    public String getShidaoTimes() {
        return this.shidaoTimes;
    }
    
    public String getShidaojdTimes() {
        return this.shidaojdTimes;
    }
    
    public boolean isShidaodebug() {
        return this.shidaodebug;
    }
    
    public String getBoss_flush_time() {
        return this.boss_flush_time;
    }
    
    public void setResetTime(final Integer resetTime) {
        this.resetTime = resetTime;
    }
    
    public void setPkguaiwuNum(final Integer pkguaiwuNum) {
        this.pkguaiwuNum = pkguaiwuNum;
    }
    
    public void setShimenNum(final Integer shimenNum) {
        this.shimenNum = shimenNum;
    }
    
    public void setFubenNum(final Integer fubenNum) {
        this.fubenNum = fubenNum;
    }
    
    public void setTttNum(final Integer tttNum) {
        this.tttNum = tttNum;
    }
    
    public void setTttTp(final Integer tttTp) {
        this.tttTp = tttTp;
    }
    
    public void setChubaoNum(final Integer chubaoNum) {
        this.chubaoNum = chubaoNum;
    }
    
    public void setXiuxingNum(final Integer xiuxingNum) {
        this.xiuxingNum = xiuxingNum;
    }
    
    public void setShuadaoNum(final Integer shuadaoNum) {
        this.shuadaoNum = shuadaoNum;
    }
    
    public void setBaibangmangNum(final Integer baibangmangNum) {
        this.baibangmangNum = baibangmangNum;
    }
    
    public void setBaxianNum(final Integer baxianNum) {
        this.baxianNum = baxianNum;
    }
    
    public void setFabaoNum(final Integer fabaoNum) {
        this.fabaoNum = fabaoNum;
    }
    
    public void setPetfly(final String petfly) {
        this.petfly = petfly;
    }
    
    public void setPersionfly(final String persionfly) {
        this.persionfly = persionfly;
    }
    
    public void setShidaoDays(final String shidaoDays) {
        this.shidaoDays = shidaoDays;
    }
    
    public void setShidao_min_level(final Integer shidao_min_level) {
        this.shidao_min_level = shidao_min_level;
    }
    
    public void setShidaoTimes(final String shidaoTimes) {
        this.shidaoTimes = shidaoTimes;
    }
    
    public void setShidaojdTimes(final String shidaojdTimes) {
        this.shidaojdTimes = shidaojdTimes;
    }
    
    public void setShidaodebug(final boolean shidaodebug) {
        this.shidaodebug = shidaodebug;
    }
    
    public void setBoss_flush_time(final String boss_flush_time) {
        this.boss_flush_time = boss_flush_time;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof renwuConfig)) {
            return false;
        }
        final renwuConfig other = (renwuConfig)o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$resetTime = this.getResetTime();
        final Object other$resetTime = other.getResetTime();
        Label_0065: {
            if (this$resetTime == null) {
                if (other$resetTime == null) {
                    break Label_0065;
                }
            }
            else if (this$resetTime.equals(other$resetTime)) {
                break Label_0065;
            }
            return false;
        }
        final Object this$pkguaiwuNum = this.getPkguaiwuNum();
        final Object other$pkguaiwuNum = other.getPkguaiwuNum();
        Label_0102: {
            if (this$pkguaiwuNum == null) {
                if (other$pkguaiwuNum == null) {
                    break Label_0102;
                }
            }
            else if (this$pkguaiwuNum.equals(other$pkguaiwuNum)) {
                break Label_0102;
            }
            return false;
        }
        final Object this$shimenNum = this.getShimenNum();
        final Object other$shimenNum = other.getShimenNum();
        Label_0139: {
            if (this$shimenNum == null) {
                if (other$shimenNum == null) {
                    break Label_0139;
                }
            }
            else if (this$shimenNum.equals(other$shimenNum)) {
                break Label_0139;
            }
            return false;
        }
        final Object this$fubenNum = this.getFubenNum();
        final Object other$fubenNum = other.getFubenNum();
        Label_0176: {
            if (this$fubenNum == null) {
                if (other$fubenNum == null) {
                    break Label_0176;
                }
            }
            else if (this$fubenNum.equals(other$fubenNum)) {
                break Label_0176;
            }
            return false;
        }
        final Object this$tttNum = this.getTttNum();
        final Object other$tttNum = other.getTttNum();
        Label_0213: {
            if (this$tttNum == null) {
                if (other$tttNum == null) {
                    break Label_0213;
                }
            }
            else if (this$tttNum.equals(other$tttNum)) {
                break Label_0213;
            }
            return false;
        }
        final Object this$tttTp = this.getTttTp();
        final Object other$tttTp = other.getTttTp();
        Label_0250: {
            if (this$tttTp == null) {
                if (other$tttTp == null) {
                    break Label_0250;
                }
            }
            else if (this$tttTp.equals(other$tttTp)) {
                break Label_0250;
            }
            return false;
        }
        final Object this$chubaoNum = this.getChubaoNum();
        final Object other$chubaoNum = other.getChubaoNum();
        Label_0287: {
            if (this$chubaoNum == null) {
                if (other$chubaoNum == null) {
                    break Label_0287;
                }
            }
            else if (this$chubaoNum.equals(other$chubaoNum)) {
                break Label_0287;
            }
            return false;
        }
        final Object this$xiuxingNum = this.getXiuxingNum();
        final Object other$xiuxingNum = other.getXiuxingNum();
        Label_0324: {
            if (this$xiuxingNum == null) {
                if (other$xiuxingNum == null) {
                    break Label_0324;
                }
            }
            else if (this$xiuxingNum.equals(other$xiuxingNum)) {
                break Label_0324;
            }
            return false;
        }
        final Object this$shuadaoNum = this.getShuadaoNum();
        final Object other$shuadaoNum = other.getShuadaoNum();
        Label_0361: {
            if (this$shuadaoNum == null) {
                if (other$shuadaoNum == null) {
                    break Label_0361;
                }
            }
            else if (this$shuadaoNum.equals(other$shuadaoNum)) {
                break Label_0361;
            }
            return false;
        }
        final Object this$baibangmangNum = this.getBaibangmangNum();
        final Object other$baibangmangNum = other.getBaibangmangNum();
        Label_0398: {
            if (this$baibangmangNum == null) {
                if (other$baibangmangNum == null) {
                    break Label_0398;
                }
            }
            else if (this$baibangmangNum.equals(other$baibangmangNum)) {
                break Label_0398;
            }
            return false;
        }
        final Object this$baxianNum = this.getBaxianNum();
        final Object other$baxianNum = other.getBaxianNum();
        Label_0435: {
            if (this$baxianNum == null) {
                if (other$baxianNum == null) {
                    break Label_0435;
                }
            }
            else if (this$baxianNum.equals(other$baxianNum)) {
                break Label_0435;
            }
            return false;
        }
        final Object this$fabaoNum = this.getFabaoNum();
        final Object other$fabaoNum = other.getFabaoNum();
        Label_0472: {
            if (this$fabaoNum == null) {
                if (other$fabaoNum == null) {
                    break Label_0472;
                }
            }
            else if (this$fabaoNum.equals(other$fabaoNum)) {
                break Label_0472;
            }
            return false;
        }
        final Object this$petfly = this.getPetfly();
        final Object other$petfly = other.getPetfly();
        Label_0509: {
            if (this$petfly == null) {
                if (other$petfly == null) {
                    break Label_0509;
                }
            }
            else if (this$petfly.equals(other$petfly)) {
                break Label_0509;
            }
            return false;
        }
        final Object this$persionfly = this.getPersionfly();
        final Object other$persionfly = other.getPersionfly();
        Label_0546: {
            if (this$persionfly == null) {
                if (other$persionfly == null) {
                    break Label_0546;
                }
            }
            else if (this$persionfly.equals(other$persionfly)) {
                break Label_0546;
            }
            return false;
        }
        final Object this$shidaoDays = this.getShidaoDays();
        final Object other$shidaoDays = other.getShidaoDays();
        Label_0583: {
            if (this$shidaoDays == null) {
                if (other$shidaoDays == null) {
                    break Label_0583;
                }
            }
            else if (this$shidaoDays.equals(other$shidaoDays)) {
                break Label_0583;
            }
            return false;
        }

        final Object this$pkdaohang = this.getPkdaohang();
        final Object other$pkdaohang = other.getPkdaohang();
        Label_0770: {
            if (this$pkdaohang == null) {
                if (this$pkdaohang == null) {
                    break Label_0770;
                }
            }
            else if (other$pkdaohang.equals(other$pkdaohang)) {
                break Label_0770;
            }
            return false;
        }

        final Object this$pkjingyan = this.getPkjingyan();
        final Object other$pkjingyan = other.getPkjingyan();
        Label_0771: {
            if (this$pkjingyan == null) {
                if (this$pkjingyan == null) {
                    break Label_0771;
                }
            }
            else if (other$pkjingyan.equals(other$pkjingyan)) {
                break Label_0771;
            }
            return false;
        }

        final Object this$pkqianneng = this.getPkqianneng();
        final Object other$pkqianneng = other.getPkqianneng();
        Label_0772: {
            if (this$pkqianneng == null) {
                if (this$pkqianneng == null) {
                    break Label_0772;
                }
            }
            else if (other$pkqianneng.equals(other$pkqianneng)) {
                break Label_0772;
            }
            return false;
        }

        final Object this$pkjifen = this.getPkjifen();
        final Object other$pkjifen = other.getPkjifen();
        Label_0773: {
            if (this$pkjifen == null) {
                if (this$pkjifen == null) {
                    break Label_0773;
                }
            }
            else if (other$pkjifen.equals(other$pkjifen)) {
                break Label_0773;
            }
            return false;
        }


        final Object this$shidao_min_level = this.getShidao_min_level();
        final Object other$shidao_min_level = other.getShidao_min_level();
        Label_0620: {
            if (this$shidao_min_level == null) {
                if (other$shidao_min_level == null) {
                    break Label_0620;
                }
            }
            else if (this$shidao_min_level.equals(other$shidao_min_level)) {
                break Label_0620;
            }
            return false;
        }
        final Object this$shidaoTimes = this.getShidaoTimes();
        final Object other$shidaoTimes = other.getShidaoTimes();
        Label_0657: {
            if (this$shidaoTimes == null) {
                if (other$shidaoTimes == null) {
                    break Label_0657;
                }
            }
            else if (this$shidaoTimes.equals(other$shidaoTimes)) {
                break Label_0657;
            }
            return false;
        }
        final Object this$shidaojdTimes = this.getShidaojdTimes();
        final Object other$shidaojdTimes = other.getShidaojdTimes();
        Label_0694: {
            if (this$shidaojdTimes == null) {
                if (other$shidaojdTimes == null) {
                    break Label_0694;
                }
            }
            else if (this$shidaojdTimes.equals(other$shidaojdTimes)) {
                break Label_0694;
            }
            return false;
        }
        if (this.isShidaodebug() != other.isShidaodebug()) {
            return false;
        }
        final Object this$boss_flush_time = this.getBoss_flush_time();
        final Object other$boss_flush_time = other.getBoss_flush_time();
        if (this$boss_flush_time == null) {
            if (other$boss_flush_time == null) {
                return true;
            }
        }
        else if (this$boss_flush_time.equals(other$boss_flush_time)) {
            return true;
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof renwuConfig;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $resetTime = this.getResetTime();
        result = result * 59 + (($resetTime == null) ? 43 : $resetTime.hashCode());
        final Object $pkguaiwuNum = this.getPkguaiwuNum();
        result = result * 59 + (($pkguaiwuNum == null) ? 43 : $pkguaiwuNum.hashCode());
        final Object $shimenNum = this.getShimenNum();
        result = result * 59 + (($shimenNum == null) ? 43 : $shimenNum.hashCode());
        final Object $fubenNum = this.getFubenNum();
        result = result * 59 + (($fubenNum == null) ? 43 : $fubenNum.hashCode());
        final Object $tttNum = this.getTttNum();
        result = result * 59 + (($tttNum == null) ? 43 : $tttNum.hashCode());
        final Object $tttTp = this.getTttTp();
        result = result * 59 + (($tttTp == null) ? 43 : $tttTp.hashCode());
        final Object $chubaoNum = this.getChubaoNum();
        result = result * 59 + (($chubaoNum == null) ? 43 : $chubaoNum.hashCode());
        final Object $xiuxingNum = this.getXiuxingNum();
        result = result * 59 + (($xiuxingNum == null) ? 43 : $xiuxingNum.hashCode());
        final Object $shuadaoNum = this.getShuadaoNum();
        result = result * 59 + (($shuadaoNum == null) ? 43 : $shuadaoNum.hashCode());
        final Object $baibangmangNum = this.getBaibangmangNum();
        result = result * 59 + (($baibangmangNum == null) ? 43 : $baibangmangNum.hashCode());
        final Object $baxianNum = this.getBaxianNum();
        result = result * 59 + (($baxianNum == null) ? 43 : $baxianNum.hashCode());
        final Object $fabaoNum = this.getFabaoNum();
        result = result * 59 + (($fabaoNum == null) ? 43 : $fabaoNum.hashCode());
        final Object $petfly = this.getPetfly();
        result = result * 59 + (($petfly == null) ? 43 : $petfly.hashCode());
        final Object $persionfly = this.getPersionfly();
        result = result * 59 + (($persionfly == null) ? 43 : $persionfly.hashCode());
        final Object $shidaoDays = this.getShidaoDays();
        result = result * 59 + (($shidaoDays == null) ? 43 : $shidaoDays.hashCode());
        final Object $shidao_min_level = this.getShidao_min_level();
        result = result * 59 + (($shidao_min_level == null) ? 43 : $shidao_min_level.hashCode());
        final Object $shidaoTimes = this.getShidaoTimes();
        result = result * 59 + (($shidaoTimes == null) ? 43 : $shidaoTimes.hashCode());
        final Object $shidaojdTimes = this.getShidaojdTimes();
        result = result * 59 + (($shidaojdTimes == null) ? 43 : $shidaojdTimes.hashCode());
        result = result * 59 + (this.isShidaodebug() ? 79 : 97);
        final Object $boss_flush_time = this.getBoss_flush_time();
        result = result * 59 + (($boss_flush_time == null) ? 43 : $boss_flush_time.hashCode());
        final Object $pkdaohang = this.getPkdaohang();
        result = result * 59 + (($pkdaohang == null) ? 43 : $pkdaohang.hashCode());
        final Object $pkjinyan = this.getPkjingyan();
        result = result * 59 + (($pkjinyan == null) ? 43 : $pkjinyan.hashCode());
        final Object $pkqianneng = this.getPkqianneng();
        result = result * 59 + (($pkqianneng == null) ? 43 : $pkqianneng.hashCode());
        final Object $pkjifen = this.getPkjifen();
        result = result * 59 + (($pkjifen == null) ? 43 : $pkjifen.hashCode());
        return result;
    }
    
    @Override
    public String toString() {
        return "renwuConfig(resetTime=" + this.getResetTime() + ", pkguaiwuNum=" + this.getPkguaiwuNum() + ", shimenNum=" + this.getShimenNum() + ", fubenNum=" + this.getFubenNum() + ", tttNum=" + this.getTttNum() + ", tttTp=" + this.getTttTp() + ", chubaoNum=" + this.getChubaoNum() + ", xiuxingNum=" + this.getXiuxingNum() + ", shuadaoNum=" + this.getShuadaoNum() + ", baibangmangNum=" + this.getBaibangmangNum() + ", baxianNum=" + this.getBaxianNum() + ", fabaoNum=" + this.getFabaoNum() + ", petfly=" + this.getPetfly() + ", persionfly=" + this.getPersionfly() + ", shidaoDays=" + this.getShidaoDays() + ", shidao_min_level=" + this.getShidao_min_level() + ", shidaoTimes=" + this.getShidaoTimes() + ", shidaojdTimes=" + this.getShidaojdTimes() + ", shidaodebug=" + this.isShidaodebug() + ", boss_flush_time=" + this.getBoss_flush_time() + ", pkdaohang=" + this.getPkdaohang() + ", pkjingyan=" + this.getPkjingyan() + ", pkqianneng=" + this.getPkqianneng() + ", pkjifen=" + this.getPkjingyan() + ")";
    }
}
