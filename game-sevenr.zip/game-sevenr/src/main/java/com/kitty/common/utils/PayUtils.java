package com.kitty.common.utils;

public class PayUtils {

    private static int rate = 2340;
    private static int baseRate = 1800;

    /**
     * 根据充值人民币返回元宝数 新区
     *
     * @param number
     * @return
     */
    public static int getGold(int number) {
        int result = 0;
        if (number >= 10000) {
            result = (number + 10000) * rate;
        } else if (number >= 5000) {
            result = (number + 4000) * rate;
        } else if (number >= 2000) {
            result = (number + 1500) * rate;
        } else if (number >= 1000) {
            result = (number + 600) * rate;
        } else if (number >= 500) {
            result = (number + 200) * rate;
        } else if (number >= 100) {
            result = (number + 35) * rate;
        } else {
            result = number * rate;
        }
        return result;
    }

    /**
     * 老区
     * @param number
     * @return
     */
//    public static int getGold(int number){
//        int result = 0;
//        if (number >= 10000) {
//            result = (number + 4000) * 1500;
//        } else if (number >= 5000) {
//            result = (number + 1500) * 1500;
//        } else if (number >= 2000) {
//            result = (number + 500) * 1500;
//        } else if (number >= 1000) {
//            result = (number + 220) * 1500;
//        } else if (number >= 500) {
//            result = (number + 100) * 1500;
//        } else {
//            result = number * 1500;
//        }
//        return result;
//    }
}
