package com.kitty.cross.logic.pk;

import org.springframework.stereotype.Controller;

@Controller
public class CrossPkFacade {
}
