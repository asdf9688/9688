package com.kitty.cross.login.cmessage;

import com.kitty.cross.CrossCommands;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

@MessageMeta(module = CrossCommands.G2C_LEAVE_CROSS)
public class G2CLeaveCross extends Message {

    private int code;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
}
