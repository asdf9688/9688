package com.kitty.cross.login.cmessage;

import com.kitty.cross.CrossCommands;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

@MessageMeta(module = CrossCommands.G2C_LOGIN_TO_SERVER)
public class G2CLoginCross extends Message {

    private byte type;

    private String playerJson;

    public byte getType() {
        return type;
    }

    public void setType(byte type) {
        this.type = type;
    }

    public String getPlayerJson() {
        return playerJson;
    }

    public void setPlayerJson(String playerJson) {
        this.playerJson = playerJson;
    }
}
