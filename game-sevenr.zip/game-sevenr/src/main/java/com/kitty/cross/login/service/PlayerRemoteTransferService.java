package com.kitty.cross.login.service;

import com.kitty.common.spring.SpringUtils;
import com.kitty.cross.core.CrossServer;
import com.kitty.cross.login.model.CrossInfo;
import com.kitty.cross.login.util.PlayerJsonUtil;
import com.kitty.game.gate.LoginAuth;
import com.kitty.game.role.model.Role;
import com.kitty.game.utils.JsonUtils;
import com.kitty.game.utils.ZipUtil;
import com.kitty.logs.LoggerFunction;
import com.kitty.mina.cache.DataCache;
import org.springframework.stereotype.Service;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
//后加
import com.kitty.cross.login.service.CrossService;

/**
 * 中心服玩家传输
 */
@Service
public class PlayerRemoteTransferService {


    public void receiverPlayerData(String fromIp, int fromServer, String playerJson, String authJson) {
        String data = ZipUtil.uncompress(playerJson);
        Role role = PlayerJsonUtil.string2Object(data, Role.class);
        CrossInfo crossInfo = new CrossInfo();
        role.setCrossInfo(crossInfo);
        crossInfo.setFromServer(fromServer);
        crossInfo.setFromIp(fromIp);
        crossInfo.setCross(true);

        SpringUtils.getBean(CrossService.class).addCrossPlayer(role);

        LoginAuth loginAuth = JsonUtils.string2Object(authJson, LoginAuth.class);
        DataCache.LOGIN_AUTHS.put(role.getSid(), loginAuth);

        LoggerFunction.CROSS.getLogger().info("[{}]服玩家（{}[{}]）接受跨服数据", fromServer, role.getName(), role.getUid());
    }


}
