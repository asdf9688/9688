package com.kitty.cross.core.callback;

import com.kitty.common.spring.SpringUtils;
import com.kitty.cross.core.client.C2SSessionPoolFactory;
import com.kitty.cross.core.client.CCSession;
import com.kitty.game.utils.TimeUtil;
import com.kitty.mina.message.Message;

import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
//后加
import com.kitty.cross.core.callback.CReqCallBack;
import com.kitty.cross.core.callback.CallBack;
import com.kitty.cross.core.callback.CallBackService;

public class CallbackTask implements Callable<Message> {

    private CCSession session;

    private Message request;

    public static CallbackTask valueOf(CCSession session, Message message) {
        CallbackTask task = new CallbackTask();
        task.request = message;
        task.session = session;
        return task;
    }

    @Override
    public Message call() throws Exception {
        try {
            CReqCallBack reqCallBack = (CReqCallBack) request;
            int index = CallBack.nextMsgId();
            reqCallBack.setIndex(index);
            reqCallBack.serialize();

            session.sendMessage(reqCallBack);

            ReentrantLock lock = new ReentrantLock();
            Condition condition = lock.newCondition();
            long maxTimeOut = 5 * TimeUtil.ONE_SECOND;
            long startTime = System.currentTimeMillis();
            CallBackService callBackService = SpringUtils.getCallBackService();
            while (System.currentTimeMillis() - startTime <= maxTimeOut) {
                CallBack c = callBackService.removeCallBack(index);
                if (c != null) {
                    return c.getData();
                }

                try {
                    lock.lockInterruptibly();
                    condition.await(10, TimeUnit.MILLISECONDS);
                } catch (Exception e) {

                } finally {
                    lock.unlock();
                }
            }
        } finally {
            SpringUtils.getBean(C2SSessionPoolFactory.class).returnSession(session);
        }
        // 抛出超时异常
        return null;
    }
}
