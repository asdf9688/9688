package com.kitty.cross.core.callback;

public interface CallBackCommands {

    int HELLO = 1;

    int LOGIN = 2;

    int LOGOUT = 3;
}
