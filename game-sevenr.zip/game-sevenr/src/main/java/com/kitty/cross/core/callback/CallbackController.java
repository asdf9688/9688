package com.kitty.cross.core.callback;

import com.kitty.common.spring.SpringUtils;
import com.kitty.cross.core.client.CCSession;
import com.kitty.cross.core.server.RpcRequestMapping;
import com.kitty.cross.core.server.SCSession;
import com.kitty.game.utils.JsonUtils;
import com.kitty.mina.message.Message;
import org.springframework.stereotype.Controller;
//后加
import com.kitty.cross.core.callback.CReqCallBack;
import com.kitty.cross.core.callback.CRespCallBack;
import com.kitty.cross.core.callback.CallBackService;
import com.kitty.cross.core.callback.CallbackHandler;


@Controller
public class CallbackController {

    @RpcRequestMapping
    public void onReqCallBack(SCSession session, CReqCallBack req) {
        int cmdType = req.getCmd();
        CallbackHandler handler = CallbackHandler.queryHandler(cmdType);
        if (handler != null) {
            req.deserialize();
            handler.onRequest(session, req);
        }
    }

    @RpcRequestMapping
    public void onRespCallBack(CCSession session, CRespCallBack respCallBack) {
        String json = respCallBack.getData();
        try {
            Message message = (Message) JsonUtils.string2Object(json, Class.forName(respCallBack.getMsgClass()));
            SpringUtils.getBean(CallBackService.class).fillCallBack(respCallBack.getIndex(), message);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
