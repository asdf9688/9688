package com.kitty.cross.login.cmessage;

import com.kitty.cross.CrossCommands;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

@MessageMeta(module = CrossCommands.C2G_LOGIN_TO_SERVER)
public class C2GLoginCross extends Message {

    /**
     * 1为成功
     */
    int resultCode;

    public int getResultCode() {
        return resultCode;
    }

    public void setResultCode(int resultCode) {
        this.resultCode = resultCode;
    }
}
