package com.kitty.cross.login.service;

import com.kitty.common.spring.SpringUtils;
import com.kitty.cross.CrossServerConfig;
import com.kitty.cross.core.CrossTransportManager;
import com.kitty.cross.core.callback.CReqCallBack;
import com.kitty.cross.core.callback.CallBackCommands;
import com.kitty.cross.core.client.C2SSessionPoolFactory;
import com.kitty.cross.core.client.CCSession;
import com.kitty.cross.login.cmessage.C2GLoginCross;
import com.kitty.cross.login.util.PlayerJsonUtil;
import com.kitty.game.ServerService;
import com.kitty.game.config.Server;
import com.kitty.game.gate.LoginAuth;
import com.kitty.game.role.model.Role;
import com.kitty.game.server.message.RespSwitchServer;
import com.kitty.game.utils.JsonUtils;
import com.kitty.game.utils.ZipUtil;
import com.kitty.logs.LoggerUtils;
import com.kitty.mina.ServerConfig;
import com.kitty.mina.message.Message;
import com.kitty.mina.message.MessagePusher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 游戏服玩家传输
 */
@Service
public class PlayerNativeTransferService {

    @Autowired
    private CrossServerConfig cSConfig;


    public void beginTransfer(Role role) {
        String json = PlayerJsonUtil.object2String(role);
        String data = ZipUtil.compress(json);

        CReqCallBack req = new CReqCallBack();
        req.setCmd(CallBackCommands.LOGIN);
        req.addParam("player", data);

        LoginAuth loginAuth = new LoginAuth();
        loginAuth.setUid(role.getUid());
        Server server = SpringUtils.getBean(ServerService.class).getServer();
        loginAuth.setServerName(server.getName());

        req.addParam("auth", JsonUtils.object2String(loginAuth));
        req.addParam("fromServer", ""+SpringUtils.getBean(ServerConfig.class).getServerId());

        CCSession session = C2SSessionPoolFactory.getInstance().borrowCrossSession();
        try {
            Message callBack = SpringUtils.getBean(CrossTransportManager.class).callBack(session, req);
            if (callBack != null) {
                C2GLoginCross loginCallback = (C2GLoginCross) callBack;
                if (loginCallback.getResultCode() > 0) {

                    RespSwitchServer respSwitchServer = new RespSwitchServer();
                    respSwitchServer.setResult((short) 1);
                    CrossServerConfig crossServerConfig = SpringUtils.getBean(CrossServerConfig.class);
                    respSwitchServer.setContent(crossServerConfig.getCenterIp() + "," + crossServerConfig.getGamePort()
                            + "," + loginAuth.getAuthKey() + "," + loginAuth.getSeed() + "," + role.getName());

//                    respSwitchServer.setContent(SpringUtils.getBean(ServerService.class).getServer().getSonIp() + "," + SpringUtils.getBean(ServerService.class).getServer().getSonPort()
//                            + "," + loginAuth.getAuthKey() + "," + loginAuth.getSeed() + "," + role.getName());

                    MessagePusher.pushMessage(role, respSwitchServer);
                }
            }
        } catch (Exception e) {
            LoggerUtils.error("", e);
        }
    }
}
