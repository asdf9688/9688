package com.kitty.cross.core;

import lombok.Data;
import org.nutz.dao.entity.annotation.Table;

@Data
@Table("p_cross")
public class P_Cross {

    private int id;

    private String ip;

    private int gamePort;

    private int rpcPort;
}
