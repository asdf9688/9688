package com.kitty.cross.demo;

import com.kitty.cross.core.callback.CReqCallBack;
import com.kitty.cross.core.callback.CallBackCommands;
import com.kitty.cross.core.callback.CallbackHandler;
import com.kitty.cross.core.server.SCSession;
import org.springframework.stereotype.Component;
//后加
import com.kitty.cross.demo.CRespCrossHeartBeat;

@Component
public class HelloCallBackHandler extends CallbackHandler {

    @Override
    public void onRequest(SCSession session, CReqCallBack req) {
        CRespCrossHeartBeat resp = new CRespCrossHeartBeat();
        sendBack(session, req, resp);
    }

    @Override
    public int cmdType() {
        return CallBackCommands.HELLO;
    }
}
