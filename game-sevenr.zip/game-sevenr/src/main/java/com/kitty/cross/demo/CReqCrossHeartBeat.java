package com.kitty.cross.demo;

import com.kitty.cross.CrossCommands;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;


@MessageMeta(module = CrossCommands.CCMD_HEART_BEAT)
public class CReqCrossHeartBeat extends Message {

    private long time = System.currentTimeMillis();

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }
}
