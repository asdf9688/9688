package com.kitty.cross.login.service;

import com.kitty.common.spring.SpringUtils;
import com.kitty.cross.core.callback.CReqCallBack;
import com.kitty.cross.core.callback.CallBackCommands;
import com.kitty.cross.core.callback.CallbackHandler;
import com.kitty.cross.core.server.SCSession;
import com.kitty.cross.login.cmessage.C2GLoginCross;
import com.kitty.cross.login.cmessage.G2CLeaveCross;
import com.kitty.game.gate.LoginAuth;
import com.kitty.game.utils.JsonUtils;
import com.kitty.game.utils.NumberUtil;
import com.kitty.mina.cache.DataCache;
import org.springframework.stereotype.Component;

@Component
public class LogoutCallBackHandler extends CallbackHandler {

    @Override
    public void onRequest(SCSession session, CReqCallBack req) {
        String authJson = req.getParams().get("auth");
        String account = req.getParams().get("account");

        LoginAuth loginAuth = JsonUtils.string2Object(authJson, LoginAuth.class);
        DataCache.LOGIN_AUTHS.put(account, loginAuth);
        G2CLeaveCross resp = new G2CLeaveCross();
        sendBack(session, req, resp);
    }

    @Override
    public int cmdType() {
        return CallBackCommands.LOGOUT;
    }
}
