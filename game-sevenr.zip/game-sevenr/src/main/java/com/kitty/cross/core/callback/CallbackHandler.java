package com.kitty.cross.core.callback;

import com.kitty.cross.core.server.SCSession;
import com.kitty.mina.message.Message;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;
//后加
import com.kitty.cross.core.callback.CReqCallBack;
import com.kitty.cross.core.callback.CRespCallBack;

public abstract class CallbackHandler {

    private static Map<Integer, CallbackHandler> handlers = new HashMap<>();

    @PostConstruct
    private void init() {
        handlers.put(cmdType(), this);
    }

    public abstract void onRequest(SCSession session, CReqCallBack req);

    public void sendBack(SCSession session, CReqCallBack req, Message response) {
        CRespCallBack callBack = CRespCallBack.valueOf(response);
        callBack.setIndex(req.getIndex());
        session.sendMessage(callBack);
    }

    public abstract int cmdType();

    public static CallbackHandler queryHandler(int type) {
        return handlers.get(type);
    }

}
