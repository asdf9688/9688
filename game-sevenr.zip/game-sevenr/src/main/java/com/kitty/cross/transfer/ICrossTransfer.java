package com.kitty.cross.transfer;

public interface ICrossTransfer {
}
