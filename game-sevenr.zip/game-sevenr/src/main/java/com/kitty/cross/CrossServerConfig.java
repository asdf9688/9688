package com.kitty.cross;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

@Service
@PropertySource({ "classpath:cross.properties" })
public class CrossServerConfig {

    /**
     * 中心服的ip
     */
    @Value("${cross.center.ip}")
    private String centerIp;
    /**
     * 中心服的rpc端口
     */
    @Value("${cross.center.rpcPort}")
    private int centerPort;
    /**
     * 中心服的游戏端口
     */
    @Value("${cross.center.gamePort}")
    private int gamePort;

    @Value("${cross.center}")
    private int isCenter;


    public boolean isCenterServer() {
        return isCenter > 0;
    }

    public String getCenterIp() {
        return centerIp;
    }

    public int getCenterPort() {
        return centerPort;
    }

    public int getGamePort() {
        return gamePort;
    }

}
