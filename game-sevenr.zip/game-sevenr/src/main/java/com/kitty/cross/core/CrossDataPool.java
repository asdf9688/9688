package com.kitty.cross.core;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.config.Reloadable;
import com.kitty.game.i18n.P_I18nId;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
//后加
import com.kitty.cross.core.P_Cross;

@Component
public class CrossDataPool implements Reloadable {

    public static Map<Integer, P_Cross> datas;

    @Override
    public void reload() {
        Dao dao = SpringUtils.getBean(Dao.class);
        List<P_Cross> list = dao.query(P_Cross.class, Cnd.NEW());
        datas = list.stream().collect(Collectors.toMap(P_Cross::getId, Function.identity()));
    }

    public static P_Cross getCrossServer(int id) {
        return datas.get(id);
    }
}
