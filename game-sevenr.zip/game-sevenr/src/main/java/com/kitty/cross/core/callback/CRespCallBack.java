package com.kitty.cross.core.callback;

import com.kitty.cross.CrossCommands;
import com.kitty.game.utils.JsonUtils;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;


@MessageMeta(module = CrossCommands.CMSG_CALL_BACK)
public class CRespCallBack extends Message {

    private int index;

    private String data;

    private String msgClass;

    public static CRespCallBack valueOf(Message message) {
        CRespCallBack response = new CRespCallBack();
        response.data = JsonUtils.object2String(message);
        response.msgClass = message.getClass().getName();

        return response;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getMsgClass() {
        return msgClass;
    }

    public void setMsgClass(String msgClass) {
        this.msgClass = msgClass;
    }
}
