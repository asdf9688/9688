package com.kitty.cross.core.codec;

import com.kitty.mina.codec.IMessageDecoder;
import com.kitty.mina.codec.IMessageEncoder;
import com.kitty.mina.codec.reflect.ReflectDecoder;
import com.kitty.mina.codec.reflect.ReflectEncoder;
//后加
import com.kitty.cross.core.codec.CrossMessageCodecFactory;

public class CrossSerializerHelper {

    public static volatile CrossSerializerHelper instance;

    private CrossMessageCodecFactory codecFactory;

    private IMessageDecoder decoder;

    private IMessageEncoder encoder;

    public static CrossSerializerHelper getInstance() {
        if (instance != null) {
            return instance;
        }
        synchronized (CrossSerializerHelper.class) {
            if (instance == null) {
                instance = new CrossSerializerHelper();
                instance.initialize();
            }
        }
        return instance;
    }

    private void initialize() {
        decoder = new ReflectDecoder();
        encoder = new ReflectEncoder();
        codecFactory = new CrossMessageCodecFactory();
    }

    public CrossMessageCodecFactory getCodecFactory() {
        return codecFactory;
    }

    public IMessageDecoder getDecoder() {
        return decoder;
    }

    public IMessageEncoder getEncoder() {
        return encoder;
    }
}
