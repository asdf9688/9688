package com.kitty.cross.core.server;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;
//后加
import com.kitty.cross.core.server.BaseCMessageDispatcher;

@Component
public class CrossHandlerBeanProcessor implements BeanPostProcessor, ApplicationContextAware, Ordered {

    @Override
    public Object postProcessBeforeInitialization(Object o, String s) throws BeansException {
        BaseCMessageDispatcher.getInstance().registerEventHandler(o);
        return o;
    }

    @Override
    public Object postProcessAfterInitialization(Object o, String s) throws BeansException {
        return o;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {

    }

    @Override
    public int getOrder() {
        return Integer.MAX_VALUE;
    }

}
