package com.kitty.cross.core.server;

import com.kitty.cross.core.client.CCSession;
import com.kitty.mina.message.Message;
//后加
import com.kitty.cross.core.server.SCSession;

public interface CMessageDispatcher {

	/**
	 * 服务端节点消息分发
	 * @param session
	 * @param message
	 */
	void serverDispatch(SCSession session, Message message);
	
	/**
	 * 客户端节点消息分发
	 * @param session
	 * @param message
	 */
	void clientDispatch(CCSession session, Message message);
	
}