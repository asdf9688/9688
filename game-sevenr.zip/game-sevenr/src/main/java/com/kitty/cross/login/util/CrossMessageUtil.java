package com.kitty.cross.login.util;

import com.kitty.common.spring.SpringUtils;
import com.kitty.cross.CrossServerConfig;
import com.kitty.game.role.model.Role;
import com.kitty.mina.message.Message;

public class CrossMessageUtil {

    public static void send(Role role, Message message) {
        if (!SpringUtils.getBean(CrossServerConfig.class).isCenterServer()) {
            return;
        }
        if (message.getModule() > 0) {
            throw new IllegalStateException("跨服状态不允许发送协议" + message.getClass().getSimpleName());
        }

    }
}
