package com.kitty.cross.login.service;

import com.kitty.common.spring.SpringUtils;
import com.kitty.cross.core.callback.CReqCallBack;
import com.kitty.cross.core.callback.CallBackCommands;
import com.kitty.cross.core.callback.CallbackHandler;
import com.kitty.cross.core.server.SCSession;
import com.kitty.cross.login.cmessage.C2GLoginCross;
import com.kitty.game.utils.NumberUtil;
import org.springframework.stereotype.Component;
//后加
import com.kitty.cross.login.service.PlayerRemoteTransferService;

@Component
public class LoginCallBackHandler extends CallbackHandler {

    @Override
    public void onRequest(SCSession session, CReqCallBack req) {
        String playerJson = req.getParams().get("player");
        String authJson = req.getParams().get("auth");
        int fromServer = NumberUtil.intValue(req.getParams().get("fromServer"));

        SpringUtils.getBean(PlayerRemoteTransferService.class).receiverPlayerData(session.getClientIp(), fromServer, playerJson, authJson);
        C2GLoginCross resp = new C2GLoginCross();
        resp.setResultCode(1);
        sendBack(session, req, resp);
    }

    @Override
    public int cmdType() {
        return CallBackCommands.LOGIN;
    }
}
