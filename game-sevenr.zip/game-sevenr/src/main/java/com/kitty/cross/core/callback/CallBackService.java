package com.kitty.cross.core.callback;

import com.kitty.mina.message.Message;
import org.springframework.stereotype.Service;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
//后加
import com.kitty.cross.core.callback.CallBack;

@Service
public class CallBackService {

    private ConcurrentMap<Integer, CallBack> callbacks = new ConcurrentHashMap<>();

    public void fillCallBack(int index, Message message) {
        CallBack callBack = new CallBack();
        callBack.setIndex(index);
        callBack.setData(message);

        callbacks.put(index, callBack);
    }

    public CallBack removeCallBack(int index) {
        return callbacks.remove(index);
    }

}
