package com.kitty.adminclient;

import com.kitty.common.db.Db4PlayerService;
import com.kitty.common.spring.SpringUtils;
import com.kitty.game.ServerService;
import com.kitty.game.utils.JsonUtils;
import com.kitty.mina.ServerConfig;
import com.kitty.mina.cache.DataCache;
import org.nutz.http.Request;
import org.nutz.http.Sender;
import org.springframework.cache.guava.GuavaCache;
import org.springframework.cache.guava.GuavaCacheManager;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class AdminClientService {

    /**
     * 每隔1分钟向管理后台上报指标
     */
    @Scheduled(cron = "0 0/1 * * * ?")
    public void postToAdmin() {
/*        ServerMonitorNode node = new ServerMonitorNode();
        node.setServerId(SpringUtils.getBean(ServerConfig.class).getServerId());
        node.setOnlinePlayerSum(DataCache.ONLINE_ROLES.size());

        GuavaCacheManager cacheManager = SpringUtils.getBean(org.springframework.cache.guava.GuavaCacheManager.class);
        GuavaCache guavaCache = (GuavaCache) (cacheManager.getCache("player"));
        node.setCachePlayerSum((int) guavaCache.getNativeCache().size());

        node.setPlayerDbQueueSum(Db4PlayerService.getInstance().size());


        try {
            Map<String, Object> params = new HashMap<>();
            String json = JsonUtils.object2String(node);
            params.put("data", json);
            Request request = Request.create(SpringUtils.getBean(ServerService.class).getAdminUrl(), Request.METHOD.POST).setParams(params);
            Sender.create(request).setTimeout(1000).send();
        } catch (Exception e) {
            LoggerUtils.error("", e);
        }*/


    }

}
