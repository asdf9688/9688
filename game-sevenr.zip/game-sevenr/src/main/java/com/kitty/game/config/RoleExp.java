package com.kitty.game.config;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

@Table("p_roleexp")
public class RoleExp {
   @Id(auto = false)
    @Comment("人物等级")
    private short level;
    @Column
    @Comment("所需经验")
    private int exp;
    @Column
    @Comment("元婴升级所需经验")
    private int upgradeExp;

    public int getUpgradeExp() {
        return upgradeExp;
    }

    public void setUpgradeExp(int upgradeExp) {
        this.upgradeExp = upgradeExp;
    }

    public short getLevel() {
        return level;
    }

    public void setLevel(short level) {
        this.level = level;
    }

    public int getExp() {
        return exp;
    }

    public void setExp(int exp) {
        this.exp = exp;
    }
}
