package com.kitty.game.config;


import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

@Table("p_newcommer_gift")
public class NewcomerGift {
    @Id
    private int id;
    @Column
    private String name;
    @Column
    private int num;
    @Column
    private int level;
    @Column
    private int pos;
    @Column
    private int type;//1装备,2物品,3代金券 4首饰
    @Column
    private int getLevel;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getPos() {
        return pos;
    }

    public void setPos(int pos) {
        this.pos = pos;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getGetLevel() {
        return getLevel;
    }

    public void setGetLevel(int getLevel) {
        this.getLevel = getLevel;
    }
}
