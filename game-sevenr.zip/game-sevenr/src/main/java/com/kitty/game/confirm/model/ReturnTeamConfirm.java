package com.kitty.game.confirm.model;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

public class ReturnTeamConfirm extends RoleConfirm{
    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.RETURN_TEAM;
    }
}
