package com.kitty.game.activity.model.user;

import lombok.Getter;
import lombok.Setter;

/**试道挑战元魔阶段数据*/
@Getter
@Setter
public class ShiDaoMonsterData {
    /**队伍ID*/
    private int teamId;
    /**元魔积分*/
    private int monsterScore;

    public ShiDaoMonsterData(int teamId) {
        this.teamId = teamId;
        this.monsterScore = 0;
    }

    public void addMonsterScore(int score) {
        this.monsterScore += score;
    }
}
