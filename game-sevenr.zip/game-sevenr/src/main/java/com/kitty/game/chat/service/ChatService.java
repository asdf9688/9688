package com.kitty.game.chat.service;

import com.kitty.common.spring.SpringUtils;
import com.kitty.common.utils.LimitedCacheMap;
import com.kitty.game.ServerService;
import com.kitty.game.activity.message.vo.DailyStatsInfo;
import com.kitty.game.admin.service.AdminService;
import com.kitty.game.chat.message.*;
import com.kitty.game.chat.message.vo.Title;
import com.kitty.game.config.GameMap;
import com.kitty.game.config.Server;
import com.kitty.game.enter.FiedValue;
import com.kitty.game.enter.RespNotifyMisc;
import com.kitty.game.enter.TitleInfo;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.equip.model.EquipField;
import com.kitty.game.equip.model.RoleEquip;
import com.kitty.game.equip.model.RoleHunQiField;
import com.kitty.game.equip.service.EquipService;
import com.kitty.game.fight.service.BroadcastService;
import com.kitty.game.fight.service.CountService;
import com.kitty.game.friend.service.FriendService;
import com.kitty.game.i18n.I18nId;
import com.kitty.game.party.service.PartyService;
import com.kitty.game.pet.model.Pet;
import com.kitty.game.pet.service.PetService;
import com.kitty.game.role.model.AccountLogin;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.AccountService;
import com.kitty.game.role.service.RoleService;
import com.kitty.game.skill.message.vo.SkillInfo;
import com.kitty.game.skill.model.RoleSkill;
import com.kitty.game.skill.service.SkillService;
import com.kitty.game.statistics.service.StatsService;
import com.kitty.game.task.message.vo.TaskInfo;
import com.kitty.game.team.message.RespMsg;
import com.kitty.game.team.model.Member;
import com.kitty.game.team.model.Team;
import com.kitty.game.team.service.TeamService;
import com.kitty.game.utils.*;
import com.kitty.logs.LoggerFunction;
import com.kitty.mina.cache.SessionUtils;
import com.kitty.mina.message.MessagePusher;
import org.apache.commons.lang3.StringUtils;
import org.apache.mina.core.session.IoSession;
import org.nutz.lang.Strings;
import org.nutz.lang.random.R;
import org.nutz.lang.util.NutMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.kitty.game.chat.message.ReqChat;
import com.kitty.game.chat.message.RespChat;
import com.kitty.game.chat.message.RespDailyStatisInfo;
import com.kitty.game.chat.message.RespItem;
import com.kitty.game.chat.message.RespRoleInfo;
import com.kitty.game.chat.message.RespRoleTask;
import com.kitty.game.chat.message.RespSkillInfo;
import com.kitty.game.chat.message.RespTempFriendState;
import com.kitty.game.chat.message.RespTitleInfo;
import com.kitty.game.utils.AsktaoUtil;
import com.kitty.game.utils.FieldUtils;
import com.kitty.game.utils.SenderUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class ChatService {
    /**
     * 查看聊天物品信息
     */
    private Logger logger = LoggerFactory.getLogger(ChatService.class);
    @Autowired
    EquipService equipService;
    @Autowired
    PetService petService;
    @Autowired
    SkillService skillService;
    @Autowired
    ServerService serverService;
    @Autowired
    RoleService roleService;
    @Autowired
    FriendService friendService;
    @Autowired
    TeamService teamService;

    private LimitedCacheMap<String, NutMap> chatCache = new LimitedCacheMap<>(500, 900 * TimeUtil.ONE_SECOND);

    public boolean chatForbid = true;

    public void checkItemInfo(IoSession session, String uuId) {
        NutMap nutMap = chatCache.get(uuId);
        if (nutMap == null) {
            MessagePusher.pushMessage(session, new RespMsg("物品信息未找到。"));
            return;
        }
        String type = nutMap.getString("type");
        switch (type) {
            case "角色": {
                List<FiedValue> list = nutMap.getAsList("list", FiedValue.class);
                RespRoleInfo respRoleInfo = new RespRoleInfo();
                respRoleInfo.setList(list);
                respRoleInfo.setType(type);
                respRoleInfo.setUuId(uuId);
                MessagePusher.pushMessage(session, respRoleInfo);
                break;
            }
            case "任务": {
                List<TaskInfo> list = nutMap.getAsList("list", TaskInfo.class);
                RespRoleTask respRoleTask = new RespRoleTask();
                respRoleTask.setList(list);
                respRoleTask.setType(type);
                respRoleTask.setUuId(uuId);
                MessagePusher.pushMessage(session, respRoleTask);
                break;
            }
            case "技能": {
                List<SkillInfo> list = nutMap.getAsList("list", SkillInfo.class);
                RespSkillInfo respSkillInfo = new RespSkillInfo();
                respSkillInfo.setList(list);
                respSkillInfo.setType(type);
                respSkillInfo.setUuId(uuId);
                MessagePusher.pushMessage(session, respSkillInfo);
                break;
            }
            case "称谓":
                Title title = nutMap.getAs("title", Title.class);
                RespTitleInfo respTitleInfo = new RespTitleInfo();
                respTitleInfo.setTitle(title);
                respTitleInfo.setType(type);
                respTitleInfo.setUuId(uuId);
                MessagePusher.pushMessage(session, respTitleInfo);
                break;
            case "今日统计": {
                DailyStatsInfo dailyStatsInfo = nutMap.getAs("data", DailyStatsInfo.class);
                RespDailyStatisInfo respDailyStatisInfo = new RespDailyStatisInfo(uuId, type, dailyStatsInfo);
                MessagePusher.pushMessage(session, respDailyStatisInfo);
                break;
            }
            default: {
                List<EquipField> list = nutMap.getAsList("list", EquipField.class);
                List<RoleHunQiField> list1 = nutMap.getAsList("list1", RoleHunQiField.class);
                RespItem respItem = new RespItem();
                respItem.setEquipFields(list,list1);
                respItem.setType(type);
                respItem.setUuId(uuId);
                MessagePusher.pushMessage(session, respItem);
                break;
            }
        }
    }

    /**
     * 文本是否包含qq群号码
     * @param word
     * @return
     */
    public boolean checkQQNumber(String word) {
        String reg = "[1-9][0-9]{5,15}";
        Pattern pattern = Pattern.compile(reg);
        Matcher matcher = pattern.matcher(word);
        while (matcher.find()) {
            String group = matcher.group();
            return true;
        }
        return false;
    }
    /**
     * 发送消息
     *
     * @param session
     * @param chat
     */
    public void chat(IoSession session, ReqChat chat) {
        Object object = session.getAttribute(Const.chatSpeed);
        Role role = SessionUtils.getRoleBySession(session);
        if (role == null) {
            return;
        }
        if (role.getLockTime() > System.currentTimeMillis()) {
            return;
        }

        Team team = teamService.getTeam(role.getRoleId());
        int time = 0;
        int worldNum = 0;
        int needMoney = 0;
        NutMap nutMap = NutMap.NEW();
        int currTime = new Long(new Date().getTime() / 1000).intValue();
        if (object == null) {
            nutMap.setv("chatTime", time);
            session.setAttribute(Const.chatSpeed, nutMap);
        } else {
            nutMap = (NutMap) object;
            time = nutMap.getInt("chatTime", 0);
            worldNum = nutMap.getInt("worldNum", 0);
        }
        if (currTime - time <= 5) {
            MessagePusher.pushMessage(session, new RespMsg("您说话太频繁了！"));
            return;
        }
        /*if (chatForbid && checkQQNumber(chat.getMsg())) {
            LoggerFunction.FORBID.getLogger().error("{} {}聊天[{}]带有qq群号", role.getRoleId(), role.getName(), chat.getMsg());
            SpringUtils.getBean(AdminService.class).blockPlayer(role,System.currentTimeMillis()+ 12 * TimeUtil.ONE_HOUR);
            return;
        }*/
        if (chatForbid && checkQQNumber(role.getName())) {
            LoggerFunction.FORBID.getLogger().error("{} {}名字[{}]带有qq群号", role.getRoleId(), role.getName(), chat.getMsg());
            SpringUtils.getBean(AdminService.class).blockPlayer(role,System.currentTimeMillis()+ 12 * TimeUtil.ONE_HOUR);
            return;
        }
        nutMap.setv("chatTime", currTime);
        if (chat.getType() == ChatConst.WORLD) {
            if (currTime - time <= 60 * 5) {
                if (worldNum > 10) {//10次以内不扣金钱
                    needMoney = (worldNum - 10) * 20000;
                    if (needMoney < 0) {
                        return;
                    }
                    if (needMoney > 5000000) {
                        needMoney = 5000000;
                    }
                    int voucher = role.getVoucher();
                    if (voucher != role.getVoucher()) {
                        session.closeNow();
                        return;
                    }
                    if (voucher < needMoney) {
                        if (role.getMoney() < needMoney) {
                            return;
                        } else {
                            role.setMoney(role.getMoney() - needMoney);
                        }
                        MessagePusher.pushMessage(session, new RespNotifyMiscEx("你使用了世界频道，消耗了" + AsktaoUtil.getMoneyFormat(needMoney) + "文金钱#n。"));
                    } else {
                        role.setVoucher(role.getVoucher() - needMoney);
                        MessagePusher.pushMessage(session, new RespNotifyMiscEx("你使用了世界频道，消耗了" + AsktaoUtil.getMoneyFormat(needMoney) + "文代金券#n。"));
                    }
                    roleService.updateRoleMoney(role);
                }
                worldNum++;
            } else {
                worldNum = 1;
            }
            nutMap.setv("worldNum", worldNum);
            nutMap.setv("chatTime", currTime);
        } else if (chat.getType() == ChatConst.TEAM) {
            if (team == null) {
                return;
            }
        }

        session.setAttribute(Const.chatSpeed, nutMap);

        Server server = SpringUtils.getBean(ServerService.class).getServer();
        if (chat.getMsg().contains("道具=")) {
            String content = chat.getMsg().substring(chat.getMsg().indexOf("\t"), chat.getMsg().indexOf("}"));
            if (!Strings.isEmpty(content)) {
                String[] strings = content.split("=");
                if (strings.length == 3) {
                    RoleEquip roleEquip = equipService.getEquipById(role, Integer.parseInt(strings[2]));
                    if (roleEquip != null) {

                        String uuId = R.UU32().toUpperCase();
                        chat.setMsg(chat.getMsg().replace("道具=" + strings[2], uuId));
                        List<EquipField> list = equipService.transferList(roleEquip.getFields());
                        NutMap itemMap = NutMap.NEW();
                        if (roleEquip.getName().contains("魂器")){
                            List<RoleHunQiField> list1 = equipService.transferList2(roleEquip.getHunQiFields());
                            itemMap.setv("list1",list1);
                        }

                        itemMap.setv("list", list);
                        itemMap.setv("type", "道具");
                        addChatCache(uuId, itemMap);
                    }
                }
            }
        } else if (chat.getMsg().contains("宠物=")) {
            String content = chat.getMsg().substring(chat.getMsg().indexOf("\t"), chat.getMsg().indexOf("}"));
            if (!Strings.isEmpty(content)) {
                String[] strings = content.split("=");
                if (strings.length == 3) {

                    String uuId = R.UU32().toUpperCase();
                    chat.setMsg(chat.getMsg().replace("宠物=" + strings[2], uuId));
                    Pet pet = role.getPetBox().getPetByPetId(Integer.parseInt(strings[2]));
                    List<EquipField> list = new ArrayList<>(pet.getAllFields());
                    NutMap itemMap = NutMap.NEW();
                    itemMap.setv("list", list);
                    itemMap.setv("type", "宠物");
                    addChatCache(uuId, itemMap);

                }
            }
        } else if (chat.getMsg().contains("角色=")) {
            String content = chat.getMsg().substring(chat.getMsg().indexOf("\t"), chat.getMsg().indexOf("}"));
            if (!Strings.isEmpty(content)) {
                String[] strings = content.split("=");
                if (strings.length == 3) {

                    String uuId = R.UU32().toUpperCase();
                    chat.setMsg(chat.getMsg().replace("角色=" + strings[2], uuId));
                    List<FiedValue> list = FieldUtils.rolePanelInfo_1(role);
                    NutMap itemMap = NutMap.NEW();
                    itemMap.setv("list", list);
                    itemMap.setv("type", "角色");
                    addChatCache(uuId, itemMap);



                }
            }
        } else if (chat.getMsg().contains("任务=")) {
            String content = chat.getMsg().substring(chat.getMsg().indexOf("\t"), chat.getMsg().indexOf("}"));
            if (!Strings.isEmpty(content)) {
                String[] strings = content.split("=");
                if (strings.length == 3) {
                    String uuId = R.UU32().toUpperCase();
                    chat.setMsg(chat.getMsg().replace("任务=" + strings[2], uuId));

                    TaskInfo taskInfo = SpringUtils.getTaskService().getTaskInfoByName(role, strings[2]);
                    if (taskInfo != null) {
                        List<TaskInfo> list = new ArrayList<>();
                        list.add(taskInfo);
                        NutMap itemMap = NutMap.NEW();
                        itemMap.setv("list", list);
                        itemMap.setv("type", "任务");
                        addChatCache(uuId, itemMap);
                    }
                }
            }
        } else if (chat.getMsg().contains("技能=")) {
            String content = chat.getMsg().substring(chat.getMsg().indexOf("\t"), chat.getMsg().indexOf("}"));
            if (!Strings.isEmpty(content)) {
                String[] strings = content.split("=");
                if (strings.length == 3) {

                    String uuId = R.UU32().toUpperCase();
                    chat.setMsg(chat.getMsg().replace("技能=" + strings[2], uuId));
                    RoleSkill roleSkill = skillService.getRoleSkill(role, Integer.parseInt(strings[2]));
                    List<SkillInfo> list = Collections.singletonList(skillService.getSkillInfo(roleSkill, role.getExtraSkillLevel()));
                    NutMap itemMap = NutMap.NEW();
                    itemMap.setv("list", list);
                    itemMap.setv("type", "技能");
                    addChatCache(uuId, itemMap);
                }
            }
        } else if (chat.getMsg().contains("称谓=")) {
            String content = chat.getMsg().substring(chat.getMsg().indexOf("\t"), chat.getMsg().indexOf("}"));
            if (!Strings.isEmpty(content)) {
                String[] strings = content.split("=");
                if (strings.length == 3) {

                    String uuId = R.UU32().toUpperCase();
                    chat.setMsg(chat.getMsg().replace("称谓=" + strings[2], uuId));

                    TitleInfo titleInfo = new TitleInfo();
                    LinkedHashMap<String, TitleInfo> hashMap = role.getExtendBox().getTitleList();
                    for (Map.Entry<String, TitleInfo> entry : hashMap.entrySet()) {
                        if (entry.getValue().getType().equals(strings[2])) {
                            titleInfo = entry.getValue();
                            break;
                        }
                    }
                    Title title = new Title();
                    if (titleInfo != null) {
                        title.setTitle(titleInfo.getTitle());
                        title.setType(titleInfo.getType());
                    }
                    NutMap itemMap = NutMap.NEW();
                    itemMap.setv("title", title);
                    itemMap.setv("type", "称谓");

                    addChatCache(uuId, itemMap);
                }
            }
        } else if (chat.getMsg().contains("今日统计=")) {
            String content = chat.getMsg().substring(chat.getMsg().indexOf("\t"), chat.getMsg().indexOf("}"));
            if (StringUtils.isNotEmpty(content)) {
                String[] strings = content.split("=");
                if (strings.length == 3) {
                    String uuId = R.UU32().toUpperCase();
                    String msg = chat.getMsg().replace(role.getName()+"=", "").replace(strings[2], uuId);
                    chat.setMsg(msg);
                    DailyStatsInfo dailyStatsInfo = SpringUtils.getBean(StatsService.class).getDailyStatsInfo(role);
                    NutMap itemMap = NutMap.NEW();
                    itemMap.setv("data", dailyStatsInfo);
                    itemMap.setv("type", "今日统计");
                    addChatCache(uuId, itemMap);
                }
            }
        }else if (chat.getMsg().contains("邀请人=")){
            String username = chat.getMsg().replace("邀请人=","").trim();
            SpringUtils.getRoleService().invite(role,username);
            return;
        }
        RespChat res = new RespChat();
        if (!Strings.isEmpty(chat.getToken())) {
            res.setToken(chat.getToken());
            res.setMsgType((short) 1);
            res.setVoiceTime(chat.getVoiceTime());
            res.setCheckSum(968048343);
        }
        res.setMsg(chat.getMsg());
        res.setList(FieldUtils.getChatList(role));
        res.setRoleName(role.getName());
        res.setLineName(server.getSonName());
        res.setRoleId(role.getRoleId());
        res.setTime(currTime);
        if (chat.getType() == ChatConst.CURRENT) {//当前频道 只在本线本地图发送
//            if (!SpringUtils.getFightService().isInFight(role)) {
//                return;
//            }
            res.setType(ChatConst.CURRENT);
//            if (!role.isVip()) {
//                MessagePusher.pushMessage(role, res);
//                return;
//
//            } else {
//
//            }
//            if (role.getLevel() < 20) {
//                MessagePusher.pushMessage(role, new RespMsg("当前频道在#R20#n级开启。"));
//                return;
//            }
            if (serverService.getServer().getId() == 10000){
                MessagePusher.pushMessage(role, new RespMsg("跨服专线只能在世界聊天。"));
                return;
            }
            SpringUtils.getBean(BroadcastService.class).sendLocalMessage(role, res);
            localChat(role,res.getMsg());

        } else if (chat.getType() == ChatConst.WORLD) {//世界消息 全线
            if (!role.isVip()) {
                res.setType(ChatConst.WORLD);
                MessagePusher.pushMessage(role, res);
                return;

            } else {
                if (role.getLevel() < 20) {
                    MessagePusher.pushMessage(role, new RespMsg("世界频道在#R20#n级开启。"));
                    return;
                }
            }
            res.setType(ChatConst.WORLD);
            SenderUtils.pushChatMessage(res);
        }
        else if (chat.getType() == ChatConst.HORN) {//喇叭消息 全线
            int count = equipService.getCount("喇叭", true, role);
            if (count <= 0) {
                return;
            }
            MessagePusher.pushMessage(session, new RespNotifyMisc("消耗了#R1#n个喇叭。"));
            equipService.delRoloEquip("喇叭", 1, true, role);
            res.setType(ChatConst.HORN);
            SenderUtils.pushChatMessage(res);
        }
        else if (chat.getType() == ChatConst.TEAM) {
            String teamTitle = "";
            if (team != null) {
                if (team.isLeader(role.getRoleId())) {
                    teamTitle = " #B队长#n";
                } else {
                    teamTitle = " #B队员#n";
                }
                res.setRoleName(role.getName() + teamTitle);
                res.setType(ChatConst.TEAM);
                for (Member member : team.getList()) {
                    Role memberRole = SpringUtils.getRoleService().getOnlinePlayer(member.getUid());
                    MessagePusher.pushMessage(memberRole, res);
                }
            }
        }

        else if (chat.getType() == ChatConst.TEAM_INFO) {
            String teamTitle = "";
            if (team != null) {
                if (team.isLeader(role.getRoleId())) {
                    teamTitle = " #B队长#n";
                } else {
                    teamTitle = " #B队员#n";
                }
                res.setRoleName(role.getName() + teamTitle);
                res.setType(ChatConst.TEAM_INFO);
                SenderUtils.pushChatMessage(res);
            }

        } else if (chat.getType() == ChatConst.PARTY) {
            if (Strings.isEmpty(role.getPartyName())) {
                return;
            }
            PartyService partyService = SpringUtils.getPartyService();
            if (partyService.isChatDeny(role)) {
                long chatDenyEndtime = partyService.getChatDenyEndtime(role) * TimeUtil.ONE_SECOND;
                if (chatDenyEndtime > 0 && chatDenyEndtime > System.currentTimeMillis()) {
                    String formatDate = TimeUtil.formatDate(new Date(chatDenyEndtime), TimeUtil.DEFAULT_DATE_FORMAT);
                    MessagePusher.notify2Player(role, I18nId.PMT_357, formatDate);
                    return;
                }
            }

            logger.info("帮派发言");
            res.setType(ChatConst.PARTY);
            res.setPartyName(role.getPartyName());

            SenderUtils.pushPartyChatMessage(role.getPartyId(), res);
        }
    }

    public void addChatCache(String uuId, NutMap itemMap) {
        chatCache.put(uuId, itemMap);
    }

    /**
     * 发谣言
     *
     * @param msg  内容
     * @param type 类型
     */
    public void sendNumor(String msg, String type) {
        RespChat respChat = new RespChat();
        respChat.setList(new ArrayList<>());
        respChat.setRoleName("谣言");
        respChat.setRoleId(0);
        respChat.setTime(new Long(System.currentTimeMillis() / 1000).intValue());
        respChat.setType(ChatConst.RUMOR);
        respChat.setMsg(msg);
        SenderUtils.pushChatMessage(respChat);
    }

    /**
     * 发系统消息
     *
     * @param msg  内容
     * @param type 类型
     */
    public void sendSystem(String msg, String type) {
        RespChat respChat = new RespChat();
        respChat.setList(new ArrayList<>());
        respChat.setRoleName("系统");
        respChat.setRoleId(0);
        respChat.setTime(new Long(System.currentTimeMillis() / 1000).intValue());
        respChat.setType(ChatConst.SYSTEM);
        respChat.setMsg(msg);
        SenderUtils.pushChatMessage(respChat);
    }

    /**
     * 发公告消息
     *
     * @param msg
     */
    public void sendAdnotice(String msg) {
        RespChat respChat = new RespChat();
        respChat.setMsg(msg);
        respChat.setList(new ArrayList<>());
        respChat.setRoleName("公告");
        ServerService serverService = SpringUtils.getBean(ServerService.class);
        respChat.setLineName(serverService.getServer().getSonName());
        respChat.setRoleId(0);
        respChat.setTime(new Long(System.currentTimeMillis() / 1000).intValue());
        respChat.setType(ChatConst.ADNOTICE);
        SenderUtils.pushChatMessage(respChat);
    }

    public void privateChat(Role from,Role to,String msg){
        int currTime = new Long(new Date().getTime() / 1000).intValue();
        RespChat res = new RespChat();
        res.setMsg("对#R"+to.getName()+"#n私聊："+msg);
        res.setList(FieldUtils.getChatList(from));
        res.setRoleName(from.getName());
        res.setLineName(serverService.getServer().getSonName());
        res.setRoleId(from.getRoleId());
        res.setTime(currTime);
        res.setType(ChatConst.WORLD);
        SenderUtils.pushChatMessage2GM(res);
    }
    public void localChat(Role from,String msg){
        int currTime = new Long(new Date().getTime() / 1000).intValue();
        RespChat res = new RespChat();
        int mapId = from.getPos().getMapId();
        GameMap gameMap = SpringUtils.getMapService().getMap(mapId);
        res.setMsg("在#R"+gameMap.getName()+"#n当前频道："+msg);
        res.setList(FieldUtils.getChatList(from));
        res.setRoleName(from.getName());
        res.setLineName(serverService.getServer().getSonName());
        res.setRoleId(from.getRoleId());
        res.setTime(currTime);
        res.setType(ChatConst.CURRENT);
        SenderUtils.pushChatMessage2GM(res);
    }
    public void failedChat(Role from,String msg){
        int currTime = new Long(new Date().getTime() / 1000).intValue();
        RespChat res = new RespChat();
        res.setMsg("#R"+"失败"+"#n内容："+msg);
        res.setList(FieldUtils.getChatList(from));
        res.setRoleName(from.getName());
        res.setLineName(serverService.getServer().getSonName());
        res.setRoleId(from.getRoleId());
        res.setTime(currTime);
        res.setType(ChatConst.WORLD);
        SenderUtils.pushChatMessage2GM(res);
    }

    public void sendLaba(String msg,Role role) {
        RespChat res = new RespChat();
        Server server = SpringUtils.getBean(ServerService.class).getServer();
        int currTime = new Long(new Date().getTime() / 1000).intValue();
        res.setMsg(msg);
        res.setList(FieldUtils.getChatList(role));
        res.setRoleName(role.getName());
        res.setLineName(server.getSonName());
        res.setRoleId(role.getRoleId());
        res.setTime(currTime);
        res.setType(ChatConst.HORN);
        SenderUtils.pushChatMessage(res);
    }

    /**
     * 请求对应gid的在线状态
     */
    public void reqTempFriendState(Role role, String gid) {
        long uid = Long.parseLong(gid);
        Role targetRole = roleService.getOnlinePlayer(uid);
        RespTempFriendState respTempFriendState = new RespTempFriendState();
        respTempFriendState.setGid(gid);
        respTempFriendState.setOnline((byte) (targetRole == null ? 2 : 1));
        MessagePusher.pushMessage(role, respTempFriendState);
    }
}
