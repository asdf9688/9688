package com.kitty.game.bag.model;

public enum GiftType {
    PET("宠物"),
    EQUIP("装备"),
    PROP("道具"),
    JEWELRY("首饰"),
    ATTRIBUTE("属性");

    private String desc;

    GiftType(String value) {
        this.desc = value;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
