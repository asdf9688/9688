package com.kitty.game.confirm.service.handler;

import com.kitty.game.confirm.service.handler.ConfirmHandler;
import com.kitty.game.equip.model.RoleEquip;
import com.kitty.game.equip.service.EquipService;
import com.kitty.game.function.service.FasionService;
import com.kitty.game.jiehun.RespWeddingCheckMusic;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.RoleService;
import com.kitty.game.team.message.ReqConfirmResult;
import com.kitty.game.team.message.RespMsg;
import com.kitty.game.team.model.Member;
import com.kitty.game.team.model.Team;
import com.kitty.game.team.service.TeamService;
import com.kitty.mina.cache.SessionUtils;
import com.kitty.mina.message.Message;
import com.kitty.mina.message.MessagePusher;
import java.text.MessageFormat;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class BuyWeddingConfirmHandler extends ConfirmHandler {
  @Autowired
  RoleService roleService;
  
  @Autowired
  EquipService equipService;
  
  @Autowired
  FasionService fasionService;
  
  @Autowired
  TeamService teamService;
  
  public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
    if ("1".equals(reqConfirmResult.getSelect())) {
      Team team = this.teamService.getTeam(role.getRoleId());
      List<Member> list = team.getList();
      int leaderId = team.getLeaderRoleId();
      Member leader = null;
      Member other = null;
      for (Member member : list) {
        if (member.getRoleId() == leaderId) {
          leader = member;
          continue;
        } 
        other = member;
      } 
      Role leaderRole = this.roleService.getOnlinePlayer(leader.getUid());
      Role otherRole = this.roleService.getOnlinePlayer(other.getUid());
      if (role.getActivity().getRechargeScore() >= 2000) {
        this.roleService.substractChargeScore(role, 2000);
      } else {
        String msg2 = "积分不足, 结婚失败";
        MessagePusher.pushMessage(role, new RespMsg(msg2));
        return;
      } 
      String msg = MessageFormat.format("你花费了#R{0}#n积分来支付此次婚礼的费用。", Integer.valueOf(2000));
      MessagePusher.pushMessage(role, new RespMsg(msg));
      leaderRole.setLoverId(otherRole.getRoleId());
      otherRole.setLoverId(leaderRole.getRoleId());
      leaderRole.save();
      otherRole.save();
      String fasionName = "龙凤呈祥服·新郎";
      short pos = this.fasionService.getFasionPos(role, "fasion_store");
      RoleEquip roleEquip = this.fasionService.getFasion(role, fasionName, 1, true);
      roleEquip.setPosition(pos);
      this.equipService.add(role, roleEquip);
      this.fasionService.sendFasionStore(roleEquip.getPosition(), role, roleEquip, "fasion_store");
      String fasionName2 = "龙凤呈祥服·新娘";
      short pos2 = this.fasionService.getFasionPos(otherRole, "fasion_store");
      RoleEquip roleEquip2 = this.fasionService.getFasion(otherRole, fasionName2, 1, true);
      roleEquip2.setPosition(pos2);
      this.equipService.add(otherRole, roleEquip2);
      this.fasionService.sendFasionStore(roleEquip2.getPosition(), otherRole, roleEquip2, "fasion_store");
      this.fasionService.equipFasion(SessionUtils.getSession(role.getRoleId()), fasionName);
      this.fasionService.equipFasion(SessionUtils.getSession(otherRole.getRoleId()), fasionName2);
      RespWeddingCheckMusic respWeddingCheckMusic = new RespWeddingCheckMusic();
      respWeddingCheckMusic.setIsReturn((byte)1);
      MessagePusher.pushMessage(role, respWeddingCheckMusic);
    } 
  }
}
