package com.kitty.game.camp.model;

import lombok.Getter;

@Getter
public enum CampEnum {
    FAIRY(2207, "仙"),
    BUDDHISM(2208, "佛"),
    MONSTER(2209, "妖"),
    DEMON(2210, "魔");

    private String value;
    private Integer taskId;

    CampEnum(Integer taskId, String value) {
        this.value = value;
        this.taskId = taskId;
    }

    public static Integer getTaskId(String value) {
        CampEnum[] campEnums = values();
        for (CampEnum campEnum : campEnums) {
            if (campEnum.getValue().equals(value)) {
                return campEnum.getTaskId();
            }
        }
        return null;
    }

    public static String getValue(Integer taskId) {
        CampEnum[] campEnums = values();
        for (CampEnum campEnum : campEnums) {
            if (campEnum.getValue().equals(taskId)) {
                return campEnum.getValue();
            }
        }
        return null;
    }
}
