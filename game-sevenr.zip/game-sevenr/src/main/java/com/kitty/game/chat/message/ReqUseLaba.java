package com.kitty.game.chat.message;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

/**
 * 使用喇叭
 */
@MessageMeta(module = Modules.CMD_TRY_USE_LABA)
public class ReqUseLaba extends Message {
}
