package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

import java.util.List;

@MessageMeta(module = Modules.MSG_CL_CARD_INFO)
public class RespCardInfo extends Message {
 
    private short size = 255;
 
    private short max_size = 500;
 
    private List<Integer> topId;
 
    private List<Integer> history_val;


    public short getSize() {
        return size;
    }

    public void setSize(short size) {
        this.size = size;
    }

    public short getMax_size() {
        return max_size;
    }

    public void setMax_size(short max_size) {
        this.max_size = max_size;
    }

    public List<Integer> getTopId() {
        return topId;
    }

    public void setTopId(List<Integer> topId) {
        this.topId = topId;
    }

    public List<Integer> getHistory_val() {
        return history_val;
    }

    public void setHistory_val(List<Integer> history_val) {
        this.history_val = history_val;
    }
}
