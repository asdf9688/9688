package com.kitty.game.activity.model.product;

import com.kitty.game.mail.model.MailAttachment;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**试道奖励*/
@Getter
@Setter
public class ShiDaoReward {
    private byte rank;

    private String title;

    private String content;

    private List<MailAttachment> attachments;

    //后加
    public void setRank(byte rank) {
        this.rank = rank;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setAttachments(List<MailAttachment> attachments) {
        this.attachments = attachments;
    }

    public byte getRank() {
        return this.rank;
    }

    public String getTitle() {
        return this.title;
    }

    public String getContent() {
        return this.content;
    }

    public List<MailAttachment> getAttachments() {
        return this.attachments;
    }
}
