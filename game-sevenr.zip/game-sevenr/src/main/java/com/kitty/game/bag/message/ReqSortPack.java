package com.kitty.game.bag.message;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.annotation.StringField;
import com.kitty.mina.message.Message;

/**
 * 整理背包
 */
@MessageMeta(module = Modules.CMD_SORT_PACK)
public class ReqSortPack extends Message {
    private short count;//有多少个物品需要整理
    @StringField(1)
    private String range;
    private short start_pos;//41 是整理背包 201是整理仓库
    @StringField(1)
    private String to_store_cards;

    public short getCount() {
        return count;
    }

    public void setCount(short count) {
        this.count = count;
    }

    public String getRange() {
        return range;
    }

    public void setRange(String range) {
        this.range = range;
    }

    public short getStart_pos() {
        return start_pos;
    }

    public void setStart_pos(short start_pos) {
        this.start_pos = start_pos;
    }

    public String getTo_store_cards() {
        return to_store_cards;
    }

    public void setTo_store_cards(String to_store_cards) {
        this.to_store_cards = to_store_cards;
    }
}
