package com.kitty.game.artifact;

import com.kitty.game.role.model.Role;
import com.kitty.game.equip.model.RoleEquip;
import com.kitty.game.fight.bean.FightObject;
import com.kitty.game.fight.bean.SuperBossFightObject;
import com.kitty.game.config.RoleDaofa;
import com.kitty.game.FieldValuePosConst;
import com.kitty.game.attribute.AttrService;
import com.kitty.game.config.RoleDaofa;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.equip.model.RoleEquip;
import com.kitty.game.equip.service.EquipService;
import com.kitty.game.fight.SkillConst;
import com.kitty.game.fight.artifact.passive.ArtifactType;
import com.kitty.game.fight.bean.FightObject;
import com.kitty.game.fight.bean.SuperBossFightObject;
import com.kitty.game.fight.message.RespSyncMessage;
import com.kitty.game.role.model.Role;
import com.kitty.game.utils.AsktaoUtil;
import com.kitty.game.utils.Const;
import com.kitty.mina.cache.DataCache;
import com.kitty.mina.message.MessagePusher;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.lang.Strings;
import org.nutz.lang.util.NutMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * 法宝
 */
@Service
public class ArtifactService {
    @Autowired
    Dao dao;
    @Autowired
    AttrService attrService;
    @Autowired
    EquipService equipService;

    /**
     * 法宝的特殊技能
     */
    private final static Map<String, Integer> skills = new HashMap<>();

    public void initArtifactExp() {
        List<RoleDaofa> list = dao.query(RoleDaofa.class, Cnd.NEW());
        for (RoleDaofa roleDaofa : list) {
            DataCache.DAOFA_LIST.put(roleDaofa.getId(), roleDaofa);
        }
        skills.put("diandao_qiankun", SkillConst.SKILL_DIAN_DAO);
        skills.put("jingangquan", SkillConst.SKILL_JING_GANG);
        skills.put("wuji_bifan", SkillConst.SKILL_WU_JI);
        skills.put("tianyan", SkillConst.SKILL_TIAN_YAN);
        skills.put("chaofeng", SkillConst.SKILL_CHAO_FENG);
        skills.put("qinmi_wujian", SkillConst.SKILL_QIN_MI);
    }

    public String getEquippedArtifact(Role role) {
        RoleEquip roleEquip = equipService.getRoleEquipByPos(role, Const.ARTIFACT);
        if (roleEquip == null) {
            return null;
        }
        for (ArtifactType item : ArtifactType.values()) {
            if (roleEquip.getName().equals(item.getName())) {
                return item.getName();
            }
        }
        return null;
    }

    public boolean getArtifactRate(String name, Role role) {
        RoleEquip roleEquip = equipService.getRoleEquipByPos(role, Const.ARTIFACT);
        if (roleEquip == null) {
            return false;
        }
        if (!roleEquip.getName().equals(name)) {
            return false;
        }

        int nimbus = roleEquip.getEquipValue(FieldValuePosConst.NIMBUS);
        // 判断灵气值是否够
        if (nimbus < 5) {/**法宝灵气值不足五点*/
            return false;
        }

        int level = roleEquip.queryLevel();

        RoleDaofa roleDaofa = equipService.getDaofaData(level);
        int rate = 0;
        if (roleDaofa != null) {
            rate = roleDaofa.getRate();
        }
        int intimacy = roleEquip.getEquipValue(FieldValuePosConst.INTIMACY);
        double dd = intimacy / 200000d;
        if (dd <= 0) {
            dd = 0;
        }
        rate = (int) (dd * 10 + rate * 10);
        if (rate >= 1000) {
            costNimbus(roleEquip, role);
            return true;
        }
        Random random = new Random();
        int value = random.nextInt(1000);
        if (value < rate) {
            costNimbus(roleEquip, role);
            return true;
        }
        return false;
    }

    public boolean getArtifactRate(int level) {
        RoleDaofa roleDaofa = equipService.getDaofaData(level);
        int rate = 0;
        if (roleDaofa != null) {
            rate = roleDaofa.getRate();
        }
        int intimacy = 200000;
        double dd = intimacy / 200000d;
        if (dd <= 0) {
            dd = 0;
        }
        rate = (int) (dd * 10 + rate * 10);
        if (rate >= 1000) {
            return true;
        }
        Random random = new Random();
        int value = random.nextInt(1000);
        if (value < rate) {
            return true;
        }
        return false;
    }


    /**
     * 每触发一次消耗灵气值
     *
     * @param roleEquip
     */
    private void costNimbus(RoleEquip roleEquip, Role role) {
        int nimbus = roleEquip.getEquipValue(FieldValuePosConst.NIMBUS);
        roleEquip.setEquipValue(FieldValuePosConst.NIMBUS, nimbus - 5);
        role.save();
        equipService.refreshRoleEquip(role, roleEquip);
    }

    /**
     * 获得超级boss法宝触发机率
     */
    public boolean getSuperBossArtifactRate(String name, SuperBossFightObject superBossObject) {
        int level = superBossObject.queryArtifactLevel(name);

        RoleDaofa roleDaofa = equipService.getDaofaData(level);
        int rate = 0;
        if (roleDaofa != null) {
            rate = roleDaofa.getRate();
        }
        rate = rate * 10;
        if (rate >= 1000) {
            return true;
        }
        Random random = new Random();
        int value = random.nextInt(1000);
        if (value < rate) {
            return true;
        }
        return false;
    }

    /**
     * 添加法宝道法
     */
    public void addArtifactExp(boolean doubleFlag, Role role) {
        RoleEquip roleEquip = equipService.getRoleEquipByPos(role, Const.ARTIFACT);
        if (roleEquip == null) {
            return;
        }
        /**一场战斗增加5点亲密度吧*/
        int intimacy = roleEquip.getEquipValue(FieldValuePosConst.INTIMACY);
        if (intimacy < 500000) {/**最大50W亲密*/
            roleEquip.setEquipValue(FieldValuePosConst.INTIMACY, intimacy + 5);
        }
        NutMap propsStatus = role.getPropsStatus();
        int point = propsStatus.getInt("ziqi");
        Random random = new Random();
        int value = random.nextInt(200);
        int exp = 1000 + value;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("获得基础道法#R"+exp+"点#n");
        if (propsStatus.getInt("wu_bei") == 1 && point >= 50) {
            propsStatus.setv("ziqi", point - 50);
            exp = exp * 2*3;
            stringBuilder.append("，开启#R五倍紫气鸿蒙#n后道法增加至#R"+exp+"点#n");
        } else if (propsStatus.getInt("san_bei") == 1 && point >= 30) {
            propsStatus.setv("ziqi", point - 30);
            exp = exp * 2*2;
            stringBuilder.append("，开启#R三倍紫气鸿蒙#n后道法增加至#R"+exp+"点#n");
        } else if (propsStatus.getInt("ziqiStatus") == 1 && point >= 10) {
            // 开启紫气鸿蒙才加道法
            propsStatus.setv("ziqi", point - 10);
            if (doubleFlag) {
                exp = exp * 2;
            }
            stringBuilder.append("，开启#R紫气鸿蒙#n后道法增加至#R"+exp+"点#n");
        }
        role.save();
        int currExp = roleEquip.getEquipValue(FieldValuePosConst.EXP);
        currExp += exp;
        roleEquip.setEquipValue(FieldValuePosConst.EXP, currExp);

        RoleDaofa currLevel = equipService.getDaofaData(roleEquip.queryLevel());
        /**升等级*/
        RoleDaofa nextLevel = equipService.getDaofaData(roleEquip.queryLevel() + 1);
        if (nextLevel != null && currLevel.getDaofa() <= currExp) {
            /**升级*/
            roleEquip.setEquipValue(FieldValuePosConst.LEVEL, nextLevel.getLevel());
            /**道法归0*/
            roleEquip.setEquipValue(FieldValuePosConst.EXP, 0);
            /**设置下一等级的EXP*/
            roleEquip.setEquipValue(FieldValuePosConst.NEXT_LEVEL_EXP, nextLevel.getDaofa());

            RespSyncMessage respSyncMessage = new RespSyncMessage();
            respSyncMessage.setCode((short) 20481);
            respSyncMessage.setMsg(AsktaoUtil.getMessageBody(new RespNotifyMiscEx(stringBuilder.toString())));
            MessagePusher.pushMessage(role, respSyncMessage);
    }
        // mod tao 输出获取道法的消息
        MessagePusher.pushMessage(role, new RespNotifyMiscEx(stringBuilder.toString()));
        // mod:e
        role.save();
        equipService.refreshRoleEquip(role, roleEquip);
    }


    /**
     * 返回法宝特殊技能ID 没有法宝或者没有特殊技能返回0
     */
    public int getSpecialSkillId(FightObject player) {
        if (!player.isPlayer()) {
            return 0;
        }
        return getSpecialSkillId(player.getRole());
    }

    public int getSpecialSkillId(Role player) {
        /**取出身上携带的元宝*/
        RoleEquip artifact = equipService.getRoleEquipByPos(player, Const.ARTIFACT);
        if (artifact == null || !artifact.isArtifact()) {
            return 0;//如果不是法宝或者 没有法宝 返回0
        }
        String skillStr = artifact.getEquipValueObject(FieldValuePosConst.ARTIFACT_SKILL);
        if (Strings.isEmpty(skillStr)) {
            return 0;
        }
        Integer skillId = skills.get(skillStr);
        if (skillId != null) {
            return skillId;
        }
        return 0;
    }

    /**取法宝特殊技能等级*/
    public int getSpecialSkillLevel(FightObject player){
        if (!player.isPlayer()) {
            return 0;
        }
        /**取出身上携带的元宝*/
        RoleEquip artifact = equipService.getRoleEquipByPos(player.getRole(), Const.ARTIFACT);
        if (artifact == null || !artifact.isArtifact()) {
            return 0;//如果不是法宝或者 没有法宝 返回0
        }
        /**如果返回的是0 需要确认是否有特殊技能 洗炼的时候给1级的*/
        return artifact.getEquipValue(FieldValuePosConst.ARTIFACT_SKILL_LEVEL);
    }


    /**是不是法宝技能*/
    public boolean isArtifactSkill(int skillId){
        return skills.containsValue(skillId);
    }
}
