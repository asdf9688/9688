package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

/**
 * 我的师徒留言
 */
@MessageMeta(module = Modules.MSG_MY_MASTER_MESSAGE)
public class RespMyAppenticeMessage extends Message {

//    private short a = 0;

    private byte a = 0;

	public byte getA() {
		return a;
	}

	public void setA(byte a) {
		this.a = a;
	}
    
    

   
}
