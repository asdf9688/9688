package com.kitty.game.drop;

import com.kitty.game.drop.model.product.DropSet;
import com.kitty.game.drop.model.product.FightDropSet;
import com.kitty.game.drop.model.product.ItemDropSet;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DropDataPool {
    /**key：掉落组，value：掉落列表 */
    public static Map<Integer, List<DropSet>> dropMapByGroup = new HashMap<>();

    /**key：掉落标识，value：最大掉落数量 */
    public static Map<Serializable, Integer> dropLimit = new HashMap<>();

    /**key: 物品名称, value: 物品对应掉落配置数据*/
    public static Map<String, ItemDropSet> itemDropMap = new HashMap<>();

    public static Map<Integer, List<FightDropSet>> fightType2DropMap = new HashMap<>();
}
