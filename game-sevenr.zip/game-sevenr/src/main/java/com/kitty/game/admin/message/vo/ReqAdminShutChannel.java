package com.kitty.game.admin.message.vo;

import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;
import lombok.Getter;

@Getter
@MessageMeta(module = Modules.CMD_ADMIN_SHUT_CHANNEL)
public class ReqAdminShutChannel extends Message {
    private String name;
    private String gid;
    private int time;
    private String channel;
    private String reason;



    public String getName() {
        return this.name;
    }

    public String getGid() {
        return this.gid;
    }

    public int getTime() {
        return this.time;
    }

    public String getChannel() {
        return this.channel;
    }

    public String getReason() {
        return this.reason;
    }
}
