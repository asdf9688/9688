package com.kitty.game.confirm.model;

import lombok.Getter;
import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;


@Getter
public class PrisonReleaseConfirm extends RoleConfirm {
    private long gid;
    private String name;

    public PrisonReleaseConfirm(long gid, String name) {
        this.gid = gid;
        this.name = name;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.PRISON_RELEASE;
    }
}
