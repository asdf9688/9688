package com.kitty.game.confirm.model;

import lombok.Getter;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

@Getter
public class BuyDevilTimeConfirm extends RoleConfirm {
    public static final byte BYTE_MEONY = 1;
    public static final byte BYTE_GOLD = 2;
    private byte type;

    public BuyDevilTimeConfirm(byte type) {
        this.type = type;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.BUY_DEVIL_TIME;
    }
}
