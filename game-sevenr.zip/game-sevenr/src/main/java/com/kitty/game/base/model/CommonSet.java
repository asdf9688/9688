package com.kitty.game.base.model;

import lombok.Getter;
import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

/***
 * 系统配置
 */
@Table("p_commonset")
@Getter
public class CommonSet {
    /**键，用于索引*/
    @Name
    @ColDefine(width = 128)
    private String skey;
    /**值*/
    @Column
    @ColDefine(type= ColType.TEXT)
    private String svalue;
    /**描述*/
    @Column
    @ColDefine(width = 512)
    private String sdesc;



    public String getSkey() {
        return this.skey;
    }

    public String getSvalue() {
        return this.svalue;
    }

    public String getSdesc() {
        return this.sdesc;
    }
}
