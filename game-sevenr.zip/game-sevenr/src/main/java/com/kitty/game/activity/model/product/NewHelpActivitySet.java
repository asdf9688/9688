package com.kitty.game.activity.model.product;

import com.kitty.game.utils.TimeUtil;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Setter
@Getter
public class NewHelpActivitySet {
        private String startTime;
         /**活动开始时间*/
        private long startTimeL;

        private String endTime;
           /**活动结束时间*/
        private long endTimeL;

        //后加

        public void setStartTime(String startTime) {
            this.startTime = startTime;
        }

        public void setStartTimeL(long startTimeL) {
            this.startTimeL = startTimeL;
        }

        public void setEndTime(String endTime) {
            this.endTime = endTime;
        }

        public void setEndTimeL(long endTimeL) {
            this.endTimeL = endTimeL;
        }

        public String getStartTime() {
            return this.startTime;
        }

        public long getStartTimeL() {
            return this.startTimeL;
        }

        public String getEndTime() {
            return this.endTime;
        }

        public long getEndTimeL() {
            return this.endTimeL;
        }

    public void init() {
        Date date = TimeUtil.parse(startTime, TimeUtil.DEFAULT_DATE_FORMAT);
        startTimeL = date.getTime();

        date = TimeUtil.parse(endTime, TimeUtil.DEFAULT_DATE_FORMAT);
        endTimeL = date.getTime();

    }

}
