package com.kitty.game.bag.model;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

@Table("p_gift_bag_data")
public class GiftBagData {
    @Id
    private int id;

    @Column
    @Comment("礼包ID")
    private Integer gid;

    @Column
    @Comment("礼包数据类型")
    private GiftType type;

    @Column
    @Comment("礼包数据名称")
    private String name;

    @Column
    @Comment("礼包内容")
    private String content;

    @Column
    @Comment("数量")
    private Integer count;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getGid() {
        return gid;
    }

    public void setGid(Integer gid) {
        this.gid = gid;
    }

    public GiftType getType() {
        return type;
    }

    public void setType(GiftType type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }
}
