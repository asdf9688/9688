package com.kitty.game.drop.model.user;

import com.kitty.game.drop.model.product.DropSet;
import lombok.Getter;
import lombok.Setter;

/**掉落*/
@Setter
@Getter
public class DropUnit {
    /**掉落配置数据*/
    private DropSet dropSet;
    /**数量*/
    private int count;

    public DropUnit() {}

    public DropUnit(DropSet dropSet, int count) {
        this.dropSet = dropSet;
        this.count = count;
    }
}
