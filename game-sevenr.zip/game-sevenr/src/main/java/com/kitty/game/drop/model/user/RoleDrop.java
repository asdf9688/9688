package com.kitty.game.drop.model.user;

import lombok.Getter;
import lombok.Setter;

import java.util.Map;

/**记录已掉落信息*/
@Getter
@Setter
public class RoleDrop {
    /**掉落数量，key: 掉落标识, value: 对应的数量，每日进行重置*/
    private Map<String, Integer> dailyDropCountMap;
}
