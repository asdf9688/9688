package com.kitty.game.confirm.model;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;


public class GiveUpTaskConfirm extends RoleConfirm{
    private String taskName;

    public GiveUpTaskConfirm(String taskName) {
        this.taskName = taskName;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.GIVE_UP_TASK;
    }

    public String getTaskName() {
        return taskName;
    }
}
