package com.kitty.game.activity.model.user;

import com.kitty.game.role.model.Role;
import lombok.Getter;
import lombok.Setter;

/**挑战神魔次数最多的记录*/
@Getter
@Setter
public class DevilFirstHistory {
    private int npcId;
    private String gid;
    private String name;
    private int icon;
    private int maxKill;
    private short weaponIcon;
    private int suitIcon;
    private int suitLightEffect;

    public DevilFirstHistory() {}

    public DevilFirstHistory(int npcId, Role role, int maxKill) {
        this.npcId = npcId;
        this.gid = role.getGid();
        this.name = role.getName();
        this.icon = role.getRoleIcon();
        this.maxKill = maxKill;
        this.weaponIcon = (short) role.getWeaponIcon();
        this.suitIcon = role.getSuitId();
        this.suitLightEffect = role.getSuitLightId();
    }
    //后加
    public void setNpcId(int npcId) {
        this.npcId = npcId;
    }

    public void setGid(String gid) {
        this.gid = gid;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public void setMaxKill(int maxKill) {
        this.maxKill = maxKill;
    }

    public void setWeaponIcon(short weaponIcon) {
        this.weaponIcon = weaponIcon;
    }

    public void setSuitIcon(int suitIcon) {
        this.suitIcon = suitIcon;
    }

    public void setSuitLightEffect(int suitLightEffect) {
        this.suitLightEffect = suitLightEffect;
    }

    public int getNpcId() {
        return this.npcId;
    }

    public String getGid() {
        return this.gid;
    }

    public String getName() {
        return this.name;
    }

    public int getIcon() {
        return this.icon;
    }

    public int getMaxKill() {
        return this.maxKill;
    }

    public short getWeaponIcon() {
        return this.weaponIcon;
    }

    public int getSuitIcon() {
        return this.suitIcon;
    }

    public int getSuitLightEffect() {
        return this.suitLightEffect;
    }
}
