package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

@MessageMeta(module = Modules.MSG_BAXIAN_LEFT_TIMES)
public class RespBaxianLeftTimes extends Message {
    private short left_time = 0;

    public short getLeft_time() {
        return left_time;
    }

    public void setLeft_time(short left_time) {
        this.left_time = left_time;
    }
}
