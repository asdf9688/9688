package com.kitty.game.config;

import com.kitty.game.boss.config.BossSet;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Default;
import org.nutz.dao.entity.annotation.Table;

import java.util.ArrayList;

@Table("p_xing")
public class Xing extends BossSet {
    @Column
    private int level;
    @Column
    private int minLevel;
    @Column
    @Default("[]")
    private ArrayList<String> bornMap;

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getMinLevel() {
        return minLevel;
    }

    public void setMinLevel(int minLevel) {
        this.minLevel = minLevel;
    }

    public ArrayList<String> getBornMap() {
        return bornMap;
    }

    public void setBornMap(ArrayList<String> bornMap) {
        this.bornMap = bornMap;
    }
}
