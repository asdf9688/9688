package com.kitty.game.confirm.service.handler;

import com.kitty.game.role.model.Role;
import com.kitty.game.equip.model.RoleEquip;
import com.kitty.game.config.ShapePen;
import com.kitty.common.spring.SpringUtils;
import com.kitty.game.confirm.model.ShapePenConfirm;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.item.service.ChangeCardService;
import com.kitty.game.team.message.ReqConfirmResult;
import com.kitty.mina.message.MessagePusher;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import com.kitty.game.confirm.service.handler.ConfirmHandler;

@Component
public class UseShapePenHandler extends ConfirmHandler{
    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
        if(reqConfirmResult.getSelect().equals("1")){
            applyShapePen(role);
        }
    }

    /**使用九曲玲珑笔*/
    private void applyShapePen(Role role) {
        ShapePenConfirm confirm =(ShapePenConfirm)role.getConfirm();
        RoleEquip roleEquip = confirm.getRoleEquip();
        ShapePen shapePen =confirm.getShapePen();
        Role targetRole =confirm.getTargetRole();

        if(role.equals(targetRole)){
            MessagePusher.pushMessage(role, new RespNotifyMiscEx(MessageFormat.format("你使用了#R九曲玲珑变身-{0}#n。", shapePen.getName())));
        }
        SpringUtils.getBean(ChangeCardService.class).useShapePen(role,targetRole,roleEquip,shapePen);
    }
}
