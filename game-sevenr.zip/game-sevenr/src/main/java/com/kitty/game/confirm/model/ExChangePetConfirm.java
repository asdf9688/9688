package com.kitty.game.confirm.model;

import com.kitty.game.config.ExchangePet;
import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

public class ExChangePetConfirm extends RoleConfirm{
    private ExchangePet exchangePet;

    public ExChangePetConfirm(ExchangePet exchangePet) {
        this.exchangePet = exchangePet;
    }

    public ExchangePet getExchangePet() {
        return exchangePet;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.EXCHANGE_PET;
    }
}
