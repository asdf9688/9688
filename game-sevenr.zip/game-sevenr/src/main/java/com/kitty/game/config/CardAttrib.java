package com.kitty.game.config;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CardAttrib {
    private String fieldName;
    private int value;//属性百分比
    private String chsName;//属性中文名

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public void setChsName(String chsName) {
        this.chsName = chsName;
    }

    public String getFieldName() {
        return this.fieldName;
    }

    public int getValue() {
        return this.value;
    }

    public String getChsName() {
        return this.chsName;
    }
}
