package com.kitty.game.admin.message.vo;

import com.kitty.game.role.model.Account;
import com.kitty.game.role.model.Role;
import lombok.Setter;

@Setter
public class QueryPlayer {
    private String server;
    private String account;
    private String name;
    private String gid;
    private short level;
    private byte polar;
    private String mac;
    private String ip;

    public QueryPlayer(Account account, Role role,String ip,String server) {
        this.account = account.getUsername();
        this.name = role.getName();
        this.gid = role.getGid();
        this.server = server;
        this.level = role.getLevel();
        this.polar = (byte) role.getPolar();
        this.mac = account.getDeviceInfo();
        this.ip = ip;
    }
    //后加
    public void setIp(String ip) {
        this.ip = ip;
    }

    public void setMac(String mac) {
        this.mac = mac;
    }

    public void setPolar(byte polar) {
        this.polar = polar;
    }

    public void setLevel(short level) {
        this.level = level;
    }

    public void setGid(String gid) {
        this.gid = gid;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public void setServer(String server) {
        this.server = server;
    }
}
