package com.kitty.game.activity.model.user;

import com.kitty.game.team.model.Member;
import com.kitty.game.team.model.Team;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
//后加
import com.kitty.game.activity.model.user.ShiDaoPKData;


/**试道队伍pk阶段数据*/
@Getter
@Setter
public class ShiDaoPKData implements Comparable<ShiDaoPKData>{
    /**队伍ID*/
    private int teamId;
    /**对决值*/
    private short pkValue;
    /**试道积分*/
    private short totalScore=10;
    /**排名*/
    private byte rank;
    /**队伍成员*/
    private List<Member> members;
    /**上一次PK结束时间*/
    private long prevPKTime;

    public ShiDaoPKData() {}

    public ShiDaoPKData(Team team, short pkValue) {
        this.teamId = team.getId();
        this.pkValue = pkValue;
        this.totalScore = 10;

        List<Member> members = getMembers(team);
        this.members = members;
    }

    private List<Member> getMembers(Team team) {
        List<Member> members = new ArrayList<>();
        ArrayList<Member> list = team.getList();
        for (Member member : list) {
            if (member.isInTeam() == false) {continue;}
            if (!members.contains(member)) {
                members.add(member);
            }
        }
        return members;
    }

    public void addTotalScore(short score) {
        this.totalScore += score;
    }
    public void subTotalScore() {
        this.totalScore = (short) (this.totalScore-2);
        if (this.totalScore<=0){
            this.totalScore = 0;
        }
    }

    public void substractPkValue(short pkValue) {
        this.pkValue -= pkValue;
    }

    @Override
    public int compareTo(ShiDaoPKData o) {
        /**按试道积分从大到小排序*/
        if (totalScore != o.totalScore) {
            return totalScore > o.totalScore ? -1 : 1;
        }

        return Integer.compare(teamId, o.teamId);
    }

    /**更新组队成员*/
    public void updateTeamMember(Team team) {
        List<Member> members = getMembers(team);
        this.members = members;
    }
    //后加
    public short getTotalScore() {
        return this.totalScore;
    }

    public byte getRank() {
        return this.rank;
    }

    public List<Member> getMembers() {
        return this.members;
    }

    public long getPrevPKTime() {
        return this.prevPKTime;
    }

    public void setTeamId(int teamId) {
        this.teamId = teamId;
    }

    public void setPkValue(short pkValue) {
        this.pkValue = pkValue;
    }

    public void setTotalScore(short totalScore) {
        this.totalScore = totalScore;
    }

    public void setRank(byte rank) {
        this.rank = rank;
    }

    public void setMembers(List<Member> members) {
        this.members = members;
    }

    public void setPrevPKTime(long prevPKTime) {
        this.prevPKTime = prevPKTime;
    }

    public int getTeamId() {
        return this.teamId;
    }

    public short getPkValue() {
        return this.pkValue;
    }
}
