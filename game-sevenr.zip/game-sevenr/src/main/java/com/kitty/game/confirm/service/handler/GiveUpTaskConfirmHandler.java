package com.kitty.game.confirm.service.handler;

import com.kitty.game.config.TaskSet;
import com.kitty.game.role.model.Role;
import com.kitty.common.spring.SpringUtils;
import com.kitty.game.activity.service.task.TowerTaskHandler;
import com.kitty.game.confirm.model.GiveUpTaskConfirm;
import com.kitty.game.task.TaskDataPool;
import com.kitty.game.task.service.NewTaskService;
import com.kitty.game.task.service.taskHandler.ChangeCardTaskHandler;
import com.kitty.game.task.service.taskHandler.DigTreasureTaskHandler;
import com.kitty.game.task.service.taskHandler.DugeonTaskHandler;
import com.kitty.game.task.service.taskHandler.ShapePenTaskTaskHandler;
import com.kitty.game.team.message.ReqConfirmResult;
import com.sun.jmx.snmp.tasks.TaskServer;
import org.springframework.stereotype.Component;
import com.kitty.game.confirm.service.handler.ConfirmHandler;

@Component
public class GiveUpTaskConfirmHandler extends ConfirmHandler{

    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {

        /**选择确认*/
        if ("1".equals(reqConfirmResult.getSelect())) {
            GiveUpTaskConfirm giveUpTaskConfirm = (GiveUpTaskConfirm)role.getConfirm();
            // TODO 暂时先把判断写死，后续再看怎么优化
            if (giveUpTaskConfirm.getTaskName().equals("通天塔")) {
                SpringUtils.getBean(TowerTaskHandler.class).confirmGiveUpTask(role);
            }else if(giveUpTaskConfirm.getTaskName().equals("千变万化")){
                SpringUtils.getBean(ChangeCardTaskHandler.class).delTask(role);
            } else if(giveUpTaskConfirm.getTaskName().equals("九曲玲珑变身")){
                SpringUtils.getBean(ShapePenTaskTaskHandler.class).delTask(role);
            } else if(giveUpTaskConfirm.getTaskName().equals("飘渺仙府")) {
                SpringUtils.getBean(DugeonTaskHandler.class).confirmGiveUpTask(role);
            }else if (giveUpTaskConfirm.getTaskName().equals("超级宝藏")){
                SpringUtils.getBean(DigTreasureTaskHandler.class).delTask(role);
            }else if (giveUpTaskConfirm.getTaskName().equals("寻找宝藏")){
                SpringUtils.getBean(DigTreasureTaskHandler.class).delTask1(role);
            }else {
                // TODO 需要实现逻辑
            }
        }
    }
}
