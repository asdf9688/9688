package com.kitty.game.confirm.model;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;


public class FightSealBossConfirm extends RoleConfirm {
    private int fightMapId;

    public FightSealBossConfirm(int fightMapId) {
        this.fightMapId = fightMapId;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.FIGHT_SEAL_BOSS;
    }

    public int getFightMapId() {
        return fightMapId;
    }
}
