package com.kitty.game.bag.message;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;


/**
 * 整理背包
 */
@MessageMeta(module = Modules.MSG_FINISH_SORT_PACK)
public class RespFinishSortPack extends Message {
    private byte start_range = 1;// custom_store fasion_store effect_store

    public byte getStart_range() {
        return start_range;
    }

    public void setStart_range(byte start_range) {
        this.start_range = start_range;
    }
}
