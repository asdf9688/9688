package com.kitty.game.confirm.model;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

public class TowerChangeRewardConfirm extends RoleConfirm{
    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.TOWER_CHANGE_REWARD;
    }
}
