package com.kitty.game.activity.message;

import com.kitty.game.activity.message.vo.ShiDaoMemberInfo;
import com.kitty.mina.Modules;
import com.kitty.mina.annotation.ListField;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

import java.util.List;

@MessageMeta(module = Modules.MSG_OPEN_SHIDWZDLG)
public class RespOpenShiDaoWZDLG extends Message {
    @ListField(1)
    private List<ShiDaoMemberInfo> list;

    public List<ShiDaoMemberInfo> getList() {
        return list;
    }

    public void setList(List<ShiDaoMemberInfo> list) {
        this.list = list;
    }
}
