package com.kitty.game.config;

import com.kitty.game.task.model.product.TaskTarget;
import com.kitty.game.task.model.product.TaskType;
import org.nutz.dao.entity.annotation.*;
import org.nutz.lang.util.NutMap;

import java.util.List;

//后加
import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Default;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;


@Table("p_taskset")
public class TaskSet implements Cloneable{
    @Id
    private int id;
    @Column
    private String taskName;
    @Column
    private String taskJieshao;
    @Column
    @ColDefine(width = 512)
    private String taskZhiyin;
    @Column
    private String taskGift;
    @Column
    private String npcName;
    @Column
    @ColDefine(width = 512)
    private String buttton;
    @Column
    private int giveUp; //是否可以放弃 1可以放弃 0不能放弃
    @Column
    @Default("{}")
    @ColDefine(width = 256)
    private NutMap rewardList; //奖励
    @Column
    @Default("0")
    private int nextId; //下一个任务id
    @Column
    @ColDefine(width = 2048)
    private String taskTargetJson;
    /**任务目标集合，有序，按顺序完成目标*/
    private List<TaskTarget> taskTargetList;
    /**上一任务id，通过计算得到*/
    private int previousId;

    /**任务类型*/
    @Column
    private TaskType taskType;

    /**
     * 获得对应下标的任务目标
     * @param index
     * @return
     */
    public TaskTarget getTaskTargetByIndex(int index) {
        if (taskTargetList == null) {return null;}
        if (index < 0 || index >= taskTargetList.size()) {
            return null;
        }

        return taskTargetList.get(index);
    }

    public int getTaskTargetCount() {
        if(taskTargetList==null){return 0;}
        return taskTargetList.size();
    }

    public int getGiveUp() {
        return giveUp;
    }

    public void setGiveUp(int giveUp) {
        this.giveUp = giveUp;
    }

    public String getButtton() {
        return buttton;
    }

    public void setButtton(String buttton) {
        this.buttton = buttton;
    }

    public String getNpcName() {
        return npcName;
    }

    public void setNpcName(String npcName) {
        this.npcName = npcName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getTaskJieshao() {
        return taskJieshao;
    }

    public void setTaskJieshao(String taskJieshao) {
        this.taskJieshao = taskJieshao;
    }

    public String getTaskZhiyin() {
        return taskZhiyin;
    }

    public void setTaskZhiyin(String taskZhiyin) {
        this.taskZhiyin = taskZhiyin;
    }

    public String getTaskGift() {
        return taskGift;
    }

    public void setTaskGift(String taskGift) {
        this.taskGift = taskGift;
    }

    public NutMap getRewardList() {
        return rewardList;
    }

    public void setRewardList(NutMap rewardList) {
        this.rewardList = rewardList;
    }

    public int getNextId() {
        return nextId;
    }

    public void setNextId(int nextId) {
        this.nextId = nextId;
    }

    public int getPreviousId() {
        return previousId;
    }

    public void setPreviousId(int previousId) {
        this.previousId = previousId;
    }

    public String getTaskTargetJson() {
        return taskTargetJson;
    }

    public void setTaskTargetList(List<TaskTarget> taskTargetList) {
        this.taskTargetList = taskTargetList;
    }

    public TaskType getTaskType() {
        return taskType;
    }

    /**浅拷贝*/
    @Override
    public TaskSet clone() throws CloneNotSupportedException {
        return (TaskSet) super.clone();
    }

    /**是否整队接取*/
    public boolean isTeamAccept() {
        if (taskType.equals(TaskType.DUGEON)) {
            return true;
        }
        return false;
    }
}
