package com.kitty.game.activity.message.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ShiDaoMemberInfo {
    private String gid;

    private String name;

    private short level;

    private byte polar;

    private short icon;
//后加
    public void setGid(String gid) {
        this.gid = gid;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLevel(short level) {
        this.level = level;
    }

    public void setPolar(byte polar) {
        this.polar = polar;
    }

    public void setIcon(short icon) {
        this.icon = icon;
    }

    public String getGid() {
        return this.gid;
    }

    public String getName() {
        return this.name;
    }

    public short getLevel() {
        return this.level;
    }

    public byte getPolar() {
        return this.polar;
    }

    public short getIcon() {
        return this.icon;
    }
//到这里
    public ShiDaoMemberInfo() {}

    public ShiDaoMemberInfo(String gid, String name, short level, byte polar, short icon) {
        this.gid = gid;
        this.name = name;
        this.level = level;
        this.polar = polar;
        this.icon = icon;
    }
}
