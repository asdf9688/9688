package com.kitty.game.activity.model.product;

import lombok.Getter;

/**证道殿护法配置*/
@Getter
public class ZDHuFaSet {
    /**对应NPC id*/
    private int npcId;
    /**职业*/
    private byte polar;
    /**性别*/
    private byte gender;
    /**挑战最小等级*/
    private short minLevel;
    /**挑战最大等级*/
    private short maxLevel;
    /**称谓*/
    private String title;
    //后加
    public int getNpcId() {
        return this.npcId;
    }

    public byte getPolar() {
        return this.polar;
    }

    public byte getGender() {
        return this.gender;
    }

    public short getMinLevel() {
        return this.minLevel;
    }

    public short getMaxLevel() {
        return this.maxLevel;
    }

    public String getTitle() {
        return this.title;
    }
}
