package com.kitty.game.config;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;



@Table("p_choujianggift")
public class ChoujiangGift {
    @Id
    private int id;
    @Column
    private byte per;
    @Column
    private String name;
    @Column
    private String str;
    @Column
    private byte type;
    @Column
    @Comment("普通抽奖概率")
    private int normal;
    @Column
    @Comment("大额抽奖概率")
    private int dae;
    @Column
    @Comment("物品类型")
    private int goodType;
    @Column
    @Comment("使用类型")
    private int useType;
    @Column
    @Comment("是否公告")
    private byte isAnnouncement;

    public int getGoodType() {
        return goodType;
    }

    public void setGoodType(int goodType) {
        this.goodType = goodType;
    }

    public int getUseType() {
        return useType;
    }

    public void setUseType(int useType) {
        this.useType = useType;
    }

    public int getNormal() {
        return normal;
    }

    public void setNormal(int normal) {
        this.normal = normal;
    }

    public int getDae() {
        return dae;
    }

    public void setDae(int dae) {
        this.dae = dae;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public byte getPer() {
        return per;
    }

    public void setPer(byte per) {
        this.per = per;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStr() {
        return str;
    }

    public void setStr(String str) {
        this.str = str;
    }

    public byte getType() {
        return type;
    }

    public void setType(byte type) {
        this.type = type;
    }

    public byte getIsAnnouncement() {
        return isAnnouncement;
    }

    public void setIsAnnouncement(byte isAnnouncement) {
        this.isAnnouncement = isAnnouncement;
    }
}
