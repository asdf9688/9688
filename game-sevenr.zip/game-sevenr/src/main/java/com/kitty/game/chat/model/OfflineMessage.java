package com.kitty.game.chat.model;

import lombok.Getter;

@Getter
public class OfflineMessage {
    /**发送时间，单位秒*/
    private int time;
    /**聊天内容*/
    private String msg;
    private String token;
    private int voiceTime;

    public int getTime() {
        return this.time;
    }

    public String getMsg() {
        return this.msg;
    }

    public String getToken() {
        return this.token;
    }

    public int getVoiceTime() {
        return this.voiceTime;
    }


    public OfflineMessage() {}

    public OfflineMessage(int time, String msg, String token, int voiceTime) {
        this.time = time;
        this.msg = msg;
        this.token = token;
        this.voiceTime = voiceTime;
    }
}
