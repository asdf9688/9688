package com.kitty.game.activity.message;

import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@MessageMeta(module = Modules.CMD_FETCH_SHUADAO_SCORE_ITEM)
public class ReqFetchShuaDaoScoreItem extends Message {
    private byte type;
    private byte index;

    public void setType(byte type) {
        this.type = type;
    }

    public void setIndex(byte index) {
        this.index = index;
    }

    public byte getType() {
        return this.type;
    }

    public byte getIndex() {
        return this.index;
    }
}
