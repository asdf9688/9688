package com.kitty.game.bangpai;

import com.kitty.game.enter.FiedValue;

import java.util.List;

public class JoinMemberInfo {
    private int icon;
    private List<FiedValue> list;
    private byte teamMembersCount;
    private byte comeback_flag;

    public byte getTeamMembersCount() {
        return teamMembersCount;
    }

    public void setTeamMembersCount(byte teamMembersCount) {
        this.teamMembersCount = teamMembersCount;
    }

    public byte getComeback_flag() {
        return comeback_flag;
    }

    public void setComeback_flag(byte comeback_flag) {
        this.comeback_flag = comeback_flag;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public List<FiedValue> getList() {
        return list;
    }

    public void setList(List<FiedValue> list) {
        this.list = list;
    }
}
