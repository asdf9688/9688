package com.kitty.game.chat.message;


import com.kitty.game.enter.FiedValue;
import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

import java.util.List;

/**
 * 处理角色发言
 */
@MessageMeta(module = Modules.MSG_CARD_INFO, cmd = 1)
public class RespRoleInfo extends Message {
    private String uuId;
    private String type;
    private List<FiedValue> list;
    private int a;
    private short b;

    public String getUuId() {
        return uuId;
    }

    public void setUuId(String uuId) {
        this.uuId = uuId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<FiedValue> getList() {
        return list;
    }

    public void setList(List<FiedValue> list) {
        this.list = list;
    }
}
