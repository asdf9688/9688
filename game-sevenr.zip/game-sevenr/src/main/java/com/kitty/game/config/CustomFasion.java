package com.kitty.game.config;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

//自定义时装
@Table("p_customfasion")
public class CustomFasion {
    @Column
    @Comment("时装Icon")
    private int icon;
    @Name
    @Comment("时装名字")
    private String name;
    @Column
    @Comment("时装部位")
    private byte pos;
    @Column
    @Comment("时装类型")
    private byte type;
    @Column
    @Comment("时装颜色")
    private byte color;
    @Column
    @Comment("时装性别")
    private byte sex;

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public byte getPos() {
        return pos;
    }

    public void setPos(byte pos) {
        this.pos = pos;
    }

    public byte getType() {
        return type;
    }

    public void setType(byte type) {
        this.type = type;
    }

    public byte getColor() {
        return color;
    }

    public void setColor(byte color) {
        this.color = color;
    }

    public byte getSex() {
        return sex;
    }

    public void setSex(byte sex) {
        this.sex = sex;
    }
}
