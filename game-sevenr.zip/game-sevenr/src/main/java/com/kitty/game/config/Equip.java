package com.kitty.game.config;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

@Table("p_equip")
public class Equip {
    @Column
    @Comment("key_name")
    private String key_name;
    @Column
    @Comment("icon")
    private int icon;
    @Column
    @Comment("gender")
    private byte gender;
    @Column
    @Comment("unit")
    private String unit;
    @Column
    @Comment("req_level")
    private short req_level;

    @Column
    @Comment("req_att")
    private int req_att;
    @Column
    @Comment("upgrade_effect/def")
    private int upgradeDef;
    @Column
    @Comment("upgrade_effect/max_life")
    private int upgradeLife;
    @Column
    @Comment("upgrade_effect/power")
    private int upgradePower;
    @Column
    @Comment("upgrade_effect/all_attrib")
    private int upgradeAttrib;
    @Column
    @Comment("basic_prop/def")
    private int basicPropDef;

    @Column
    @Comment("basic_prop/phy_power")
    private int basicPhyPower;
    @Column
    @Comment("basic_prop/mag_power")
    private int basicMagPower;
    @Column
    @Comment("basic_prop/max_mana")
    private int basicMana;
    @Column
    @Comment("basic_prop/max_life")
    private int basicLife;
    @Column
    @Comment("basic_prop/speed")
    private int basicSpeed;

    @Column
    @Comment("basic_prop/base_dodge")
    private int basicDodge;
    @Column
    @Comment("max_durability")
    private int durability;
    @Column
    @Comment("value")
    private int value;
    @Column
    @Comment("reputation")
    private int reputation;
    @Column
    @Comment("prop_recg/max_life")
    private int propRecgLife;

    @Column
    @Comment("prop_bind/max_life")
    private int propBindLife;
    @Column
    @Comment("prop_bind/max_mana")
    private int propBindMana;

    @Column
    @Comment("装备位置")
    private byte position;
    @Column
    @Comment("门派要求")
    private byte menpai;
    @Column
    @Comment("合成所需装备名称")
    private String name;
    @Column
    @Comment("可以合成的装备")
    private String upgradeName;

    public String getUpgradeName() {
        return upgradeName;
    }

    public void setUpgradeName(String upgradeName) {
        this.upgradeName = upgradeName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public byte getMenpai() {
        return menpai;
    }

    public void setMenpai(byte menpai) {
        this.menpai = menpai;
    }

    public byte getPosition() {
        return position;
    }

    public void setPosition(byte position) {
        this.position = position;
    }

    public String getKey_name() {
        return key_name;
    }

    public void setKey_name(String key_name) {
        this.key_name = key_name;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public byte getGender() {
        return gender;
    }

    public void setGender(byte gender) {
        this.gender = gender;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public short getReq_level() {
        return req_level;
    }

    public void setReq_level(short req_level) {
        this.req_level = req_level;
    }

    public int getReq_att() {
        return req_att;
    }

    public void setReq_att(int req_att) {
        this.req_att = req_att;
    }

    public int getUpgradeDef() {
        return upgradeDef;
    }

    public void setUpgradeDef(int upgradeDef) {
        this.upgradeDef = upgradeDef;
    }

    public int getUpgradeLife() {
        return upgradeLife;
    }

    public void setUpgradeLife(int upgradeLife) {
        this.upgradeLife = upgradeLife;
    }

    public int getUpgradePower() {
        return upgradePower;
    }

    public void setUpgradePower(int upgradePower) {
        this.upgradePower = upgradePower;
    }

    public int getUpgradeAttrib() {
        return upgradeAttrib;
    }

    public void setUpgradeAttrib(int upgradeAttrib) {
        this.upgradeAttrib = upgradeAttrib;
    }

    public int getBasicPropDef() {
        return basicPropDef;
    }

    public void setBasicPropDef(int basicPropDef) {
        this.basicPropDef = basicPropDef;
    }

    public int getBasicPhyPower() {
        return basicPhyPower;
    }

    public void setBasicPhyPower(int basicPhyPower) {
        this.basicPhyPower = basicPhyPower;
    }

    public int getBasicMagPower() {
        return basicMagPower;
    }

    public void setBasicMagPower(int basicMagPower) {
        this.basicMagPower = basicMagPower;
    }

    public int getBasicMana() {
        return basicMana;
    }

    public void setBasicMana(int basicMana) {
        this.basicMana = basicMana;
    }

    public int getBasicLife() {
        return basicLife;
    }

    public void setBasicLife(int basicLife) {
        this.basicLife = basicLife;
    }

    public int getBasicSpeed() {
        return basicSpeed;
    }

    public void setBasicSpeed(int basicSpeed) {
        this.basicSpeed = basicSpeed;
    }

    public int getBasicDodge() {
        return basicDodge;
    }

    public void setBasicDodge(int basicDodge) {
        this.basicDodge = basicDodge;
    }

    public int getDurability() {
        return durability;
    }

    public void setDurability(int durability) {
        this.durability = durability;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public int getReputation() {
        return reputation;
    }

    public void setReputation(int reputation) {
        this.reputation = reputation;
    }

    public int getPropRecgLife() {
        return propRecgLife;
    }

    public void setPropRecgLife(int propRecgLife) {
        this.propRecgLife = propRecgLife;
    }

    public int getPropBindLife() {
        return propBindLife;
    }

    public void setPropBindLife(int propBindLife) {
        this.propBindLife = propBindLife;
    }

    public int getPropBindMana() {
        return propBindMana;
    }

    public void setPropBindMana(int propBindMana) {
        this.propBindMana = propBindMana;
    }
}
