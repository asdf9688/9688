package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

@MessageMeta(module = Modules.CMD_TELEPORT)
public class ReqTelePort extends Message {
    private int mapId;  //地图ID
    private int x;  //猜测坐标X
    private int y;  //猜测坐标Y
    private byte isTaskWalk;  //

    public int getMapId() {
        return mapId;
    }

    public void setMapId(int mapId) {
        this.mapId = mapId;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public byte getIsTaskWalk() {
        return isTaskWalk;
    }

    public void setIsTaskWalk(byte isTaskWalk) {
        this.isTaskWalk = isTaskWalk;
    }
}
