package com.kitty.game.bangpai;

import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;
import com.kitty.game.bangpai.JoinMemberInfo;

import java.util.List;


/**
 * 帮派申请
 */
@MessageMeta(module = Modules.MSG_DIALOG,cmd =1)
public class RespJoinPartyList extends Message {
    private String caption;
    private String content="remote";
    private String name;
    private String type="party";//invite_join
    private List<JoinMemberInfo> list;

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<JoinMemberInfo> getList() {
        return list;
    }

    public void setList(List<JoinMemberInfo> list) {
        this.list = list;
    }
}
