package com.kitty.game.confirm.model;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

public class PetFightConfirm extends RoleConfirm {

    private int petId;

    private int oldPetId;

    public PetFightConfirm(int petId ,int oldPetId) {
        this.petId = petId;
        this.oldPetId =oldPetId;
    }

    public int getOldPetId() {
        return oldPetId;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.PET_FIGHT;
    }

    public int getPetId() {
        return petId;
    }
}
