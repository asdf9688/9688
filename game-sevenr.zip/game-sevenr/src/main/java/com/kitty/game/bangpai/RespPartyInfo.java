package com.kitty.game.bangpai;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

import java.util.List;

import com.kitty.game.bangpai.PartyInfo;

/**
 * 打开帮派
 */
@MessageMeta(module = Modules.MSG_PARTY_LIST_EX)
public class RespPartyInfo extends Message {
    private String order;
    private List<PartyInfo> list;

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public List<PartyInfo> getList() {
        return list;
    }

    public void setList(List<PartyInfo> list) {
        this.list = list;
    }
}
