package com.kitty.game.confirm.model;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

public class MSDRConfirmOnekey extends RoleConfirm {
    String msg;
    public MSDRConfirmOnekey(String msg){
        this.msg = msg;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.msdr_onekey;
    }
}
