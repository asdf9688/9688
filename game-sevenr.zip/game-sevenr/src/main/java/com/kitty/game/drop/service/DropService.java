package com.kitty.game.drop.service;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.ServerService;
import com.kitty.game.base.service.BagService;
import com.kitty.game.drop.DropDataPool;
import com.kitty.game.drop.model.product.DropSet;
import com.kitty.game.drop.model.product.FightDropSet;
import com.kitty.game.drop.model.product.ItemDropSet;
import com.kitty.game.drop.model.user.DropUnit;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.equip.service.EquipService;
import com.kitty.game.item.ItemDataPool;
import com.kitty.game.item.service.ChangeCardService;
import com.kitty.game.item.service.PetStoneService;
import com.kitty.game.map.service.MapService;
import com.kitty.game.pet.PetDataPool;
import com.kitty.game.pet.bean.PetObject;
import com.kitty.game.pet.model.Pet;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.RoleService;
import com.kitty.game.team.message.RespMsg;
import com.kitty.game.utils.Const;
import com.kitty.mina.message.MessagePusher;
import org.apache.commons.lang3.StringUtils;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.nutz.json.Json;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.Serializable;
import java.text.MessageFormat;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
//后加
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
//import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Map.Entry;

@Service
public class DropService {
    @Autowired
    EquipService equipService;
    @Autowired
    RoleService roleService;
    /**最大概率值，几分之一*/
    private final static int MAX_ODDS = 1000;
    /**不加入包裹 的*/
    private final static List<String> NOT_BAG = Arrays.asList(Const.EXP_NAME, Const.DAOHANG_NAME, Const.CHANGE_CARD_NAME, Const.PET_NAME, Const.POT_NAME);

    public void loadProduct() {
        loadDropSet();
        loadItemDropSet();
        loadFightDropSet();
    }

    /**加载掉落数据*/
    public void loadDropSet() {
        Dao dao = SpringUtils.getBean(Dao.class);
        List<DropSet> list = dao.query(DropSet.class, Cnd.NEW());
        Map<Integer, List<DropSet>> dropMapByGroup = new HashMap<>();
        for (DropSet dropSet : list) {
            List<DropSet> dropSets = dropMapByGroup.computeIfAbsent(dropSet.getDropGroup(), k -> new ArrayList<>());
            dropSets.add(dropSet);
        }

        DropDataPool.dropMapByGroup = dropMapByGroup;
    }

    /**加载物品对应掉落数据*/
    public void loadItemDropSet() {
        Dao dao = SpringUtils.getBean(Dao.class);
        List<ItemDropSet> list = dao.query(ItemDropSet.class, Cnd.NEW());
        Map<String, ItemDropSet> itemDropMap = new HashMap<>();
        for (ItemDropSet itemDropSet : list) {
            itemDropMap.put(itemDropSet.getItemName(), itemDropSet);
        }
        DropDataPool.itemDropMap = itemDropMap;
    }

    public void loadFightDropSet() {
        Dao dao = SpringUtils.getBean(Dao.class);
        List<FightDropSet> list = dao.query(FightDropSet.class, Cnd.NEW());
        Map<Integer, FightDropSet> fightDropMap = new HashMap<>();

        Map<Integer, List<FightDropSet>> fightType2DropMap = new HashMap<>();
        for (FightDropSet fightDropSet : list) {
            fightDropSet.getFightTypes().forEach((fightType) -> {
                List<FightDropSet> fightDropSets = fightType2DropMap.computeIfAbsent(fightType, k -> new ArrayList<>());
                fightDropSets.add(fightDropSet);
            });

        }
        DropDataPool.fightType2DropMap = fightType2DropMap;
    }

    /**从传入map中获得对应数据*/
    public void loadCommonSet(Map<String ,String> commonSetMap) {
        //TODO 暂时先这样读取，有需要时再加个表
        String dropLimitJson = commonSetMap.get("drop_limit");
        Map<String, Integer> map = Json.fromJson(Map.class, dropLimitJson);
        Map<Serializable, Integer> dropLimit = new HashMap<>();
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            dropLimit.put(entry.getKey(), entry.getValue());
        }
        DropDataPool.dropLimit = dropLimit;
    }

    /**掉落*/
    public List<DropUnit> drop(Role role, int dropGroup) {
        return drop(role, dropGroup, null);
    }

    /**掉落*/
    public List<DropUnit> drop(Role role, int dropGroup, String dropLimitKey) {
        if (canDrop(role, dropLimitKey) == false) {
            return null;
        }

        List<DropUnit> dropList = doDrop(role, dropGroup);
        if (dropList == null || dropList.size() == 0) {
            return null;
        }

        /**判断下包裹空间是否足够，不足够时不添加掉落*/
        int posCount = getPosCount(dropList);
        if (posCount > 0 && SpringUtils.getBean(BagService.class).checkBagEnough(role, false, posCount) == false) {
            return null;
        }

        addDrop(role, dropList, dropLimitKey);

        return dropList;
    }

    /**判断是否可以掉落*/
    public boolean canDrop(Role role, String dropLimitKey) {
        Integer max = getMaxDropCount(role, dropLimitKey);
        /**不限制*/
        if (max == null) {return true;}

        /**判断已产生掉落的数量是否达到上限*/
        Map<String, Integer> dailyDropCountMap = role.getRoleDrop().getDailyDropCountMap();
        if (dailyDropCountMap == null || !dailyDropCountMap.containsKey(dropLimitKey)) {
            return true;
        }

        /**未达到上限*/
        if (dailyDropCountMap.get(dropLimitKey) < max) {
            return true;
        }

        return false;
    }

    /**获得剩余可掉落的数量， 返回-1表示没限制*/
    public int getRemainDropCount(Role role, String dropLimitKey) {
        Integer max = getMaxDropCount(role, dropLimitKey);
        /**不限制*/
        if (max == null) {return -1;}

        /**判断已产生掉落的数量是否达到上限*/
        Map<String, Integer> dailyDropCountMap = role.getRoleDrop().getDailyDropCountMap();
        if (dailyDropCountMap == null || !dailyDropCountMap.containsKey(dropLimitKey)) {
            return max;
        }

        if (dailyDropCountMap.get(dropLimitKey) < max) {
            return max - dailyDropCountMap.get(dropLimitKey);
        }

        return 0;
    }

    /**获得可掉落的上限*/
    public Integer getMaxDropCount(Role role, Serializable dropLimitKey) {
        return DropDataPool.dropLimit.get(dropLimitKey);
    }

    private List<DropSet> getDropSetList(int dropGroup) {
        return DropDataPool.dropMapByGroup.get(dropGroup);
    }

    private List<DropUnit> doDrop(Role role, int dropGroup) {
        List<DropUnit> dropList = new ArrayList<>();
        List<DropSet> dropSetList = getDropSetList(dropGroup);

        List<DropSet> list = new ArrayList<>();
        ThreadLocalRandom threadLocalRandom = ThreadLocalRandom.current();
        for (DropSet dropSet : dropSetList) {
            if (!matchDropCondition(role, dropSet)) {continue;}
            if (dropSet.getType() == DropSet.TYPE_SELF_MUTI) {
                if (threadLocalRandom.nextInt(MAX_ODDS) < dropSet.getOdds()) {
                    dropList.add(new DropUnit(dropSet, getDropCount(role.getLevel(), dropSet)));
                }
            } else if (dropSet.getType() == DropSet.TYPE_GROUP) {
                list.add(dropSet);
            }
        }

        if (list.size() > 0) {
            DropUnit dropUnit = randomDropInGroup(role, list);
            if (dropUnit != null) {dropList.add(dropUnit);}
        }


        return dropList;
    }

    /**匹配掉落条件*/
    private boolean matchDropCondition(Role role, DropSet dropSet) {
        if (dropSet.getExtraParam() != null) {
            int gender = (int) dropSet.getExtraParam().getOrDefault("gender", 0);
            /**性别不匹配*/
            if (gender > 0 && gender != role.getGender()) {
                return false;
            }
        }

        return true;
    }

    /**获得掉落数量*/
    private int getDropCount(short level, DropSet dropSet) {
        int count = 0;
        if (dropSet.getMinItemCount() == dropSet.getMaxItemCount()) {
            count = dropSet.getMaxItemCount();
        } else {
            count = ThreadLocalRandom.current().nextInt(dropSet.getMinItemCount(), dropSet.getMaxItemCount()+1);
        }

        if (dropSet.getMultiplyLevel() == 1) {
            count *= level;
        }
        return count;
    }

    private DropUnit randomDropInGroup(Role role, List<DropSet> list) {
        int totalOdds = list.stream().mapToInt((dropSet) -> dropSet.getOdds()).sum();

        int odds = ThreadLocalRandom.current().nextInt(totalOdds);
        int sumOdds = 0;
        for (DropSet dropSet : list) {
            sumOdds += dropSet.getOdds();
            if (odds < sumOdds) {
                return new DropUnit(dropSet, getDropCount(role.getLevel(), dropSet));
            }
        }

        return null;
    }

    public void addDrop(Role role, List<DropUnit> dropList, String dropLimitKey) {
        if (dropList == null) {return ;}

        for (DropUnit dropUnit : dropList) {
            addDrop(role, dropUnit, dropLimitKey);
        }
    }

    private boolean addDrop(Role role, DropUnit dropUnit, String dropLimitKey) {
        String limitKey = dropLimitKey != null ? dropLimitKey : dropUnit.getDropSet().getItemName();
        if (limitKey.equals("天倾石")){
            int value = new Random().nextInt(100);
            if (value >=10){
                return false;
            }
        }
        int count = dropUnit.getCount();
        if (isLimitDrop(role, limitKey)) {
            int remainCount = getRemainCount(role, limitKey);
            if (remainCount == 0) {return false;}

            count = dropUnit.getCount() > remainCount ? remainCount : dropUnit.getCount();
            addDropLimit(role, limitKey, count);
        }

        addItem(role, dropUnit, count);

        return true;
    }

    public void addDropLimit(Role role, String dropLimitKey, int count) {
        Integer max = getMaxDropCount(role, dropLimitKey);
        /**不限制*/
        if (max == null) {return ;}

        Map<String, Integer> dailyDropCountMap = role.getRoleDrop().getDailyDropCountMap();
        if (dailyDropCountMap == null) {
            dailyDropCountMap = new HashMap<>();
            role.getRoleDrop().setDailyDropCountMap(dailyDropCountMap);
        }
        Integer hasCount = dailyDropCountMap.getOrDefault(dropLimitKey, 0);
        dailyDropCountMap.put(dropLimitKey, hasCount + count);

        role.save();
    }

    /**是否有限制 的掉落*/
    private boolean isLimitDrop(Role role, Serializable dropLimitKey) {
        return getMaxDropCount(role, dropLimitKey) != null;
    }

    /**获得剩余可加的数量*/
    private int getRemainCount(Role role, String dropLimitKey) {
        Integer max = getMaxDropCount(role, dropLimitKey);
        if (max == null) {
            return 0;
        }

        if (role.getRoleDrop().getDailyDropCountMap() == null) {
            return max;
        }

        return max - role.getRoleDrop().getDailyDropCountMap().getOrDefault(dropLimitKey, 0);
    }

    /**添加道具*/
    private void addItem(Role role, DropUnit dropUnit, int count) {
        DropSet dropSet = dropUnit.getDropSet();
        switch (dropSet.getItemName()) {

            case Const.EXP_NAME:
                roleService.addExp(role, count, role.getLevel(), role.getPetBox().getFightPetId());
                break;
            case Const.DAOHANG_NAME:
                if (dropSet.getDropGroup()==15){
                    // 道行盒子不衰减
                    roleService.addTotalTao11111(role, count);
                    roleService.addMonthTao11111(role,count);
                }else {
                    roleService.addTao(role, count);
                }
                break;
            case Const.PET_STONE_NAME:
                addPetStone(role, dropUnit, count);
                break;
            case Const.CHANGE_CARD_NAME:
                addChangeCard(role, dropUnit, count);
                break;
            case Const.PET_NAME:
                if (SpringUtils.getPetService().isEquippedFull(role)) {
                    MessagePusher.pushMessage(role,new RespMsg("当前宠物包裹已满，请整理后再来吧。"));
                    return;
                }
                addPet(role, dropUnit, count);
                break;
            case Const.FABAO_NAME:
                addFaBao(role, dropUnit, count);
                break;
            case Const.JEWELRY_NAME:
                addJewelry(role, dropUnit, count);
                break;
            case Const.POT_NAME:
                roleService.addPot(role, count);
                break;
            case Const.Yinde_NAME:
                roleService.addYinde(role, count,true);
                MessagePusher.pushMessage(role,new RespNotifyMiscEx("获得#R"+count+"#n阴德值!!!"));
                break;
            default:
                addMall(role, dropUnit, count);
        }
    }

    /**
     * 发送掉落的谣言
     */
    private void sendNumor(Role role, DropSet dropSet, String dropItemName) {
        String numor = getNumor(role, dropSet, dropItemName);
        if (StringUtils.isNotEmpty(numor)) {
            SpringUtils.getChatService().sendNumor(numor, Const.BRODCAST_MSG_TYPE_ROLE);
        }
    }

    /**
     * 发送掉落的公告
     */
    private void sendAdNotice(Role role, DropSet dropSet, String dropItemName) {
        String numor = getNumor(role, dropSet, dropItemName);
        if (StringUtils.isNotEmpty(numor)) {
            SpringUtils.getChatService().sendAdnotice(numor);
        }
    }

    /**
     * 获得掉落谣言内容
     */
    private String getNumor(Role role, DropSet dropSet, String dropItemName) {
        if (StringUtils.isNotEmpty(dropSet.getNumor())) {
            /**替换角色名字、道具名字等*/
            String monsterName = role.getTempCache("drop_monster_name", "");
            String numor = dropSet.getNumor()
                    .replaceAll("#角色名字#", role.getName())
                    .replaceAll("#道具名字#", dropItemName)
                    .replaceAll("#帮派名字#", role.getPartyName())
                    .replaceAll("#区名字#", SpringUtils.getBean(ServerService.class).getServer().getSonName())
                    .replaceAll("#地图名字#", SpringUtils.getBean(MapService.class).getMap(role.getPos().getMapId()).getName())
                    .replaceAll("#怪物名字#", monsterName)
                    ;
            return numor;
        }

        return null;
    }

    private void addMall(Role role, DropUnit dropUnit, int count) {
        DropSet dropSet = dropUnit.getDropSet();
        equipService.addMall(dropSet.getItemName(), false, role, count);
        sendNumor(role, dropSet, dropSet.getItemName());
    }

    /**添加妖石*/
    private void addPetStone(Role role, DropUnit dropUnit, int count) {
        short newPos = SpringUtils.getBean(BagService.class).getPos(role, false);
        DropSet dropSet = dropUnit.getDropSet();
        List<String> nameList = (List<String>)dropSet.getExtraParam().get("name");
        String name = getRandomName(nameList);

        String levelStr = (String) dropSet.getExtraParam().get("level");
        String[] levelArray = levelStr.split("-");
        int minLevel = Integer.parseInt(levelArray[0].trim());
        int maxLevel = Integer.parseInt(levelArray[1].trim());
        int level = 0;
        if (minLevel == maxLevel) {
            level = maxLevel;
        } else {
            level = ThreadLocalRandom.current().nextInt(minLevel, maxLevel + 1);
        }

        SpringUtils.getBean(PetStoneService.class).getPetStone(role, name, newPos, true, level, count);

        sendNumor(role, dropSet,name);
    }

    private String getRandomName(List<String> nameList) {
        if (nameList.size() == 1) {
            return nameList.get(0);
        } else {
            int index = ThreadLocalRandom.current().nextInt(nameList.size());
            return nameList.get(index);
        }
    }

    /**添加变身卡*/
    public void addChangeCard(Role role, DropUnit dropUnit, int count) {
        for (int i=0; i<count; i++) {
            DropSet dropSet = dropUnit.getDropSet();
            String name = null;
            List<String> nameList = dropSet.getExtraParam() != null ? (List<String>)dropSet.getExtraParam().get("name") : null;
            if (nameList == null || nameList.size() == 0) {
                List<String> list = new ArrayList<>(ItemDataPool.name2ChangeCard.keySet());
                int index = ThreadLocalRandom.current().nextInt(list.size());
                name = list.get(index);
            } else {
                name = getRandomName(nameList);
            }

            SpringUtils.getBean(ChangeCardService.class).getChangeCard(role, name);

            sendNumor(role, dropSet, name);
        }
    }

    /**添加宠物*/
    public void addPet(Role role, DropUnit dropUnit, int count) {
        DropSet dropSet = dropUnit.getDropSet();
        List<String> nameList = (List<String>)dropSet.getExtraParam().get("name");
        String name = getRandomName(nameList);
        PetObject petObject = PetDataPool.getPetObject(name);
        Pet pet = SpringUtils.getPetService().addPet(petObject, role, false);
        SpringUtils.getPetService().loadPet(role, pet);
        String msg = MessageFormat.format("你获得了一只#R{0}#n。", name) ;
        MessagePusher.pushMessage(role, new RespNotifyMiscEx(msg));

        sendAdNotice(role, dropSet, name);
    }

    /**添加法宝*/
    private void addFaBao(Role role, DropUnit dropUnit, int count) {
        /**包裹空间不足够时，返回*/
        short pos = SpringUtils.getBean(BagService.class).getPos(role, false);
        if (pos <= 0) {
            return;
        }

        EquipService equipService = SpringUtils.getBean(EquipService.class);
        DropSet dropSet = dropUnit.getDropSet();
        List<String> nameList = (List<String>)dropSet.getExtraParam().get("name");
        String name = getRandomName(nameList);
        equipService.getArtifact(name, role);

        String msg = MessageFormat.format("你获得了#R1{0}#n#R{1}#n。",  equipService.getItemUnit(name),name) ;
        MessagePusher.pushMessage(role, new RespNotifyMiscEx(msg));

        sendNumor(role, dropSet, name+"法宝");
    }

    /**添加首饰*/
    private void addJewelry(Role role, DropUnit dropUnit, int count) {
        /**包裹空间不足够时，返回*/
        short pos = SpringUtils.getBean(BagService.class).getPos(role, false);
        if (pos <= 0) {
            return;
        }

        EquipService equipService = SpringUtils.getBean(EquipService.class);
        DropSet dropSet = dropUnit.getDropSet();
        List<String> nameList = (List<String>)dropSet.getExtraParam().get("name");
        String name = getRandomName(nameList);
        equipService.getJewelry(role, name, false, 1, true);

        String msg = MessageFormat.format("你获得了#R1{0}#n#R{1}#n。",  equipService.getItemUnit(name), name);
        MessagePusher.pushMessage(role, new RespNotifyMiscEx(msg));

        sendNumor(role, dropSet, name);
    }

    /**重置掉落上限每日记录*/
    public void dailyReset(Role role) {
        if (role.getRoleDrop().getDailyDropCountMap() != null) {
            role.getRoleDrop().getDailyDropCountMap().clear();
        }
    }

    /**是否掉落物品(使用时产生掉落)*/
    public boolean isDropItem(String itemName) {
        return DropDataPool.itemDropMap.containsKey(itemName);
    }

    public ItemDropSet getItemDropSet(String itemName) {
        return DropDataPool.itemDropMap.get(itemName);
    }

    /**获得需要包裹格子数量*/
    public int getPosCount(List<DropUnit> dropList) {
        //TODO 没有判断加的数量是否超过叠加上限
        int count = 0;
        for (DropUnit dropUnit : dropList) {
            if (!NOT_BAG.contains(dropUnit.getDropSet().getItemName())) {
                count += 1;
            }
        }
        return count;
    }
}
