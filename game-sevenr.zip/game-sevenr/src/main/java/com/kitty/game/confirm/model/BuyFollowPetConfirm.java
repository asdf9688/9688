package com.kitty.game.confirm.model;

import com.kitty.game.config.Fasion;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

public class BuyFollowPetConfirm extends RoleConfirm {

    /**
     * 购买的时装
     */
    private Fasion fasion;

    public BuyFollowPetConfirm(Fasion fasion) {

        this.fasion = fasion;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.BUY_FOLLOWPET;
    }

    public Fasion getFasion() {
        return fasion;
    }
}
