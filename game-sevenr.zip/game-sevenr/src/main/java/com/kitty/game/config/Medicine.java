package com.kitty.game.config;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;


@Table("p_medicine")
public class Medicine {
    @Name

    private String key_name;
    @Column
    private int icon;
    @Column
    private int bonus_award_rate;
    @Column
    private String unit;
    @Column
    private int limit_recover_level;
    @Column
    private int recover_mana;
    @Column
    private int recover_life;
    @Column
    private int price;
    @Column
    private int combinedNum;

    public int getCombinedNum() {
        return combinedNum;
    }

    public void setCombinedNum(int combinedNum) {
        this.combinedNum = combinedNum;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getKey_name() {
        return key_name;
    }

    public void setKey_name(String key_name) {
        this.key_name = key_name;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public int getBonus_award_rate() {
        return bonus_award_rate;
    }

    public void setBonus_award_rate(int bonus_award_rate) {
        this.bonus_award_rate = bonus_award_rate;
    }

    public int getLimit_recover_level() {
        return limit_recover_level;
    }

    public void setLimit_recover_level(int limit_recover_level) {
        this.limit_recover_level = limit_recover_level;
    }

    public int getRecover_mana() {
        return recover_mana;
    }

    public void setRecover_mana(int recover_mana) {
        this.recover_mana = recover_mana;
    }

    public int getRecover_life() {
        return recover_life;
    }

    public void setRecover_life(int recover_life) {
        this.recover_life = recover_life;
    }
}
