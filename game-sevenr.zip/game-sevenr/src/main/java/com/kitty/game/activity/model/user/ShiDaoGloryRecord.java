package com.kitty.game.activity.model.user;

import lombok.Getter;
import lombok.Setter;

/**试道王者记录*/
@Setter
@Getter

public class ShiDaoGloryRecord {
    private String gid;
    private String name;
    private short level;
    private short icon;
    private byte polar;
    private boolean isLeader;

    public ShiDaoGloryRecord() {}

    public ShiDaoGloryRecord(String gid, String name, short level, short icon, byte polar, boolean isLeader) {
        this.gid = gid;
        this.name = name;
        this.level = level;
        this.icon = icon;
        this.polar = polar;
        this.isLeader = isLeader;
    }
    //后加
    public void setGid(String gid) {
        this.gid = gid;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLevel(short level) {
        this.level = level;
    }

    public void setIcon(short icon) {
        this.icon = icon;
    }

    public void setPolar(byte polar) {
        this.polar = polar;
    }

    public void setLeader(boolean isLeader) {
        this.isLeader = isLeader;
    }

    public String getGid() {
        return this.gid;
    }

    public String getName() {
        return this.name;
    }

    public short getLevel() {
        return this.level;
    }

    public short getIcon() {
        return this.icon;
    }

    public byte getPolar() {
        return this.polar;
    }

    public boolean isLeader() {
        return this.isLeader;
    }
}
