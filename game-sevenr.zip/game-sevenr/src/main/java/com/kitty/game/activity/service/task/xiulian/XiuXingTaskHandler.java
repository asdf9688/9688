package com.kitty.game.activity.service.task.xiulian;

import com.kitty.game.role.model.Role;
import com.kitty.game.config.NPC;
import com.kitty.game.activity.service.task.XiuLianTaskHandler;
import com.kitty.game.npc.model.NpcButton;
import com.kitty.game.task.model.product.TaskType;
import com.kitty.game.utils.Const;
import org.springframework.stereotype.Component;


/**修行任务处理类*/
@Component
public class XiuXingTaskHandler extends XiuLianTaskHandler {
    private final int acceptNpcId = 14691;
    private final String xiuLianName = "修行";
    private final int taskIdAtNpc = 75;
    private final TaskType taskType =  TaskType.XIU_XING;
    private final int acceptMinLevel = 30;
    private final String acceptTeamCountNotEnough = "修炼战斗非同一般，还是组满#R{0}#n人再来找我吧。[离开]";
    private final String acceptLevelNotEnough = "#Y{0}#n角色低于#R{1}级#n，无法接受此等修炼。[离开]";
    private final String accepted = "你已经领取#R修行#n任务，还不快去接受指点。[离开]";
    private final String reaminCountNotEnough = /*"你今日已修行{0}次，还是先去休息休息吧。[离开]"*/"#Y{0}#n今日修炼次数已达上限，修行将没有任何奖励。[接受/"+ NpcButton.ACCEPT_XIUXING_TASK_NO_REWARD.getKey()+"][离开]";;
    private final String fightTeamCountNotEnough = "修炼战斗非同一般，还是组满#R{0}#n人再来找我吧。[离开]";
    private final String fightLevelNotEnough = "#Y{0}#n角色低于#R{1}级#n，无法接受此等修炼。[离开]";
    private final String notAccepted = "你还未领取#R修行#n任务。[离开]";
    private final String messageTemplate = "成功领取了#R修行#n任务，速去接受众灵神指点！";
    private final int npcBossCount = 5;

    @Override
    public int getAcceptNpcId() {
        return acceptNpcId;
    }

    @Override
    public String getXiuLianName() {
        return xiuLianName;
    }

    @Override
    public int getTaskIdAtNpc() {
        return taskIdAtNpc;
    }

    @Override
    public TaskType getTaskType() {
        return taskType;
    }

    @Override
    protected int getFightType(Role role) {
        return Const.fightType_xiuxing;
    }

    @Override
    public int getAcceptMinLevel() {
        return acceptMinLevel;
    }

    @Override
    public String getAcceptTeamCountNotEnough() {
        return acceptTeamCountNotEnough;
    }

    @Override
    public String getAcceptLevelNotEnough() {
        return acceptLevelNotEnough;
    }

    @Override
    public String getAccepted() {
        return accepted;
    }

    @Override
    public String getReaminCountNotEnough() {
        return reaminCountNotEnough;
    }

    @Override
    public String getFightTeamCountNotEnough() {
        return fightTeamCountNotEnough;
    }

    @Override
    public String getFightLevelNotEnough() {
        return fightLevelNotEnough;
    }

    @Override
    public String getNotAccepted() {
        return notAccepted;
    }

    @Override
    public String getMessageTemplate() {
        return messageTemplate;
    }

    @Override
    public int getNpcBossCount() {
        return npcBossCount;
    }

    @Override
    public String getFightStartPrompt(NPC bossNpc) {
        return null;
    }

    /**接取修行任务，弹出有成员没有奖励后仍然领取*/
    public void acceptXiuXingTaskAfterNoRewardTip(Role role, NPC npc, boolean auto) {
        role.getTalk().pushChooseParam(Const.XIULIAN_NO_REWARD_TIP_KEY, true);
        acceptTaskAtNpc(role, npc, auto);
    }
}
