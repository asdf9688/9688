package com.kitty.game.child.model;

import com.kitty.common.spring.SpringUtils;
import lombok.Data;
import lombok.Getter;
import org.apache.mina.core.session.IoSession;
import org.codehaus.jackson.annotate.JsonIgnore;


/**
 * 飞升的信息
 */
@Getter
@Data
public class ChildInfo {
    /**
     * 真身的状态  0 真身 1元婴 仙 2血婴 魔
     */
    private byte state;
    /**
     * 飞升的类型  0未飞升 1元婴 2血婴 3仙 4魔
     */
    private byte type;
    /**
     * 等级
     */
    private short level = 1;//等级默认给1
    /**
     * 当前经验
     */
    private int exp;


    /**
     * 增加的相性上限
     */
    @JsonIgnore
    public int getMaxPolarExtra() {
        return this.level / 7;
    }

    private int xian = 0; //仙点
    private int mo = 0;//魔点
    private int upgradeTotal = 0;//总点数

    private byte upgradeIsOpen;
    private byte upgradeAddType;

    private int xianmoqiehuan;
    /**
     * 升级所需经验
     */
    @JsonIgnore
    public long getUpgradeExp() {
        return SpringUtils.getRoleService().getRoleFlyUpNeedExp(this.level);
    }

    public void setState(byte state) {
        this.state = state;
    }

    public void setType(byte type) {
        this.type = type;
    }

    public void setLevel(short level) {
        this.level = level;
    }

    public void setExp(int exp) {
        this.exp = exp;
    }

}
