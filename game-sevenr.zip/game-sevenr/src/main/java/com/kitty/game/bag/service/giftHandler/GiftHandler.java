package com.kitty.game.bag.service.giftHandler;

import com.kitty.game.bag.model.GiftBagData;
import com.kitty.game.role.model.Role;
import com.kitty.logs.LoggerFunction;
import org.slf4j.Logger;
import org.springframework.stereotype.Component;

@Component
public abstract class GiftHandler {
    protected Logger logger = LoggerFunction.GIFT.getLogger();

    public abstract void getReward(Role role, GiftBagData giftBagData);
}
