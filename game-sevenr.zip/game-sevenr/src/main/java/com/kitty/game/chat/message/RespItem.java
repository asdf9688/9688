package com.kitty.game.chat.message;


import com.kitty.game.equip.model.EquipField;
import com.kitty.game.equip.model.RoleHunQiField;
import com.kitty.mina.Modules;
import com.kitty.mina.annotation.ListField;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

import java.util.List;

/**
 * 返回物品信息
 */
@MessageMeta(module = Modules.MSG_CARD_INFO)
public class RespItem extends Message {
    private String uuId;
    private String type;
//    private List<EquipField> list;

    public String getUuId() {
        return uuId;
    }

    public void setUuId(String uuId) {
        this.uuId = uuId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    private short size;

    @ListField(2)
    private List<EquipField> equipFields;
    @ListField(2)
    private List<RoleHunQiField> hunQiFields;

    public short getSize() {
        return (short) ((equipFields == null ? 0 : equipFields.size()) + (hunQiFields == null ? 0
                : hunQiFields.size()));
    }

    public void setSize(short size) {
        this.size = size;
    }

    public List<EquipField> getEquipFields() {
        return equipFields;
    }

    public void setEquipFields(List<EquipField> equipFields, List<RoleHunQiField> hunQiFields) {
        this.equipFields = equipFields;
        this.hunQiFields = hunQiFields;
        setSize(getSize());
    }

    public List<RoleHunQiField> getHunQiFields() {
        return hunQiFields;
    }

    public void setHunQiFields(List<RoleHunQiField> hunQiFields) {
        this.hunQiFields = hunQiFields;
        setSize(getSize());
    }
}
