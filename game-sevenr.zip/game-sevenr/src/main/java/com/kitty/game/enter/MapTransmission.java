package com.kitty.game.enter;

public class MapTransmission {
    private String name;
    private short X;
    private short Y;
    private short dir;
    private short a=0;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public short getX() {
        return X;
    }

    public void setX(short x) {
        X = x;
    }

    public short getY() {
        return Y;
    }

    public void setY(short y) {
        Y = y;
    }

    public short getDir() {
        return dir;
    }

    public void setDir(short dir) {
        this.dir = dir;
    }

    public short getA() {
        return a;
    }

    public void setA(short a) {
        this.a = a;
    }
}
