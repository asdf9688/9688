package com.kitty.game.activity.model.product;
//活动类型加活动次数

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.EnumSet;
import java.util.Iterator;

/**活动类型*/
public enum ActivityType {
    /**师门任务活动*/
    SCHOOL_TASK("1", 20),
    /**除暴任务活动*/
    CHU_BAO_TASK("2", 20),
    /**降妖刷道任务活动*/
    SHUA_DAO_XIANGYAO_TASK("3", -1),
    /**伏魔刷道任务活动*/
    SHUA_DAO_FUMO_TASK("4", -1),
    /**飞仙渡邪刷道任务活动*/
    SHUA_DAO_FEIXIANDUXIE_TASK("5", -1),
    /**修行任务活动*/
    XIU_XING_TASK("6", 40),
    /**助人为乐任务活动*/
    HELP_PEOPLE_TASK("7", 3),
    /**通天塔任务活动*/
    TOWER_TASK("8", 1),
    /**悬赏任务活动*/
    XUAN_SHANG("9", 2),
    /**悬赏任务战斗奖励*/
    XUAN_SHANG_FIHGT("10", 10),
    /**挑战掌门*/
    ZHANG_MEN("11", 1),
    /**英雄会活动*/
    YING_XIONG_HUI("12", 1),
    /**证道殿挑战胜利*/
    ZHENG_DAO_DIAN_WIN("13", 1),
    /**证道殿挑战失败*/
    ZHENG_DAO_DIAN_FAIL("14", 2),
    /**五行竞猜*/
    XU_XING_JING_CAI("15", 80),
    /**帮派传话*/
    PARTY_MAIL("16", 5),
    /**帮派日常挑战*/
    PARTY_DAILY_TASK("17", 1),
    /**帮派日常发红包*/
    PARTY_SEND_BAG("18", 8),
    /**超级boss*/
    SUPER_BOSS("19", 10),
    /**天星挑战*/
    XING_GUAN_tian("20", 20),
    /**副本*/
    DUGEON_TASK("21", 1),
    /**上古或者万年*/
    SEAL_BOSS("22", 30),
    /**守护神挑战*/
    MAP_GUARDIAN("23", 1),
    /**神魔挑战活动*/
    DEVIL_ACTIVTY("24", 1),
    /**战神挑战活动*/
    zhansheng_ACTIVTY("25", 10),
    /**地星挑战*/
    XING_GUAN_di("26", 20),
    /**宠物顿悟丹*/
    cwdwd("27", 9999),
    /**宠风散*/
    cjcfs("28", 9999),
    /**仙风散*/
    cjxfs("29", 9999),
    /**紫气鸿蒙*/
    zqhm("30", 9999),

    /**
     * 地狱名言
     */
    lymy("31",1),

    /**
     * 七杀星君
     */
    QSXJ("32", 10),

    /**
     * 九天真君
     */
    JTZJ("33", 1),
    /**
     * 添加修法
     */
    XIUFA_TASK("34", 5),
    // add:e
    /**
     * 魔龙吞天
     */
    molongtuntian("35", 1),
    /**
     * 魔龙之尾
     */
    molongzhiwei("36", 1),
    /**
     * 魔龙之眼
     */
    molongzhiyan("37", 1),
    /**
     * 魔龙之首
     */
    molongzhishou("38", 1),

    /**
     * 魔龙之爪
     */
    molongzhizhua("39", 1),


    /**
     * 九幽大帝
     */
    jiuyou("40", 1),

    /**
     * 真武大帝
     */
    zhenwu("41", 1),

    /**
     * 邪灵大帝
     */
    xieling("42", 1),

    /**
     * 杀戮大帝
     */
    shalu("43", 1),

    /**
     * 大日金乌
     */
    darijinwu("44", 1),


    /**
     * 天杨戬
     */
    tianyangjian("45", 1),

    /**
     * 天哪吒
     */
    tiannezha("46", 1),

    /**
     * 天孔宣
     */
    tiankongxuan("47", 1),

    /**
     * 天太白
     */
    tiantaibai("48", 1),

    /**
     * 天李靖
     */
    tianlijing("49", 1),

    /**
     * 天雷震子
     */
    tianleizhnzi("50", 1),

    /**
     * 天帝
     */
    tiandi("51", 1),

    /**
     * 变异星君
     */
    bianyixingjun_ACTIVTY("52", 5),
    /**
     * 烟花年兽
     */
    BHYH_ACTIVTY("53", 200),
    ;

    /**活动id*/
    private String activityId;
    /**活动总次数*/
    private int totalCount;

    ActivityType(String activityId, int totalCount) {
        this.activityId = activityId;
        this.totalCount = totalCount;
    }

    public String getActivityId() {
        return this.activityId;
    }

    public int getTotalCount() {
        return this.totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }
    private static final Logger log = LoggerFactory.getLogger(ActivityType.class);
    public static void upActivityType(String activityType, int totalCount) {
        log.info("刷新挑战次数：" + activityType + "变更为：" + totalCount);
        Iterator var2 = EnumSet.allOf(ActivityType.class).iterator();

        while(var2.hasNext()) {
            ActivityType type = (ActivityType)var2.next();
            if (type.toString().equals(activityType)) {
                type.setTotalCount(totalCount);
            }
        }

    }

    public static void main(String[] args) {
        System.out.println(bianyixingjun_ACTIVTY.activityId + "\n" + bianyixingjun_ACTIVTY.totalCount);
        upActivityType(bianyixingjun_ACTIVTY.toString(), 21);
        System.out.println(bianyixingjun_ACTIVTY.activityId + "\n" + bianyixingjun_ACTIVTY.totalCount);
    }
}
