package com.kitty.game.boss.config;


import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Default;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

import java.util.ArrayList;

@Table("p_bossset")
public class BossSet {
    @Id
    private int id;
    @Column
    private String name;//强盗
    @Column
    @Default("1")
    private int xiangxin;
    @Column
    private int qixue;
    @Column
    @Default("[]")
    private ArrayList<Integer> skills;
    @Column
    private int icon;
    @Column
    private int wugong;
    @Column
    private int fagong;
    @Column
    private int phy_rate;//物理概率
    @Column
    private int mag_rate;//法术概率
    @Column
    private int sudu;//速度
    @Column
    private int fangyu;//防御
    @Column
    private int daohang;//道行
    @Column
    private int qianneng;//潜能
    @Column
    private int money;//奖励金钱
    @Column
    private int resist_forgotten;//抗遗忘
    @Column
    private int resist_poison;//抗毒
    @Column
    private int resist_frozen;//抗冰冻
    @Column
    private int resist_sleep;//抗昏睡
    @Column
    private int resist_confusion;//抗混乱

    @Column
    private int rewardDaohang;
    @Column
    private int rewardDaijinquan;//非vip给代金券
    @Column
    private int rewardQianneng;
    @Column
    private int rewardMoney;//vip给金钱
    @Column
    private int rewardExp;//经验
    @Column
    private int petRewardWuxue;//宠物武学

    public int getPetRewardWuxue() {
        return petRewardWuxue;
    }

    public void setPetRewardWuxue(int petRewardWuxue) {
        this.petRewardWuxue = petRewardWuxue;
    }

    public int getRewardExp() {
        return rewardExp;
    }

    public void setRewardExp(int rewardExp) {
        this.rewardExp = rewardExp;
    }

    public int getRewardDaohang() {
        return rewardDaohang;
    }

    public void setRewardDaohang(int rewardDaohang) {
        this.rewardDaohang = rewardDaohang;
    }

    public int getRewardDaijinquan() {
        return rewardDaijinquan;
    }

    public void setRewardDaijinquan(int rewardDaijinquan) {
        this.rewardDaijinquan = rewardDaijinquan;
    }

    public int getRewardQianneng() {
        return rewardQianneng;
    }

    public void setRewardQianneng(int rewardQianneng) {
        this.rewardQianneng = rewardQianneng;
    }

    public int getRewardMoney() {
        return rewardMoney;
    }

    public void setRewardMoney(int rewardMoney) {
        this.rewardMoney = rewardMoney;
    }

    public int getResist_forgotten() {
        return resist_forgotten;
    }

    public void setResist_forgotten(int resist_forgotten) {
        this.resist_forgotten = resist_forgotten;
    }

    public int getResist_poison() {
        return resist_poison;
    }

    public void setResist_poison(int resist_poison) {
        this.resist_poison = resist_poison;
    }

    public int getResist_frozen() {
        return resist_frozen;
    }

    public void setResist_frozen(int resist_frozen) {
        this.resist_frozen = resist_frozen;
    }

    public int getResist_sleep() {
        return resist_sleep;
    }

    public void setResist_sleep(int resist_sleep) {
        this.resist_sleep = resist_sleep;
    }

    public int getResist_confusion() {
        return resist_confusion;
    }

    public void setResist_confusion(int resist_confusion) {
        this.resist_confusion = resist_confusion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQixue() {
        return qixue;
    }

    public void setQixue(int qixue) {
        this.qixue = qixue;
    }

    public ArrayList<Integer> getSkills() {
        return skills;
    }

    public void setSkills(ArrayList<Integer> skills) {
        this.skills = skills;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public int getXiangxin() {
        return xiangxin;
    }

    public void setXiangxin(int xiangxin) {
        this.xiangxin = xiangxin;
    }

    public int getWugong() {
        return wugong;
    }

    public void setWugong(int wugong) {
        this.wugong = wugong;
    }

    public int getFagong() {
        return fagong;
    }

    public void setFagong(int fagong) {
        this.fagong = fagong;
    }

    public int getPhy_rate() {
        return phy_rate;
    }

    public void setPhy_rate(int phy_rate) {
        this.phy_rate = phy_rate;
    }

    public int getMag_rate() {
        return mag_rate;
    }

    public void setMag_rate(int mag_rate) {
        this.mag_rate = mag_rate;
    }

    public int getSudu() {
        return sudu;
    }

    public void setSudu(int sudu) {
        this.sudu = sudu;
    }

    public int getFangyu() {
        return fangyu;
    }

    public void setFangyu(int fangyu) {
        this.fangyu = fangyu;
    }

    public int getDaohang() {
        return daohang;
    }

    public void setDaohang(int daohang) {
        this.daohang = daohang;
    }

    public int getQianneng() {
        return qianneng;
    }

    public void setQianneng(int qianneng) {
        this.qianneng = qianneng;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }
}
