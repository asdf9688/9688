package com.kitty.game.child.facade;

import com.kitty.game.child.message.ReqChangeChildState;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.RoleService;
import com.kitty.mina.annotation.RequestMapping;
import com.kitty.mina.cache.SessionUtils;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class ChildController {
    Logger logger = LoggerFactory.getLogger(this.getClass());
    @Autowired
    private RoleService roleService;

    @RequestMapping
    public void changeChildState(IoSession session, ReqChangeChildState req) {
        Role role = SessionUtils.getRoleBySession(session);

        roleService.changeChildState(role, req.getState());
    }
}
