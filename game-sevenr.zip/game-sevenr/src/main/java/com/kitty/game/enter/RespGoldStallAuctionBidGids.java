package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

/**
 * 通知珍宝交易竞拍的商品
 */

@MessageMeta(module = Modules.MSG_GOLD_STALL_AUCTION_BID_GIDS)
public class RespGoldStallAuctionBidGids extends Message {

    private byte a = 0;//是一个列表 用到的时候再改吧

    public byte getA() {
        return a;
    }

    public void setA(byte a) {
        this.a = a;
    }
}
