package com.kitty.game.config;

import org.nutz.dao.entity.annotation.*;
//后加
import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Default;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

@Table("p_xinjun")
public class XinJun {
    @Id
    private int id;
    @Column
    private String name;
    @Column
    private int polar;
    @Column
    private int religion;
    @Column
    @Default("0")
    private String life_effect;
    @Column
    @Default("0")
    private String speed_effect;
    @Column
    @Default("0")
    private String mag_effect;
    @Column
    @Default("0")
    private String phy_effect;
    @Column
    @Default("0")
    private String tao_effect;
    @Column
    @Default("0")
    private int accurate;//准确
    @Column
    @Default("0")
    private int stunt_rate;//特技
    @Column
    @Default("0")
    private int double_hit_rate;
    @Column
    @Default("0")
    private int double_hit;
    @Column
    @Default("0")
    private String damage_sel_rate;
    @Column
    @Default("0")
    private String damage_sel;
    @Column
    @Default("0")
    private String penetrate_rate;// 穿透概率
    @Column
    @Default("0")
    private String penetrate;

    @Column
    @Default("0")
    private String resist_metal;//抗金
    @Column
    @Default("0")
    private String resist_wood;//抗金
    @Column
    @Default("0")
    private String resist_water;//抗金
    @Column
    @Default("0")
    private String resist_fire;//抗金
    @Column
    @Default("0")
    private String resist_earth;//抗金

    @Column
    @Default("0")
    private String resist_forgotten;//抗金
    @Column
    @Default("0")
    private String resist_poison;//抗金
    @Column
    @Default("0")
    private String resist_frozen;//抗金
    @Column
    @Default("0")
    private String resist_sleep;//抗金
    @Column
    @Default("0")
    private String resist_confusion;//抗金

    @Column
    @Default("0")
    private String phy_absorb;//抗金
    @Column
    @Default("0")
    private String mag_absorb;//抗金
    @Column
    @Default("0")
    private int danger_state;//危险程度
    @Column
    @Default("0")
    private int obstacles_rate;//抗金
    @Column
    @Default("0")
    private int mag_statics_rate;//抗金
    @Column
    @Default("0")
    private int phy_statics_rate;//抗金

    @Column
    @Default("0")
    private String god_book_skills;//狂暴
    @Column
    @Default("0")
    private String special_skills;//天生技能
    @Column
    @Default("0")
    @ColDefine(customType = "TEXT", type = ColType.VARCHAR)
    private String skills;//技能id
    @Column
    @Default("0")
    private int petIcon;
    @Column
    @Default("0")
    private int rewardDaohang;//奖励道行
    @Column
    @Default("0")
    private int rewardExp;//奖励经验
    @Column
    @Default("0")
    private int petRewardWxue;//宠物武学
    @Column
    @Default("0")
    private int fangyu;

    public int getPetRewardWxue() {
        return petRewardWxue;
    }

    public void setPetRewardWxue(int petRewardWxue) {
        this.petRewardWxue = petRewardWxue;
    }

    public int getFangyu() {
        return fangyu;
    }

    public void setFangyu(int fangyu) {
        this.fangyu = fangyu;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPolar() {
        return polar;
    }

    public void setPolar(int polar) {
        this.polar = polar;
    }

    public int getReligion() {
        return religion;
    }

    public void setReligion(int religion) {
        this.religion = religion;
    }

    public String getLife_effect() {
        return life_effect;
    }

    public void setLife_effect(String life_effect) {
        this.life_effect = life_effect;
    }

    public String getSpeed_effect() {
        return speed_effect;
    }

    public void setSpeed_effect(String speed_effect) {
        this.speed_effect = speed_effect;
    }

    public String getMag_effect() {
        return mag_effect;
    }

    public void setMag_effect(String mag_effect) {
        this.mag_effect = mag_effect;
    }

    public String getPhy_effect() {
        return phy_effect;
    }

    public void setPhy_effect(String phy_effect) {
        this.phy_effect = phy_effect;
    }

    public String getTao_effect() {
        return tao_effect;
    }

    public void setTao_effect(String tao_effect) {
        this.tao_effect = tao_effect;
    }

    public int getAccurate() {
        return accurate;
    }

    public void setAccurate(int accurate) {
        this.accurate = accurate;
    }

    public int getDouble_hit_rate() {
        return double_hit_rate;
    }

    public void setDouble_hit_rate(int double_hit_rate) {
        this.double_hit_rate = double_hit_rate;
    }

    public int getDouble_hit() {
        return double_hit;
    }

    public void setDouble_hit(int double_hit) {
        this.double_hit = double_hit;
    }

    public String getDamage_sel_rate() {
        return damage_sel_rate;
    }

    public void setDamage_sel_rate(String damage_sel_rate) {
        this.damage_sel_rate = damage_sel_rate;
    }

    public String getDamage_sel() {
        return damage_sel;
    }

    public void setDamage_sel(String damage_sel) {
        this.damage_sel = damage_sel;
    }

    public String getPenetrate_rate() {
        return penetrate_rate;
    }

    public void setPenetrate_rate(String penetrate_rate) {
        this.penetrate_rate = penetrate_rate;
    }

    public String getPenetrate() {
        return penetrate;
    }

    public void setPenetrate(String penetrate) {
        this.penetrate = penetrate;
    }

    public String getResist_metal() {
        return resist_metal;
    }

    public void setResist_metal(String resist_metal) {
        this.resist_metal = resist_metal;
    }

    public String getResist_wood() {
        return resist_wood;
    }

    public void setResist_wood(String resist_wood) {
        this.resist_wood = resist_wood;
    }

    public String getResist_water() {
        return resist_water;
    }

    public void setResist_water(String resist_water) {
        this.resist_water = resist_water;
    }

    public String getResist_fire() {
        return resist_fire;
    }

    public void setResist_fire(String resist_fire) {
        this.resist_fire = resist_fire;
    }

    public String getResist_earth() {
        return resist_earth;
    }

    public void setResist_earth(String resist_earth) {
        this.resist_earth = resist_earth;
    }

    public String getResist_forgotten() {
        return resist_forgotten;
    }

    public void setResist_forgotten(String resist_forgotten) {
        this.resist_forgotten = resist_forgotten;
    }

    public String getResist_poison() {
        return resist_poison;
    }

    public void setResist_poison(String resist_poison) {
        this.resist_poison = resist_poison;
    }

    public String getResist_frozen() {
        return resist_frozen;
    }

    public void setResist_frozen(String resist_frozen) {
        this.resist_frozen = resist_frozen;
    }

    public String getResist_sleep() {
        return resist_sleep;
    }

    public void setResist_sleep(String resist_sleep) {
        this.resist_sleep = resist_sleep;
    }

    public String getResist_confusion() {
        return resist_confusion;
    }

    public void setResist_confusion(String resist_confusion) {
        this.resist_confusion = resist_confusion;
    }

    public String getPhy_absorb() {
        return phy_absorb;
    }

    public void setPhy_absorb(String phy_absorb) {
        this.phy_absorb = phy_absorb;
    }

    public String getMag_absorb() {
        return mag_absorb;
    }

    public void setMag_absorb(String mag_absorb) {
        this.mag_absorb = mag_absorb;
    }

    public int getDanger_state() {
        return danger_state;
    }

    public void setDanger_state(int danger_state) {
        this.danger_state = danger_state;
    }

    public int getObstacles_rate() {
        return obstacles_rate;
    }

    public void setObstacles_rate(int obstacles_rate) {
        this.obstacles_rate = obstacles_rate;
    }

    public int getMag_statics_rate() {
        return mag_statics_rate;
    }

    public void setMag_statics_rate(int mag_statics_rate) {
        this.mag_statics_rate = mag_statics_rate;
    }

    public int getPhy_statics_rate() {
        return phy_statics_rate;
    }

    public void setPhy_statics_rate(int phy_statics_rate) {
        this.phy_statics_rate = phy_statics_rate;
    }

    public String getGod_book_skills() {
        return god_book_skills;
    }

    public void setGod_book_skills(String god_book_skills) {
        this.god_book_skills = god_book_skills;
    }

    public String getSpecial_skills() {
        return special_skills;
    }

    public void setSpecial_skills(String special_skills) {
        this.special_skills = special_skills;
    }

    public String getSkills() {
        return skills;
    }

    public void setSkills(String skills) {
        this.skills = skills;
    }

    public int getStunt_rate() {
        return stunt_rate;
    }

    public void setStunt_rate(int stunt_rate) {
        this.stunt_rate = stunt_rate;
    }

    public int getPetIcon() {
        return petIcon;
    }

    public void setPetIcon(int petIcon) {
        this.petIcon = petIcon;
    }

    public int getRewardDaohang() {
        return rewardDaohang;
    }

    public void setRewardDaohang(int rewardDaohang) {
        this.rewardDaohang = rewardDaohang;
    }

    public int getRewardExp() {
        return rewardExp;
    }

    public void setRewardExp(int rewardExp) {
        this.rewardExp = rewardExp;
    }
}
