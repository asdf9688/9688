package com.kitty.game.config;

import lombok.Getter;
import lombok.Setter;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

@Setter
@Getter
@Table("p_grocerys")
public class Grocery {
    @Id
    private short goods_no;
    @Column
    private int pay_type;
    @Column
    private String name;//名称
    @Column
    private int price;//价格
    @Column
    private short level;//等级
    @Column
    private boolean sale;//是否出售
    @Column
    private byte type;

    public void setGoods_no(short goods_no) {
        this.goods_no = goods_no;
    }

    public void setPay_type(int pay_type) {
        this.pay_type = pay_type;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setLevel(short level) {
        this.level = level;
    }

    public void setSale(boolean sale) {
        this.sale = sale;
    }

    public void setType(byte type) {
        this.type = type;
    }

    public short getGoods_no() {
        return this.goods_no;
    }

    public int getPay_type() {
        return this.pay_type;
    }

    public String getName() {
        return this.name;
    }

    public int getPrice() {
        return this.price;
    }

    public short getLevel() {
        return this.level;
    }

    public boolean isSale() {
        return this.sale;
    }

    public byte getType() {
        return this.type;
    }


}
