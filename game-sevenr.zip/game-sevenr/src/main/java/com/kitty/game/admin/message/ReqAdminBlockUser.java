package com.kitty.game.admin.message;

import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;
import lombok.Getter;

import static com.kitty.mina.NewModules.CMD_ADMIN_BLOCK_USER;

@Getter
@MessageMeta(module = CMD_ADMIN_BLOCK_USER)
public class ReqAdminBlockUser extends Message {
    private String name;
    private String gid;
    private int time;
    private String reason;
    private boolean removeGoods;


    public String getName() {
        return this.name;
    }

    public String getGid() {
        return this.gid;
    }

    public int getTime() {
        return this.time;
    }

    public String getReason() {
        return this.reason;
    }

    public boolean isRemoveGoods() {
        return this.removeGoods;
    }
}
