package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

import java.util.List;

@MessageMeta(module = Modules.MSG_LBS_FRIEND_GID_LIST)
public class RespLBS_FriendGidList extends Message {
    private List<String>  gidInfo;

    public List<String> getGidInfo() {
        return gidInfo;
    }

    public void setGidInfo(List<String> gidInfo) {
        this.gidInfo = gidInfo;
    }
}
