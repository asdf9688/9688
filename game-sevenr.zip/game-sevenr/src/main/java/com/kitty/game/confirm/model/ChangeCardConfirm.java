package com.kitty.game.confirm.model;

import com.kitty.game.role.model.Role;
import com.kitty.game.equip.model.RoleEquip;
import com.kitty.game.item.config.ChangeCard;
import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

public class ChangeCardConfirm extends RoleConfirm {
    private RoleEquip roleEquip;
    private Role targetRole;
    private ChangeCard changeCard;
    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.USE_CHANGE_CARD;
    }

    public ChangeCard getChangeCard() {
        return changeCard;
    }

    public ChangeCardConfirm(Role targetRole, RoleEquip roleEquip, ChangeCard changeCard) {
        this.roleEquip = roleEquip;
        this.targetRole =targetRole;
        this.changeCard =changeCard;
    }

    public Role getTargetRole() {
        return targetRole;
    }

    public RoleEquip getRoleEquip() {
        return roleEquip;
    }
}
