package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

import java.util.List;
import com.kitty.game.enter.WarData;

/**
 * 赛事管理员数据
 */
@MessageMeta(module = Modules.MSG_MATCH_ADMIN_DATA)
public class RespMatchAdminData extends Message {

    private List<WarData> warDataList;

    public List<WarData> getWarDataList() {
        return warDataList;
    }

    public void setWarDataList(List<WarData> warDataList) {
        this.warDataList = warDataList;
    }

}
