package com.kitty.game.config;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Table;

@Table("p_exchangepet")
public class ExchangePet {
    @Column
    private byte type;//1生肖 2神兽
    @Column
    private String name;
    @Column
    private int num;//兑换需要数量

    public byte getType() {
        return type;
    }

    public void setType(byte type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
}
