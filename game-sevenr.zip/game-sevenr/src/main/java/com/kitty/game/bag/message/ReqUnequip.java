package com.kitty.game.bag.message;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

/**
 * 卸下装备
 */
@MessageMeta(module = Modules.CMD_UNEQUIP)
public class ReqUnequip extends Message {
    private byte oldPos;
    private byte newPos;

    public byte getOldPos() {
        return oldPos;
    }

    public void setOldPos(byte oldPos) {
        this.oldPos = oldPos;
    }

    public byte getNewPos() {
        return newPos;
    }

    public void setNewPos(byte newPos) {
        this.newPos = newPos;
    }
}
