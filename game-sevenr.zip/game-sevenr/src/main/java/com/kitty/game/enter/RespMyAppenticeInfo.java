package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

/**
 * 我的师徒信息
 */
@MessageMeta(module = Modules.MSG_MY_APPENTICE_INFO)
public class RespMyAppenticeInfo extends Message {

    private short a = 0;

    public short getA() {
        return a;
    }

    public void setA(short a) {
        this.a = a;
    }

}
