package com.kitty.game.activity.service.other;

import com.kitty.common.spring.SpringUtils;
import com.kitty.core.SchedulerManager;
import com.kitty.game.activity.ActivityDataPool;
import com.kitty.game.activity.model.product.NewHelpActivitySet;
import com.kitty.game.base.service.BagService;
import com.kitty.game.config.NPC;
import com.kitty.game.i18n.I18nId;
import com.kitty.game.i18n.I18nIdDataPool;
import com.kitty.game.npc.model.NpcButton;
import com.kitty.game.rank.model.record.NewHelpRankRecord;
import com.kitty.game.rank.model.record.RankRecord;
import com.kitty.game.rank.service.handler.NewHelpRankHandler;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.RoleService;
import com.kitty.game.utils.Const;
import com.kitty.game.utils.TimeUtil;
import com.kitty.logs.LoggerFunction;
import com.kitty.logs.Reason;
import com.kitty.mina.message.MessagePusher;
import org.apache.commons.lang3.StringUtils;
import org.nutz.json.Json;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**新服助力活动处理类*/
@Component
public class NewHelpActivityHandler {
    private static String GIFT_NAME = "道行盛典礼包";
    private static int MAX_RANK_COUNT = 10;
    private static short MIN_LEVEL = 20;
    private static int GOLD_PER_GIFT = 518;

    private Logger logger = LoggerFunction.ACTIVITY.getLogger();
    @Autowired
    RoleService roleService;
    @Autowired
    NewHelpRankHandler newHelpRankHandler;

    public void loadCommonSet(Map<String, String> commonSetMap) {
        NewHelpActivitySet newHelpActivitySet = Json.fromJson(NewHelpActivitySet.class, commonSetMap.get("new_help_activities_set"));
        if (newHelpActivitySet != null) {
            newHelpActivitySet.init();
            ActivityDataPool.newHelpActivitySet = newHelpActivitySet;
        }
    }

    public void init() {
        /**新服助力活动每30分钟系统消息*/
        long now = System.currentTimeMillis();
        if (now < ActivityDataPool.newHelpActivitySet.getEndTimeL()) {
            long delay = now > ActivityDataPool.newHelpActivitySet.getStartTimeL() ? 5 * TimeUtil.ONE_MINUTE : ActivityDataPool.newHelpActivitySet.getStartTimeL() - now;
            SchedulerManager.getInstance().scheduleAtFixedRate(()->sendSystem(), delay, 30 * TimeUtil.ONE_MINUTE);
        }
    }

    public void view(Role role, NPC npc) {
        String content = I18nIdDataPool.getI18nContent(I18nId.PMT_1402);
        SpringUtils.getNpcService().sendNpcContent(role, npc, content);
    }

    public void listItem(Role role, NPC npc) {
        String content = I18nIdDataPool.getI18nContent(I18nId.PMT_1403);
        SpringUtils.getNpcService().sendNpcContent(role, npc, content);
    }

    public void buyItem(Role role, NPC npc, int count) {
        long now = System.currentTimeMillis();
        /**活动还未开始*/
        if (now < ActivityDataPool.newHelpActivitySet.getStartTimeL()) {
            MessagePusher.notify2Player(role, I18nId.PMT_1400);
            return ;
        }

        /**活动已经结束*/
        if (now > ActivityDataPool.newHelpActivitySet.getEndTimeL()) {
            MessagePusher.notify2Player(role, I18nId.PMT_1401);
            return ;
        }

        if (role.getLevel() < MIN_LEVEL) {
            MessagePusher.notify2Player(role, I18nId.PMT_1410, MIN_LEVEL);
            return ;
        }

        /**判断金元宝是否足够*/
        int needGold = GOLD_PER_GIFT * count;
        if (role.getGold() < needGold) {
            MessagePusher.notify2Player(role, I18nId.PMT_403);
            return ;
        }

        int needBagCount = 1;
        /**判断包裹空间*/
        if (SpringUtils.getBean(BagService.class).checkBagEnough(role, false, needBagCount) == false) {
            MessagePusher.notify2Player(role, I18nId.PMT_412);
            return ;
        }

        /**扣除金元宝*/
        roleService.subtractGold(role, needGold, Reason.NEW_HELP_ACTIVITIES);

        SpringUtils.getEquipService().addMall(GIFT_NAME,false, role,count);

        /**增加购买数量*/
        int newCount =  role.getActivity().getBuyNewHelpGiftCount() + count;
        role.getActivity().setBuyNewHelpGiftCount(newCount);
        role.save();
        logger.info("购买新服助力礼包|{}|{}|{}|{}", role.getUid(), role.getName(), count, newCount);

        /**更新排行榜*/
        newHelpRankHandler.updateRank(role, newCount);
    }

    public void viewRank(Role role, NPC npc) {
        StringBuilder buttons = new StringBuilder();
        for (int i=0; i<MAX_RANK_COUNT; i++) {
            int order = i+1;
            String orderChinse = Const.ORDER_CHINESE.get(order);
            if (orderChinse == null) {continue;}
            String button = I18nIdDataPool.getI18nContent(I18nId.PMT_1405, orderChinse, order);
            buttons.append(button);
        }
        buttons.append(Const.LEAVE_BUTTON);

        String content = I18nIdDataPool.getI18nContent(I18nId.PMT_1404, buttons.toString());
        SpringUtils.getNpcService().sendNpcContent(role, npc, content);
    }

    public void viewRankOrder(Role role, NPC npc, String msg) {
        String orderStr = msg.replace(NpcButton.NEW_HELP_RANK_ORDER_PREFIX.getKey(), "");
        if (StringUtils.isEmpty(orderStr)) {return ;}

        int order = Integer.parseInt(orderStr);
        int index = order -1;
        List<RankRecord> records = newHelpRankHandler.getRecordsFrom(0, MAX_RANK_COUNT);
        String name = null;
        if (records.size() > index) {
            NewHelpRankRecord rankRecord = (NewHelpRankRecord)records.get(index);
            name = I18nIdDataPool.getI18nContent(I18nId.PMT_1408, rankRecord.getName());
        } else {
            name = I18nIdDataPool.getI18nContent(I18nId.PMT_1407);
        }
        String orderChinese = Const.ORDER_CHINESE.get(order);
        String content = I18nIdDataPool.getI18nContent(I18nId.PMT_1406, orderChinese, name);
        SpringUtils.getNpcService().sendNpcContent(role, npc, content);
    }

    /**
     * 发系统消息
     */
    public void sendSystem() {
        /**活动时间内发系统消息*/
        long now = System.currentTimeMillis();
        if (now > ActivityDataPool.newHelpActivitySet.getStartTimeL() && now < ActivityDataPool.newHelpActivitySet.getEndTimeL()) {
            String content = I18nIdDataPool.getI18nContent(I18nId.PMT_1409);
            SpringUtils.getChatService().sendSystem(content, Const.BRODCAST_MSG_TYPE_ROLE);
        }
    }
}