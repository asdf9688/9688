package com.kitty.game.bag.message;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

/**
 * 存钱
 */
@MessageMeta(module = Modules.CMD_DEPOSIT)
public class ReqSaveMoney extends Message {
    private int id;
    private int saveMoney;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSaveMoney() {
        return saveMoney;
    }

    public void setSaveMoney(int saveMoney) {
        this.saveMoney = saveMoney;
    }
}
