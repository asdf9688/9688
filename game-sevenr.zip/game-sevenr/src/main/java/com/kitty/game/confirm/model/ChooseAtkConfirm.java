package com.kitty.game.confirm.model;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

/**力法选择确认*/
public class ChooseAtkConfirm extends RoleConfirm {

    /**任务ID*/
    private int taskId;

    public ChooseAtkConfirm(int taskId) {
        this.taskId = taskId;
    }

    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.CHOOSE_ATK;
    }
}
