package com.kitty.game.bangpai;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.annotation.StringField;
import com.kitty.mina.message.Message;

/**
 * 修改帮派Icon
 */
@MessageMeta(module = Modules.CMD_SUBMIT_ICON)
public class ReqModifyPartyIcon extends Message {
    private byte oper_type;
    private String md5_value;
    @StringField(value = 1)
    private String file_data;

    public byte getOper_type() {
        return oper_type;
    }

    public void setOper_type(byte oper_type) {
        this.oper_type = oper_type;
    }

    public String getMd5_value() {
        return md5_value;
    }

    public void setMd5_value(String md5_value) {
        this.md5_value = md5_value;
    }

    public String getFile_data() {
        return file_data;
    }

    public void setFile_data(String file_data) {
        this.file_data = file_data;
    }
}
