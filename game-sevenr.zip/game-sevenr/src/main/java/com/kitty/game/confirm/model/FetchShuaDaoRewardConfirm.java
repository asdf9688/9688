package com.kitty.game.confirm.model;


import lombok.Getter;
import lombok.Setter;
import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;


@Getter
@Setter
public class FetchShuaDaoRewardConfirm extends RoleConfirm {
    private byte type;
    private byte index;

    public FetchShuaDaoRewardConfirm(byte type, byte index) {
        this.type = type;
        this.index = index;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.FETCH_SHUADAO_REWARD;
    }
}
