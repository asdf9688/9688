package com.kitty.game.confirm.model;

import com.kitty.game.role.model.Role;
import lombok.Getter;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

/**添加好友*/
@Getter
public class AddFriendConfirm extends RoleConfirm {
    private Role target;

    public AddFriendConfirm(Role target) {
        this.target = target;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.ADD_FRIEND;
    }
}
