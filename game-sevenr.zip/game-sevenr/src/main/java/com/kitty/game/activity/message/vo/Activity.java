package com.kitty.game.activity.message.vo;

public class Activity {
    private  String key;
    private String para;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getPara() {
        return para;
    }

    public void setPara(String para) {
        this.para = para;
    }
}
