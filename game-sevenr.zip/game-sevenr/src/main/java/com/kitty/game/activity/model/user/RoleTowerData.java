package com.kitty.game.activity.model.user;

import lombok.Getter;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnore;

/**玩家通天塔数据*/
@Setter
@Getter
public class RoleTowerData {
    /**奖励类型，经验奖励*/
    public static final byte REWARD_EXP = 1;
    /**奖励类型，道行奖励*/
    public static final byte REWARD_DAOHANG = 2;

    /**修炼阶段*/
    public static final byte STAGE_REFINE = 1;
    /**突破阶段*/
    public static final byte STAGE_BREAK = 2;
    /**突破阶段最大失败次数*/
    public static final byte MAX_FAIL_COUNT = 3;

    /**当前层数*/
    private int currentLayer;
    /**当前层数挑战星君名字*/
    private String currentXinJun;
    /**当前层数是否已经完成*/
    private boolean isCurrentFinish;
    /**奖励类型*/
    private byte rewardType;
    /**阶段*/
    private byte stage;
    /**突破阶段失败次数*/
    private int failCount;
    /**上次所在层数*/
    private int oldLayer;

    public RoleTowerData() {
        isCurrentFinish = false;
        stage = STAGE_REFINE;
        failCount = 0;
        oldLayer = 0;
    }

    /**是否在突破阶段*/
    @JsonIgnore
    public boolean isInBreakStage() {
        return stage == STAGE_BREAK;
    }

    public void setCurrentLayer(int currentLayer) {
        this.currentLayer = currentLayer;
    }

    public void setCurrentXinJun(String currentXinJun) {
        this.currentXinJun = currentXinJun;
    }

    public void setCurrentFinish(boolean isCurrentFinish) {
        this.isCurrentFinish = isCurrentFinish;
    }

    public void setRewardType(byte rewardType) {
        this.rewardType = rewardType;
    }

    public void setStage(byte stage) {
        this.stage = stage;
    }

    public void setFailCount(int failCount) {
        this.failCount = failCount;
    }

    public void setOldLayer(int oldLayer) {
        this.oldLayer = oldLayer;
    }

    public int getCurrentLayer() {
        return this.currentLayer;
    }

    public String getCurrentXinJun() {
        return this.currentXinJun;
    }

    public boolean isCurrentFinish() {
        return this.isCurrentFinish;
    }

    public byte getRewardType() {
        return this.rewardType;
    }

    public byte getStage() {
        return this.stage;
    }

    public int getFailCount() {
        return this.failCount;
    }

    public int getOldLayer() {
        return this.oldLayer;
    }
}
