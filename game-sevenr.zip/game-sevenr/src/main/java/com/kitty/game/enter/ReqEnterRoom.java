package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

@MessageMeta(module = Modules.CMD_ENTER_ROOM)
public class ReqEnterRoom extends Message {
    private String mapName;
    private byte isTaskWalk;

    public byte getIsTaskWalk() {
        return isTaskWalk;
    }

    public void setIsTaskWalk(byte isTaskWalk) {
        this.isTaskWalk = isTaskWalk;
    }

    public String getMapName() {
        return mapName;
    }

    public void setMapName(String mapName) {
        this.mapName = mapName;
    }

}
