package com.kitty.game.bangpai;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;


@MessageMeta(module = Modules.MSG_PARTY_ICON, cmd = 1)
public class RespPartyIconNull extends Message {

}
