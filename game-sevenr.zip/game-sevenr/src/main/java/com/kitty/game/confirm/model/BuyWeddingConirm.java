package com.kitty.game.confirm.model;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

public class BuyWeddingConirm extends RoleConfirm {
  public ConfirmType getConfirmType() {
    return ConfirmType.BUY_WEDDING;
  }
}
