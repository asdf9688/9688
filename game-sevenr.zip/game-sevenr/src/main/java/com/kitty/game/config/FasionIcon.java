package com.kitty.game.config;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;


@Table("p_fasionicon")
public class FasionIcon {
    @Column
    @Comment("时装名称")
    private String name;
    @Column
    @Comment("时装Icon")//背包图标
    private int icon;
    @Column
    @Comment("时装外观Icon")//穿上icon
    private int fasionIcon;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public int getFasionIcon() {
        return fasionIcon;
    }

    public void setFasionIcon(int fasionIcon) {
        this.fasionIcon = fasionIcon;
    }
}
