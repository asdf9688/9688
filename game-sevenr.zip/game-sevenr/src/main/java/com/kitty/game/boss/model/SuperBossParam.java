package com.kitty.game.boss.model;

import com.kitty.game.boss.config.BossSet;
import com.kitty.game.fight.ai.model.RoundSkillUnit;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
//后写
import com.kitty.game.boss.model.BossParam;

@Setter
@Getter
public class SuperBossParam extends BossParam {
    private List<RoundSkillUnit> roundSkills = new ArrayList<>();
    private Map<String, Integer> artifactMap = new HashMap<>();
    private byte mainShowAfterRound;
    private byte smallEscapeAfterRound;

    public SuperBossParam(BossSet bossSet, String name) {
        super(bossSet, name);
    }

    //后写
    public Map<String, Integer> getArtifactMap() {
        return this.artifactMap;
    }

    public byte getMainShowAfterRound() {
        return this.mainShowAfterRound;
    }

    public byte getSmallEscapeAfterRound() {
        return this.smallEscapeAfterRound;
    }

    public List<RoundSkillUnit> getRoundSkills() {
        return this.roundSkills;
    }
    public void setRoundSkills(List<RoundSkillUnit> roundSkills) {
        this.roundSkills = roundSkills;
    }

    public void setArtifactMap(Map<String, Integer> artifactMap) {
        this.artifactMap = artifactMap;
    }

    public void setMainShowAfterRound(byte mainShowAfterRound) {
        this.mainShowAfterRound = mainShowAfterRound;
    }

    public void setSmallEscapeAfterRound(byte smallEscapeAfterRound) {
        this.smallEscapeAfterRound = smallEscapeAfterRound;
    }

}
