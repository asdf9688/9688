package com.kitty.game.activity.model.product.shuadao;

import com.kitty.game.activity.model.product.ActivityType;
import com.kitty.game.activity.model.product.RandomNpcParam;
import com.kitty.game.npc.model.NpcButton;
import com.kitty.game.utils.Const;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
//后加
import com.kitty.game.activity.model.product.shuadao.ShuaDaoSet;

/**降妖*/
public class XiangYaoShuaDaoSet extends ShuaDaoSet{
    /**对应bossset表的名字*/
    private List<String> bossNames = Arrays.asList("鸟怪", "蟒精", "鱼精", "狐狸精", "琵琶精");
    /**名字前缀*/
    private List<String> prefixNames = Arrays.asList("狂妄的", "狡诈的", "杀生的", "糊涂的", "贪吃的", "庸俗的", "曾恶的", "膨胀的", "疯狂的", "冲动的");
    /**小怪对应bossset表的名字*/
    private List<String> smallBossNames = Arrays.asList("黄怪", "绿鬼", "蓝精", "红魔", "紫魅", "疯魑", "狂魍", "爆魉");

    @Override
    public int getAcceptNpcId() {
        return 14996;
    }

    @Override
    public String getShuaDaoName() {
        return "降妖";
    }

    @Override
    public int getMinLevel() {
        return 45;
    }

    @Override
    public String getLevelNotEnoughDesc() {
        return "#Y{0}#n角色等级低于#R{1}级#n，无法承担降妖的重任[离开]";
    }

    @Override
    public int getFightTaskId() {
        return 72;
    }

    @Override
    public int getGuideTaskId() {
        return 73;
    }

    @Override
    public String getContent() {
        return "哈哈，送上门的肥肉！[今天我就要为民除害/" + NpcButton.DO_SHUADAO.getKey() + "][我先准备准备]";
    }

    @Override
    public RandomNpcParam getRandomNpcParam() {
        RandomNpcParam randomNpcParam = new RandomNpcParam();

        int bossNameIndex = ThreadLocalRandom.current().nextInt(bossNames.size());
        String bossName = bossNames.get(bossNameIndex);
        randomNpcParam.setBossName(bossName);

        int prefixNameIndex = ThreadLocalRandom.current().nextInt(prefixNames.size());
        String prefixName = prefixNames.get(prefixNameIndex);
        String npcName = prefixName + bossName;
        randomNpcParam.setNpcName(npcName);

        return randomNpcParam;
    }

    @Override
    public ActivityType getActivityType() {
        return ActivityType.SHUA_DAO_XIANGYAO_TASK;
    }

    @Override
    public int getNpcBossCount() {
        return 1;
    }

    @Override
    public List<String> getSmallBossNames() {
        return smallBossNames;
    }

    @Override
    public String getSmallAlias() {
        return null;
    }

    @Override
    public int getBossTotalCount() {
        return 0;
    }

    @Override
    public int getCountRate() {
        return 1;
    }

    @Override
    public String getRankKey() {
        return Const.xiangyaoRank;
    }
}
