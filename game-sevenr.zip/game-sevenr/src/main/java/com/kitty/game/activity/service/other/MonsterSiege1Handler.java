//package com.kitty.game.activity.service.other;
//
//import com.kitty.game.activity.service.time.FightActivityHandler;
//import org.springframework.stereotype.Component;
//
//@Component
//public class MonsterSiege1Handler extends FightActivityHandler {
//
//}
