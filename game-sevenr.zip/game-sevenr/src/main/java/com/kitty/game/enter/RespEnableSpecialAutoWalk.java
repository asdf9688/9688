package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

@MessageMeta(module = Modules.MSG_ENABLE_SPECIAL_AUTO_WALK)
public class RespEnableSpecialAutoWalk extends Message {

    private byte enable = 1;

    public byte getEnable() {
        return enable;
    }

    public void setEnable(byte enable) {
        this.enable = enable;
    }
}
