package com.kitty.game.bag.message;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

/**
 * 使用物品
 */
@MessageMeta(module = Modules.CMD_APPLY)
public class ReqItemUse extends Message {
    private byte pos;
    private short num;

    public byte getPos() {
        return pos;
    }

    public void setPos(byte pos) {
        this.pos = pos;
    }

    public short getNum() {
        return num;
    }

    public void setNum(short num) {
        this.num = num;
    }
}
