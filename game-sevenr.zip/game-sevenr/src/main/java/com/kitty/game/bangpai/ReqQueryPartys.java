package com.kitty.game.bangpai;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

/**
 * 打开帮派 --未入帮
 */
@MessageMeta(module = Modules.CMD_QUERY_PARTYS)
public class ReqQueryPartys extends Message {
    private String type;
    private String para;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPara() {
        return para;
    }

    public void setPara(String para) {
        this.para = para;
    }
}
