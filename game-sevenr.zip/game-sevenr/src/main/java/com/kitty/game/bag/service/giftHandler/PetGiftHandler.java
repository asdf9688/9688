package com.kitty.game.bag.service.giftHandler;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.bag.model.GiftBagData;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.pet.PetDataPool;
import com.kitty.game.pet.PetType;
import com.kitty.game.pet.bean.PetObject;
import com.kitty.game.pet.model.Pet;
import com.kitty.game.pet.service.PetService;
import com.kitty.game.role.model.Role;
import com.kitty.game.team.message.RespMsg;
import com.kitty.mina.message.MessagePusher;
import org.springframework.stereotype.Component;

/**
 * 开启礼包得到宠物奖励
 */
@Component
public class PetGiftHandler extends GiftHandler {

    @Override
    public void getReward(Role role, GiftBagData giftBagData) {
        PetObject petObject = PetDataPool.getPetObject(giftBagData.getName());
        if (petObject == null){
            MessagePusher.pushMessage(role, new RespMsg("宠物不存在。"));
            return;
        }
        if (petObject.getPetType() ==  PetType.ghost?
                !SpringUtils.getPetService().isEquippedGhostFull(role)
                : !SpringUtils.getPetService().isEquippedFull(role)) {
            if (petObject != null) {
                Pet pet = SpringUtils.getBean(PetService.class).addPet(petObject, role, false);
                SpringUtils.getBean(PetService.class).loadPet(role, pet);
            }
            MessagePusher.pushMessage(role,new RespNotifyMiscEx("获得宠物成功"));
        } else {
            MessagePusher.pushMessage(role, new RespMsg("当前宠物包裹已满，请整理后再来吧。"));
        }
    }
}
