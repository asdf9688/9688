package com.kitty.game.activity.model.user;

import com.kitty.game.utils.TimeUtil;
import lombok.Getter;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnore;

import java.util.List;

@Setter
@Getter
public class Dugeon {
    private long id;
    private long createTime;
    private long endTime;
    private List<Long> memberList;

    public Dugeon() {}

    public Dugeon(long id, List<Long> memberList) {
        this.id = id;
        this.createTime = System.currentTimeMillis();
        this.endTime = createTime + (120 * TimeUtil.ONE_MINUTE);
        this.memberList = memberList;
    }

    /**是否是创建者*/
    @JsonIgnore
    public boolean isCreator(long uid)  {
        /**第1个成员为创建者*/
        return memberList.get(0) == uid;
    }

    @JsonIgnore
    public boolean isOverTime() {
        return System.currentTimeMillis() >= endTime;
    }

    //后加
    public void setId(long id) {
        this.id = id;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    public void setMemberList(List<Long> memberList) {
        this.memberList = memberList;
    }

    public long getId() {
        return this.id;
    }

    public long getCreateTime() {
        return this.createTime;
    }

    public long getEndTime() {
        return this.endTime;
    }

    public List<Long> getMemberList() {
        return this.memberList;
    }
}
