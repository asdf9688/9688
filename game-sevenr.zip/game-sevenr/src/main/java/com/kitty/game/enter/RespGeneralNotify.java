package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

@MessageMeta(module = Modules.MSG_GENERAL_NOTIFY)
public class RespGeneralNotify extends Message {
    private short notify;
    private String value;

    public short getNotify() {
        return notify;
    }

    public short getTop() {
        return notify;
    }

    public void setNotify(int notify) {
        this.notify = (short) notify;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }




    /*Icon*/
     //                       编号    等级
/*  主界面图标-背包,            1,      0,          EMPTY_STRING
    主界面图标-隐藏菜单,        2,      0,          EMPTY_STRING
    主界面图标-帮派,            3,      25,         开启主界面图标-帮派
    主界面图标-打造,            4,      35,         开启主界面图标-打造
    主界面图标-守护,            5,      -1,         开启主界面图标-守护
    主界面图标-系统,            6,      0,          EMPTY_STRING
    主界面图标-好友,            7,      0,          EMPTY_STRING
    主界面图标-世界地图,        8,      0,          EMPTY_STRING
    主界面图标-小地图,          9,      0,          EMPTY_STRING
    主界面图标-排行榜,          10,     25,         开启主界面图标-排行榜
    主界面图标-商城,            11,     0,          EMPTY_STRING
    主界面图标-交易,            12,     0,          EMPTY_STRING
    主界面图标-集市,            13,     0,          EMPTY_STRING
    主界面图标-珍宝,            14,     0,          EMPTY_STRING
    主界面图标-福利,            15,     0,          EMPTY_STRING
    主界面图标-巡逻,            16,     20,         开启主界面图标-巡逻
    主界面图标-刷道,            17,     45,         开启主界面图标-刷道
    主界面图标-活动,            18,     -1,         开启主界面图标-活动  20级
    主界面图标-首饰,            19,     35,         EMPTY_STRING
    主界面图标-装备,            20,     40,         EMPTY_STRING
    主界面图标-法宝,            21,     70,         开启主界面图标-法宝
    主界面图标-观战中心,        22,     50,         开启主界面图标-观战中心
    主界面图标-周年庆,          23,     -1,         开启主界面图标-周年庆
    主界面图标-QQ合作,          24,     -1,         开启主界面图标-QQ合作
    主界面图标-居所,            25,     75,         开启主界面图标-居所
    主界面图标-提升,            26,     0,          EMPTY_STRING
    主界面图标-成就,            27,     0,          EMPTY_STRING
    主界面图标-洛书,         28,     80,         EMPTY_STRING*/


/*Tab Icons*/
/*  [36] = "SkillDlgCheckBox",  -- 技能  10级开放
    [37] = "PetAttribDlgCheckBox",  -- 宠物属性 默认开放
    [38] = "PetSkillDlgCheckBox",  -- 宠物技能 默认开放
    [39] = "PetGetAttribDlgCheckBox",  -- 宠物加点 默认开放
    [40] = "PetHandbookDlgCheckBox",  -- 宠物图鉴 默认开放
    [41] = "EquipmentSplitTabDlgCheckBox",  -- 装备拆分 35级 和打造一起开放
    [42] = "EquipmentUpgradeDlgCheckBox",  -- 装备改造  35级 和打造一起开放
    [43] = "EquipmentRefiningTabDlgCheckBox",  -- 装备炼化 35级 和打造一起开放
    [44] = "EquipmentRefiningSuitDlgCheckBox",  -- 套装  应该是70级 ?
    [45] = "EquipmentEvolveDlgCheckBox",  -- 装备进化 应该是70级 ?
    [46] = "GuardAttribDlgCheckBox", -- 守护属性  和守护一起
    [47] = "ArtifactRefineTabDlgCheckBox",  -- 法宝洗炼   和法宝一起
    [48] = "ArtifactSkillUpTabDlgCheckBox", -- 法宝特技   和法宝一起*/

}
