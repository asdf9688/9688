package com.kitty.game.activity.model.product;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**地图守护神配置*/
@Getter
public class MapGuardianSet {
    /**对应NPC id*/
    private int npcId;
    /**挑战最小等级*/
    private short minLevel;
    /**挑战最大等级*/
    private short maxLevel;
    /**同组的npcId*/
    private List<Integer> sameGroupNpcIds;

    //后加
    public int getNpcId() {
        return this.npcId;
    }

    public short getMinLevel() {
        return this.minLevel;
    }

    public short getMaxLevel() {
        return this.maxLevel;
    }

    public void setSameGroupNpcIds(List<Integer> sameGroupNpcIds) {
        this.sameGroupNpcIds = sameGroupNpcIds;
    }

    public List<Integer> getSameGroupNpcIds() {
        return this.sameGroupNpcIds;
    }
}
