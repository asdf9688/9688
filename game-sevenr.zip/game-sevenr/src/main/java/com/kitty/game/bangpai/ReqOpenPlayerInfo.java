package com.kitty.game.bangpai;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

/**
 * 打开帮派
 */
@MessageMeta(module = Modules.CMD_GET_PARTY_CHANNEL_DENY_LIST)
public class ReqOpenPlayerInfo extends Message {

}
