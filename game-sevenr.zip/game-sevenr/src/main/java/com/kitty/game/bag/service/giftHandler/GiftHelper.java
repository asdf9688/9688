package com.kitty.game.bag.service.giftHandler;


import com.kitty.common.spring.SpringUtils;
import com.kitty.game.bag.model.GiftType;

import java.util.HashMap;
import java.util.Map;

public enum GiftHelper {
    INSTANCE;

    private static final Map<GiftType, GiftHandler> handlers = new HashMap<>();

    public void init(GiftType giftType, GiftHandler giftHandler) {
        handlers.put(giftType, giftHandler);
    }

    public GiftHandler getGiftHelper(GiftType giftType) {
        return handlers.get(giftType);
    }

    public Map<GiftType, GiftHandler> getHandlers() {
        return handlers;
    }

    static {
        INSTANCE.init(GiftType.EQUIP, SpringUtils.getBean(EquipGiftHandler.class));
        INSTANCE.init(GiftType.PET, SpringUtils.getBean(EquipGiftHandler.class));
        INSTANCE.init(GiftType.PROP, SpringUtils.getBean(EquipGiftHandler.class));
        INSTANCE.init(GiftType.JEWELRY, SpringUtils.getBean(EquipGiftHandler.class));
        INSTANCE.init(GiftType.ATTRIBUTE, SpringUtils.getBean(AttributeGiftHandler.class));
    }
}
