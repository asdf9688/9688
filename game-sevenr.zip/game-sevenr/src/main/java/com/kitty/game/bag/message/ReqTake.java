package com.kitty.game.bag.message;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

/**
 * 仓库取出
 */
@MessageMeta(module = Modules.CMD_TAKE)
public class ReqTake extends Message {
    private int id;
    private short from_pos;
    private short to_pos;
    private short amount;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public short getFrom_pos() {
        return from_pos;
    }

    public void setFrom_pos(short from_pos) {
        this.from_pos = from_pos;
    }

    public short getTo_pos() {
        return to_pos;
    }

    public void setTo_pos(short to_pos) {
        this.to_pos = to_pos;
    }

    public short getAmount() {
        return amount;
    }

    public void setAmount(short amount) {
        this.amount = amount;
    }
}
