package com.kitty.game.confirm.service.handler;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.confirm.service.handler.ConfirmHandler;
import com.kitty.game.equip.model.RoleEquip;
import com.kitty.game.equip.service.EquipService;
import com.kitty.game.role.model.Role;
import com.kitty.game.task.service.taskHandler.DigTreasureTaskHandler;
import com.kitty.game.team.message.ReqConfirmResult;
import com.kitty.game.utils.Const;
import com.kitty.mina.cache.SessionUtils;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class DigConfirmHandler extends ConfirmHandler {
    Logger logger = LoggerFactory.getLogger(getClass());

    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
        if ("1".equals(reqConfirmResult.getSelect())) {
            int digTreasureType = role.getActivity().getDigTreasureType();
            logger.error("确认继续挖宝=={}",digTreasureType);
            String name = Const.TREASURE_SUPER_SENIOR_ITEM_NAME;
            if (digTreasureType != Const.DIG_TREASURE_TYPE_SUPER_SENIOR){
                digTreasureType = Const.DIG_TREASURE_TYPE_SUPER;
                name = Const.TREASURE_SUPER_ITEM_NAME;
            }
            IoSession session = SessionUtils.getSession(role.getRoleId());
            if (session == null) {
                return;
            }
            RoleEquip roleEquip = SpringUtils.getBean(EquipService.class).getRoleEquipByName(session, name);
            if (roleEquip == null) {
                return;
            }
            SpringUtils.getBean(DigTreasureTaskHandler.class).useTreasureMapItem(role, (byte) digTreasureType, roleEquip);
        }
    }
}
