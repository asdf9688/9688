package com.kitty.game.difu;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.RoleService;
import com.kitty.game.team.message.RespMsg;
import com.kitty.game.team.service.TeamService;
import com.kitty.listener.EventDispatcher;
import com.kitty.listener.EventType;
import com.kitty.listener.event.EnterMapEvent;
import com.kitty.listener.event.LeaveMapEvent;
import com.kitty.mina.message.MessagePusher;
import org.nutz.lang.Strings;
import org.springframework.stereotype.Service;


@Service
public class DifuService {
    public void enter(Role role, String msg) {
        if (Strings.isEmpty(msg)){
            return;
        }
        SpringUtils.getMapService().changeMap(role, 60001, 43, 26);
    }

    public void leave(Role role, String msg) {
        SpringUtils.getMapService().changeMap(role, 23000, 64, 58);
    }

    public void diyushengyuan(Role role, String msg) {
        SpringUtils.getMapService().changeMap(role, 60006, 41, 31);
    }
    public void dariditu(Role role, String msg) {
        SpringUtils.getMapService().changeMap(role, 20003, 36, 37);
    }
    public void backdifuzhucheng(Role role, String msg) {
        SpringUtils.getMapService().changeMap(role, 60000, 89, 67);
    }

    public void jinrudigong(Role role, String msg) {

    }
    /*试炼之地*/
    public void hell(Role role, String msg) {
        SpringUtils.getMapService().changeMap(role, 16101, 49, 38);
    }
    /*九层妖塔1*/
    public void jiuceng1(Role role, String msg) {
        SpringUtils.getMapService().changeMap(role, 37101, 31, 27);
    }
    /*九层妖塔2*/
    public void jiuceng2(Role role, String msg) {
        SpringUtils.getMapService().changeMap(role, 37105, 52, 35);
    }
    /*九层妖塔3*/
    public void jiuceng3(Role role, String msg) {
        SpringUtils.getMapService().changeMap(role, 37105, 52, 35);
    }
    /*九层妖塔4*/
    public void jiuceng4(Role role, String msg) {
        SpringUtils.getMapService().changeMap(role, 37105, 52, 35);
    }
    /*九层妖塔5*/
    public void jiuceng5(Role role, String msg) {
        SpringUtils.getMapService().changeMap(role, 37105, 52, 35);
    }
    /*九层妖塔6*/
    public void jiuceng6(Role role, String msg) {
        SpringUtils.getMapService().changeMap(role, 37105, 52, 35);
    }
    /*九层妖塔7*/
    public void jiuceng7(Role role, String msg) {
        SpringUtils.getMapService().changeMap(role, 37105, 52, 35);
    }
    /*九层妖塔8*/
    public void jiuceng8(Role role, String msg) {
        SpringUtils.getMapService().changeMap(role, 37105, 52, 35);
    }
    /*九层妖塔9*/
    public void jiuceng9(Role role, String msg) {
        SpringUtils.getMapService().changeMap(role, 37105, 52, 35);
    }

    public void zhenyaota(Role role, String msg) {
        SpringUtils.getMapService().changeMap(role, 37101, 31, 27);
    }

    public void shengjihuanjing(Role role, String msg) {
        // 扣除积分（幻境试炼-后续优化读取数据库积分）
        TeamService teamService = SpringUtils.getTeamService();
        if (teamService.isInTeam(role) == false) {
            SpringUtils.getBean(RoleService.class).substractChargeScore(role, 500);
            SpringUtils.getMapService().changeMap(role, 37126, 20, 20);
        }else {
            MessagePusher.pushMessage(role, new RespMsg("进入幻境前不允许组队！进入后可以组队！"));
        }

    }

    public void yuwaizhanchang(Role role, String msg) {
        TeamService teamService = SpringUtils.getTeamService();
        if (teamService.isInTeam(role) == false) {
            SpringUtils.getBean(RoleService.class).substractChargeScore(role, 500);
            SpringUtils.getMapService().changeMap(role, 37126, 20, 20);
        }else {
            // TODO::暂时禁止组队进入，后续做阵营判断。非同阵营不允许组队
            MessagePusher.pushMessage(role, new RespMsg("你可组队前往战场！"));
        }
    }
}
