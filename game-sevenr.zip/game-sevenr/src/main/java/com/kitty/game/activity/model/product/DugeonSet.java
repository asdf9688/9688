package com.kitty.game.activity.model.product;

import lombok.Getter;

@Getter
public class DugeonSet {
    /**奖励*/
    private int expReward;

    private int taoReward;

    private int matiralReward;

    private int potReward;

    //后加
    public int getExpReward() {
        return this.expReward;
    }

    public int getTaoReward() {
        return this.taoReward;
    }

    public int getMatiralReward() {
        return this.matiralReward;
    }

    public int getPotReward() {
        return this.potReward;
    }
}
