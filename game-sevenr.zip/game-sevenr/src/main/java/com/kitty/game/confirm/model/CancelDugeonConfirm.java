package com.kitty.game.confirm.model;


import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

public class CancelDugeonConfirm extends RoleConfirm {
    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.CANCAL_DUGEON;
    }
}
