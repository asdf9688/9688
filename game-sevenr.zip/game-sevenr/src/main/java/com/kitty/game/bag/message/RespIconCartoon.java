package com.kitty.game.bag.message;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

import java.util.Random;


/**
 * 仓库物品
 */
@MessageMeta(module = Modules.MSG_ICON_CARTOON)
public class RespIconCartoon extends Message {
    private short type = 1;//2宠物 1物品
    private String name;
    private String param;
    private short rightNow = 0;

    public short getRightNow() {
        return rightNow;
    }

    public void setRightNow(short rightNow) {
        this.rightNow = rightNow;
    }

    public short getType() {
        return type;
    }

    public void setType(short a) {
        this.type = a;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getParam() {
        return param;
    }

    public void setParam(String param) {
        this.param = param;
    }

    public RespIconCartoon() {
        this.type = 1;
    }

    public RespIconCartoon(String name) {
        Random random = new Random();
        this.name = name;
        this.param = (random.nextInt(999999999) + 100000000) + "";
        this.rightNow=0;
        this.type = 1;
    }
}
