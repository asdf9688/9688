package com.kitty.game.confirm.service.handler;

import com.kitty.game.confirm.service.handler.ConfirmHandler;
import com.kitty.game.role.model.Role;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.equip.service.EquipService;
import com.kitty.game.team.message.ReqConfirmResult;
import com.kitty.game.team.message.RespMsg;
import com.kitty.game.utils.AsktaoUtil;
import com.kitty.game.utils.TimeUtil;
import com.kitty.game.welfare.message.vo.DailySignGift;
import com.kitty.game.welfare.service.WelfareService;
import com.kitty.mina.message.MessagePusher;
import com.kitty.game.role.service.RoleService;
import org.nutz.lang.util.NutMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Map;

@Component
public class DoReplenishConfirmHandler extends ConfirmHandler {
    @Autowired
    RoleService roleService;
    @Autowired
    WelfareService welfareService;
    @Autowired
    EquipService equipService;

    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
        if ("1".equals(reqConfirmResult.getSelect())) {
            doReplenishSign(role);
        }
    }

    /**
     * 确认补签
     * TODO 逻辑没看懂，后续补偿
     */
    public void doReplenishSign(Role role) {
        Map<String, Integer> nutMap = role.getExtendBox().getWelfare();
        int size = role.getExtendBox().getSignSize();
        DailySignGift dailySignGift = welfareService.getSignGift(size);
        if (dailySignGift == null) {
            return;
        }
        String str = role.getExtendBox().getSignDay();
        String today = TimeUtil.formatDate(new Date());
        if (str.equals(today)) {
            return;
        }
        String dd = TimeUtil.getDay(new Date());
        if (size >= Integer.parseInt(dd)) {
            return;
        }
/*        String currDate = TimeUtil.formatDate(new Date());
        if (currDate.equals(nutMap.getString("buSign"))) {
            return;
        }
        if (role.getMoney() < 2580000) {
            if (role.getVoucher() < 2580000) {
                MessagePusher.pushMessage(role, new RespMsg("你的金钱不足。"));
                return;
            } else {
                MessagePusher.pushMessage(role, new RespNotifyMiscEx("补签成功，你花费了" + AsktaoUtil.getMoneyFormat(2580000) + "代金卷。"));
                roleService.subtractVoucher(role, 2580000);
            }
        } else {
            MessagePusher.pushMessage(role, new RespNotifyMiscEx("补签成功，你花费了" + AsktaoUtil.getMoneyFormat(2580000) + "文钱。"));
            roleService.subtractMoney(role, 2580000);
        }

        nutMap.setv("buSign", TimeUtil.formatDate(new Date()));
        nutMap.setv("today", today);
        nutMap.setv("size", nutMap.getInt("size", 0) + 1);
        welfareService.getSignGift(role, dailySignGift);

        welfareService.dailySign(role);
        role.save();*/
    }

}
