package com.kitty.game.confirm.service.handler;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.confirm.model.ForcePKConfirm;
import com.kitty.game.pk.service.PkService;
import com.kitty.game.role.model.Role;
import com.kitty.game.team.message.ReqConfirmResult;
import org.springframework.stereotype.Component;
import com.kitty.game.confirm.service.handler.ConfirmHandler;

@Component
public class ForcePKConfirmHandler extends ConfirmHandler {
    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
        if ("1".equals(reqConfirmResult.getSelect())) {
            ForcePKConfirm forcePKConfirm = (ForcePKConfirm)role.getConfirm();
            SpringUtils.getBean(PkService.class).confirmForcePK(role, forcePKConfirm.getTargetUid());
        }
    }
}
