package com.kitty.game.confirm.service.handler;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.confirm.model.ConfirmType;

import java.util.HashMap;
import java.util.Map;
//后写
import com.kitty.game.confirm.service.handler.AcceptKillTaskConfirmHandler;
import com.kitty.game.confirm.service.handler.AddFriendConfirmHandler;
import com.kitty.game.confirm.service.handler.AvoidMonsterConfirmHandler;
import com.kitty.game.confirm.service.handler.BuyCustomFasionConfirmHandler;
import com.kitty.game.confirm.service.handler.BuyDevilTimeConfirmHandler;
import com.kitty.game.confirm.service.handler.BuyEffectConfirmHandler;
import com.kitty.game.confirm.service.handler.BuyFashionConfirmHandler;
import com.kitty.game.confirm.service.handler.BuyFollowPetConfirmHandler;
import com.kitty.game.confirm.service.handler.BuyVipConfirmHandler;
//import com.kitty.game.confirm.service.handler.BuyWeddingConfirmHandler;
import com.kitty.game.confirm.service.handler.CancelDugeonConfirmHandler;
import com.kitty.game.confirm.service.handler.ChooseAtkConfirmHandler;
import com.kitty.game.confirm.service.handler.ConfirmHandler;
import com.kitty.game.confirm.service.handler.CreatePartyConfrimHandler;
import com.kitty.game.confirm.service.handler.DWDRConfirmHandler;
import com.kitty.game.confirm.service.handler.DoReplenishConfirmHandler;
import com.kitty.game.confirm.service.handler.ExChangePetConfirmHandler;
import com.kitty.game.confirm.service.handler.FetchShuaDaoRewardConfirmHandler;
import com.kitty.game.confirm.service.handler.FightSealBossConfirmHandler;
import com.kitty.game.confirm.service.handler.ForcePKConfirmHandler;
import com.kitty.game.confirm.service.handler.GSGConfirmHandler;
import com.kitty.game.confirm.service.handler.GiveUpTaskConfirmHandler;
import com.kitty.game.confirm.service.handler.GotoFPKConfirmHandler;
import com.kitty.game.confirm.service.handler.HDDSInviteConfirmHandler;
import com.kitty.game.confirm.service.handler.HDDSOfflineConfirmHandler;
import com.kitty.game.confirm.service.handler.HelpPeopleConfirmHandler;
import com.kitty.game.confirm.service.handler.LeaveTeamConfirmHandler;
import com.kitty.game.confirm.service.handler.LihunConfirmHandler;
import com.kitty.game.confirm.service.handler.MSDRConfirmHandler;
import com.kitty.game.confirm.service.handler.OfflineConfirmHandler;
import com.kitty.game.confirm.service.handler.OfflineTimeConfirmHandler;
import com.kitty.game.confirm.service.handler.PartyDonateConfirmHandler;
import com.kitty.game.confirm.service.handler.PetFightConfirmHandler;
import com.kitty.game.confirm.service.handler.PrisonReleaseConfirmHandler;
import com.kitty.game.confirm.service.handler.RequestTeamLeaderHandler;
import com.kitty.game.confirm.service.handler.ReturnTeamHandler;
import com.kitty.game.confirm.service.handler.TowerChangeRewardConfirmHandler;
import com.kitty.game.confirm.service.handler.TowerFlyUpConfirmHandler;
import com.kitty.game.confirm.service.handler.UseChangeCardHandler;
import com.kitty.game.confirm.service.handler.UseShapePenHandler;
import com.kitty.game.confirm.service.handler.ZHJConfirmHandler;
import com.kitty.game.xmd.XianMoConfirmHandler;


/**确认框*/
public enum ConfirmHandlerHelper {
    INSTANCE;

    private Map<ConfirmType, ConfirmHandler> handlers = new HashMap<>();

    private void registerHandler(ConfirmType confirmType, ConfirmHandler confirmHandler) {
        handlers.put(confirmType, confirmHandler);
    }

    public ConfirmHandler getTargetHandler(ConfirmType confirmType) {
        return handlers.get(confirmType);
    }

    public void initialize() {
        registerHandler(ConfirmType.CHOOSE_ATK, SpringUtils.getBean(ChooseAtkConfirmHandler.class));
        registerHandler(ConfirmType.GIVE_UP_TASK, SpringUtils.getBean(GiveUpTaskConfirmHandler.class));
        registerHandler(ConfirmType.HELP_PEOPLE_REWARD_MORE, SpringUtils.getBean(HelpPeopleConfirmHandler.class));
        registerHandler(ConfirmType.TOWER_FLY_UP, SpringUtils.getBean(TowerFlyUpConfirmHandler.class));
        registerHandler(ConfirmType.TOWER_CHANGE_REWARD, SpringUtils.getBean(TowerChangeRewardConfirmHandler.class));
        registerHandler(ConfirmType.FIGHT_SEAL_BOSS, SpringUtils.getBean(FightSealBossConfirmHandler.class));
        registerHandler(ConfirmType.PET_FIGHT, SpringUtils.getBean(PetFightConfirmHandler.class));
        registerHandler(ConfirmType.DO_REPLENISH_SIGN, SpringUtils.getBean(DoReplenishConfirmHandler.class));
        registerHandler(ConfirmType.BUY_CUSTOMFASHION, SpringUtils.getBean(BuyCustomFasionConfirmHandler.class));
        registerHandler(ConfirmType.BUY_FASHION, SpringUtils.getBean(BuyFashionConfirmHandler.class));
        registerHandler(ConfirmType.BUY_FOLLOWPET, SpringUtils.getBean(BuyFollowPetConfirmHandler.class));
        registerHandler(ConfirmType.BUY_EFFECT, SpringUtils.getBean(BuyEffectConfirmHandler.class));
        registerHandler(ConfirmType.BUY_VIP, SpringUtils.getBean(BuyVipConfirmHandler.class));
        registerHandler(ConfirmType.EXCHANGE_PET, SpringUtils.getBean(ExChangePetConfirmHandler.class));
        registerHandler(ConfirmType.RETURN_TEAM, SpringUtils.getBean(ReturnTeamHandler.class));
        registerHandler(ConfirmType.USE_CHANGE_CARD, SpringUtils.getBean(UseChangeCardHandler.class));
        registerHandler(ConfirmType.USE_SHAPE_PEN, SpringUtils.getBean(UseShapePenHandler.class));

        registerHandler(ConfirmType.LEAVE_TEAM, SpringUtils.getBean(LeaveTeamConfirmHandler.class));
        registerHandler(ConfirmType.zhj_duihuan, SpringUtils.getBean(ZHJConfirmHandler.class));
        registerHandler(ConfirmType.invite_reward, SpringUtils.getBean(HDDSInviteConfirmHandler.class));
        registerHandler(ConfirmType.offline_reward, SpringUtils.getBean(HDDSOfflineConfirmHandler.class));
        registerHandler(ConfirmType.BUY_offline, SpringUtils.getBean(OfflineConfirmHandler.class));
        registerHandler(ConfirmType.BUY_offline_time, SpringUtils.getBean(OfflineTimeConfirmHandler.class));
        registerHandler(ConfirmType.dwdr_leiji, SpringUtils.getBean(DWDRConfirmHandler.class));
        registerHandler(ConfirmType.msdr_onekey, SpringUtils.getBean(MSDRConfirmHandler.class));
        registerHandler(ConfirmType.gsg_gaizao, SpringUtils.getBean(GSGConfirmHandler.class));
        registerHandler(ConfirmType.REQUEST_TEAN_LEADER, SpringUtils.getBean(RequestTeamLeaderHandler.class));
        registerHandler(ConfirmType.FETCH_SHUADAO_REWARD, SpringUtils.getBean(FetchShuaDaoRewardConfirmHandler.class));
        registerHandler(ConfirmType.AVOID_MONSTER, SpringUtils.getBean(AvoidMonsterConfirmHandler.class));
        registerHandler(ConfirmType.CREATE_PARTY, SpringUtils.getBean(CreatePartyConfrimHandler.class));
        registerHandler(ConfirmType.PARTY_DONATE, SpringUtils.getBean(PartyDonateConfirmHandler.class));
        registerHandler(ConfirmType.FORCE_PK, SpringUtils.getBean(ForcePKConfirmHandler.class));
        registerHandler(ConfirmType.PRISON_RELEASE, SpringUtils.getBean(PrisonReleaseConfirmHandler.class));
        registerHandler(ConfirmType.GOTO_FPK, SpringUtils.getBean(GotoFPKConfirmHandler.class));
        registerHandler(ConfirmType.ACCEPT_KILL_TASK, SpringUtils.getBean(AcceptKillTaskConfirmHandler.class));
        registerHandler(ConfirmType.ADD_FRIEND, SpringUtils.getBean(AddFriendConfirmHandler.class));
        registerHandler(ConfirmType.CANCAL_DUGEON, SpringUtils.getBean(CancelDugeonConfirmHandler.class));
        registerHandler(ConfirmType.BUY_DEVIL_TIME, SpringUtils.getBean(BuyDevilTimeConfirmHandler.class));
        registerHandler(ConfirmType.LIHUN, SpringUtils.getBean(LihunConfirmHandler.class));//离婚
        registerHandler(ConfirmType.XIANMO_RE, SpringUtils.getBean(XianMoConfirmHandler.class));//仙魔转换
        registerHandler(ConfirmType.DELETE_ROLE, SpringUtils.getBean(DeleteRoleConfirmHandler.class));
    }

    static  {
        /**初始化*/
        INSTANCE.initialize();
    }
}
