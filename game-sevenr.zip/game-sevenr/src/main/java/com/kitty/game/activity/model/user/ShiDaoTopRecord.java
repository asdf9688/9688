package com.kitty.game.activity.model.user;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ShiDaoTopRecord {
    private long uid;
    private String name;
    private int rank;
    private String levelRange;
    /**是否已经领取每天奖励*/
    private boolean dayRewardFetch;

    public ShiDaoTopRecord() {}

    public ShiDaoTopRecord(long uid, int rank, String levelRange, boolean dayRewardFetch,String name) {
        this.uid = uid;
        this.rank = rank;
        this.levelRange = levelRange;
        this.dayRewardFetch = dayRewardFetch;
        this.name = name;
    }
    //后加
    public void setUid(long uid) {
        this.uid = uid;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public void setLevelRange(String levelRange) {
        this.levelRange = levelRange;
    }

    public void setDayRewardFetch(boolean dayRewardFetch) {
        this.dayRewardFetch = dayRewardFetch;
    }

    public long getUid() {
        return this.uid;
    }

    public String getName() {
        return this.name;
    }

    public int getRank() {
        return this.rank;
    }

    public String getLevelRange() {
        return this.levelRange;
    }

    public boolean isDayRewardFetch() {
        return this.dayRewardFetch;
    }


}
