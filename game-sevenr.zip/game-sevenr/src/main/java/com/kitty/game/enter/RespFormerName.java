package com.kitty.game.enter;

import com.kitty.mina.Modules;
import com.kitty.mina.annotation.ListField;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;
import com.kitty.mina.annotation.ListField;

import java.util.Set;


/**
 * 历史角色名
 */
@MessageMeta(module = Modules.MSG_FORMER_NAME)
public class RespFormerName extends Message {
    private boolean is_ok=true;
    @ListField(value = 1)
    private Set<String> nameList;


    public Set<String> getNameList() {
        return nameList;
    }

    public void setNameList(Set<String> nameList) {
        this.nameList = nameList;
    }
}
