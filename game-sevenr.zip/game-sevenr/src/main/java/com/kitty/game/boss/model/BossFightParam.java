package com.kitty.game.boss.model;

import lombok.Getter;
import lombok.Setter;
import org.nutz.lang.util.NutMap;

import java.util.List;
//后写
import com.kitty.game.boss.model.BossParam;

@Getter
@Setter
public class BossFightParam {
    private List<BossParam> bossParamList;
    /**战斗类型*/
    private int fightType;
    /**任务id*/
    private int taskId;
    /**NPC id*/
    private int npcId;
    /**NPC 等级*/
    private short npcLevel;
    private NutMap reward;
    /**战斗喊话*/
    private List<String> shoutingList;
    /**是否加载守护*/
    private boolean loadGuard = true;

    public BossFightParam(List<BossParam> bossParamList, int fightType) {
        this.bossParamList = bossParamList;
        this.fightType = fightType;
    }

    public BossFightParam(List<BossParam> bossParamList, int fightType, int taskId, int npcId) {
        this.bossParamList = bossParamList;
        this.fightType = fightType;
        this.taskId = taskId;
        this.npcId = npcId;
    }


//后写

    public void setBossParamList(List<BossParam> bossParamList) {
        this.bossParamList = bossParamList;
    }

    public void setFightType(int fightType) {
        this.fightType = fightType;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    public void setNpcId(int npcId) {
        this.npcId = npcId;
    }

    public void setNpcLevel(short npcLevel) {
        this.npcLevel = npcLevel;
    }

    public void setReward(NutMap reward) {
        this.reward = reward;
    }

    public void setShoutingList(List<String> shoutingList) {
        this.shoutingList = shoutingList;
    }

    public void setLoadGuard(boolean loadGuard) {
        this.loadGuard = loadGuard;
    }

    public List<BossParam> getBossParamList() {
        return this.bossParamList;
    }

    public int getFightType() {
        return this.fightType;
    }

    public int getTaskId() {
        return this.taskId;
    }

    public int getNpcId() {
        return this.npcId;
    }

    public short getNpcLevel() {
        return this.npcLevel;
    }

    public NutMap getReward() {
        return this.reward;
    }

    public List<String> getShoutingList() {
        return this.shoutingList;
    }

    public boolean isLoadGuard() {
        return this.loadGuard;
    }
}


