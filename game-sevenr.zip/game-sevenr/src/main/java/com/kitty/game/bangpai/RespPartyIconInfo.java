package com.kitty.game.bangpai;

import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.annotation.StringField;
import com.kitty.mina.message.Message;


//处理CMD_REQUEST_ICON时，把图标的buffer信息发送给客户端
@MessageMeta(module = Modules.MSG_SEND_ICON)
public class RespPartyIconInfo extends Message {
    private String md5_value;
    @StringField(1)
    private String file_dat;

    public String getMd5_value() {
        return md5_value;
    }

    public void setMd5_value(String md5_value) {
        this.md5_value = md5_value;
    }

    public String getFile_dat() {
        return file_dat;
    }

    public void setFile_dat(String file_dat) {
        this.file_dat = file_dat;
    }
}
