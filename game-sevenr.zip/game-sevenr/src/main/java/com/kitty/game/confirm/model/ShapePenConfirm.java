package com.kitty.game.confirm.model;

import com.kitty.game.role.model.Role;
import com.kitty.game.equip.model.RoleEquip;
import com.kitty.game.config.ShapePen;
import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

public class ShapePenConfirm extends RoleConfirm {
    private Role targetRole;
    private ShapePen shapePen;
    private RoleEquip roleEquip;

    public ShapePenConfirm(Role targetRole, ShapePen shapePen, RoleEquip roleEquip) {
        this.roleEquip =roleEquip;
        this.shapePen=shapePen;
        this.targetRole=targetRole;

    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.USE_SHAPE_PEN;
    }

    public Role getTargetRole() {
        return targetRole;
    }

    public ShapePen getShapePen() {
        return shapePen;
    }

    public RoleEquip getRoleEquip() {
        return roleEquip;
    }
}
