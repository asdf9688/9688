package com.kitty.game.confirm.model;

import lombok.Getter;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

/**
 * 对方为好友时加入黑名单
 */
@Getter
public class AddBlackConfirm extends RoleConfirm {
    private String targetName;

    public AddBlackConfirm(String targetName) {
        this.targetName = targetName;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.ADD_BLACK;
    }
}
