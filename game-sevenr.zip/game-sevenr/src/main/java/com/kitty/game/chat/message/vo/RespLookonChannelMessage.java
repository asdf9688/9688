package com.kitty.game.chat.message.vo;

import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;
import lombok.Setter;

import static com.kitty.mina.NewModules.MSG_LOOKON_CHANNEL_MESSAGE;

@Setter
@MessageMeta(module = MSG_LOOKON_CHANNEL_MESSAGE)
public class RespLookonChannelMessage extends Message {
    private String sender;
    private String msg;

    public RespLookonChannelMessage(String msg) {
        this.msg = msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

}
