package com.kitty.game.activity.model.product;

import lombok.Getter;
import lombok.Setter;

import java.util.Arrays;
import java.util.List;
//后加
import com.kitty.game.activity.model.product.ActivityType;
/**活动活跃度配置*/
@Setter
@Getter
public class ActivityLivenessSet {
    /**活动名称*/
    private String name;
    /**活动类型列表*/
    private List<ActivityType> activityTypeList;
    /**每完成一次对应活动加的活跃度*/
    private float perLiveness;
    /**活动最大加的活跃度*/
    private int maxLiveness;

    public ActivityLivenessSet(String name, ActivityType activityType, float perLiveness, int maxLiveness) {
        this.name = name;
        this.activityTypeList = Arrays.asList(activityType);
        this.perLiveness = perLiveness;
        this.maxLiveness = maxLiveness;
    }

    public ActivityLivenessSet(String name, List<ActivityType> activityTypeList, float perLiveness, int maxLiveness) {
        this.name = name;
        this.activityTypeList = activityTypeList;
        this.perLiveness = perLiveness;
        this.maxLiveness = maxLiveness;
    }
}
