package com.kitty.game.admin.facade;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.admin.message.ReqAdminBlockUser;
import com.kitty.game.admin.message.ReqAdminMakeEquip;
import com.kitty.game.admin.message.ReqAdminQueryPlayer;
import com.kitty.game.admin.message.vo.ReqAdminShutChannel;
import com.kitty.game.admin.service.AdminService;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.role.model.Account;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.AccountService;
import com.kitty.game.team.message.RespMsg;
import com.kitty.game.utils.TimeUtil;
import com.kitty.logs.LoggerFunction;
import com.kitty.mina.annotation.RequestMapping;
import com.kitty.mina.cache.SessionUtils;
import com.kitty.mina.message.MessagePusher;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class AdminController {
    private final Logger logger = LoggerFunction.GM.getLogger();
    @Autowired
    AdminService adminService;
    @Autowired
    AccountService accountService;


    @RequestMapping
    public void makeEquip(IoSession session, ReqAdminMakeEquip makeEquip) {
        /**需要先验证账号权限*/
        Role role = SessionUtils.getRoleBySession(session);
        Account account = accountService.getAccount(role.getSid());
        if (checkPrivilege(account, 1000)) {
//            adminService.makeEquip(role, makeEquip);
        }
    }

    @RequestMapping
    public void queryPlayer(IoSession session, ReqAdminQueryPlayer queryPlayer) {
        Role role = SessionUtils.getRoleBySession(session);
        Account account = accountService.getAccount(role.getSid());
        if (checkPrivilege(account, 200)) {
            adminService.queryPlayer(role, queryPlayer.getName(), queryPlayer.getType());
        }
    }

    @RequestMapping
    public void blockPlayer(IoSession session, ReqAdminBlockUser blockUser) {
        Role role = SessionUtils.getRoleBySession(session);
        Account account = accountService.getAccount(role.getSid());
        if (checkPrivilege(account, 200)) {
            Role target = SpringUtils.getPlayerService().getPlayerBy(Long.parseLong(blockUser.getGid()));
            if (target == null) {
                MessagePusher.pushMessage(role, new RespMsg("角色不存在!"));
                return;
            }
            if (blockUser.getTime() <= 0 && account.getPrivilege() >= 1000){
                logger.error("解封角色GM:{},目标:{},禁言时间:{},禁言原因:{}", account.getUsername(), blockUser.getName(), blockUser.getTime(), blockUser.getReason());
                adminService.blockPlayer(target, 0);
                MessagePusher.pushMessage(role, new RespNotifyMiscEx("角色解封成功!"));
            }else {
                Account targetAccount = accountService.getAccount(target.getSid());
                if (targetAccount.getPrivilege()==1000){
                    MessagePusher.pushMessage(role, new RespMsg("不能封闭管理员!"));
                    return;
                }
                logger.error("封闭角色GM:{},目标:{},禁言时间:{},禁言原因:{}", account.getUsername(), blockUser.getName(), blockUser.getTime(), blockUser.getReason());
                adminService.blockPlayer(target, System.currentTimeMillis() + blockUser.getTime() * TimeUtil.ONE_SECOND);
                MessagePusher.pushMessage(role, new RespNotifyMiscEx("角色封闭成功!"));
                MessagePusher.pushMessage(target, new RespNotifyMiscEx("你已被封禁!"));
            }
        }
    }


    /**
     * 禁言角色
     */
    @RequestMapping
    public void shutChanel(IoSession session, ReqAdminShutChannel shutChannel) {
        Role role = SessionUtils.getRoleBySession(session);
        Account account = accountService.getAccount(role.getSid());
        if (checkPrivilege(account, 200)) {
            Role target = SpringUtils.getPlayerService().getPlayerBy(Long.parseLong(shutChannel.getGid()));
            if (target == null) {
                MessagePusher.pushMessage(role, new RespMsg("角色不存在!"));
                return;
            }
            if (shutChannel.getTime()<= 0 && account.getPrivilege() >= 1000){
                logger.error("解开禁言角色GM:{},目标:{},禁言时间:{},禁言原因:{}", account.getUsername(), shutChannel.getName(), shutChannel.getTime(), shutChannel.getReason());
                adminService.shutChannel(target, System.currentTimeMillis() + shutChannel.getTime() * TimeUtil.ONE_SECOND);
                MessagePusher.pushMessage(role, new RespNotifyMiscEx("角色发言已经解开!"));
                MessagePusher.pushMessage(target, new RespNotifyMiscEx("你已可以畅所欲言!"));
            }else {
                Account targetAccount = accountService.getAccount(target.getSid());
                if (targetAccount.getPrivilege()==1000){
                    MessagePusher.pushMessage(role, new RespMsg("不能禁言管理员!"));
                    return;
                }
                logger.error("禁言角色GM:{},目标:{},禁言时间:{},禁言原因:{}", account.getUsername(), shutChannel.getName(), shutChannel.getTime(), shutChannel.getReason());
                adminService.shutChannel(target, System.currentTimeMillis() + shutChannel.getTime() * TimeUtil.ONE_SECOND);
                MessagePusher.pushMessage(role, new RespNotifyMiscEx("角色禁言成功!"));
                MessagePusher.pushMessage(target, new RespNotifyMiscEx("你已被禁言!"));
            }
        }

    }

    private boolean checkPrivilege(Account account, int reqPrivilege) {
        return account != null && account.getPrivilege() >= reqPrivilege;
    }

}
