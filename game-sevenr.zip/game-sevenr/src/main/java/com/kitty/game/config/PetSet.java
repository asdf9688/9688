package com.kitty.game.config;


import com.kitty.game.enter.FiedValue;
import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;
import org.nutz.lang.util.NutMap;

import java.util.ArrayList;
import java.util.List;

/**
 * 宠物的公共数据
 */
@Table("p_petset")
public class PetSet {
    @Column
    private String name;
    @Column
    @Comment("相性")
    private short polar;
    @Column
    private short icon;
    @Column
    @Comment("飞升前的气血")
    private String qixueFanwei;
    @Column
    @Comment("飞升前的法力")
    private String faliFanwei;
    @Column
    @Comment("飞升前的速度")
    private String suduFanwei;
    @Column
    @Comment("飞升前的物攻")
    private String wugongFanwei;
    @Column
    @Comment("飞升前的法攻")
    private String fagongFanwei;
    @Column
    @Comment("飞升后的气血")
    private String qixueFanwei1;
    @Column
    @Comment("飞升后的法力")
    private String faliFanwei1;
    @Column
    @Comment("飞升后的速度")
    private String suduFanwei1;
    @Column
    @Comment("飞升后的物攻")
    private String wugongFanwei1;
    @Column
    @Comment("飞升后的法攻")
    private String fagongFanwei1;
    @Column
    @Comment("是否是坐骑或者宠物")
    private byte type;//
    @Column
    @Comment("阶位")
    private short jiewei;//
    @Column
    @Comment("等级")
    private short level;
    @Column
    @Comment("气血")
    private int life;
    @Column
    @Comment("法力")
    private int mana;
    @Column
    @Comment("攻击")
    private int power;
    @Column
    @Comment("防御")
    private int def;
    @Column
    @Comment("速度")
    private int speed;
    @Column
    @Comment("道行")
    private int tao;
    @Column
    @Comment("经验")
    private int exp;
    @Column
    @Comment("携带等级")
    private short req_level;
    @Column
    @Comment("地图id")
    private int mapId;
    @Column
    @Comment("种类 神兽4 变异3 普通2")
    private byte type1;// 种类 神兽4 变异3 普通2
    @Column
    @Comment("坐骑增加人物属性")
    @ColDefine(width = 1024)
    private NutMap mountFields;
    @Column
    @Comment("坐骑概率")
    private int persent;
    @Column
    @Comment("坐骑概率1")
    private int persent1;
    @Column
    @Comment("技能ID列表")
    private ArrayList<Integer> skillIds;

    public int getPersent() {
        return persent;
    }

    public void setPersent(int persent) {
        this.persent = persent;
    }

    public ArrayList<Integer> getSkillIds() {
        return skillIds;
    }

    public void setSkillIds(ArrayList<Integer> skillIds) {
        this.skillIds = skillIds;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public short getPolar() {
        return polar;
    }

    public void setPolar(short polar) {
        this.polar = polar;
    }

    public short getIcon() {
        return icon;
    }

    public void setIcon(short icon) {
        this.icon = icon;
    }

    public String getQixueFanwei() {
        return qixueFanwei;
    }

    public void setQixueFanwei(String qixueFanwei) {
        this.qixueFanwei = qixueFanwei;
    }

    public String getFaliFanwei() {
        return faliFanwei;
    }

    public void setFaliFanwei(String faliFanwei) {
        this.faliFanwei = faliFanwei;
    }

    public String getSuduFanwei() {
        return suduFanwei;
    }

    public void setSuduFanwei(String suduFanwei) {
        this.suduFanwei = suduFanwei;
    }

    public String getWugongFanwei() {
        return wugongFanwei;
    }

    public void setWugongFanwei(String wugongFanwei) {
        this.wugongFanwei = wugongFanwei;
    }

    public String getFagongFanwei() {
        return fagongFanwei;
    }

    public void setFagongFanwei(String fagongFanwei) {
        this.fagongFanwei = fagongFanwei;
    }

    public String getQixueFanwei1() {
        return qixueFanwei1;
    }

    public void setQixueFanwei1(String qixueFanwei1) {
        this.qixueFanwei1 = qixueFanwei1;
    }

    public String getFaliFanwei1() {
        return faliFanwei1;
    }

    public void setFaliFanwei1(String faliFanwei1) {
        this.faliFanwei1 = faliFanwei1;
    }

    public String getSuduFanwei1() {
        return suduFanwei1;
    }

    public void setSuduFanwei1(String suduFanwei1) {
        this.suduFanwei1 = suduFanwei1;
    }

    public String getWugongFanwei1() {
        return wugongFanwei1;
    }

    public NutMap getMountFields() {
        return mountFields;
    }

    public void setMountFields(NutMap mountFields) {
        this.mountFields = mountFields;
    }

    public int getPersent1() {
        return persent1;
    }

    public void setPersent1(int persent1) {
        this.persent1 = persent1;
    }

    public void setWugongFanwei1(String wugongFanwei1) {
        this.wugongFanwei1 = wugongFanwei1;
    }

    public String getFagongFanwei1() {
        return fagongFanwei1;
    }

    public void setFagongFanwei1(String fagongFanwei1) {
        this.fagongFanwei1 = fagongFanwei1;
    }

    public byte getType() {
        return type;
    }

    public void setType(byte type) {
        this.type = type;
    }

    public short getJiewei() {
        return jiewei;
    }

    public void setJiewei(short jiewei) {
        this.jiewei = jiewei;
    }

    public short getLevel() {
        return level;
    }

    public void setLevel(short level) {
        this.level = level;
    }

    public int getLife() {
        return life;
    }

    public void setLife(int life) {
        this.life = life;
    }

    public int getMana() {
        return mana;
    }

    public void setMana(int mana) {
        this.mana = mana;
    }

    public int getPower() {
        return power;
    }

    public void setPower(int power) {
        this.power = power;
    }

    public int getDef() {
        return def;
    }

    public void setDef(int def) {
        this.def = def;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public int getTao() {
        return tao;
    }

    public void setTao(int tao) {
        this.tao = tao;
    }

    public int getExp() {
        return exp;
    }

    public void setExp(int exp) {
        this.exp = exp;
    }

    public short getReq_level() {
        return req_level;
    }

    public void setReq_level(short req_level) {
        this.req_level = req_level;
    }

    public int getMapId() {
        return mapId;
    }

    public void setMapId(int mapId) {
        this.mapId = mapId;
    }

    public byte getType1() {
        return type1;
    }

    public void setType1(byte type1) {
        this.type1 = type1;
    }
    
    public List<FiedValue> getMonsterFieldValue() {
		ArrayList<FiedValue> arrayList1 = new ArrayList<>();
		{
			FiedValue fiedValue = new FiedValue();
			fiedValue.setType((short) 1);
			fiedValue.setVT((byte) 4);
			fiedValue.setValue(getName());
			arrayList1.add(fiedValue);
		}
		{
			FiedValue fiedValue = new FiedValue();
			fiedValue.setType((short) 40);
			fiedValue.setVT((byte) 7);
			fiedValue.setValue(getIcon());
			arrayList1.add(fiedValue);
		}
		{
			FiedValue fiedValue = new FiedValue();
			fiedValue.setType((short) 41);
			fiedValue.setVT((byte) 7);
			fiedValue.setValue((short) 2);
			arrayList1.add(fiedValue);
		}
		{
			FiedValue fiedValue = new FiedValue();
			fiedValue.setType((short) 204);// 宠物主人ID
			fiedValue.setVT((byte) 3);
			fiedValue.setValue((int) 0);
			arrayList1.add(fiedValue);
		}
		{
			FiedValue fiedValue = new FiedValue();
			fiedValue.setType((short) 341);
			fiedValue.setVT((byte) 1);
			fiedValue.setValue((byte) 0);
			arrayList1.add(fiedValue);
		}
		{
			FiedValue fiedValue = new FiedValue();
			fiedValue.setType((short) 340);
			fiedValue.setVT((byte) 1);
			fiedValue.setValue((byte) 0);
			arrayList1.add(fiedValue);
		}
		return arrayList1;
	}
}
