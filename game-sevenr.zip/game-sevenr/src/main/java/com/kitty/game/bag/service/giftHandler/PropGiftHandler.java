package com.kitty.game.bag.service.giftHandler;

import com.kitty.game.bag.model.GiftBagData;
import com.kitty.game.role.model.Role;
import org.springframework.stereotype.Component;

/**
 * 开启礼包得到道具奖励
 */
@Component
public class PropGiftHandler extends GiftHandler {

    @Override
    public void getReward(Role role, GiftBagData giftBagData) {

    }
}
