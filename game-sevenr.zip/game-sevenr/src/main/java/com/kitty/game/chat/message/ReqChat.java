package com.kitty.game.chat.message;


import com.kitty.game.chat.message.vo.ChatInfo;
import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.annotation.StringField;
import com.kitty.mina.message.Message;

import java.util.List;

/**
 * 聊天
 */
@MessageMeta(module = Modules.CMD_CHAT_EX)
public class ReqChat extends Message {
    private short type;
    private short compress;
    private short orgLength;
    @StringField(value = 1)
    private String msg;
    private List<ChatInfo> list;
    private int voiceTime;
    @StringField(value = 1)
    private String token;
    private String para;

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public short getCompress() {
        return compress;
    }

    public void setCompress(short compress) {
        this.compress = compress;
    }

    public short getOrgLength() {
        return orgLength;
    }

    public void setOrgLength(short orgLength) {
        this.orgLength = orgLength;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public List<ChatInfo> getList() {
        return list;
    }

    public void setList(List<ChatInfo> list) {
        this.list = list;
    }

    public int getVoiceTime() {
        return voiceTime;
    }

    public void setVoiceTime(int voiceTime) {
        this.voiceTime = voiceTime;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getPara() {
        return para;
    }

    public void setPara(String para) {
        this.para = para;
    }
}
