package com.kitty.game.confirm.service.handler;

import com.kitty.game.role.model.Role;
import com.kitty.game.config.GameMap;
import com.kitty.common.spring.SpringUtils;
import com.kitty.game.confirm.model.FightSealBossConfirm;
import com.kitty.game.npc.message.RespAutoWalk;
import com.kitty.game.task.service.taskHandler.DigTreasureTaskHandler;
import com.kitty.game.team.message.ReqConfirmResult;
import com.kitty.game.utils.Const;
import com.kitty.mina.message.MessagePusher;
import org.springframework.stereotype.Component;
import com.kitty.game.confirm.service.handler.ConfirmHandler;

import java.text.MessageFormat;

@Component
public class FightSealBossConfirmHandler extends ConfirmHandler {
    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
        if ("1".equals(reqConfirmResult.getSelect())) {
            /**自动寻路到*/
            FightSealBossConfirm confirm = (FightSealBossConfirm)role.getConfirm();
            GameMap map = SpringUtils.getMapService().getMap(confirm.getFightMapId());
            RespAutoWalk respAutoWalk = new RespAutoWalk();
            respAutoWalk.setTaskName("");
            respAutoWalk.setDest(MessageFormat.format("#Z{0}#Z", map.getName()));
            MessagePusher.pushMessage(role, respAutoWalk);
        } else if ("0".equals(reqConfirmResult.getSelect())) {
            SpringUtils.getBean(DigTreasureTaskHandler.class).checkContinueUseTreasureMapItem(role, Const.DIG_TREASURE_TYPE_SUPER);
        }
    }
}
