package com.kitty.game.confirm.model;

import lombok.Getter;
//后加
import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

@Getter
public class AvoidMonsterConfirm extends RoleConfirm {
    /**是否开启*/
    private boolean open;

    public AvoidMonsterConfirm(boolean open) {
        this.open = open;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.AVOID_MONSTER;
    }
}
