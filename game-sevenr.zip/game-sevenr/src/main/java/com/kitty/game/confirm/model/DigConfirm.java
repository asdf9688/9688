package com.kitty.game.confirm.model;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

public class DigConfirm extends RoleConfirm {
    private int fightMapId;

    public DigConfirm(int fightMapId) {
        this.fightMapId = fightMapId;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.wabao_confirm;
    }

    public int getFightMapId() {
        return fightMapId;
    }
}
