//package com.kitty.game.activity.service.other;
//
//import com.kitty.common.spring.SpringUtils;
//import com.kitty.core.SchedulerManager;
//import com.kitty.game.activity.service.time.FightActivityHandler;
//import com.kitty.game.boss.config.BossSet;
//import com.kitty.game.boss.model.BossFightParam;
//import com.kitty.game.boss.model.BossParam;
//import com.kitty.game.boss.service.NewBossService;
//import com.kitty.game.chat.service.ChatService;
//import com.kitty.game.config.NPC;
//import com.kitty.game.enter.Position;
//import com.kitty.game.equip.message.RespNotifyMiscEx;
//import com.kitty.game.fight.bean.Fight;
//import com.kitty.game.mail.model.Mail;
//import com.kitty.game.npc.model.NpcButton;
//import com.kitty.game.pet.PetDataPool;
//import com.kitty.game.pet.PetType;
//import com.kitty.game.pet.bean.PetObject;
//import com.kitty.game.pet.model.Pet;
//import com.kitty.game.pet.service.PetService;
//import com.kitty.game.role.model.Role;
//import com.kitty.game.role.service.RoleService;
//import com.kitty.game.team.message.RespMsg;
//import com.kitty.game.team.model.Team;
//import com.kitty.game.utils.Const;
//import com.kitty.game.utils.TimeUtil;
//import com.kitty.listener.event.FightEndEvent;
//import com.kitty.mina.cache.DataCache;
//import com.kitty.mina.message.MessagePusher;
//import com.kitty.web.admin.common.Result;
//import org.nutz.lang.util.NutMap;
//import org.springframework.stereotype.Component;
//
//import java.text.MessageFormat;
//import java.util.*;
//import java.util.concurrent.ThreadLocalRandom;
//
//
///**
// * 精灵处理类
// */
//@Component
//public class UpLevelJlHandler extends FightActivityHandler {
//    /**
//     * 升级幻境
//     */
//    private static final List<Integer> MAPIDS = Arrays.asList(37126);
//
//    private static final String [] petArr=new String[]{"花木兰","赵子龙"};
//
//    /**
//     * 每个地图显示的海盗数量
//     */
//    private static final int PIRATE_COUNT_PER_MAP = 50;  //刷新数量
//    private static final String PIRATE_NAME = "精灵";
//    private static final int PIRATE_ICON = 6288;
//    private static final int ACCEPT_MIN_LEVEL = 60;
//    /**
//     * 精灵入侵持续时间，单位毫秒
//     */
//    private static final long PIRATE_CONTINUED_TIME = 15 * TimeUtil.ONE_MINUTE;
//    /**
//     * 最少组队人数
//     */
//    private static final int MIN_TEAM_COUNT = 1;
//    private static final String KILL_MESSAGE = "刚刚有#R1#n名#Y海盗#n被我们的英雄消灭了！真是了不起啊！尚有#R{0}#n名#Y海盗#n仍在#Z东海渔村#Z和#Z无名小镇#Z作乱，请众位英雄继续加油啊！";
//    private static final String PIRATE_COME_NUMOR = "传闻有一批#Y精灵#n入侵，现已登陆#Z升级幻境#Z。请能为之士速速前去杀退精灵！";
//    private static final String PIRATE_ALL_KILL_NUMOR = "入侵的精灵已全部被消灭！看来中洲大陆真是能人辈出啊！";
//    private static final String CONTENT = "来呀 打我呀 看你不顺眼！[我要经验/" + NpcButton.Fight_the_elves.getKey() + "][糟了！遇到精灵了，赶紧逃命/逃命]";
//    private static final String IN_FIGHT = "瞅什么瞅！没见过帅哥吗！[离开]";
//    private static final String TEAM_COUNT_NOT_ENOUGH = "先组队才能打[离开]";
//    private static final String TEAM_LEVEL_NOT_ENOUGH = "看你们这么嫩，想来也是个雏，你们还是躲一边玩去吧！（队伍中#Y{0}#n的等级不足{1}级，能力不足以除害）[离开]";
//    private static final String SPECAIL_REWARD_MESSAGE = "听闻#Y{0}#n在铲除精灵时,获得了#Z{1}#Z,请能为之士速速前去杀退精灵。！";
//    private static final String REWARD_MESSAGE = "你获得了一{0}#R{1}#n。";
//
//    /**
//     * 刷新经验精灵，显示在对应的地图上
//     */
////    public void flushPirate() {
////        /**先让之前刷新的经验精灵消失*/
////        hidePirate();
////
////        /**遍历刷新经验精灵*/
////        for (int mapId : MAPIDS) {
////            for (int i = 0; i < PIRATE_COUNT_PER_MAP; i++) {
////                createPirate(mapId);
////            }
////        }
////
////        /**发谣言*/
////        SpringUtils.getBean(ChatService.class).sendNumor(PIRATE_COME_NUMOR, Const.BRODCAST_MSG_TYPE_ROLE);
////
////        /**增加定时任务，持续时间结束后删除*/
////        SchedulerManager.getInstance().schedule(() -> hidePirate(), PIRATE_CONTINUED_TIME);
////    }
//
//
//    /**
//     * 在地图上刷新一个经验精灵
//     */
//    private void createPirate(int mapId) {
//        Position position = getRandomPosition(mapId);
//
//        NPC npc = new NPC();
//        npc.setIcon(PIRATE_ICON);
//
//        npc.setId(SpringUtils.getBean(NewBossService.class).getTempNpcId());
//        npc.setX(position.getX());
//        npc.setY(position.getY());
//        npc.setFangxiang((short) new Random().nextInt(8));/**随机方向*/
//        npc.setMapId(mapId);
//        npc.setCreateTime(System.currentTimeMillis());
//        npc.setEndTime(npc.getCreateTime() + PIRATE_CONTINUED_TIME);
//        npc.setType(NPC.TYPE_jingling);//npc类型
//        npc.setContent(CONTENT);
//        npc.setName(PIRATE_NAME);
//        npc.setBossSetName(PIRATE_NAME);
//        bossService.broadcastNpcShow(null, npc);
//
//        DataCache.PIRATE_NPCS.put(npc.getId(), npc);
//
//        Set<Integer> set = DataCache.PIRATE_MAP_NPC.get(mapId);
//        if (set == null) {
//            set = new HashSet<>();
//            DataCache.PIRATE_MAP_NPC.put(mapId, set);
//        }
//        DataCache.PIRATE_MAP_NPC.get(mapId).add(npc.getId());
//    }
//
//    /**
//     * 使所有经验精灵在对应地图上消失
//     */
////    public void hidePirate() {
////        logger.warn("升级幻境结束");
////        if (DataCache.PIRATE_NPCS.size() > 0) {
////            List<NPC> list = new ArrayList<>(DataCache.PIRATE_NPCS.values());
////            for (NPC npc : list) {
////                if (npc.isInFight()) {
////                    /**在战斗中隐藏*/
////                    bossService.broadcastNpcHide(null, npc);
////                } else {
////                    clearPirate(npc);
////                }
////            }
////        }
////    }
//
//    /**
//     * 移除经验精灵
//     */
//    private void clearPirate(NPC npc) {
//        if (npc == null) {
//            return;
//        }
//
//        DataCache.PIRATE_NPCS.remove(npc.getId());
//        Set<Integer> set1 = DataCache.PIRATE_MAP_NPC.get(npc.getMapId());
//        if (set1 != null) {
//            set1.remove(npc.getId());
//        }
//        removeUsedPosition(npc.getMapId(), npc.getX(), npc.getY());
//
//        bossService.broadcastNpcHide(null, npc);
//    }
//
//    @Override
//    protected String getNpcContent(Role role, NPC bossNpc) {
//        return null;
//    }
//
//    @Override
//    public String getNpcContentNotFight(Role role, NPC bossNpc) {
//        /**检测是否在战斗中*/
//        if (bossNpc.isInFight()) {
//            return IN_FIGHT;
//        }
//
//        /**检测队伍人数*/
//        int teamCount = teamService.getTeamCount(role);
//        if (teamCount < MIN_TEAM_COUNT) {
//            return TEAM_COUNT_NOT_ENOUGH;
//        }
//
//        /**检测等级*/
//        Team team = teamService.getTeam(role.getRoleId());
//        String names = teamService.checkMember(team, memberRole -> memberRole.getLevel() < ACCEPT_MIN_LEVEL);
//        if (names != null) {
//            return MessageFormat.format(TEAM_LEVEL_NOT_ENOUGH, names, ACCEPT_MIN_LEVEL);
//        }
//
//        return null;
//    }
//
//    @Override
//    public void doStartFight(Role role, NPC bossNpc) {
//        List<BossParam> bossParamList = newBossParamList(role, bossNpc);
//        BossFightParam bossFightParam = new BossFightParam(bossParamList, getFightType(role));
//        bossFightParam.setNpcId(bossNpc.getId());
//        Fight fight = bossService.startFightToBoss(role, bossFightParam);
//
//    }
//
//    @Override
//    protected int getFightType(Role role) {
//        return Const.fightType_elves;
//    }
//
//    @Override
//    protected NPC getBossNpc(int npcId) {
//        return DataCache.PIRATE_NPCS.get(npcId);
//    }
//
//    @Override
//    protected void clearNpcAfterWin(Role role, NPC bossNpc) {
//        clearPirateAfterFightWin(bossNpc);
//    }
//
//    private List<BossParam> newBossParamList(Role role, NPC bossNpc) {
//        List<BossParam> bossParamList = new ArrayList<>();
//        int count = getBossCount(role);
//
//        /**npc对应的加在第1个*/
//        BossSet bossSet = bossService.getBossSet(bossNpc.getBossSetName());
//        bossParamList.add(new BossParam(bossSet, bossNpc.getName()));
//
//        /**加count-1个*/
//        for (int i = 1; i < count; i++) {
//            bossSet = bossService.getBossSet(bossNpc.getBossSetName());
//            bossParamList.add(new BossParam(bossSet, bossSet.getName()));
//        }
//
//        return bossParamList;
//    }
//
//    @Override
//    public int getBossCount(Role role) {
//        /**最多有10个*/
//        int allCount = 10;
//        int teamCount = teamService.getTeamCount(role);
//
//        /**根据组队数量计算怪的数量*/
//        int count = 0;
//        if (teamCount <= 3) {
//            int minCount = 6;
//            count = ThreadLocalRandom.current().nextInt(allCount - minCount + 1) + minCount;
//        } else if (teamCount == 4) {
//            int minCount = 8;
//            count = ThreadLocalRandom.current().nextInt(allCount - minCount + 1) + (minCount);
//        } else {
//            count = allCount;
//        }
//        return count;
//    }
//
//    /**
//     * 在战斗胜利后移除经验精灵
//     */
//    private void clearPirateAfterFightWin(NPC npc) {
//        int oldPirateCount = DataCache.PIRATE_NPCS.size();
//        /**移除精灵操作*/
//        clearPirate(npc);
//        int newPirateCount = DataCache.PIRATE_NPCS.size();
//
//        if (newPirateCount != oldPirateCount) {
//            if (newPirateCount > 0) {
//                /**不是最后一个时，发的谣言*/
//                String msg = MessageFormat.format(KILL_MESSAGE, newPirateCount);
//                SpringUtils.getChatService().sendNumor(msg, Const.BRODCAST_MSG_TYPE_ROLE);
//            } else {
//                /**杀死最后一个时，发的谣言*/
//                if (oldPirateCount == 1 && newPirateCount == 0) {
//                    SpringUtils.getChatService().sendNumor(PIRATE_ALL_KILL_NUMOR, Const.BRODCAST_MSG_TYPE_ROLE);
//                }
//            }
//        }
//    }
//
//    /**
//     * 给奖励
//     */
//    public void giveReward(Role role, FightEndEvent fightEndEvent, NPC bossNpc) {
//        NutMap reward = fightEndEvent.getReward();
//        /**经验金钱奖励*/
//        int exp = role.getLevel() * reward.getInt("rewardExp", 0);
//        int pot = role.getLevel() * reward.getInt("rewardQianneng",0);
//        int money = reward.getInt("rewardMoney", 0);
//
//        RoleService roleService = SpringUtils.getRoleService();
//        roleService.addMoney(role, money);
//        roleService.addPot(role,pot);
//
//        int currPetId = role.getTempCache("fight_current_pet_id", 0);
//        NutMap nutMap = role.getPropsStatus();
//        int point = nutMap.getInt("role");
//        if (nutMap.getInt("roleStatus") == 1 && point >= 4) {
//            nutMap.setv("role", point - 4);
//            role.save();
//            roleService.addExp(role, exp * 2, role.getLevel(), currPetId);//除暴 怪物按照20级算
//        } else {
//            roleService.addExp(role, exp, role.getLevel(), currPetId);//除暴 怪物按照20级算
//        }
//        int randomInt=new Random().nextInt(200);
//
//        if(randomInt<=1){
//            PetObject petObject = PetDataPool.getPetObject(petArr[randomInt]);
//            Mail mail = SpringUtils.getMailService().createMail("获得宠物", "获得宠物", 1 * TimeUtil.ONE_DAY);
//            ArrayList<NutMap> maps = new ArrayList<>();
//            maps.add(new NutMap().setv("data", "#I宠物|"+petArr[randomInt]+"(神兽)#r1#I").setv("type", Const.mailPet).setv("petName", petArr[randomInt]).setv("value",1));
//            mail.getDatas().addAll(maps);
//            SpringUtils.getMailService().sendNewMail(role,mail);
//        }
//        roleService.addRechargeScore(role, 5);
//
//    }
//
//    @Override
//    protected void clearNpcTimeOut(NPC npc) {
//        clearPirate(npc);
//    }
//
//
//
//
//
//}