package com.kitty.game.activity.service.other;

import com.kitty.game.role.model.Role;
import com.kitty.game.drop.service.DropService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**天降宝盒处理类*/
@Component
public class TianJiangBaoHeHandler {
    @Autowired
    DropService dropService;

    /**宝盒对应的掉落组*/
    private int boxDropGroup;
    private static final String dropName = "天降宝盒";

    /**从传入map中获得对应数据*/
    public void loadCommonSet(Map<String ,String> commonSetMap) {
        String dropGroup = commonSetMap.get("tianjiangbaohe_drop_group");
        int group = Integer.parseInt(dropGroup.trim());
        boxDropGroup = group;
    }

    /**掉落宝盒*/
    public void dropBox(Role role) {
        dropService.drop(role, boxDropGroup, dropName);
    }
}
