package com.kitty.game.activity.model.user;

import com.kitty.common.model.Pos;
import lombok.Getter;
import lombok.Setter;
import org.nutz.lang.util.NutMap;

import java.util.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;


/**
 * 角色活动
 */
@Getter
@Setter
public class RoleActivity {
    /**
     * 活动已经完成次数
     */
    private NutMap finishCounts = new NutMap();

    /**
     * 正在进行刷道每轮时间
     */
    private Map<String, LinkedList<Integer>> shuaDaoUsedTime = new HashMap<>(3);
    /**
     * 最近十轮刷道耗时(单位秒)
     */
    private Map<String, Integer> tenShuaDaoUsedTime = new HashMap<>();
    /**
     * 刷道积分
     */
    private int shuaDaoScore = 0;
    /**
     * 怪物数量，理论上应该从战斗中获取的，但貌似战斗战斗时会清数据，接口传进来有点麻烦
     */
    private transient int monsterCount;
    /**
     * 刷道积分奖励领取状态, key: 积分, 领取状态
     */
    private Map<Integer, Boolean> shuaDaoFetchStatus = new HashMap<>();

    /**
     * 通天塔数据
     */
    private RoleTowerData roleTowerData = new RoleTowerData();

    /**
     * 玩家活跃度
     */
    private float liveness;

    /**
     * 活跃度奖励领取状态
     */
    private Map<Integer, Boolean> livenessRewardFetchStatus = new HashMap<>();

    /**
     * 挖宝的类型(分普通藏宝图和超级藏宝图的挖宝)
     */
    private byte digTreasureType;
    /**
     * 挖宝的目标位置
     */
    private Pos digTreasurePosition;

    /**
     * 七日登录奖励领取奖励
     */
    private Map<Byte, Boolean> servenDayRewardStatus = new HashMap<>();

    /**
     * 砸蛋
     */
    private Map<Byte, String> zadan = new HashMap<>();

    /**
     * 首日充值奖励
     */
    private NutMap chargeActivity = new NutMap();

    /**
     * 充值积分
     */
    private int rechargeScore;
    /**
     * 累计充值积分
     */
    private short totalRechargeScore;

    /**
     * 购买新服助力礼包的次数
     */
    private int buyNewHelpGiftCount;

    /**
     * 副本奖励标识，true为有奖励领取
     */
    private boolean dugeonReward;

    /**
     * 剩余挑战神魔活动时间
     */
    private int remainDevilTime;
    private Map<Integer, Integer> devilKillCounts = new HashMap<>(5);
    private int meiriLevel = 0;

    /**
     * 每日一次充值30得3倍，凌晨清除
     */
    private boolean charge30 = true;

    private boolean chenghao38 = false;
    private boolean chenghao222 = false;
    private boolean chenghao288 = false;
    private boolean chenghao322 = false;
    private boolean chenghao333 = false;
    private boolean chenghao344 = false;
    private boolean chenghao355 = false;
    private boolean chenghao388 = false;
    private boolean chenghao399 = false;
    private boolean chenghao444 = false;
    private boolean chenghao455 = false;
    private boolean chenghao466 = false;
    private boolean chenghao588 = false;
    private boolean chenghao599 = false;
    private boolean chenghao866 = false;
    private boolean chenghao877 = false;
    private boolean chenghao888 = false;
    private boolean chenghao1111 = false;
    private boolean chenghao1222 = false;
    private boolean chenghao1333 = false;





    private boolean activity38 = false;
    private boolean activity222 = false;
    private boolean activity288 = false;
    private boolean activity322 = false;
    private boolean activity333 = false;
    private boolean activity344 = false;
    private boolean activity355 = false;
    private boolean activity388 = false;
    private boolean activity399 = false;
    private boolean activity444 = false;
    private boolean activity455 = false;
    private boolean activity466 = false;
    private boolean activity588 = false;
    private boolean activity599 = false;
    private boolean activity866 = false;
    private boolean activity877 = false;
    private boolean activity888 = false;
    private boolean activity1111 = false;
    private boolean activity1222 = false;
    private boolean activity1333 = false;


    /**
     * 每个玩家首次单笔充值98、198、328、648、1000、2000、3000、4000、5000得双倍倍元宝和积分
     */
    private List<Integer> chargeAppoints = new ArrayList<>();


    public void dailyReset() {
        finishCounts = NutMap.NEW();
        liveness = 0;
        livenessRewardFetchStatus = new HashMap<>();
        zadan = new HashMap<>();
        remainDevilTime = 0;
        devilKillCounts = new HashMap<>(5);
        charge30 = true;
    }

    //每日零点重置
//    public void daily0Reset() {
//    	charge30 = true ;
//    }
    //其他指定金额数据重置
    public void dailyChargeAppointsReset() {
        chargeAppoints = new ArrayList<>();
    }

    //后加
    public NutMap getChargeActivity() {
        return this.chargeActivity;
    }

    public int getRechargeScore() {
        return this.rechargeScore;
    }

    public short getTotalRechargeScore() {
        return this.totalRechargeScore;
    }

    public int getBuyNewHelpGiftCount() {
        return this.buyNewHelpGiftCount;
    }

    public boolean isDugeonReward() {
        return this.dugeonReward;
    }

    public int getRemainDevilTime() {
        return this.remainDevilTime;
    }

    public Map<Integer, Integer> getDevilKillCounts() {
        return this.devilKillCounts;
    }

    public int getMeiriLevel() {
        return this.meiriLevel;
    }

    public boolean isCharge30() {
        return this.charge30;
    }

    private boolean activity30 = false;

    public boolean isActivity38() {
        return this.activity38;
    }

    public boolean isActivity222() {
        return this.activity222;
    }

    public boolean isActivity288() {
        return this.activity288;
    }

    public boolean isActivity322() {
        return this.activity322;
    }

    public boolean isActivity333() {
        return this.activity333;
    }

    public boolean isActivity344() {
        return this.activity344;
    }

    public boolean isActivity355() {
        return this.activity355;
    }

    public boolean isActivity388() {
        return this.activity388;
    }

    public boolean isActivity399() {
        return this.activity399;
    }

    public boolean isActivity444() {
        return this.activity444;
    }

    public boolean isActivity455() {
        return this.activity455;
    }

    public boolean isActivity466() {
        return this.activity466;
    }

    public boolean isActivity588() {
        return this.activity588;
    }

    public boolean isActivity599() {
        return this.activity599;
    }

    public boolean isActivity866() {
        return this.activity866;
    }

    public boolean isActivity877() {
        return this.activity877;
    }

    public boolean isActivity888() {
        return this.activity888;
    }

    public boolean isActivity1111() {
        return this.activity1111;
    }

    public boolean isActivity1222() {
        return this.activity1222;
    }

    public boolean isActivity1333() {
        return this.activity1333;
    }








    public List<Integer> getChargeAppoints() {
        return this.chargeAppoints;
    }

    public Map<Integer, Boolean> getLivenessRewardFetchStatus() {
        return this.livenessRewardFetchStatus;
    }

    public byte getDigTreasureType() {
        return this.digTreasureType;
    }

    public Pos getDigTreasurePosition() {
        return this.digTreasurePosition;
    }

    public Map<Byte, Boolean> getServenDayRewardStatus() {
        return this.servenDayRewardStatus;
    }

    public Map<Byte, String> getZadan() {
        return this.zadan;
    }

    public RoleTowerData getRoleTowerData() {
        return this.roleTowerData;
    }

    public float getLiveness() {
        return this.liveness;
    }

    public Map<Integer, Boolean> getShuaDaoFetchStatus() {
        return this.shuaDaoFetchStatus;
    }

    public int getShuaDaoScore() {
        return this.shuaDaoScore;
    }

    public int getMonsterCount() {
        return this.monsterCount;
    }

    public NutMap getFinishCounts() {
        return this.finishCounts;
    }

    public Map<String, LinkedList<Integer>> getShuaDaoUsedTime() {
        return this.shuaDaoUsedTime;
    }

    public Map<String, Integer> getTenShuaDaoUsedTime() {
        return this.tenShuaDaoUsedTime;
    }

    public void setFinishCounts(NutMap finishCounts) {
        this.finishCounts = finishCounts;
    }

    public void setShuaDaoUsedTime(Map<String, LinkedList<Integer>> shuaDaoUsedTime) {
        this.shuaDaoUsedTime = shuaDaoUsedTime;
    }

    public void setTenShuaDaoUsedTime(Map<String, Integer> tenShuaDaoUsedTime) {
        this.tenShuaDaoUsedTime = tenShuaDaoUsedTime;
    }

    public void setShuaDaoScore(int shuaDaoScore) {
        this.shuaDaoScore = shuaDaoScore;
    }

    public void setMonsterCount(int monsterCount) {
        this.monsterCount = monsterCount;
    }

    public void setShuaDaoFetchStatus(Map<Integer, Boolean> shuaDaoFetchStatus) {
        this.shuaDaoFetchStatus = shuaDaoFetchStatus;
    }

    public void setRoleTowerData(RoleTowerData roleTowerData) {
        this.roleTowerData = roleTowerData;
    }

    public void setLiveness(float liveness) {
        this.liveness = liveness;
    }

    public void setLivenessRewardFetchStatus(Map<Integer, Boolean> livenessRewardFetchStatus) {
        this.livenessRewardFetchStatus = livenessRewardFetchStatus;
    }

    public void setDigTreasureType(byte digTreasureType) {
        this.digTreasureType = digTreasureType;
    }

    public void setDigTreasurePosition(Pos digTreasurePosition) {
        this.digTreasurePosition = digTreasurePosition;
    }

    public void setServenDayRewardStatus(Map<Byte, Boolean> servenDayRewardStatus) {
        this.servenDayRewardStatus = servenDayRewardStatus;
    }

    public void setZadan(Map<Byte, String> zadan) {
        this.zadan = zadan;
    }

    public void setChargeActivity(NutMap chargeActivity) {
        this.chargeActivity = chargeActivity;
    }

    public void setRechargeScore(int rechargeScore) {
        this.rechargeScore = rechargeScore;
    }

    public void setTotalRechargeScore(short totalRechargeScore) {
        this.totalRechargeScore = totalRechargeScore;
    }

    public void setBuyNewHelpGiftCount(int buyNewHelpGiftCount) {
        this.buyNewHelpGiftCount = buyNewHelpGiftCount;
    }

    public void setDugeonReward(boolean dugeonReward) {
        this.dugeonReward = dugeonReward;
    }

    public void setRemainDevilTime(int remainDevilTime) {
        this.remainDevilTime = remainDevilTime;
    }

    public void setDevilKillCounts(Map<Integer, Integer> devilKillCounts) {
        this.devilKillCounts = devilKillCounts;
    }

    public void setMeiriLevel(int meiriLevel) {
        this.meiriLevel = meiriLevel;
    }

    public void setCharge30(boolean charge30) {
        this.charge30 = charge30;
    }

    public void setActivity38(boolean activity38) {
        this.activity38 = activity38;
    }

    public void setActivity222(boolean activity222) {
        this.activity222 = activity222;
    }

    public void setActivity288(boolean activity288) {
        this.activity288 = activity288;
    }

    public void setActivity322(boolean activity322) {
        this.activity322 = activity322;
    }

    public void setActivity333(boolean activity333) {
        this.activity333 = activity333;
    }

    public void setActivity344(boolean activity344) {
        this.activity344 = activity344;
    }

    public void setActivity355(boolean activity355) {
        this.activity355 = activity355;
    }

    public void setActivity388(boolean activity366) {
        this.activity388 = activity388;
    }

    public void setActivity399(boolean activity399) {
        this.activity399 = activity399;
    }

    public void setActivity444(boolean activity444) {
        this.activity444 = activity444;
    }

    public void setActivity455(boolean activity455) {
        this.activity455 = activity455;
    }

    public void setActivity466(boolean activity466) {
        this.activity466 = activity466;
    }

    public void setActivity588(boolean activity588) {
        this.activity588 = activity588;
    }

    public void setActivity599(boolean activity599) {
        this.activity599 = activity599;
    }

    public void setActivity866(boolean activity866) {
        this.activity866 = activity866;
    }

    public void setActivity877(boolean activity877) {
        this.activity877 = activity877;
    }

    public void setActivity888(boolean activity888) {
        this.activity888 = activity888;
    }

    public void setActivity1111(boolean activity1111) {
        this.activity1111 = activity1111;
    }

    public void setActivity1222(boolean activity1222) {
        this.activity1222 = activity1222;
    }

    public void setActivity1333(boolean activity1333) {
        this.activity1333 = activity1333;
    }


    public void setChargeAppoints(List<Integer> chargeAppoints) {
        this.chargeAppoints = chargeAppoints;
    }
}

