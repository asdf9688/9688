package com.kitty.game.confirm.model;

import lombok.Getter;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

@Getter
public class CreatePartyConfirm extends RoleConfirm {
    /**帮派名称*/
    private String partyName;

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.CREATE_PARTY;
    }

    public CreatePartyConfirm(String partyName) {
        this.partyName = partyName;
    }
}
