package com.kitty.game.config;

import lombok.Getter;
import lombok.Setter;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Table;

@Setter
@Getter
@Table("p_shapepen")
public class ShapePen implements Cloneable{
    @Column
    private String name;
    @Column
    private short icon;
    @Column
    private String keyName;

    private int expireTime;

    public void setName(String name) {
        this.name = name;
    }

    public void setIcon(short icon) {
        this.icon = icon;
    }

    public void setKeyName(String keyName) {
        this.keyName = keyName;
    }

    public void setExpireTime(int expireTime) {
        this.expireTime = expireTime;
    }

    public String getName() {
        return this.name;
    }

    public short getIcon() {
        return this.icon;
    }

    public String getKeyName() {
        return this.keyName;
    }

    public int getExpireTime() {
        return this.expireTime;
    }

    @Override
    public ShapePen clone() {
        try {
            return (ShapePen) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }
}
