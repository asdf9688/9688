package com.kitty.game.confirm.model;

import java.util.Map;
import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

public class EnterShiDaoConfirm extends RoleConfirm {

    /**投票结果*/
    private Map<Integer, Short> ballotResults;

    public EnterShiDaoConfirm(Map<Integer, Short> ballotResults) {
        this.ballotResults = ballotResults;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.ENTER_SHIDAO_MAP;
    }

    public Map<Integer, Short> getBallotResults() {
        return ballotResults;
    }
}
