package com.kitty.game.drop.model.product;

import lombok.Getter;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

import java.util.Map;

@Table("p_dropset")
@Getter
public class DropSet {
    /**单独判断掉落机率, 一组可产生多个掉落*/
    public static final byte TYPE_SELF_MUTI = 1;
    /**组内判断掉落机率，一组一定且只会产生一个掉落*/
    public static final byte TYPE_GROUP = 2;


    /**掉落id*/
    @Id(auto = false)
    private int Id;
    /**掉落组*/
    @Column
    private int dropGroup;
    /**掉落类型*/
    @Column
    private byte type;
    /**掉落机率*/
    @Column
    private int odds;
    /**道具名称*/
    @Column
    private String itemName;
    /**道具参数*/
    @Column
    private Map extraParam;
    /**道具最少数量*/
    @Column
    private int minItemCount;
    /**道具最大数量*/
    @Column
    private int maxItemCount;
    /**乘以等级*/
    @Column
    private byte multiplyLevel;
    /**获得时的谣言内容*/
    @Column
    private String numor;
}
