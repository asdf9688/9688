package com.kitty.game.camp.service;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.camp.model.CampEnum;
import com.kitty.game.config.NPC;
import com.kitty.game.config.TaskSet;
import com.kitty.game.npc.model.NpcButton;
import com.kitty.game.role.model.Role;
import com.kitty.game.task.service.NewTaskService;
import com.kitty.game.task.service.taskHandler.ChengXianTaskHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class CampService {
    Logger logger = LoggerFactory.getLogger(CampService.class);


    public void init() {

    }

    public void popTaskTalk(Role role, NPC npc, String msg) {
        String orderStr = msg.replace(NpcButton.CAMP_SELECTION_PREFIX.getKey() + role.getChildInfo().getType() + "_", "");
        Integer taskId = CampEnum.getTaskId(orderStr);

        popTaskTalk(role, taskId);
    }

    public void popTaskTalk(Role role, int taskId) {
        TaskSet taskSet = SpringUtils.getBean(NewTaskService.class).getTaskSet(taskId, role);
        SpringUtils.getBean(ChengXianTaskHandler.class).acceptTask(role, taskSet);
    }
}
