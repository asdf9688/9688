package com.kitty.game.activity.model.product;

import lombok.Getter;
import lombok.Setter;

import java.util.Calendar;

/**
 * 试道大会配置
 */
@Setter
@Getter
public class ShiDaoSet {
    /**
     * 最小等级
     */
    private int minLevel = 60;

    public int getMinLevel() {
        return this.minLevel;
    }

    public void setMinLevel(int minLevel) {
        this.minLevel = minLevel;
    }

    /**
     * 最少组队人数
     */
    private int minTeamMemberCount = 3;

    public int getMinTeamMemberCount() {
        return this.minTeamMemberCount;
    }

    public void setMinTeamMemberCount(int minTeamMemberCount) {
        this.minTeamMemberCount = minTeamMemberCount;
    }

    /**
     * 总道是每周几
     */
    private int totalDayOfWeek = Calendar.SUNDAY;

    public int getTotalDayOfWeek() {
        return this.totalDayOfWeek;
    }

    public void setTotalDayOfWeek(int totalDayOfWeek) {
        this.totalDayOfWeek = totalDayOfWeek;
    }

    /**
     * 报名时间
     */

    private String signupTime = "20:50:00";

    public String getSignupTime() {
        return this.signupTime;
    }

    public void setSignupTime(String signupTime) {
        this.signupTime = signupTime;
    }

    /**
     * 开始时间
     */

    private String startTime = "21:00:00";

    public String getStartTime() {
        return this.startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    /**
     * 多少时间后杀元魔
     */
    private String monsterEndTime = "21:30:00";

    public String getMonsterEndTime() {
        return this.monsterEndTime;
    }

    public void setMonsterEndTime(String monsterEndTime) {
        this.monsterEndTime = monsterEndTime;
    }

    /**
     * 未知
     */
    private String endTime = "23:00:00";

    public String getEndTime() {
        return this.endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    /**
     * 每个等级段试道开启的最少队伍数量
     */
    private int minTeamCountShiDaoStart = 1;

    public int getMinTeamCountShiDaoStart() {
        return this.minTeamCountShiDaoStart;
    }

    public void setMinTeamCountShiDaoStart(int minTeamCountShiDaoStart) {
        this.minTeamCountShiDaoStart = minTeamCountShiDaoStart;
    }

    /**
     * 升到PK阶段的积分
     */
    private int minMonsterScorePK = 0;

    public int getMinMonsterScorePK() {
        return this.minMonsterScorePK;
    }

    public void setMinMonsterScorePK(int minMonsterScorePK) {
        this.minMonsterScorePK = minMonsterScorePK;
    }

    /**
     * 没打一次记多少分
     */
    private int scoreKillMonster = 1;

    public int getScoreKillMonster() {
        return this.scoreKillMonster;
    }

    public void setScoreKillMonster(int scoreKillMonster) {
        this.scoreKillMonster = scoreKillMonster;
    }

    /**
     * PK分数
     */
    private short scorePkWin = 10;

    public short getScorePkWin() {
        return this.scorePkWin;
    }

    public void setScorePkWin(short scorePkWin) {
        this.scorePkWin = scorePkWin;
    }
}
