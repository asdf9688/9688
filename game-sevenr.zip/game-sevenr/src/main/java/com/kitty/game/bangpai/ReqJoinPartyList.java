package com.kitty.game.bangpai;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

/**
 * 查看帮派申请列表
 */
@MessageMeta(module = Modules.CMD_PARTY_REQUEST_LIST)
public class ReqJoinPartyList extends Message {

}
