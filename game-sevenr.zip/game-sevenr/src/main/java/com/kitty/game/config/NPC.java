package com.kitty.game.config;

import com.kitty.game.pet.model.Pet;
import org.nutz.dao.entity.annotation.*;
import org.nutz.lang.util.NutMap;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Default;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;



@Table("p_npc")
public class NPC implements Cloneable{
    /**NPC类型，一直显示的那种NPC*/
    public static final byte TYPE_NORMAL = 1;
    /**NPC类型，任务触发显示*/
    public static final byte TYPE_TASK = 2;
    /**NPC类型 不同门派显示不同NPC任务*/
    public static final byte TYPE_TASK_SCHOOL = 3;
    /**NPC类型，除暴*/
    public static final byte TYPE_CHU_BAO = 4;
    /**NPC类型，采集的植物*/
    public static final byte TYPE_GATHER = 5;
    /**NPC类型，刷道*/
    public static final byte TYPE_SHUA_DAO = 6;
    /**NPC类型，星君*/
    public static final byte TYPE_XIN_JUN = 7;
    /**NPC类型，海盗*/
    public static final byte TYPE_PIRATE = 8;
    /**NPC类型，36天罡星、72地煞星 星官*/
    public static final byte TYPE_XING_GUAN = 9;
    /**NPC类型，悬赏*/
    public static final byte TYPE_XUAN_SHANG = 10;
    /**NPC类型，上古妖王*/
    public static final byte TYPE_SHANG_GU = 11;
    /**NPC类型，万年老妖*/
    public static final byte TYPE_WAN_NIAN = 12;
    /**NPC类型，掌门*/
    public static final byte TYPE_ZHANG_MEN = 13;
    /**NPC类型，英雄会的英雄*/
    public static final byte TYPE_YING_XIONG = 14;
    /**NPC类型，元魔*/
    public static final byte TYPE_YUANMO = 15;
    /**NPC类型，超级boss*/
    public static final byte TYPE_SUPER_BOSS = 16;
    /**NPC类型，战神*/
    public static final byte TYPE_ZHAN_SHEN = 17;
    /**NPC类型，九天真君*/
    public static final byte TYPE_JIU_TIAN = 18;
    /**NPC类型，七杀*/
    public static final byte TYPE_QISHA_TIAN = 19;
    /**幻境精灵*/
    public static final byte TYPE_jingling = 20;
    /**天界叛逆*/
    public static final byte TYPE_TIANJIANG_XIAFAN = 21;
    /**地府叛逆*/
    public static final byte TYPE_DIFU_XIAFAN = 22;
    /**异族入侵*/
    public static final byte TYPE_ALIEN_INTRUSION = 23;
    /**镇妖塔*/
    public static final byte TYPE_ALIEN_ZHENYAO = 24;
    /**桃柳林杀鬼*/
    public static final byte TYPE_TAOLIULIN_SHAGUI =25;
    /*变异星君*/
    public static final byte TYPE_BIANYI_XINJUN =26;
    /*烟花年兽*/
    public static final byte TYPE_BIANYI_YHNS =27;

    @Id
    private int id;
    @Column
    @Comment("npc名称")
    private String name;

    /**只实现浅克隆，暂时用于任务中生成新的NPC修改npc的名字和icon*/
    @Override
    public NPC clone() throws CloneNotSupportedException {
        return (NPC)super.clone();
    }

    /**NPC类型*/
    @Column
    @Default("1")
    @Comment("npc类型")
    private byte type;
    @Column
    private short x;
    @Column
    private short y;
    @Column
    private short fangxiang;
    @Column
    @Comment("地图id")
    private int mapId;
    @Column
    @Comment("对话")
    private String content;
    @Column
    @Comment("对话2")
    private String content1;
    @Column
    @Comment("外观")
    private int icon;
    @Column
    @Comment("物品")
    @Default("[]")
    private List<String> list;
    private int wuqiId;
    private int taozhuangId;
    private int faguangId;
    private NutMap status;
    private long createTime = System.currentTimeMillis();
    /**结束显示时间戳, -1为一直显示*/
    private long endTime = -1;
    private Lock lock = new ReentrantLock(true);
    private String tempName;
    private int level;
    private Xing xing;
    private long roleUid;

    private NutMap roleInfo;//挑战星君成功后玩家信息
    private Pet pet;
    /**是否是在战斗中*/
    private AtomicBoolean inFight = new AtomicBoolean();
    /**对应bossSet表的名字*/
    private String bossSetName;
    /**头衔*/
    private String title;
    /**相性*/
    private byte polar;
    /**用于区分见奖励*/
    private byte fujia_type;
    public NPC() {
        /**初始为空字符串，避免显示为null*/
        content = "";
    }

    public long getRoleUid() {
        return roleUid;
    }

    public void setRoleUid(long roleUid) {
        this.roleUid = roleUid;
    }

    public int getLevel() {
        return level;
    }

    public Xing getXing() {
        return xing;
    }

    public void setXing(Xing xing) {
        this.xing = xing;
    }

    public void setfujia_type(byte fujia_type) {
        this.fujia_type = fujia_type;
    }
    public byte getfujia_type() {
        return fujia_type;
    }



    public void setLevel(int level) {
        this.level = level;
    }

    public int getWuqiId() {
        return wuqiId;
    }

    public void setWuqiId(int wuqiId) {
        this.wuqiId = wuqiId;
    }

    public String getTempName() {
        return tempName;
    }

    public void setTempName(String tempName) {
        this.tempName = tempName;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public List<String> getList() {
        return list;
    }

    public void setList(List<String> list) {
        this.list = list;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public short getX() {
        return x;
    }

    public void setX(short x) {
        this.x = x;
    }

    public short getY() {
        return y;
    }

    public void setY(short y) {
        this.y = y;
    }

    public short getFangxiang() {
        return fangxiang;
    }

    public void setFangxiang(short fangxiang) {
        this.fangxiang = fangxiang;
    }

    public int getMapId() {
        return mapId;
    }

    public void setMapId(int mapId) {
        this.mapId = mapId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public String getContent1() {
        return content1;
    }

    public void setContent1(String content1) {
        this.content1 = content1;
    }

    public NutMap getRoleInfo() {
        return roleInfo;
    }

    public void setRoleInfo(NutMap roleInfo) {
        this.roleInfo = roleInfo;
    }

    public Pet getPet() {
        return pet;
    }

    public void setPet(Pet pet) {
        this.pet = pet;
    }

    public NutMap getStatus() {
        if (this.status == null){
            return NutMap.NEW();
        }
        return status;
    }

    public void setStatus(NutMap status) {
        this.status = status;
    }

    public Lock getLock() {
        return lock;
    }

    public void setLock(Lock lock) {
        this.lock = lock;
    }

    public int getTaozhuangId() {
        return taozhuangId;
    }

    public void setTaozhuangId(int taozhuangId) {
        this.taozhuangId = taozhuangId;
    }

    public int getFaguangId() {
        return faguangId;
    }

    public void setFaguangId(int faguangId) {
        this.faguangId = faguangId;
    }

    public byte getType() {
        return type;
    }

    public void setType(byte type) {
        this.type = type;
    }

    public long getEndTime() {
        return endTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    public boolean isInFight() {
        return inFight.get();
    }

    public void setInFight(boolean inFight) {
        this.inFight.set(inFight);
    }

    public AtomicBoolean getInFight() {
        return this.inFight;
    }

    public String getBossSetName() {
        return bossSetName;
    }

    public void setBossSetName(String bossSetName) {
        this.bossSetName = bossSetName;
    }

    /**是否显示*/
    public boolean isShow() {
        /**当前时间超过结束时间时不显示*/
        if (endTime > 0  && System.currentTimeMillis()> endTime) {
            return false;
        }

        return true;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public byte getPolar() {
        return polar;
    }

    public void setPolar(byte polar) {
        this.polar = polar;
    }

    /**是否匹配相性*/
    public boolean isMatchPolar(byte polar) {
        if (this.polar <= 0) {return true;}
        if (this.polar == polar) {return true;}

        return false;
    }
}
