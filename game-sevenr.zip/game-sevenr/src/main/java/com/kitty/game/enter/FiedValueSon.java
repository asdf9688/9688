package com.kitty.game.enter;


import com.kitty.mina.annotation.LongField;
import com.kitty.game.enter.FiedValue;

public class FiedValueSon extends FiedValue {
    private short type;
    private byte VT;
    @LongField(1)
    private long value1;

    public FiedValueSon(int fieldId, int type, long value) {
        this.type = (short) fieldId;
        this.VT = 3;
        this.value1 = value;
    }


    public FiedValueSon(int fieldId, long value) {
        this.type = (short) fieldId;
        this.VT = 3;
        this.value1 = value;
    }

    public FiedValueSon() {
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public byte getVT() {
        return VT;
    }

    public void setVT(byte VT) {
        this.VT = VT;
    }

    public long getValue1() {
        return value1;
    }

    public void setValue1(long value1) {
        this.value1 = value1;
    }
}
