package com.kitty.game.base.service;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.activity.service.other.*;
import com.kitty.game.activity.service.shidao.ShiDaoHandler;
import com.kitty.game.activity.service.task.ShuaDaoTaskHandler;
import com.kitty.game.market.MarketService;
import com.kitty.game.base.model.CommonSet;
import com.kitty.game.drop.service.DropService;
import com.kitty.game.equip.EquipDataPool;
import com.kitty.game.item.service.CangBaoXiangHandler;
import com.kitty.game.pet.PetDataPool;
import com.kitty.game.talk.service.TalkService;
import com.kitty.game.task.service.NewTaskService;
import com.kitty.game.attribute.AttrService;
import com.kitty.game.task.service.taskHandler.DugeonTaskHandler;
import com.kitty.game.welfare.service.FirstPayRewardHandler;
import com.kitty.game.welfare.service.RechargeScoreRewardHandler;
import com.kitty.game.welfare.service.ServenDayRewardHandler;
import com.kitty.game.role.service.PayService;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
//后写
import com.kitty.game.activity.service.other.MapGuardianHandler;
import com.kitty.game.activity.service.other.NewHelpActivityHandler;
import com.kitty.game.activity.service.other.TianJiangBaoHeHandler;
import com.kitty.game.activity.service.other.YingXiongHuiHandler;
import com.kitty.game.activity.service.other.ZhengDaoDianHandler;

@Service
public class CommonService {
    /**加载commonset表数据*/
    public void loadProduct() {
        Dao dao = SpringUtils.getBean(Dao.class);
        List<CommonSet> list = dao.query(CommonSet.class, Cnd.NEW());
        Map<String ,String> commonSetMap = new HashMap<>(list.size());
        for (CommonSet commonSet : list) {
            commonSetMap.put(commonSet.getSkey(), commonSet.getSvalue());
        }

        SpringUtils.getBean(NewTaskService.class).loadCommonSet(commonSetMap);
        SpringUtils.getBean(TalkService.class).loadCommonSet(commonSetMap);
        SpringUtils.getBean(YingXiongHuiHandler.class).loadCommonSet(commonSetMap);
        SpringUtils.getBean(ZhengDaoDianHandler.class).loadCommonSet(commonSetMap);
        SpringUtils.getBean(ShiDaoHandler.class).loadCommonSet(commonSetMap);
        SpringUtils.getBean(AttrService.class).loadCommonSet(commonSetMap);
        SpringUtils.getBean(MarketService.class).loadCommonSet(commonSetMap);

        EquipDataPool.loadCommonSet(commonSetMap);
        PetDataPool.loadCommonSet(commonSetMap);
        SpringUtils.getBean(ShuaDaoTaskHandler.class).loadCommonSet(commonSetMap);
        SpringUtils.getBean(DropService.class).loadCommonSet(commonSetMap);
        SpringUtils.getBean(TianJiangBaoHeHandler.class).loadCommonSet(commonSetMap);
        SpringUtils.getBean(CangBaoXiangHandler.class).loadCommonSet(commonSetMap);
        SpringUtils.getBean(ServenDayRewardHandler.class).loadCommonSet(commonSetMap);
        SpringUtils.getBean(PayService.class).loadCommonSet(commonSetMap);
        SpringUtils.getBean(FirstPayRewardHandler.class).loadCommonSet(commonSetMap);
        SpringUtils.getBean(RechargeScoreRewardHandler.class).loadCommonSet(commonSetMap);
        SpringUtils.getBean(NewHelpActivityHandler.class).loadCommonSet(commonSetMap);
        SpringUtils.getBean(DugeonTaskHandler.class).loadCommonSet(commonSetMap);
        SpringUtils.getBean(MapGuardianHandler.class).loadCommonSet(commonSetMap);
    }
}
