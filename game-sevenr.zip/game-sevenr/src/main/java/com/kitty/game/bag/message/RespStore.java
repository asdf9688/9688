package com.kitty.game.bag.message;


import com.kitty.game.bag.model.StoreEquipInfo;
import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

import java.util.List;


/**
 * 仓库物品
 */
@MessageMeta(module = Modules.MSG_STORE)
public class RespStore extends Message {
    private String str;// custom_store fasion_store effect_store normal_store
    private int npcId= 0;
    private List<StoreEquipInfo> list;//装备列表

    public List<StoreEquipInfo> getList() {
        return list;
    }

    public void setList(List<StoreEquipInfo> list) {
        this.list = list;
    }

    public String getStr() {
        return str;
    }

    public void setStr(String str) {
        this.str = str;
    }

    public int getNpcId() {
        return npcId;
    }

    public void setNpcId(int npcId) {
        this.npcId = npcId;
    }
}
