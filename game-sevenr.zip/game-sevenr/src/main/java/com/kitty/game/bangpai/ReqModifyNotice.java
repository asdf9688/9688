package com.kitty.game.bangpai;

import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.annotation.StringField;
import com.kitty.mina.message.Message;

@MessageMeta(module = Modules.CMD_PARTY_MODIFY_ANNOUNCE)
public class ReqModifyNotice extends Message {
    @StringField(value = 1)
    private String notice;

    public String getNotice() {
        return notice;
    }

    public void setNotice(String notice) {
        this.notice = notice;
    }
}
