package com.kitty.game.activity.model.product;

import lombok.Getter;
import lombok.Setter;

import java.util.Map;

/**刷道积分奖励配置*/
@Getter
@Setter
public class ShuaDaoRewardSet {
    /**需求积分*/
    private int score;
    /**奖励道具*/
    private Map<String, Integer> items;
    //后加
    public void setScore(int score) {
        this.score = score;
    }

    public void setItems(Map<String, Integer> items) {
        this.items = items;
    }

    public int getScore() {
        return this.score;
    }

    public Map<String, Integer> getItems() {
        return this.items;
    }
}
