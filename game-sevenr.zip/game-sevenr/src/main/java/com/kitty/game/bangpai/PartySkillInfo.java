package com.kitty.game.bangpai;

public class PartySkillInfo {
    private String skillName="如意圈";//技能名
    private short skillId;//技能ID
    private short skillLevel=0;//技能等级
    private int currJindu=0;//当前研发进度
    private int total=1000;//需要总研发进度

    public String getSkillName() {
        return skillName;
    }

    public void setSkillName(String skillName) {
        this.skillName = skillName;
    }

    public short getSkillLevel() {
        return skillLevel;
    }

    public void setSkillLevel(short skillLevel) {
        this.skillLevel = skillLevel;
    }

    public short getSkillId() {
        return skillId;
    }

    public void setSkillId(short skillId) {
        this.skillId = skillId;
    }

    public int getCurrJindu() {
        return currJindu;
    }

    public void setCurrJindu(int currJindu) {
        this.currJindu = currJindu;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
}
