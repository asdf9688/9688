package com.kitty.game.activity.service.boos.service;

import com.kitty.game.activity.model.product.SuperBoss;
import com.kitty.game.boss.config.BossSet;
import com.kitty.game.boss.model.SuperBossParam;
import com.kitty.game.boss.service.NewBossService;
import com.kitty.game.config.NPC;
import com.kitty.game.fight.ai.model.RoundSkillUnit;
import com.kitty.game.utils.Const;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

@Component
public class BoosService {

    @Autowired
    protected NewBossService bossService;

    /**
     * 各门派的攻击技能
     */
    private static final Map<Byte, Integer> POLAR_SKILLS = new HashMap<>();
    /**
     * 各门派的障碍技能
     */
    private static final Map<Byte, Integer> POLAR_HELP_SKILLS = new HashMap<>();

    private static final List<Byte> POLARS = Arrays.asList(Const.SCHOOL_METAL, Const.SCHOOL_WOOD, Const.SCHOOL_WATER, Const.SCHOOL_FIRE, Const.SCHOOL_EARTH);
    @PostConstruct
    private void init() {
        /**各门派的5阶攻击技能*/
        POLAR_SKILLS.put(Const.SCHOOL_METAL, 15);
        POLAR_SKILLS.put(Const.SCHOOL_WOOD, 65);
        POLAR_SKILLS.put(Const.SCHOOL_WATER, 114);
        POLAR_SKILLS.put(Const.SCHOOL_FIRE, 165);
        POLAR_SKILLS.put(Const.SCHOOL_EARTH, 214);

        /**各门派的5阶障碍技能*/
        POLAR_HELP_SKILLS.put(Const.SCHOOL_METAL, 25);
        POLAR_HELP_SKILLS.put(Const.SCHOOL_WOOD, 75);
        POLAR_HELP_SKILLS.put(Const.SCHOOL_WATER, 125);
        POLAR_HELP_SKILLS.put(Const.SCHOOL_FIRE, 175);
        POLAR_HELP_SKILLS.put(Const.SCHOOL_EARTH, 225);
    }

    public SuperBossParam newSuperBossParam(NPC bossNpc,SuperBoss superBoss) {
        BossSet bossSet = bossService.getBossSet(bossNpc.getName());
        SuperBossParam bossParam = new SuperBossParam(bossSet, bossNpc.getName());
        /**随机相性*/
        byte polar = getRandomPolar();
        bossParam.setPolar(polar);
        /**获得对应的技能*/
        ArrayList<Integer> skillIds = getSkillIdsMatchPolar(polar);
        bossParam.setSkillIds(skillIds);
        bossParam.setRoundSkills(getRoundSkills(polar, superBoss));

        /**对应的法宝*/
        bossParam.setArtifactMap(superBoss.getArtifactMap());


        return bossParam;
    }

    public List<RoundSkillUnit> getRoundSkills(byte polar, SuperBoss superBoss) {
        List<RoundSkillUnit> list = new ArrayList<>();
        list.add(new RoundSkillUnit(5, 5, superBoss.getSkillId()));
        Integer skillId = POLAR_HELP_SKILLS.get(polar);
        list.add(new RoundSkillUnit(6, 5, skillId));
        return list;
    }


    /**
     * 获得随机相性
     */
    public byte getRandomPolar() {
        int index = ThreadLocalRandom.current().nextInt(POLARS.size());
        return POLARS.get(index);
    }

    /**
     * 获得匹配相性的技能ID列表
     */
    public ArrayList<Integer> getSkillIdsMatchPolar(byte polar) {
        ArrayList<Integer> skilIds = new ArrayList<>();
        /**相性的技能*/
        Integer skill_id = POLAR_SKILLS.get(polar);
        skilIds.add(skill_id);
        /**力破千钧*/
        skilIds.add(501);
        /**普通攻击*/
        skilIds.add(2);
        return skilIds;
    }


}
