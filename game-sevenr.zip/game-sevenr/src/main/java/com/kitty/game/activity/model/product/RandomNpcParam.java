package com.kitty.game.activity.model.product;

/**随机生成的NPC的参数传递类*/
public class RandomNpcParam {
    /**对应bossset表的名字*/
    private String bossName;
    /**显示在地图上的NPC名字*/
    private String npcName;

    public String getBossName() {
        return bossName;
    }

    public void setBossName(String bossName) {
        this.bossName = bossName;
    }

    public String getNpcName() {
        return npcName;
    }

    public void setNpcName(String npcName) {
        this.npcName = npcName;
    }
}
