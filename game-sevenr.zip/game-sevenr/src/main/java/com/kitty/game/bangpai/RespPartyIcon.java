package com.kitty.game.bangpai;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

/**
 * 帮派图标的MD5  广播包
 */
@MessageMeta(module = Modules.MSG_PARTY_ICON)
public class RespPartyIcon extends Message {
    private int roleId = 1;
    private String md5_value;

    public int getRoleId() {
        return roleId;
    }

    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }

    public String getMd5_value() {
        return md5_value;
    }

    public void setMd5_value(String md5_value) {
        this.md5_value = md5_value;
    }
}
