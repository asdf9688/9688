package com.kitty.game.confirm.model;

import lombok.Getter;
import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

import java.util.Map;

@Getter
public class TowerTeamFlyUpConfirm extends RoleConfirm{
    /**消耗资源类型*/
    private byte flyUpType;
    /**飞升层数*/
    private int flyUpCount;
    /**投票结果*/
    private Map<Integer, Short> ballotResults;

    public TowerTeamFlyUpConfirm(byte flyUpType, int flyUpCount, Map<Integer, Short> ballotResults) {
        this.flyUpType = flyUpType;
        this.flyUpCount = flyUpCount;
        this.ballotResults = ballotResults;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.TOWER_TEAM_FLY_UP;
    }
}
