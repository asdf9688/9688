package com.kitty.game.bangpai;

public class PartyDeny {
   
    private String gid;
   
    private int endTime;

    public PartyDeny() {}

    public PartyDeny(String gid, int endTime) {
        this.gid = gid;
        this.endTime = endTime;
    }

    public String getGid() {
        return gid;
    }

    public void setGid(String gid) {
        this.gid = gid;
    }

    public int getEndTime() {
        return endTime;
    }

    public void setEndTime(int endTime) {
        this.endTime = endTime;
    }
}
