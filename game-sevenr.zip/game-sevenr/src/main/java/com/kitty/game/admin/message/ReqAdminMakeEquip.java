package com.kitty.game.admin.message;

import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;
import lombok.Getter;

/**
 * GM制作装备 需要判断权限
 */
@Getter
@MessageMeta(module = Modules.CMD_ADMIN_MAKE_EQUIPMENT)
public class ReqAdminMakeEquip extends Message {
    private String equipType;
    private short req_level;
    private byte rebuildLevel;
    private String blue;// 蓝属性类型及对应数值 以“:”分隔；不同属性以“|”分隔。
    private String pink;// 粉属性及对应数值
    private String yellow;// 粉属性及对应数值
    private String green;// 黄属性及对应数值
    private String black;// 套装明属性类型及对应数值，以“:”分隔
    private String gongming;// 共鸣属性
    

    public String getEquipType() {
        return equipType;
    }

    public void setEquipType(String equipType) {
        this.equipType = equipType;
    }

    public short getReq_level() {
        return req_level;
    }

    public void setReq_level(short req_level) {
        this.req_level = req_level;
    }

    public byte getRebuildLevel() {
        return rebuildLevel;
    }

    public void setRebuildLevel(byte rebuildLevel) {
        this.rebuildLevel = rebuildLevel;
    }

    public String getBlue() {
        return blue;
    }

    public void setBlue(String blue) {
        this.blue = blue;
    }

    public String getPink() {
        return pink;
    }

    public void setPink(String pink) {
        this.pink = pink;
    }

    public String getYellow() {
        return yellow;
    }

    public void setYellow(String yellow) {
        this.yellow = yellow;
    }

    public String getGreen() {
        return green;
    }

    public void setGreen(String green) {
        this.green = green;
    }

    public String getBlack() {
        return black;
    }

    public void setBlack(String black) {
        this.black = black;
    }

    public String getGongming() {
        return gongming;
    }

    public void setGongming(String gongming) {
        this.gongming = gongming;
    }
}
