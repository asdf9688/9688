package com.kitty.game.activity.service.seal;

import com.kitty.game.role.model.Role;
import com.kitty.game.config.NPC;
import com.kitty.game.npc.model.NpcButton;
import com.kitty.game.utils.Const;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
//后加
import com.kitty.game.activity.service.seal.SealBossHandler;

/**万年老妖处理类*/
@Component
public class WanNianBossHandler extends SealBossHandler {
    private final String npcName = "万年老妖";
    private final String bossName = "万年老妖";
    private final List<String> smallBossNames = Arrays.asList("上古妖王1","上古妖王2","上古妖王3","上古妖王4");
    private final String smallName = "小妖";
    private final String fightTag = NpcButton.FIGHT_TO_WANNIAN.getKey();
    private final int firstTalkId = 1227;

    @Override
    public String getOwnerNpcName() {
        return null;
    }

    @Override
    public String getNpcName() {
        return npcName;
    }

    @Override
    public String getBossName() {
        return bossName;
    }

    @Override
    public List<String> getSmallBossNames() {
        return smallBossNames;
    }

    @Override
    public String getSmallName() {
        return smallName;
    }

    @Override
    public String getFightTag() {
        return fightTag;
    }

    @Override
    public int getFirstTalkId() {
        return firstTalkId;
    }

    @Override
    public byte getNpcType() {
        return NPC.TYPE_WAN_NIAN;
    }

    @Override
    protected int getFightType(Role role) {
        return Const.fightType_wannian;
    }
}
