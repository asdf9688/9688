package com.kitty.game.activity.service.other;

import cn.hutool.setting.AbsSetting;
import com.kitty.common.spring.SpringUtils;
import com.kitty.game.activity.model.product.ActivityType;
import com.kitty.game.activity.model.user.DevilFirstHistory;
import com.kitty.game.activity.service.ActivityService;
import com.kitty.game.activity.service.time.FightActivityHandler;
import com.kitty.game.boss.config.BossSet;
import com.kitty.game.boss.model.BossFightParam;
import com.kitty.game.boss.model.BossParam;
import com.kitty.game.config.NPC;
import com.kitty.game.config.TaskSet;
import com.kitty.game.confirm.model.BuyDevilTimeConfirm;
import com.kitty.game.friend.model.RoleOfflineData;
import com.kitty.game.i18n.I18nId;
import com.kitty.game.i18n.I18nIdDataPool;
import com.kitty.game.map.model.GroupMapParam;
import com.kitty.game.npc.service.NewNpcService;
import com.kitty.game.pet.model.Pet;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.RoleService;
import com.kitty.game.task.message.vo.TaskInfo;
import com.kitty.game.task.service.NewTaskService;
import com.kitty.game.team.message.RespConfirm;
import com.kitty.game.team.message.RespMsg;
import com.kitty.game.utils.AsktaoUtil;
import com.kitty.game.utils.Const;
import com.kitty.game.utils.JsonUtils;
import com.kitty.game.utils.TimeUtil;
import com.kitty.listener.event.FightEndEvent;
import com.kitty.logs.Reason;
import com.kitty.mina.cache.DataCache;
import com.kitty.mina.message.MessagePusher;
import org.nutz.dao.Dao;
import org.nutz.lang.util.NutMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
//后加
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Component
public class DevilActivityHandler extends FightActivityHandler {
    @Autowired
    NewNpcService npcService;
    @Autowired
    ActivityService activityService;
    private static final int ENTER_MAPID = 40000;
    private static final int ENTER_X = 23;
    private static final int ENTER_Y = 25;

    private int buyNeedGold = 2000;
    private int buyNeedMoney = 20000000;
    private int buyMinute = 120;

    private int taskId = 126;
    private int minLevel = 50;

    private Map<String, List<String>> smallBossNames = new HashMap<>();
    private Map<String, String> smallNames = new HashMap<>();
    private List<Integer> devilNpcIds = Arrays.asList(1100, 1101, 1102, 1103, 1104);
    @PostConstruct
    public void init() {
        smallBossNames.put("一星天神", Arrays.asList("一星天兵侍卫1", "一星天兵侍卫2", "一星天兵侍卫3", "一星天兵侍卫4"));
        smallBossNames.put("二星天神", Arrays.asList("二星天兵侍卫1", "二星天兵侍卫2", "二星天兵侍卫3", "二星天兵侍卫4"));
        smallBossNames.put("三星天神", Arrays.asList("三星天兵侍卫1", "三星天兵侍卫2", "三星天兵侍卫3", "三星天兵侍卫4"));
        smallBossNames.put("四星天神", Arrays.asList("四星天兵侍卫1", "四星天兵侍卫2", "四星天兵侍卫3", "四星天兵侍卫4"));
        smallBossNames.put("五星天神", Arrays.asList("五星天兵侍卫1", "五星天兵侍卫2", "五星天兵侍卫3", "五星天兵侍卫4"));


        smallNames.put("一星天神", "一星天兵侍卫");
        smallNames.put("二星天神", "二星天兵侍卫");
        smallNames.put("三星天神", "三星天兵侍卫");
        smallNames.put("四星天神", "四星天兵侍卫");
        smallNames.put("五星天神", "五星天兵侍卫");
    }

    public void loadCommon() {
        /**初始为100*/
        for (int npcId : devilNpcIds) {
            DataCache.DEVIL_MAX_KILLS.put(npcId, 100);
        }
        Dao dao = SpringUtils.getBean(Dao.class);
        RoleOfflineData roleOfflineData = dao.fetch(RoleOfflineData.class, "devil_max_kills");
        if (roleOfflineData != null) {
            Map<Integer, Integer> killsMap = JsonUtils.string2Map(roleOfflineData.getData(), Integer.class, Integer.class);
            if (killsMap != null) {
                DataCache.DEVIL_MAX_KILLS.putAll(killsMap);
            }
        }


        roleOfflineData = dao.fetch(RoleOfflineData.class, "devil_first_histories");
        if (roleOfflineData != null) {
            Map<Integer, DevilFirstHistory> historyMap = JsonUtils.string2Map(roleOfflineData.getData(), Integer.class, DevilFirstHistory.class);
            if (historyMap != null) {
                DataCache.DEVIL_FIRST_HISTORIES.putAll(historyMap);
            }
        }
    }

    @PreDestroy
    private void shutDown() {
        saveCommon();
    }

    private void saveCommon() {
        Dao dao = SpringUtils.getBean(Dao.class);
        String data = JsonUtils.map2String(DataCache.DEVIL_MAX_KILLS);
        dao.insertOrUpdate(new RoleOfflineData("devil_max_kills", data));

        data = JsonUtils.map2String(DataCache.DEVIL_FIRST_HISTORIES);
        dao.insertOrUpdate(new RoleOfflineData("devil_first_histories", data));
    }

    @Override
    protected String getNpcContent(Role role, NPC bossNpc) {
        return null;
    }

    @Override
    protected String getNpcContentNotFight(Role role, NPC bossNpc) {
        if (teamService.isInTeam(role)) {
            /**组队*/
            String names = teamService.checkMember(role, memberRole -> memberRole.getActivity().getRemainDevilTime() <= 0);
            if (names != null) {
                return I18nIdDataPool.getI18nContent(I18nId.PMT_1602, names);
            }

            names = teamService.checkMember(role, memberRole -> !isInMap(memberRole));
            if (names != null) {
                return I18nIdDataPool.getI18nContent(I18nId.PMT_1605, names);
            }

            names = teamService.checkMember(role, memberRole -> memberRole.getLevel() < minLevel);
            if (names != null) {
                return I18nIdDataPool.getI18nContent(I18nId.PMT_1617, names, minLevel);
            }
        } else {
            /**未组队*/
            if (role.getActivity().getRemainDevilTime() <= 0) {
                if (!activityService.isHaveRemainCount(role, ActivityType.DEVIL_ACTIVTY)) {
                    return I18nIdDataPool.getI18nContent(I18nId.PMT_1603);
                } else {
                    return I18nIdDataPool.getI18nContent(I18nId.PMT_1604);
                }
            }
            if (!isInMap(role)) {
                return I18nIdDataPool.getI18nContent(I18nId.PMT_1606);
            }
            if (role.getLevel() < minLevel) {
                return I18nIdDataPool.getI18nContent(I18nId.PMT_1616, minLevel);
            }
        }

        return null;
    }

    @Override
    protected void doStartFight(Role role, NPC bossNpc) {
        List<BossParam> bossParamList = newBossParamList(role, bossNpc);
        BossFightParam bossFightParam = new BossFightParam(bossParamList, getFightType(role));
        bossFightParam.setNpcId(bossNpc.getId());
        if (role.getTianshentime() >0&&System.currentTimeMillis()-role.getTianshentime()<=20000){
            return;
        }
        role.setTianshentime(System.currentTimeMillis());
        bossService.startFightToBoss(role, bossFightParam);
    }

    private List<BossParam> newBossParamList(Role role, NPC npc) {
        List<BossParam> bossParamList = new ArrayList<>();
        int count = 10;

        /**npc对应的加在第1个*/
        BossSet bossSet = bossService.getBossSet(npc.getName());
        BossParam bossParam = new BossParam(bossSet, npc.getName());
        bossParamList.add(bossParam);
        DevilFirstHistory devilFirstHistory = DataCache.DEVIL_FIRST_HISTORIES.get(npc.getId());
        if (devilFirstHistory != null) {
            bossParam.setIcon((short) devilFirstHistory.getIcon());
            bossParam.setWeaponIcon(devilFirstHistory.getWeaponIcon());
            bossParam.setSuitIcon(devilFirstHistory.getSuitIcon());
            bossParam.setSuitLightEffect(devilFirstHistory.getSuitLightEffect());
        }

        List<String> list = smallBossNames.get(npc.getName());
        /**加count-1个*/
        for (int i = 1; i < count; i++) {
            int index = ThreadLocalRandom.current().nextInt(list.size());
            bossSet = bossService.getBossSet(list.get(index));
            bossParamList.add(new BossParam(bossSet, smallNames.get(npc.getName())));
        }

        return bossParamList;
    }

    @Override
    protected int getFightType(Role role) {
        return Const.fightType_devil;
    }

    @Override
    protected NPC getBossNpc(int npcId) {
        return SpringUtils.getMapService().getNpc(npcId);
    }

    @Override
    protected void clearNpcAfterWin(Role role, NPC bossNpc) {

    }

    @Override
    protected void giveReward(Role role, FightEndEvent fightEndEvent, NPC bossNpc) {
        /**不在地图不给奖励*/
        if (!isInMap(role)) {return ;}

        /**只给道行和武学*/
        int daohang = fightEndEvent.getReward().getInt("rewardDaohang", 0) * role.getLevel();
        int petWuxue = fightEndEvent.getReward().getInt("petRewardWuxue", 0) * role.getLevel();
        RoleService roleService = SpringUtils.getRoleService();
        roleService.addTao(role, daohang);
        int currPetId = role.getTempCache("fight_current_pet_id", 0);
        Pet pet = SpringUtils.getPetService().getPetById(currPetId, role);
        if (pet != null) {
            roleService.addPetMatiral(role, pet, petWuxue);
        }

        /**同时记录胜利次数*/
        addKillCount(role, bossNpc);
    }

    /**
     * 增加胜利次数
     */
    private void addKillCount(Role role, NPC npc) {
        int npcId = npc.getId();
        int count = role.getActivity().getDevilKillCounts().getOrDefault(npcId, 0);
        int newCount = count + 1;
        role.getActivity().getDevilKillCounts().put(npcId, newCount);
        role.save();

        if (newCount > getMaxKill(npcId)) {
            setMaxKill(npcId, newCount);

            if (teamService.isNotInTeamOrLeader(role)) {
                updateFirstHistory(npcId, role, newCount);
                bossService.broadcastNpcUpdate(new GroupMapParam(role), npc);
                String content = I18nIdDataPool.getI18nContent(I18nId.PMT_1614, role.getName());
                SpringUtils.getChatService().sendNumor(content, Const.BRODCAST_MSG_TYPE_ROLE);
            }
        }
    }

    private int getMaxKill(int npcId) {
        return DataCache.DEVIL_MAX_KILLS.getOrDefault(npcId, 0);
    }

    private void setMaxKill(int npcId, int killCount) {
        DataCache.DEVIL_MAX_KILLS.put(npcId, killCount);
    }

    private void updateFirstHistory(int npcId, Role role, int killCount) {
        DevilFirstHistory devilFirstHistory = new DevilFirstHistory(npcId, role, killCount);
        DataCache.DEVIL_FIRST_HISTORIES.put(npcId, devilFirstHistory);
    }

    @Override
    protected void clearNpcTimeOut(NPC npc) {

    }

    @Override
    public boolean isSetInFight() {
        /**不需要设置进入战斗状态，可以同时进入战斗*/
        return false;
    }

    /**
     * 查看挑战神魔活动
     */
    public void view(Role role, NPC npc) {
        String content = I18nIdDataPool.getI18nContent(I18nId.PMT_1600);
        npcService.sendNpcContent(role, npc, content);
    }

    /**
     * 进入挑战神魔地图
     */
    public void enter(Role role, NPC npc) {
        String check = checkEnter(role);
        if (check != null) {
            npcService.sendNpcContent(role, npc, check);
        }

        doEnter(role);
    }

    private String checkEnter(Role role) {
        return null;
    }

    /**
     * 执行进入地图逻辑
     */
    private void doEnter(Role role) {
        SpringUtils.getMapService().changeMap(role, ENTER_MAPID, ENTER_X, ENTER_Y);
    }

    /**
     * 是否在挑战神魔地图
     */
    private boolean isInMap(Role role) {
        return SpringUtils.getMapService().isInMap(role, ENTER_MAPID);
    }

    /**
     * 在NPC处选择购买挑战神魔时间
     */
    public void buyTimeList(Role role, NPC npc) {
        String content = I18nIdDataPool.getI18nContent(I18nId.PMT_1612);
        npcService.sendNpcContent(role, npc, content);
    }

    public void buyTimeMoney(Role role, NPC npc) {
        role.setConfirm(new BuyDevilTimeConfirm(BuyDevilTimeConfirm.BYTE_MEONY));

        String msg = I18nIdDataPool.getI18nContent(I18nId.PMT_1613, AsktaoUtil.getMoneyFormat(buyNeedMoney), buyMinute);
        RespConfirm respConfirm = new RespConfirm();
        respConfirm.setTips(msg);
        MessagePusher.pushMessage(role, respConfirm);
    }

    public void buyTimeGold(Role role, NPC npc) {
        role.setConfirm(new BuyDevilTimeConfirm(BuyDevilTimeConfirm.BYTE_GOLD));

        String msg = I18nIdDataPool.getI18nContent(I18nId.PMT_1607, buyNeedGold, buyMinute);
        RespConfirm respConfirm = new RespConfirm();
        respConfirm.setTips(msg);
        MessagePusher.pushMessage(role, respConfirm);
    }

    /**
     * 确认购买挑战神魔时间
     */
    public void confirmBuyTime(Role role, byte buyType) {
        /**没有购买次数时不让购买*/
        if (!activityService.isHaveRemainCount(role, ActivityType.DEVIL_ACTIVTY)) {
            MessagePusher.notify2Player(role, I18nId.PMT_1608);
            return ;
        }
        /**小于可挑战等级时不让购买*/
        if (role.getLevel() < minLevel) {
            String content = I18nIdDataPool.getI18nContent(I18nId.PMT_1616, minLevel);
            content = content.replace(Const.LEAVE_BUTTON, "");
            MessagePusher.pushMessage(role, new RespMsg(content));
            return ;
        }


        if (buyType == BuyDevilTimeConfirm.BYTE_MEONY) {
            if (role.getMoney() < buyNeedMoney) {
                MessagePusher.notify2Player(role, I18nId.PMT_401);
                return ;
            }

            /**扣除金钱*/
            SpringUtils.getRoleService().subtractMoney(role, buyNeedMoney, Reason.BUY_DEVIL_TIME);
        } else if (buyType == BuyDevilTimeConfirm.BYTE_GOLD) {
            if (role.getGold() < buyNeedGold) {
                MessagePusher.notify2Player(role, I18nId.PMT_403);
                return ;
            }

            /**扣除金元宝*/
            SpringUtils.getRoleService().subtractGold(role, buyNeedGold, Reason.BUY_DEVIL_TIME);
        }

        activityService.addFinishCount(role, ActivityType.DEVIL_ACTIVTY, 1);
        /**增加时间*/
        role.getActivity().setRemainDevilTime((int) (buyMinute * TimeUtil.ONE_MINUTE));
        role.save();
        MessagePusher.notify2Player(role, I18nId.PMT_1609, buyMinute);

        /**买完后传送到地图*/
        doEnter(role);
    }

    @Override
    public void handleHeartBeat(Role role, long prevHeartTime) {
        /**在地图时更新挑战剩余时间*/
        if (isInMap(role) && (prevHeartTime > 0 && role.getActivity().getRemainDevilTime() > 0)) {
            int before = role.getActivity().getRemainDevilTime();
            long now = System.currentTimeMillis();
            long diff = now - prevHeartTime;
            if (role.getActivity().getRemainDevilTime() > diff) {
                long remain = role.getActivity().getRemainDevilTime() - diff;
                role.getActivity().setRemainDevilTime((int) remain);
            } else {
                role.getActivity().setRemainDevilTime(0);
            }
            role.save();

            sendTaskInfo(role);
        }
    }

    @Override
    public void handleLogin(Role role) {
        if (role.getLevel() < minLevel) {
            return ;
        }
        sendTaskInfo(role);
    }

    private void sendTaskInfo(Role role) {
        NewTaskService taskService = SpringUtils.getTaskService();
        TaskSet taskSet = taskService.getTaskSet(taskId, role);
        if (taskSet == null) {return ;}
        TaskInfo taskInfo = taskService.getTaskInfo(role, taskSet);
        if (taskInfo != null) {
            if (role.getActivity().getRemainDevilTime() > 0) {
                int remainMinute = (int) (role.getActivity().getRemainDevilTime() / TimeUtil.ONE_MINUTE);
                String content = I18nIdDataPool.getI18nContent(I18nId.PMT_1610, remainMinute);
                taskInfo.setTaskInfo(taskInfo.getTaskInfo() + content);
                taskInfo.setTaskZhiyin(taskInfo.getTaskZhiyin() + content);
            }
            SpringUtils.getTaskService().pushTaskInfo(role, taskInfo);
        }
    }

    public void sendSystem() {
        String content = I18nIdDataPool.getI18nContent(I18nId.PMT_1615);
        SpringUtils.getChatService().sendSystem(content, Const.BRODCAST_MSG_TYPE_ROLE);
    }

    public void sendAdNotice() {
        String content = I18nIdDataPool.getI18nContent(I18nId.PMT_1615);
        SpringUtils.getChatService().sendAdnotice(content);

    }
}
