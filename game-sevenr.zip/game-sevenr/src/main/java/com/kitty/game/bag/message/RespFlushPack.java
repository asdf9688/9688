package com.kitty.game.bag.message;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;


/**
 * 刷新背包？
 */
@MessageMeta(module = Modules.MSG_FLUSH_PACK)
public class RespFlushPack extends Message {
    private short a = 1;
    private short b = 166;
    private short c = 0;
    private String type;

    public short getA() {
        return a;
    }

    public void setA(short a) {
        this.a = a;
    }

    public short getB() {
        return b;
    }

    public void setB(short b) {
        this.b = b;
    }

    public short getC() {
        return c;
    }

    public void setC(short c) {
        this.c = c;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
