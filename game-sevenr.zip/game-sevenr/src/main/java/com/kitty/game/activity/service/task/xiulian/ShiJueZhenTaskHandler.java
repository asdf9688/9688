package com.kitty.game.activity.service.task.xiulian;

import com.kitty.game.role.model.Role;
import com.kitty.game.boss.config.BossSet;
import com.kitty.game.config.NPC;
import com.kitty.common.spring.SpringUtils;
import com.kitty.game.activity.service.task.XiuLianTaskHandler;
import com.kitty.game.boss.service.NewBossService;
import com.kitty.game.npc.model.NpcButton;
import com.kitty.game.school.model.SchoolSet;
import com.kitty.game.school.service.SchoolService;
import com.kitty.game.task.model.product.TaskType;
import com.kitty.game.utils.Const;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**十绝阵任务处理类*/
@Component
public class ShiJueZhenTaskHandler extends XiuLianTaskHandler {
    private final int acceptNpcId = 14554;
    private final String xiuLianName = "十绝阵";
    private final int taskIdAtNpc = 102;
    private final TaskType taskType =  TaskType.SHI_JUE_ZHEN;
    private final int acceptMinLevel = 100;
    private final String acceptTeamCountNotEnough = "十绝阵战斗非同一般，还是组满#R{0}#n人再来找我吧。[离开]";
    private final String acceptLevelNotEnough = "#Y{0}#n等级低于#R{1}级#n，无法经受十绝阵考验。[离开]";
    private final String accepted = "你已经领取#R十绝阵#n任务，还不快去挑战。[离开]";
    private final String reaminCountNotEnough = "#Y{0}#n今日修炼次数已达上限，挑战十绝阵将没有任何奖励。[接受/"+ NpcButton.ACCEPT_SHIJUEZHEN_TASK_NO_REWARD.getKey()+"][离开]";
    private final String fightTeamCountNotEnough = "十绝阵战斗非同一般，还是组满#R{0}#n人再来找我吧。[离开]";
    private final String fightLevelNotEnough = "#Y{0}#n等级低于#R{1}级#n，无法经受十绝阵考验。[离开]";
    private final String notAccepted = "你们现在不需要我指点。[离开]";
    private final String messageTemplate = "你的队伍成功领取十绝阵任务，#R请注意修行与十绝阵共用领取奖励次数#n。";
    private final int npcBossCount = 10;
    private volatile Map<String, String> fightStartPromptMap = null;


    @Override
    public int getAcceptNpcId() {
        return acceptNpcId;
    }

    @Override
    public String getXiuLianName() {
        return xiuLianName;
    }

    @Override
    public int getTaskIdAtNpc() {
        return taskIdAtNpc;
    }

    @Override
    public TaskType getTaskType() {
        return taskType;
    }

    @Override
    protected int getFightType(Role role) {
        return Const.fightType_shijuezhen;
    }

    @Override
    public int getAcceptMinLevel() {
        return acceptMinLevel;
    }

    @Override
    public String getAcceptTeamCountNotEnough() {
        return acceptTeamCountNotEnough;
    }

    @Override
    public String getAcceptLevelNotEnough() {
        return acceptLevelNotEnough;
    }

    @Override
    public String getAccepted() {
        return accepted;
    }

    @Override
    public String getReaminCountNotEnough() {
        return reaminCountNotEnough;
    }

    @Override
    public String getFightTeamCountNotEnough() {
        return fightTeamCountNotEnough;
    }

    @Override
    public String getFightLevelNotEnough() {
        return fightLevelNotEnough;
    }

    @Override
    public String getNotAccepted() {
        return notAccepted;
    }

    @Override
    public String getMessageTemplate() {
        return messageTemplate;
    }

    @Override
    public int getNpcBossCount() {
        return npcBossCount;
    }

    @Override
    public String getFightStartPrompt(NPC bossNpc) {
        if (fightStartPromptMap == null) {
            synchronized (this) {
                if (fightStartPromptMap == null) {
                    initFightStartPromptMap();
                }
            }
        }

        return fightStartPromptMap.get(bossNpc.getName());
    }

    private void initFightStartPromptMap() {
        Map<String, String> fightStartPromptMap = new HashMap<>();
        List<String> list = Arrays.asList("金光阵主","风吼阵主","落魄阵主","化血阵主","寒冰阵主","红水阵主","烈焰阵主","地烈阵主","天阙阵主","红砂阵主");
        NewBossService bossService = SpringUtils.getBean(NewBossService.class);
        SchoolService schoolService = SpringUtils.getBean(SchoolService.class);
        for (String name : list) {
            BossSet bossSet = bossService.getBossSet(name);
            SchoolSet shoolSet = schoolService.getShoolSet((byte) bossSet.getXiangxin());
            String messageTemplate = "你进入了{0}，将持续受到{1}系法术伤害。";
            fightStartPromptMap.put(name, MessageFormat.format(messageTemplate, name.replace("主", ""), shoolSet.getTypeName()));
        }


        this.fightStartPromptMap = fightStartPromptMap;
    }

    /**接取十绝阵任务，弹出有成员没有奖励后仍然领取*/
    public void acceptShiJueZhenTaskAfterNoRewardTip(Role role, NPC npc, boolean auto) {
        role.getTalk().pushChooseParam(Const.XIULIAN_NO_REWARD_TIP_KEY, true);
        acceptTaskAtNpc(role, npc, auto);
    }
}
