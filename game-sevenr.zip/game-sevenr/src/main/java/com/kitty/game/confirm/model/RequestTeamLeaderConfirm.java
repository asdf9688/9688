package com.kitty.game.confirm.model;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

public class RequestTeamLeaderConfirm extends RoleConfirm {
    private int requestId;//申请人ID
    private boolean agree = false;
    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.REQUEST_TEAN_LEADER;
    }

    public RequestTeamLeaderConfirm(int requestId) {
        this.requestId = requestId;
    }

    public int getRequestId() {
        return requestId;
    }

    public boolean isAgree() {
        return agree;
    }

    public void setAgree(boolean agree) {
        this.agree = agree;
    }
}
