package com.kitty.game.activity.model.product.shuadao;

import com.kitty.game.activity.model.product.ActivityType;
import com.kitty.game.activity.model.product.RandomNpcParam;
import com.kitty.game.npc.model.NpcButton;
import com.kitty.game.utils.Const;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
//后加
import com.kitty.game.activity.model.product.shuadao.ShuaDaoSet;

/**飞仙渡邪*/
public class FeiXianDuXieShuaDaoSet extends ShuaDaoSet{
    /**主怪对应bossset表的名称列表*/
    private List<String> bossNames = Arrays.asList("飞仙主怪3", "飞仙主怪1", "飞仙主怪2");
    /**主怪名称前缀列表*/
    private List<String> prefixNames = Arrays.asList("灭天", "诛天", "噬血", "至恶", "恶煞", "灭地", "阳奎", "黑煞", "逆天");
    /**主怪中间名称列表*/
    private List<String> names = Arrays.asList("邪神", "邪仙");
    /**主怪名称后缀列表*/
    private List<String> postfixNames = Arrays.asList("傲世", "飘渺", "巫辰", "混元", "无极", "虚空", "狂獠", "猖枭", "凶狈");

    /**小怪对应bossset表的名称列表*/
    private List<String> smallBossNames = Arrays.asList("飞仙小怪1号", "飞仙小怪2号", "飞仙小怪3号", "飞仙小怪4号", "飞仙小怪5号", "飞仙小怪6号", "飞仙小怪7号");
    /**小怪名称*/
    private String smallName = "邪仙爪牙";

    @Override
    public int getAcceptNpcId() {
        return 14555;
    }


    @Override
    public String getShuaDaoName() {
        return "飞仙渡邪";
    }

    @Override
    public int getMinLevel() {
        return 120;
    }

    @Override
    public String getLevelNotEnoughDesc() {
        return "#Y{0}#n角色等级低于#R{1}级#n，日后再来吧！[离开]";
    }

    @Override
    public int getFightTaskId() {
        return 91;
    }

    @Override
    public int getGuideTaskId() {
        return 92;
    }

    @Override
    public String getContent() {
        return "哈哈，送上门的肥肉！[今日让我来渡你/" + NpcButton.DO_SHUADAO.getKey() + "][我先准备准备]";
    }

    @Override
    public RandomNpcParam getRandomNpcParam() {
        RandomNpcParam randomNpcParam = new RandomNpcParam();

        int bossNameIndex = ThreadLocalRandom.current().nextInt(bossNames.size());
        String bossName = bossNames.get(bossNameIndex);
        randomNpcParam.setBossName(bossName);

        int prefixNameIndex = ThreadLocalRandom.current().nextInt(prefixNames.size());
        String prefixName = prefixNames.get(prefixNameIndex);

        int nameIndex = ThreadLocalRandom.current().nextInt(names.size());
        String name = names.get(nameIndex);

        int postfixNameIndex = ThreadLocalRandom.current().nextInt(postfixNames.size());
        String postfixName = postfixNames.get(postfixNameIndex);

        String npcName = prefixName + name + postfixName;
        randomNpcParam.setNpcName(npcName);

        return randomNpcParam;
    }

    @Override
    public ActivityType getActivityType() {
        return ActivityType.SHUA_DAO_FEIXIANDUXIE_TASK;
    }

    @Override
    public int getNpcBossCount() {
        return 3;
    }

    @Override
    public List<String> getSmallBossNames() {
        return smallBossNames;
    }

    @Override
    public String getSmallAlias() {
        return smallName;
    }

    @Override
    public int getBossTotalCount() {
        return 10;
    }

    @Override
    public int getCountRate() {
        /**飞仙渡仙按4次刷道算*/
        return 4;
    }

    @Override
    public String getRankKey() {
        return Const.feixianduxieRank;
    }
}
