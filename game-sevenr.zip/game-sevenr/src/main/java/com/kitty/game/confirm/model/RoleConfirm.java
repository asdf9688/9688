package com.kitty.game.confirm.model;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

/**玩家确认框请求抽象类*/
public abstract class RoleConfirm {
    public abstract ConfirmType getConfirmType();
}
