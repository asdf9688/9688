package com.kitty.game.confirm.service.handler;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.equip.service.ZHJService;
import com.kitty.game.role.model.Role;
import com.kitty.game.team.message.ReqConfirmResult;
import org.springframework.stereotype.Component;
import com.kitty.game.confirm.service.handler.ConfirmHandler;

@Component
public class OfflineConfirmHandler extends ConfirmHandler {
    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
        /**确认兑换*/
        if ("1".equals(reqConfirmResult.getSelect())) {

        }
    }
}
