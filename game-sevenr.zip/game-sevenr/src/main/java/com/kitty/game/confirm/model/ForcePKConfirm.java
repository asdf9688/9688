package com.kitty.game.confirm.model;

import lombok.Getter;
import lombok.Setter;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;


@Setter
@Getter
public class ForcePKConfirm extends RoleConfirm {
    /**pk目标uid*/
    private long targetUid;

    public ForcePKConfirm(long targetUid) {
        this.targetUid = targetUid;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.FORCE_PK;
    }
}
