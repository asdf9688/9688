package com.kitty.game.confirm.service.handler;

import com.kitty.game.role.model.Role;
import com.kitty.common.spring.SpringUtils;
import com.kitty.game.confirm.model.AvoidMonsterConfirm;
import com.kitty.game.team.message.ReqConfirmResult;
import org.springframework.stereotype.Component;
import com.kitty.game.confirm.service.handler.ConfirmHandler;

@Component
public class AvoidMonsterConfirmHandler extends ConfirmHandler {
    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
        if ("1".equals(reqConfirmResult.getSelect())) {
            AvoidMonsterConfirm confirm = (AvoidMonsterConfirm)role.getConfirm();
            if (confirm.isOpen()) {
                /**开启操作*/
                SpringUtils.getFightService().openAvoidMonster(role);
            } else {
                /**关闭操作*/
                SpringUtils.getFightService().closeAvoidMonster(role);
            }
        }
    }
}
