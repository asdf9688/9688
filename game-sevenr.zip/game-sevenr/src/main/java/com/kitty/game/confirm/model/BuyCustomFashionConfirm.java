package com.kitty.game.confirm.model;

import com.kitty.game.config.Fasion;

import java.util.List;
//后加
import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

public class BuyCustomFashionConfirm extends RoleConfirm{
    /**总价格*/
    private int price;

    /**购买的时装列表*/
    private List<Fasion> list;

    public BuyCustomFashionConfirm(int price, List<Fasion> list) {
        this.price = price;
        this.list = list;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.BUY_CUSTOMFASHION;
    }

    public int getPrice() {
        return price;
    }

    public List<Fasion> getList() {
        return list;
    }

}
