package com.kitty.game.chat.message;

import com.kitty.game.activity.message.vo.DailyStatsInfo;
import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

@MessageMeta(module = Modules.MSG_CARD_INFO, cmd = 5)
public class RespDailyStatisInfo extends Message {
    private String uuId;
    private String type;
    DailyStatsInfo dailyStatsInfo;

    public RespDailyStatisInfo(String uuId, String type, DailyStatsInfo dailyStatsInfo) {
        this.uuId = uuId;
        this.type = type;
        this.dailyStatsInfo = dailyStatsInfo;
    }
}
