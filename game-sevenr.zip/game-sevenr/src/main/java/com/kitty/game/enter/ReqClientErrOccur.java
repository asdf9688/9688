package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.annotation.StringField;
import com.kitty.mina.message.Message;

/**
 * 记录客户端错误
 */
@MessageMeta(module = Modules.CMD_CLIENT_ERR_OCCUR)
public class ReqClientErrOccur extends Message {
    private short errType;
    @StringField(value = 1)
    private String msg;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public short getErrType() {
        return errType;
    }

    public void setErrType(short errType) {
        this.errType = errType;
    }
}
