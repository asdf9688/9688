package com.kitty.game.confirm.service;

import com.kitty.common.config.ConfigUtil;
import com.kitty.game.confirm.model.BuyDevilTimeConfirm;
import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.TowerFlyUpConfirm;
import com.kitty.game.role.model.Role;
import com.kitty.game.confirm.model.RoleConfirm;
import com.kitty.game.confirm.service.handler.ConfirmHandler;
import com.kitty.game.confirm.service.handler.ConfirmHandlerHelper;
import com.kitty.game.team.message.ReqConfirmResult;
import com.kitty.game.team.message.RespConfirm;
import com.kitty.game.team.message.RespMsg;
import com.kitty.game.utils.AsktaoUtil;
import com.kitty.game.utils.Const;
import com.kitty.game.xmd.XIanMoTimeConfirm;
import com.kitty.mina.message.MessagePusher;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;

/**确认框相关 业务处理类*/
@Service
public class ConfirmService {
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
        /**拿到之前缓存的确认框请求数据*/
        RoleConfirm roleConfirm = role.getConfirm();
        if(reqConfirmResult.getSelect().equals("4")){
            role.setConfirm(new XIanMoTimeConfirm());
            role.getChildInfo().setXianmoqiehuan(4);
            RespConfirm respConfirm = new RespConfirm();
            respConfirm.setTips("弃仙成魔需要消耗积分:#R"+ ConfigUtil.reward.getXIANMO_XIAOHAO()+"#n确定要操作吗？");
            respConfirm.setConfirm_type("");
            MessagePusher.pushMessage(role, respConfirm);
        }else if(reqConfirmResult.getSelect().equals("3")){
            role.setConfirm(new XIanMoTimeConfirm());
            role.getChildInfo().setXianmoqiehuan(3);
            RespConfirm respConfirm = new RespConfirm();
            respConfirm.setTips("弃魔成仙需要消耗积分:#R"+ ConfigUtil.reward.getXIANMO_XIAOHAO()+"#n确定要操作吗？");
            respConfirm.setConfirm_type("");
            MessagePusher.pushMessage(role, respConfirm);
        }
        if(roleConfirm==null){
            MessagePusher.pushMessage(role,new RespMsg("很抱歉，该功能暂未开放。"));
            return;
        }
        ConfirmHandler handler= ConfirmHandlerHelper.INSTANCE.getTargetHandler(roleConfirm.getConfirmType());
        if(handler!=null){
            handler.handleConfirmResult(role, reqConfirmResult);
        }else {
            MessagePusher.pushMessage(role,new RespMsg("很抱歉，该功能暂未开放。"));
        }
    }
}
