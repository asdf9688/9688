package com.kitty.game.chat.message.vo;

import com.kitty.mina.annotation.StringField;

public class ChatInfo {
    @StringField(value = 1)
    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
