package com.kitty.game.chat.message;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.annotation.StringField;
import com.kitty.mina.message.Message;

/**
 * 系统消息 谣言提示
 */
@MessageMeta(module = Modules.MSG_MESSAGE)
public class RespMessage extends Message {
    private short channel;//频道
    private int id;
    private String typeName = "系统";
    @StringField(value = 1)
    private String msg;
    private int time;
    private short privilege;
    private String lineName;
    private short show_extra;
    private byte show_time;
    private short icon;

    public short getChannel() {
        return channel;
    }

    public void setChannel(short channel) {
        this.channel = channel;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public short getPrivilege() {
        return privilege;
    }

    public void setPrivilege(short privilege) {
        this.privilege = privilege;
    }

    public String getLineName() {
        return lineName;
    }

    public void setLineName(String lineName) {
        this.lineName = lineName;
    }

    public short getShow_extra() {
        return show_extra;
    }

    public void setShow_extra(short show_extra) {
        this.show_extra = show_extra;
    }

    public byte getShow_time() {
        return show_time;
    }

    public void setShow_time(byte show_time) {
        this.show_time = show_time;
    }

    public short getIcon() {
        return icon;
    }

    public void setIcon(short icon) {
        this.icon = icon;
    }
}
