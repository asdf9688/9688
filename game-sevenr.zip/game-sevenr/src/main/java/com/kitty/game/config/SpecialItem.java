package com.kitty.game.config;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

@Table("p_specialitem")
public class SpecialItem {
    @Name
    private String key_name;//
    @Column
    @Comment("背包中图片")
    private int icon;
    @Column
    @Comment("是否叠加")
    private boolean combined;
    @Column
    @Comment("叠加数量")
    private short combinedNum;
    @Column
    @Comment("是否浮动参数")
    private boolean no_float;
    @Column
    @Comment("出售价格")
    private int price;
    @Column
    @Comment("声望价格")
    private int sell_value;
    @Column
    @Comment("颜色")
    private String color;
    @Column
    @Comment("时装性别")
    private byte sex;//1男 2女
    @Column
    @Comment("量词")
    private String unit;

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public byte getSex() {
        return sex;
    }

    public void setSex(byte sex) {
        this.sex = sex;
    }


    public short getCombinedNum() {
        return combinedNum==0?999:combinedNum;
    }

    public void setCombinedNum(short combinedNum) {
        this.combinedNum = combinedNum;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getKey_name() {
        return key_name;
    }

    public void setKey_name(String key_name) {
        this.key_name = key_name;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public boolean isCombined() {
        return combined;
    }

    public void setCombined(boolean combined) {
        this.combined = combined;
    }

    public boolean isNo_float() {
        return no_float;
    }

    public void setNo_float(boolean no_float) {
        this.no_float = no_float;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getSell_value() {
        return sell_value;
    }

    public void setSell_value(int sell_value) {
        this.sell_value = sell_value;
    }
}
