package com.kitty.game.confirm.service.handler;

import com.kitty.game.role.model.Role;
import com.kitty.game.equip.model.RoleEquip;
import com.kitty.game.item.config.ChangeCard;
import com.kitty.common.spring.SpringUtils;
import com.kitty.game.confirm.model.ChangeCardConfirm;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.item.service.ChangeCardService;
import com.kitty.game.team.message.ReqConfirmResult;
import com.kitty.mina.message.MessagePusher;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import com.kitty.game.confirm.service.handler.ConfirmHandler;

@Component
public class UseChangeCardHandler extends ConfirmHandler {
    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
        if (reqConfirmResult.getSelect().equals("1")) {
            applyCard(role);
        }
    }

    /**
     * 确定使用变身卡
     */
    private void applyCard(Role role) {
        RoleEquip roleEquip = ((ChangeCardConfirm) role.getConfirm()).getRoleEquip();
        Role targetRole = ((ChangeCardConfirm) role.getConfirm()).getTargetRole();
        ChangeCard changeCard = ((ChangeCardConfirm) role.getConfirm()).getChangeCard();

        if (role.equals(targetRole)) {
            MessagePusher.pushMessage(role, new RespNotifyMiscEx(MessageFormat.format("你使用了一张#R{0}#n。可在任务界面查看变身卡效果。", changeCard.getName())));
        }
        /**使用变身卡*/
        SpringUtils.getBean(ChangeCardService.class).useChangeCard(role, targetRole, roleEquip, changeCard);
    }

}
