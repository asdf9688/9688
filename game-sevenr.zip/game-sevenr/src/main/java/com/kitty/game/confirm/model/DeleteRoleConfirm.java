package com.kitty.game.confirm.model;

public class DeleteRoleConfirm extends RoleConfirm {
    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.DELETE_ROLE;
    }
}
