package com.kitty.game.activity.model.product.shuadao;

import com.kitty.game.activity.model.product.ActivityType;
import com.kitty.game.activity.model.product.RandomNpcParam;
import com.kitty.game.npc.model.NpcButton;
import com.kitty.game.utils.Const;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import com.kitty.game.activity.model.product.shuadao.ShuaDaoSet;

/**伏魔*/
public class FuMoShuaDaoSet extends ShuaDaoSet{
    /**对应bossset表的名字*/
    private List<String> bossNames = Arrays.asList("刺猬", "悍猪", "黑熊", "狂狮", "巨象");
    /**名字前缀*/
    private List<String> prefixNames = Arrays.asList("妖王", "魔王", "百目", "黑风", "噬生", "灰骨", "墨足", "狰狞", "苍麟", "须魅", "盘甲", "符尸");
    /**名字后缀*/
    private List<String> postfixNames = Arrays.asList("寒离", "七心", "寸影", "花翎", "刑炎", "孤煞", "破天", "尤鸾", "邪牙", "幻世", "焚魂", "撼雷", "玄溟", "赤地", "蚀月", "戮神");
    /**小怪对应bossset表的名字*/
    private List<String> smallBossNames = Arrays.asList("镜灵", "傲灵", "爆灵", "狂灵", "疯灵", "艮灵", "离灵", "坎灵", "震灵", "兑灵");

    @Override
    public int getAcceptNpcId() {
        return 15194;
    }

    @Override
    public String getShuaDaoName() {
        return "伏魔";
    }

    @Override
    public int getMinLevel() {
        return 80;
    }

    @Override
    public String getLevelNotEnoughDesc() {
        return "#Y{0}#n角色等级低于#R{1}级#n，日后再来吧！[离开]";
    }

    @Override
    public int getFightTaskId() {
        return 80;
    }

    @Override
    public int getGuideTaskId() {
        return 81;
    }

    @Override
    public String getContent() {
        return "哈哈，送上门的肥肉！[今天我就要为民除害/" + NpcButton.DO_SHUADAO.getKey() + "][我先准备准备]";
    }

    @Override
    public RandomNpcParam getRandomNpcParam() {
        RandomNpcParam randomNpcParam = new RandomNpcParam();

        int bossNameIndex = ThreadLocalRandom.current().nextInt(bossNames.size());
        String bossName = bossNames.get(bossNameIndex);
        randomNpcParam.setBossName(bossName);

        int prefixNameIndex = ThreadLocalRandom.current().nextInt(prefixNames.size());
        String prefixName = prefixNames.get(prefixNameIndex);

        int postfixNameIndex = ThreadLocalRandom.current().nextInt(postfixNames.size());
        String postfixName = postfixNames.get(postfixNameIndex);

        String npcName = prefixName + bossName + postfixName;
        randomNpcParam.setNpcName(npcName);

        return randomNpcParam;
    }

    @Override
    public ActivityType getActivityType() {
        return ActivityType.SHUA_DAO_FUMO_TASK;
    }

    @Override
    public int getNpcBossCount() {
        return 3;
    }

    @Override
    public List<String> getSmallBossNames() {
        return smallBossNames;
    }

    @Override
    public String getSmallAlias() {
        return null;
    }

    @Override
    public int getBossTotalCount() {
        return 0;
    }

    @Override
    public int getCountRate() {
        return 1;
    }

    @Override
    public String getRankKey() {
        return Const.fumoRank;
    }
}
