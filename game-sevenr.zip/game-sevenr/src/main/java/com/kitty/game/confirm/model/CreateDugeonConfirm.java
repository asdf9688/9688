package com.kitty.game.confirm.model;

import lombok.Getter;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

import java.util.Map;

@Getter
public class CreateDugeonConfirm extends RoleConfirm {
    /**投票结果*/
    private Map<Integer, Short> ballotResults;

    public CreateDugeonConfirm(Map<Integer, Short> ballotResults) {
        this.ballotResults = ballotResults;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.CREATE_DUGEON;
    }
}
