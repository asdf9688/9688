package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

import java.util.Date;

/**
 *  用于通知客户端显示图标
 */
@MessageMeta(module = Modules.MSG_LD_LIFEDEATH_ID)
public class RespLD_LifeDeathId extends Message {
    
    private String id;
    
    private int time = new Long(new Date().getTime()/1000).intValue();
    
    private short type = 0;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }
}
