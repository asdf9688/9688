package com.kitty.game.activity.service.seal;

import com.kitty.common.spring.SpringUtils;
import com.kitty.core.SchedulerManager;
import com.kitty.game.activity.model.product.ActivityType;
import com.kitty.game.activity.service.time.FightActivityHandler;
import com.kitty.game.base.service.BagService;
import com.kitty.game.boss.config.BossSet;
import com.kitty.game.boss.model.BossFightParam;
import com.kitty.game.boss.model.BossNpcParam;
import com.kitty.game.boss.model.BossParam;
import com.kitty.game.config.GameMap;
import com.kitty.game.config.MapBossPos;
import com.kitty.game.config.NPC;
import com.kitty.game.config.TalkSet;
import com.kitty.game.confirm.model.FightSealBossConfirm;
import com.kitty.game.enter.Position;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.equip.service.EquipService;
import com.kitty.game.fight.bean.Fight;
import com.kitty.game.mail.model.Mail;
import com.kitty.game.pet.model.Pet;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.RoleService;
import com.kitty.game.talk.service.TalkService;
import com.kitty.game.team.message.RespConfirm;
import com.kitty.game.team.model.Member;
import com.kitty.game.team.model.Team;
import com.kitty.game.utils.AsktaoUtil;
import com.kitty.game.utils.Const;
import com.kitty.game.utils.TimeUtil;
import com.kitty.listener.event.FightEndEvent;
import com.kitty.logs.Reason;
import com.kitty.mina.cache.DataCache;
import com.kitty.mina.message.MessagePusher;
import com.kitty.mina.task.ThreadLocalUtil;
import org.nutz.lang.util.NutMap;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * 封印的boss处理类
 */
@Component
public abstract class SealBossHandler extends FightActivityHandler {
    private static final List<Integer> MAPIDS = Arrays.asList(2000, 3000, 4000, 24000, 6000, 8000, 9000, 8100, 13000, 14000, 15000, 16000, 10200, 10300, 10400, 10500, 16100, 18000, 17000, 17100,
            17200, 17400, 17500, 17600, 17700, 22000, 19002);
    /**
     * 出现的方向
     */
    private static final short DIRECTION = 6;
    /**
     * 持续显示的秒数
     */
    private static final int SHOW_TIME_SEC = 30 * 60;
    /**
     * 角色最大可少于等级数
     */
    private static final int MAX_LESS_LEVEL = 20;
    /**
     * 角色最大可超过等级数
     */
    private static final int MAX_MORE_LEVEL = 20;
    /**
     * 最少组队人数
     */
    private static final int MIN_TEAM_COUNT = 1;
    /**
     * 在放出的前几分钟只能由放出的那个玩家挑战
     */
    private static final int WAIT_TIME = (int) (3 * TimeUtil.ONE_MINUTE);
    /**
     * 拥有者奖励系数
     */
    private static final int OWNER_REWARD_RATE = 8;

    private final static String BREAK_SEAL_NUMOR = "大事不好了！#Y{0}#n挖掘宝藏时，不小心将#Y神龙真人#n禁锢的#Y{1}#n#R（{2}级）#n放了出来，据说那妖王现正在#R#Z{3}#Z#n为害世人，正道人士请速往降服！";

    private final static String BREAK_SEAL_NIANSHOU = "大事不好了！#Y{0}#n使用烟花道具时，给新年烟花中的#Y逃跑的年兽#n放了出来，据说那只年兽#R#Z{3}#Z#n携带了大量好礼，请道友前去击杀！#R道具经验道行等你获得";

    private static final String CONTENT = "新鲜的人肉，看来今天又有口福了！\r\n#R战斗结束时死亡的角色会受到惩罚。#n[为民除害（妖王等级{0}级）/{1}] [隔岸观火/look_on][饶了我吧/离开]";

    private static final String NianshouTEXT = "新年快乐呦！！！。#n[庆祝新年/tiaozhan_yanhuanianshou] [隔岸观火][没得兴趣/离开]";


    private static final String FIGHT_CONFIRM_TEXT = "你挖出了#Y{0}#n，是否前往讨伐？";
    private static final String FIGHT_TO = "前往讨伐";
    private static final String FIGHT_CANCAL = "继续挖宝";
    private static final String NOT_YOU = "本座打算给释放本座的小道士一个挽回错误的机会，你们若想送死还是等#R几分钟#n后再来吧。[离开]";
    private static final String ROLE_MORE_LEVEL = "道长修为高深，小妖无意与您争斗。[离开]";
    private static final String IN_FIGHT = "急什么！吃了他们就轮到你了！[离开]";
    private static final String LEVEL_NOT_ENOUGH = "凭你这点修为，给本座塞牙缝都不够。[离开]";
    private static final String TEAM_COUNT_NOT_ENOUGH = "#R" + MIN_TEAM_COUNT + "人#n都凑不齐,连给我塞牙缝的资格都没有！[离开]";
    private static final String REMAIN_COUNT_NOT_ENOUGH = "#Y{0}#n今日击杀数量已经用完。[离开]";
    private static final String OWNER_REWARD = "你放出的#Y{0}#n被消灭了，因此获得{1}道行。";
    private static final String OWNER_REWARD_MAIL_TITLE = "{0}被消灭了";
    private static final String OWNER_REWARD_MAIL_CONTENT = "你放出的#Y{0}#n被消灭了，因此获得道行奖励。";
    private static final String KILL_NUMOR = "传说中的#R{0}（{1}级）#n已被#Y{2}#n成功封印，中洲大陆真是人才辈出啊。";
    private static final String SIVER_REWARD_NOTICE = "恭喜你，得到了#Y%s#n银元宝新春活动的奖励。";
    private static final String SIVER_REWARD_NUMER = "传闻#Y%s#n在#R新春活动#n击杀了#R%s#n中获得了#R1000银元宝#n，大家也快来参与吧！";
    private static final String SYSTEM_NOTICE = "#R新春活动#n活动正在进行中，请大家踊跃铲除#R上古妖王、万年妖王#n，保卫家园，有概率掉落丰厚的奖励（银元宝法宝等等）。";

    public abstract String getOwnerNpcName();

    public abstract String getNpcName();

    public abstract String getBossName();

    public abstract List<String> getSmallBossNames();

    public abstract String getSmallName();

    public abstract String getFightTag();

    /**
     * 挖出时的第1个对话ID
     */
    public abstract int getFirstTalkId();

    public abstract byte getNpcType();


    /**
     * 破坏了封印
     */
    public boolean breakSeal_Nianshou(Role role,byte ty) {
        Collection<NPC> npcs = DataCache.TASK_NPCS.values();
        for (NPC snpc : npcs) {
            if(snpc.getRoleUid() == role.getUid()){
                return false;
            }
        }
        /**创建NPC*/
        NPC npc = createNpc_MAP(role,9000,ty);//地图ID
        ///限制人
        scheduleUpdateNpcName(npc);

        /**发谣言*/

        pushBreakSealNumor_NS(role, npc); //谣言



        /**弹出对话*/
        //popTalk(role);


        role.pushTempCache("break_seal", true);
        role.pushTempCache("fight_seal_boss_map", npc.getMapId());
        role.pushTempCache("fight_seal_boss_handler", getClass());

        return true;
    }

    public void breakSeal(Role role) {
        /**创建NPC*/
        NPC npc = createNpc(role);

        scheduleUpdateNpcName(npc);
        /**发谣言*/
        pushBreakSealNumor(role, npc);

        /**弹出对话*/
        popTalk(role);


        role.pushTempCache("break_seal", true);
        role.pushTempCache("fight_seal_boss_map", npc.getMapId());
        role.pushTempCache("fight_seal_boss_handler", getClass());


    }

    private void scheduleUpdateNpcName(NPC npc) {
        /**上古妖王在最开始时显示xx的上古妖王，3分钟后显示上古妖王*/
        if (getOwnerNpcName() != null) {
            SchedulerManager.getInstance().schedule(() -> {
                npc.setName(getNpcName());
                bossService.broadcastNpcUpdate(null, npc);
            }, WAIT_TIME);
        }
    }

    /**
     * 发谣言
     */
    private void pushBreakSealNumor(Role role, NPC npc) {
        GameMap map = SpringUtils.getMapService().getMap(npc.getMapId());
        String msg = MessageFormat.format(BREAK_SEAL_NUMOR, role.getName(), getNpcName(), npc.getLevel(), map.getName());
        SpringUtils.getChatService().sendNumor(msg, Const.BRODCAST_MSG_TYPE_ROLE);
    }
    /**
     * 发谣言
     */
    private void pushBreakSealNumor_NS(Role role, NPC npc) {
        GameMap map = SpringUtils.getMapService().getMap(npc.getMapId());
        String msg = MessageFormat.format(BREAK_SEAL_NIANSHOU, role.getName(), getNpcName(), npc.getLevel(), map.getName());
        SpringUtils.getChatService().sendNumor(msg, Const.BRODCAST_MSG_TYPE_ROLE);
    }
    /**
     * 弹出对话
     */
    private void popTalk(Role role) {
        TalkService talkService = SpringUtils.getBean(TalkService.class);

        TalkSet talkSet = talkService.getTalkSet(getFirstTalkId(), role);
        /**找不到对话时，则不处理*/
        if (talkSet == null) {
            return;
        }
        /**弹出对话*/
        talkService.popFirstTalk(role, talkSet);
    }

    /**
     * 弹出是否讨伐的确认框
     */
    public void fightConfirm(Role role, int mapId) {
        if (role == null) {
            return;
        }

        role.setConfirm(new FightSealBossConfirm(mapId));

        RespConfirm respConfirm = new RespConfirm();
        respConfirm.setTips(MessageFormat.format(FIGHT_CONFIRM_TEXT, getNpcName()));
        respConfirm.setConfirmText(FIGHT_TO);
        respConfirm.setCancelText(FIGHT_CANCAL);
        MessagePusher.pushMessage(role, respConfirm);
    }

    /**
     * 创建个NPC
     */
    public NPC createNpc(Role role) {
        BossNpcParam bossNpcParam = newBossNpcParam(role);
        return bossService.createBossNpc(role, bossNpcParam);
    }
    /**
     * 创建个NPC
     */
    public NPC createNpc_MAP(Role role,int MAP_ID,byte fujia_ty) {
        BossNpcParam bossNpcParam = newBossNpcParam_MAP_ID(role,MAP_ID,fujia_ty);
        return bossService.createBossNpc(role, bossNpcParam);
    }
    public BossNpcParam newBossNpcParam_MAP_ID(Role role,int MAP_id,byte fujia_ty) {
        BossNpcParam bossNpcParam = new BossNpcParam();

        BossSet bossSet = bossService.getBossSet(getBossName());
        bossNpcParam.setNpcIcon(bossSet.getIcon());
        bossNpcParam.setBossSetName(bossSet.getName());


        int randomMapId = MAP_id;///getRandomMapId();
        MapBossPos mapBossPos = bossService.getMapBossPos(randomMapId);
        Position position = bossService.getRandomPosition(mapBossPos);
        bossNpcParam.setMapId(mapBossPos.getMapId());
        bossNpcParam.setPosition(position);
        bossNpcParam.setfujia_type(fujia_ty);
        bossNpcParam.setDirection(DIRECTION);
        bossNpcParam.setShowTimeSec(SHOW_TIME_SEC);

        String npcName = getOwnerNpcName() != null ? MessageFormat.format(getOwnerNpcName(), role.getName()) : getNpcName();
        bossNpcParam.setNpcName(npcName);

        bossNpcParam.setNpcType(getNpcType());
        /**属于哪个玩家*/
        bossNpcParam.setRoleUid(role.getUid());
        bossNpcParam.setLevel(getRandomLevel(role));

        bossNpcParam.setContent(NianshouTEXT);

        bossNpcParam.setBroad(true);

        return bossNpcParam;
    }
    public BossNpcParam newBossNpcParam(Role role) {
        BossNpcParam bossNpcParam = new BossNpcParam();

        BossSet bossSet = bossService.getBossSet(getBossName());
        bossNpcParam.setNpcIcon(bossSet.getIcon());
        bossNpcParam.setBossSetName(bossSet.getName());


        int randomMapId = getRandomMapId();
        MapBossPos mapBossPos = bossService.getMapBossPos(randomMapId);
        Position position = bossService.getRandomPosition(mapBossPos);
        bossNpcParam.setMapId(mapBossPos.getMapId());
        bossNpcParam.setPosition(position);

        bossNpcParam.setDirection(DIRECTION);
        bossNpcParam.setShowTimeSec(SHOW_TIME_SEC);

        String npcName = getOwnerNpcName() != null ? MessageFormat.format(getOwnerNpcName(), role.getName()) : getNpcName();
        bossNpcParam.setNpcName(npcName);

        bossNpcParam.setNpcType(getNpcType());
        /**属于哪个玩家*/
        bossNpcParam.setRoleUid(role.getUid());
        bossNpcParam.setLevel(getRandomLevel(role));

        bossNpcParam.setContent(MessageFormat.format(CONTENT, bossNpcParam.getLevel(), getFightTag()));

        bossNpcParam.setBroad(true);

        return bossNpcParam;
    }

    /**
     * 获得随机出现的地图ID
     */
    private int getRandomMapId() {
        int index = ThreadLocalRandom.current().nextInt(MAPIDS.size());
        return MAPIDS.get(index);
    }

    /**
     * 获得随机等级
     */
    private int getRandomLevel(Role role) {
        int minLimit = -10;
        int maxLimit = 10;
        int rand = ThreadLocalRandom.current().nextInt(minLimit, maxLimit);
        Team team = teamService.getTeam(role.getRoleId());
        int level = 0;
        if (team != null) {
            for (Member member : team.getList()) {
                if (level == 0) {
                    level = member.getLevel();
                }
                if (member.getLevel() > level) {
                    level = member.getLevel();
                }
            }
            level = level + 5;
        } else {
            level = role.getLevel();
        }
        return level;
    }

    @Override
    public String getNpcContent(Role role, NPC bossNpc) {
        return MessageFormat.format(CONTENT, bossNpc.getLevel(), getFightTag());
    }

    @Override
    public String getNpcContentNotFight(Role role, NPC bossNpc) {
        /**检测是否在战斗中*/
        if (bossNpc.isInFight()) {
            return IN_FIGHT;
        }

        /**只检测队长等级，不检测队伍中其他成员等级*/
        if (role.getLevel() < bossNpc.getLevel() - MAX_LESS_LEVEL) {
            return LEVEL_NOT_ENOUGH;
        }

        /**角色等级超过怪太多等级时*/
        if (role.getLevel() > bossNpc.getLevel() + MAX_MORE_LEVEL) {
            return ROLE_MORE_LEVEL;
        }

        /**检测队伍人数*/
        int teamCount = teamService.getTeamCount(role);
        if (teamCount < MIN_TEAM_COUNT) {
            return TEAM_COUNT_NOT_ENOUGH;
        }

        Team team = teamService.getTeam(role.getRoleId());
        ActivityType finalSEAL = ActivityType.SEAL_BOSS;
        if(bossNpc.getType() == NPC.TYPE_BIANYI_YHNS)
        {
            finalSEAL = ActivityType.BHYH_ACTIVTY;

        }
        //ActivityType finalSEAL = SEAL;
        ActivityType finalSEAL1 = finalSEAL;
        String names = teamService.checkMember(role, memberRole -> !SpringUtils.getActivityService().isHaveRemainCount(memberRole,
                finalSEAL1));


        if (names != null) {
            return MessageFormat.format(REMAIN_COUNT_NOT_ENOUGH, names);
        }

        if (bossNpc.getRoleUid() != 0 && System.currentTimeMillis() - bossNpc.getCreateTime() < WAIT_TIME) {
            names = teamService.checkMember(team, memberRole -> memberRole.getUid() == bossNpc.getRoleUid());
            /**当前不是对应那个玩家时，返回*/
            if (names == null) {
                return NOT_YOU;
            }
        }

        return null;
    }

    @Override
    public void doStartFight(Role role, NPC boss) {
        List<BossParam> bossParamList = newBossParamList(role, boss);
        int a = getFightType(role);
        BossFightParam bossFightParam = new BossFightParam(bossParamList, a);
        bossFightParam.setNpcId(boss.getId());
        bossFightParam.setNpcLevel((short) boss.getLevel());
        bossFightParam.setReward(NutMap.NEW().setv("rewardLevel", boss.getLevel()));
        bossService.startFightToBoss(role, bossFightParam);

        // 上古消耗积分
        /*if (null != fight && boss.getType() == NPC.TYPE_SHANG_GU) {
            int score = 1;
            teamService.memberHandle(role, memberRole ->
                    {
                        SpringUtils.getRoleService().substractChargeScore(role, score);
                        MessagePusher.pushMessage(role, new RespNotifyMiscEx("战斗消耗#R" + score + "#n积分！"));
                    }
            );
        }*/
    }

    private List<BossParam> newBossParamList(Role role, NPC npc) {


        List<BossParam> bossParamList = new ArrayList<>();
        int count =10;
        if (npc.getType() == NPC.TYPE_BIANYI_YHNS){////烟花年兽
            count = 5;
        }

        /**npc对应的加在第1个*/
        BossSet bossSet = bossService.getBossSet(npc.getBossSetName());
        bossParamList.add(new BossParam(bossSet, npc.getName()));

        List<String> bossNames = new ArrayList<>();
        bossNames.addAll(getSmallBossNames());
        bossNames.remove(npc.getBossSetName());
        /**加count-1个*/
        for (int i = 1; i < count; i++) {
            int index = ThreadLocalRandom.current().nextInt(bossNames.size());
            bossSet = bossService.getBossSet(bossNames.get(index));
            bossParamList.add(new BossParam(bossSet, getSmallName()));
        }
        return bossParamList;

    }

    @Override
    public NPC getBossNpc(int npcId) {
        return DataCache.TASK_NPCS.get(npcId);
    }

    @Override
    public void clearNpcAfterWin(Role role, NPC bossNpc) {
        clearNpc(bossNpc);

        giveOwnerReward(bossNpc);
        pushKillNumor(role, bossNpc);
    }

    private void clearNpc(NPC npc) {
        bossService.delTaskNpc(npc);
        bossService.broadcastNpcHide(null, npc);
    }

    /**
     * 给拥有者奖励
     */
    private void giveOwnerReward(NPC bossNpc) {
        /**拥有者在线时直接加，没在线发邮件给玩家*/
        Role role = SpringUtils.getPlayerService().getPlayerBy(bossNpc.getRoleUid());
        if (SpringUtils.getRoleService().isOnline(role)) {
            ThreadLocalUtil.addLocalTask(role, () -> {
                long oldDaohang = role.getTaoPoint();
                int daohang = bossNpc.getLevel() * OWNER_REWARD_RATE;
                SpringUtils.getRoleService().addTao(role, daohang);
                /**实际加的道行*/
                long add = role.getTaoPoint() - oldDaohang;
                String msg = MessageFormat.format(OWNER_REWARD, bossNpc.getBossSetName(), AsktaoUtil.getFormatTao(add));


                MessagePusher.pushMessage(role, new RespNotifyMiscEx(msg));
            });
        } else {
            String title = MessageFormat.format(OWNER_REWARD_MAIL_TITLE, getNpcName());
            String content = MessageFormat.format(OWNER_REWARD_MAIL_CONTENT, getNpcName());
            Mail mail = SpringUtils.getMailService().createMail(title, content, 30 * TimeUtil.ONE_DAY);
            /**附件中为加的道行值*/
            int daohang = bossNpc.getLevel() * OWNER_REWARD_RATE;
            mail.getDatas().add(NutMap.NEW().setv("data", MessageFormat.format("#I道行|道行#r{0}#I", daohang)).setv("type", Const.mailDaohang).setv("value", daohang));
            SpringUtils.getMailService().sendNewMail(role, mail);
        }
    }

    /**
     * 发杀掉后谣言
     */
    private void pushKillNumor(Role role, NPC bossNpc) {
        Team team = teamService.getTeam(role.getRoleId());
        String memberNames = teamService.getMemberNames(team);
        String msg = MessageFormat.format(KILL_NUMOR, getNpcName(), bossNpc.getLevel(), memberNames);
        SpringUtils.getChatService().sendNumor(msg, Const.BRODCAST_MSG_TYPE_ROLE);
    }

    public void giveReward_nianshou(Role role, FightEndEvent fightEndEvent, NPC boss) {
        NutMap reward = fightEndEvent.getReward();
        int exp = reward.getInt("rewardLevel", 30) * reward.getInt("rewardExp", 0);
        int money = reward.getInt("rewardMoney", 0);
        int daohang = reward.getInt("rewardLevel", 30) * reward.getInt("rewardDaohang", 0);
        int petWuxue = reward.getInt("rewardLevel", 30) * reward.getInt("petRewardWuxue", 0);
        RoleService roleService = SpringUtils.getRoleService();
        if(boss.getfujia_type() == 1){
            if (exp > 0) {
                int currPetId = role.getTempCache("fight_current_pet_id", 0);

                NutMap nutMap = role.getPropsStatus();
                int point = nutMap.getInt("role");
                if (nutMap.getInt("roleStatus") == 1 && point >= 4) {
                    nutMap.setv("role", point - 4);
                    roleService.addExp(role, (exp * 62)*2, role.getLevel(), currPetId);
                } else {
                    roleService.addExp(role, exp * 62, role.getLevel(), currPetId);
                }
            }
        }
        if(boss.getfujia_type() == 2){ ///道行

            if (daohang > 0) {
                if (getNpcType() == NPC.TYPE_WAN_NIAN) {
                    daohang = daohang * 50;
                }
                NutMap nutMap = role.getPropsStatus();
                int point = nutMap.getInt("role");
                if (nutMap.getInt("roleStatus") == 1 && point >= 4) {
                    nutMap.setv("role", point - 4);
                    roleService.addTao(role, daohang * 14);
                } else {
                    roleService.addTao(role, daohang*7);
                }

            }


        }


        int wupinRate = ThreadLocalRandom.current().nextInt(500);
        if (wupinRate < 1) {
            Mail mail = SpringUtils.getMailService().createMail("击杀逃跑年兽", "击杀逃跑年兽", 30 * TimeUtil.ONE_DAY);
            String[] strings = {"1元充值卡"};
            int index = new Random().nextInt(strings.length);
            ArrayList<NutMap> maps = new ArrayList<>();
            maps.add(new NutMap().setv("data", "#I物品|" + strings[index] + "#r1#I").setv("type", Const.mailItem).setv("petName", strings[index]).setv("value", 1));

            mail.getDatas().addAll(maps);
            SpringUtils.getMailService().sendNewMail(role, mail);
        }

    }
    @Override
    public void giveReward(Role role, FightEndEvent fightEndEvent, NPC boss) {
        if (!teamService.isInTeam(role)) {
            MessagePusher.pushMessage(role, new RespNotifyMiscEx("离队无法获得奖励"));
            return;
        }
        if (boss.getType() == NPC.TYPE_BIANYI_YHNS){
            giveReward_nianshou(role,fightEndEvent,boss);
            return;
        }

        NutMap reward = fightEndEvent.getReward();
        int exp = reward.getInt("rewardLevel", 30) * reward.getInt("rewardExp", 0);
        int money = reward.getInt("rewardMoney", 0);
        int daohang = reward.getInt("rewardLevel", 5) * reward.getInt("rewardDaohang", 0);
        int petWuxue = reward.getInt("rewardLevel", 10) * reward.getInt("petRewardWuxue", 0);


        int score = reward.getInt("rewardScore", 2);

        RoleService roleService = SpringUtils.getRoleService();
        if (daohang > 0) {
            if (getNpcType() == NPC.TYPE_WAN_NIAN) {
                daohang = daohang * 50;
            }
            NutMap nutMap = role.getPropsStatus();
            int point = nutMap.getInt("role");
            if (nutMap.getInt("roleStatus") == 1 && point >= 4) {
                nutMap.setv("role", point - 4);
                roleService.addTao(role, daohang * 2);
            } else {
                roleService.addTao(role, daohang);
            }

        }
//        if (money > 0) {
//            roleService.addMoney(role, money);
//        }

        /*击杀上古给与积分奖励*/
//        if (score > 0 && boss.getType() == NPC.TYPE_SHANG_GU) {
//            roleService.addRechargeScore(role, score);
//        }

        roleService.addRechargeScore(role, score);

        if (exp > 0) {
            int currPetId = role.getTempCache("fight_current_pet_id", 0);

            NutMap nutMap = role.getPropsStatus();
            int point = nutMap.getInt("role");
            if (nutMap.getInt("roleStatus") == 1 && point >= 4) {
                nutMap.setv("role", point - 4);
                roleService.addExp(role, exp * 2, role.getLevel(), currPetId);
            } else {
                roleService.addExp(role, exp, role.getLevel(), currPetId);
            }
        }
        // 上古万年掉落30万元宝
        //   roleService.addGold(role, 10000, Reason.hdds_gold_shanngguwannian);
//        if (getNpcType() == NPC.TYPE_WAN_NIAN) {
//            int value = new Random().nextInt(50000);
//            if (value == 1) {
//                String[] strings = {"朱雀(神兽)", "九尾狐(神兽)", "太极熊(精怪)", "墨麒麟(精怪)"};
//                int index = new Random().nextInt(strings.length);
//                String name = strings[index];
//                Mail mail = SpringUtils.getMailService().createMail("击杀万年老妖", "击杀万年老妖", 30 * TimeUtil.ONE_DAY);
//                ArrayList<NutMap> maps = new ArrayList<>();
//                maps.add(new NutMap().setv("data", "#I宠物|" + name + "$1$0$IsFly=0#I").setv("type", Const.mailPet).setv("petName", name.substring(0, name.indexOf("("))));
//                mail.getDatas().addAll(maps);
//                SpringUtils.getMailService().sendNewMail(role, mail);
//                String content = "惊闻玩家#R" + role.getName() + "#n在#R消灭万年老妖#n后，获得#R" + name + "#n！真是可喜可贺！#51 #82";
//                SpringUtils.getChatService().sendAdnotice(content);
//            }
//        }
//        int value = new Random().nextInt(600);
//        if (value == 1) {
//            SpringUtils.getBean(EquipService.class).addMall("道行盛典礼包", false, role);
//            String content = "惊闻玩家#R" + role.getName() + "#n在#R消灭上古妖王#n后，获得#R" + "道行盛典礼包" + "#n！真是可喜可贺！#51 #82";
//            SpringUtils.getChatService().sendAdnotice(content);
//        }
//        SpringUtils.getRoleService().yinde(role, 100);
//        MessagePusher.pushMessage(role, new RespNotifyMiscEx("获得100点阴德！！"));
//        short pos = SpringUtils.getBean(BagService.class).getPos(role, false);
//        if (pos <= 0) {
//            return;
//        }
//        String levels = reward.getString("rewardLevel", "30");
//        int level = Integer.parseInt(levels.substring(0, levels.length() - 1)) * 10;
//        /**装备等级最多120*/
//        if (level > 120) {
//            level = 120;
//        }
//        SpringUtils.getEquipService().getNotIdentifyEquip(level, role, pos);
        role.save();

//        /**5%概率获得1000银元宝*/
//        int rand = ThreadLocalRandom.current().nextInt(1000);
//        if (rand < 50) {
//            int siver = 1000;
//            roleService.addSiver(role, siver, Reason.FIGHT_SHANGGU);
//            String content = String.format(SIVER_REWARD_NOTICE, siver);
//            MessagePusher.pushMessage(role, new RespNotifyMiscEx(content));
//
//            content = String.format(SIVER_REWARD_NUMER, role.getName(), getNpcName());
//            SpringUtils.getChatService().sendNumor(content, Const.BRODCAST_MSG_TYPE_ROLE);
//        }
        /**1%概率获得法宝*/
        int fabaoRate = ThreadLocalRandom.current().nextInt(100);
        if (fabaoRate < 10) {
            Mail mail = SpringUtils.getMailService().createMail("击杀上古万年老妖", "击杀上古万年老妖掉落法宝", 30 * TimeUtil.ONE_DAY);
            String[] strings = {"混元金斗", "番天印", "阴阳镜", "定海珠", "金蛟剪", "九龙神火罩", "卸甲金葫"};
            int index = new Random().nextInt(strings.length);
            ArrayList<NutMap> maps = new ArrayList<>();
            maps.add(new NutMap().setv("data", "#I物品|" + strings[index] + "#r1#I").setv("type", Const.mailFabao).setv("petName", strings[index]).setv("value", 1));
            mail.getDatas().addAll(maps);
            SpringUtils.getMailService().sendNewMail(role, mail);
        }
        int currPetId = role.getTempCache("fight_current_pet_id", 0);
        Pet pet = SpringUtils.getPetService().getPetById(currPetId, role);
        if (pet != null) {
            if (getNpcType() == NPC.TYPE_WAN_NIAN) {
                petWuxue = petWuxue * 2;
            }
            roleService.addPetMatiral(role, pet, petWuxue);
        }
        int wupinRate = ThreadLocalRandom.current().nextInt(100);
        if (wupinRate < 100) {
            Mail mail = SpringUtils.getMailService().createMail("击杀上古万年", "击杀上古万年", 30 * TimeUtil.ONE_DAY);
            String[] strings = {"超级女娲石", "天倾石", "10元充值卡", "天星石"};
            int index = new Random().nextInt(strings.length);
            ArrayList<NutMap> maps = new ArrayList<>();
            maps.add(new NutMap().setv("data", "#I物品|" + strings[index] + "#r1#I").setv("type", Const.mailItem).setv("petName", strings[index]).setv("value", 1));

            mail.getDatas().addAll(maps);
            SpringUtils.getMailService().sendNewMail(role, mail);
        }
        if (wupinRate < 10) {
            Mail mail = SpringUtils.getMailService().createMail("击杀上古万年", "击杀上古万年", 30 * TimeUtil.ONE_DAY);
            String[] strings = {"1元充值卡"};
            int index = new Random().nextInt(strings.length);
            ArrayList<NutMap> maps = new ArrayList<>();
            maps.add(new NutMap().setv("data", "#I物品|" + strings[index] + "#r1#I").setv("type", Const.mailItem).setv("petName", strings[index]).setv("value", 1));

            mail.getDatas().addAll(maps);
            SpringUtils.getMailService().sendNewMail(role, mail);
        }
        roleService.addluoshuExp(role, 2000);
        roleService.addYinde(role, 2000,true);


    }

    @Override
    public void clearNpcTimeOut(NPC npc) {
        clearNpc(npc);
    }

    @Override
    public void doFightFail(Role role, FightEndEvent fightEndEvent) {
        super.doFightFail(role, fightEndEvent);

        teamService.memberHandleThreadLocal(role, memberRole -> SpringUtils.getRoleService().punishFightDead(memberRole));
    }

    @Override
    public void doFightWinForSingle(Role role, FightEndEvent fightEndEvent, NPC bossNpc) {
        if (role.getLastDead() == 0) {
            teamService.memberHandleThreadLocal(role, memberRole -> SpringUtils.getRoleService().punishFightDead(memberRole));
        } else {
            super.doFightWinForSingle(role, fightEndEvent, bossNpc);
            ActivityType activityType = null;
            if (getNpcType() == NPC.TYPE_WAN_NIAN) {
                activityType = ActivityType.SEAL_BOSS;
            } else if(getNpcType() == NPC.TYPE_BIANYI_YHNS) {
                activityType = ActivityType.BHYH_ACTIVTY;
            }

            else {
                activityType = ActivityType.SEAL_BOSS;
            }
            SpringUtils.getActivityService().addFinishCount(role, activityType, 1);
        }

    }

    /**
     * 发送系统消息
     */
    public void sendSystem() {
        SpringUtils.getChatService().sendSystem(SYSTEM_NOTICE, Const.BRODCAST_MSG_TYPE_ROLE);
    }
}
