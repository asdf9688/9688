package com.kitty.game.confirm.service.handler;

import com.kitty.game.role.model.Role;
import com.kitty.common.spring.SpringUtils;
import com.kitty.game.confirm.model.BuyVipConfirm;
import com.kitty.game.confirm.service.handler.ConfirmHandler;
import com.kitty.game.enter.RespVipStatus;
import com.kitty.game.enter.TitleInfo;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.team.message.ReqConfirmResult;
import com.kitty.logs.Reason;
import com.kitty.mina.message.MessagePusher;
import com.kitty.game.fight.service.BroadcastService;
import com.kitty.game.role.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class BuyVipConfirmHandler extends ConfirmHandler{
    @Autowired
    RoleService roleService;
    @Autowired
    BroadcastService broadcastService;
    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
        if ("1".equals(reqConfirmResult.getSelect())) {
            buyVip(role);
        }
    }
    private void buyVip(Role role) {
        BuyVipConfirm confirm = (BuyVipConfirm) role.getConfirm();
        int price =confirm.getPrice();
        if (price >= 3000) {
            int roleGold = role.getGold();
            if (roleGold > price) {
                int expireTime = role.getExpireTime();
                if (expireTime == 0) {// 没有买过会员
                    expireTime = new Long(new Date().getTime() / 1000).intValue();
                }
                int currTime = new Long(new Date().getTime() / 1000).intValue();
                byte vipType = 1;
                if (price == 3000) {// 月卡
                    expireTime += 86400 * 30;
                } else if (price == 9000) {// 季卡
                    expireTime += 86400 * 90;
                } else if (price == 36000) {// 年卡
                    expireTime += 86400 * 365;
                }
                TitleInfo titleInfo = new TitleInfo();
                titleInfo.setType("位列仙班");
                titleInfo.setTitle("位列仙班·灵识初开");
                int lastDay = new Long((expireTime - currTime) / 86400).intValue();
                if (lastDay >= 365) {
                    vipType = 3;
                    titleInfo.setTitle("位列仙班·大道无穷");
                } else if (lastDay >= 90) {
                    vipType = 2;
                    titleInfo.setTitle("位列仙班·道法自然");
                }
                titleInfo.setTime(expireTime);
                roleService.addTitle(role, titleInfo);
                role.setVipType(vipType);
                role.setExpireTime(expireTime);

                SpringUtils.getRoleService().subtractGold(role, price, Reason.BUY_VIP);

                roleService.updateRoleGoldAndSiver(role);
                RespVipStatus RespVipStatus = new RespVipStatus(); // 会员状态
                RespVipStatus.setType(role.getVipType());
                RespVipStatus.setExpireTime(role.getExpireTime());
                RespVipStatus.setReceive(role.isReceive());
                MessagePusher.pushMessage(role, RespVipStatus);

                RespNotifyMiscEx respNotifyMiscEx = new RespNotifyMiscEx();
                respNotifyMiscEx.setMsg("购买成功，花费了#R" + price + "#n元宝，位列仙班剩余天数：#R" + lastDay + "#n天。");
                MessagePusher.pushMessage(role, respNotifyMiscEx);
                broadcastService.sendUpdateAppear(role);
            }
        }
    }
}
