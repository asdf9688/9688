package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

@MessageMeta(module = Modules.MSG_MAILBOX_REFRESH)
public class RespaddVerifyInfo extends Message {

    private short a = 1;
    private String b = "6|21";
    private byte c = 0;
    private short d = 768;
    private String e = "6|21";
    private int f = 0;
    private int time;
    private int time1;
    private short g = 1;

    public short getA() {
        return a;
    }

    public void setA(short a) {
        this.a = a;
    }

    public String getB() {
        return b;
    }

    public void setB(String b) {
        this.b = b;
    }

    public byte getC() {
        return c;
    }

    public void setC(byte c) {
        this.c = c;
    }

    public short getD() {
        return d;
    }

    public void setD(short d) {
        this.d = d;
    }

    public String getE() {
        return e;
    }

    public void setE(String e) {
        this.e = e;
    }

    public int getF() {
        return f;
    }

    public void setF(int f) {
        this.f = f;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public int getTime1() {
        return time1;
    }

    public void setTime1(int time1) {
        this.time1 = time1;
    }

    public short getG() {
        return g;
    }

    public void setG(short g) {
        this.g = g;
    }
}
