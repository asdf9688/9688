package com.kitty.game.confirm.model;

import com.kitty.game.config.Fasion;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

public class BuyEffectConfirm extends RoleConfirm {

    /**
     * 购买的特效
     */
    private Fasion fasion;

    public BuyEffectConfirm(Fasion fasion) {

        this.fasion = fasion;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.BUY_EFFECT;
    }

    public Fasion getFasion() {
        return fasion;
    }
}
