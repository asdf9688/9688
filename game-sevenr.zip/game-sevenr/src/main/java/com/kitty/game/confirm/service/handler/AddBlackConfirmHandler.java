package com.kitty.game.confirm.service.handler;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.confirm.model.AddBlackConfirm;
import com.kitty.game.role.model.Role;
import com.kitty.game.team.message.ReqConfirmResult;
import org.springframework.stereotype.Component;

@Component
public class AddBlackConfirmHandler extends ConfirmHandler {
    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
        if ("1".equals(reqConfirmResult.getSelect())) {
            AddBlackConfirm addBlackConfirm = (AddBlackConfirm)role.getConfirm();
            SpringUtils.getFriendService().confirmAddBlack(role, addBlackConfirm.getTargetName());
        }
    }
}
