package com.kitty.game.bag.model;

import com.kitty.common.db.BaseEntity;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

@Table("p_gift_bag")
public class GiftBag extends BaseEntity<Integer> {
    @Id
    private Integer id;

    @Column
    @Comment("礼包名称")
    private String name;

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

}
