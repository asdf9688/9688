package com.kitty.game.attribute;

import org.nutz.lang.util.NutMap;

import java.util.Map;
import java.util.Set;

/**属性相关的配置*/
public class AttributeDataPool {

    /**装备基础属性最大值 属性英文名->装备位置-> 值为Set 1-200级 按位置取*/
    public static NutMap fieldMaxMap;

    /**套装固定属性的最大值 属性英文名->装备位置-> 值为Set 1-200级 按位置取*/
    public static NutMap suitFieldMaxMap;

    /**套装固定属性的最小值 属性英文名->装备位置-> 值为Set 1-200级 按位置取*/
    public static NutMap suitFieldMinMap;

    /**装备基础属性最小值 属性英文名->装备位置-> 值为Set 1-200级 按位置取*/
    public static NutMap fieldMinMap;

    /**特殊属性  取到值说明是特殊属性*/
    public static NutMap specialFiledMap;

    /**属性名的中文名 中文名对应的英文名*/
    public static Map<String,String> nameToName;

    /**属性名的英文名对应的属性ID*/
    public static Map<String,String> nameToFieldId;

    /**基础属性 pos > map level > value*/
    public static NutMap basicAttrib;

    /**属性值按百分比显示的属性名集合*/
    public static Set<String> percentFiledNames;
}
