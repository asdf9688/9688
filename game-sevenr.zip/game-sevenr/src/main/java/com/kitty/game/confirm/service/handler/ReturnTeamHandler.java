package com.kitty.game.confirm.service.handler;

import com.kitty.game.role.model.Role;
import com.kitty.common.spring.SpringUtils;
import com.kitty.game.team.message.ReqConfirmResult;
import com.kitty.game.team.model.Team;
import org.springframework.stereotype.Component;
import com.kitty.game.confirm.service.handler.ConfirmHandler;

@Component
public class ReturnTeamHandler extends ConfirmHandler{
    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
        /**同意归队*/
        if(reqConfirmResult.getSelect().equals("1")){
            Team team = SpringUtils.getTeamService().getTeam(role.getRoleId());
            if (team == null) {
                return;
            }
            SpringUtils.getTeamService().returnTeam(role);
            SpringUtils.getTeamService().sendTeamChangeMsg(team, "#Y#<" + role.getName() + "#>#n回到了队伍。");
        }
    }
}
