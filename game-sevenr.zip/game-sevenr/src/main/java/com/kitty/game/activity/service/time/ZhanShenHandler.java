package com.kitty.game.activity.service.time;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.activity.model.product.ActivityType;
import com.kitty.game.base.service.BagService;
import com.kitty.game.boss.config.BossSet;
import com.kitty.game.boss.model.BossFightParam;
import com.kitty.game.boss.model.BossParam;
import com.kitty.game.boss.service.NewBossService;
import com.kitty.game.config.NPC;
import com.kitty.game.config.OnlineMall;
import com.kitty.game.enter.Position;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.equip.service.EquipService;
import com.kitty.game.fight.bean.Fight;
import com.kitty.game.i18n.I18nId;
import com.kitty.game.i18n.I18nIdDataPool;
import com.kitty.game.mail.model.Mail;
import com.kitty.game.npc.model.NpcButton;
import com.kitty.game.pet.model.Pet;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.PayService;
import com.kitty.game.role.service.RoleService;
import com.kitty.game.team.model.Team;
import com.kitty.game.utils.Const;
import com.kitty.game.utils.TimeUtil;
import com.kitty.listener.event.FightEndEvent;
import com.kitty.logs.LoggerFunction;
import com.kitty.logs.Reason;
import com.kitty.mina.cache.DataCache;
import com.kitty.mina.message.MessagePusher;
import org.nutz.lang.util.NutMap;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import com.kitty.game.activity.service.time.FightActivityHandler;

/**
 * 战神处理类
 */
@Component
public class ZhanShenHandler extends FightActivityHandler {
    /**
     * 天墉城、无名小镇和东海渔村
     */
    private static final List<Integer> MAPIDS = Arrays.asList(5000);
    /**
     * 每小时刷新战神的数量
     */
    private static final int COUNT_PER_HOUR = 20;
    /**
     * 战神npc显示名称
     */
    private static final String NAME = "战神";
    private static final String SMALL_BOSS_NAME = "战将";
    /**
     * 战神icon
     */
    private static final int ICON = 6232;
    /**
     * 战神持续时间，单位毫秒
     */
    private static final long NPC_CONTINUED_TIME = 60 * TimeUtil.ONE_MINUTE;
    private static final String CONTENT = "只有最勇敢的人，才可以得到最好的装备！\n#R战斗结束时死亡的角色会受到惩罚。#n[我要挑战/" + NpcButton.FIGHT_TO_ZHANSHEN.getKey() + "][离开]";

    private static final String IN_FIGHT = "即使是神仙，也不能一次对付两个。[离开]";
    /**
     * 最少组队人数
     */
    private static final int MIN_TEAM_COUNT = 1;
    private static final String TEAM_COUNT_NOT_ENOUGH = "你还是凑齐三个人再来向我挑战吧！[离开]";
    private static final int ACCEPT_MIN_LEVEL = 40;
    private static final String TEAM_LEVEL_NOT_ENOUGH = "#Y{0}#n的等级还没有{1}级。[离开]";

    /**
     * 刷新战神，显示在对应的地图上
     */
    public void flushNpc() {
        LoggerFunction.BUG.getLogger().warn("开始刷新战神！！！");
        for (int i = 0; i < COUNT_PER_HOUR; i++) {
            /**随机地图*/
            int mapId = getRandomMapId();
            createNpc(mapId);
        }
    }

    private int getRandomMapId() {
        int rand = ThreadLocalRandom.current().nextInt(MAPIDS.size());
        return MAPIDS.get(rand);
    }

    private void createNpc(int mapId) {
        Position position = getRandomPosition(mapId);

        NPC npc = new NPC();
        npc.setIcon(ICON);
        npc.setId(SpringUtils.getBean(NewBossService.class).getTempNpcId());
        npc.setX(position.getX());
        npc.setY(position.getY());
        npc.setFangxiang((short) new Random().nextInt(8));/*随机方向*/
        npc.setMapId(mapId);
        npc.setCreateTime(System.currentTimeMillis());
        npc.setEndTime(npc.getCreateTime() + NPC_CONTINUED_TIME);
        npc.setType(NPC.TYPE_ZHAN_SHEN);
        npc.setContent(CONTENT);
        npc.setName(NAME);
        npc.setBossSetName(NAME);
        bossService.addTaskNpc(npc);
        bossService.broadcastNpcShow(null, npc);
    }

    @Override
    protected String getNpcContent(Role role, NPC bossNpc) {
        return null;
    }

    @Override
    protected String getNpcContentNotFight(Role role, NPC bossNpc) {
        /**检测是否在战斗中*/
        if (bossNpc.isInFight()) {
            return IN_FIGHT;
        }

        /**检测队伍人数*/
        int teamCount = teamService.getTeamCount(role);
        if (teamCount < MIN_TEAM_COUNT) {
            return TEAM_COUNT_NOT_ENOUGH;
        }

        /**检测等级*/
        Team team = teamService.getTeam(role.getRoleId());
        String names = teamService.checkMember(team, memberRole -> memberRole.getLevel() < ACCEPT_MIN_LEVEL);
        if (names != null) {
            return MessageFormat.format(TEAM_LEVEL_NOT_ENOUGH, names, ACCEPT_MIN_LEVEL);
        }

        names = teamService.checkMember(team, memberRole -> getRoleRemainCount(memberRole) <= 0);
        if (names != null) {
            return "#R" + names + "#n没有挑战次数";
        }
        if (getRoleRemainCount(role) <= 0) {
            return "#R" + role.getName() + "#n没有挑战次数";
        }
        return null;
    }

    private byte getRoleRemainCount(Role role) {
        return (byte) SpringUtils.getActivityService().getRemainCount(role, ActivityType.zhansheng_ACTIVTY);
    }

    @Override
    protected void doStartFight(Role role, NPC bossNpc) {
        List<BossParam> bossParamList = newBossParamList(role, bossNpc);
        BossFightParam bossFightParam = new BossFightParam(bossParamList, getFightType(role));
        bossFightParam.setNpcId(bossNpc.getId());
        int maxRoleLevel = teamService.getMaxRoleLevelInTeam(role);
        bossFightParam.setNpcLevel((short) maxRoleLevel);
        Fight fight = bossService.startFightToBoss(role, bossFightParam);
        /*if (null != fight) {
//        	int gold = 50000;
            int score = 1;
            teamService.memberHandle(role, memberRole ->
                    {
                        SpringUtils.getRoleService().substractChargeScore(role, score);
                        MessagePusher.pushMessage(role, new RespNotifyMiscEx("战斗消耗#R" + score + "#n积分！"));
                    }
            );
        }*/
    }

    private List<BossParam> newBossParamList(Role role, NPC bossNpc) {
        List<BossParam> bossParamList = new ArrayList<>();
        int count = 10;

        /**npc对应的加在第1个*/
        BossSet bossSet = bossService.getBossSet(bossNpc.getBossSetName());
        bossParamList.add(new BossParam(bossSet, bossNpc.getName()));

        /**加count-1个*/
        for (int i = 1; i < count; i++) {
            bossSet = bossService.getBossSet(SMALL_BOSS_NAME);
            bossParamList.add(new BossParam(bossSet, SMALL_BOSS_NAME));
        }

        return bossParamList;
    }

    @Override
    protected int getFightType(Role role) {
        return Const.fightType_zhanShen;
    }

    @Override
    protected NPC getBossNpc(int npcId) {
        return SpringUtils.getMapService().getNpc(npcId);
    }

    @Override
    protected void clearNpcAfterWin(Role role, NPC bossNpc) {
        clearNpc(bossNpc);
    }

    private void clearNpc(NPC npc) {
        if (npc == null) {
            return;
        }

        bossService.delTaskNpc(npc);
        removeUsedPosition(npc.getMapId(), npc.getX(), npc.getY());
        bossService.broadcastNpcHide(null, npc);
    }

    @Override
    protected void giveReward(Role role, FightEndEvent fightEndEvent, NPC bossNpc) {
        if (!teamService.isInTeam(role)) {
            MessagePusher.pushMessage(role, new RespNotifyMiscEx("离队无法获得奖励"));
            return;
        }
        /**道行武学奖励*/
        NutMap reward = fightEndEvent.getReward();
        int exp = role.getLevel() * reward.getInt("rewardExp", 0);
        int daohang = fightEndEvent.getReward().getInt("rewardDaohang", 1) * role.getLevel();
        int petWuxue = fightEndEvent.getReward().getInt("petRewardWuxue", 3) * role.getLevel();
        RoleService roleService = SpringUtils.getRoleService();
        roleService.addTao(role, daohang);
        int currPetId = role.getTempCache("fight_current_pet_id", 0);
        Pet pet = SpringUtils.getPetService().getPetById(currPetId, role);
        if (pet != null) {
            roleService.addPetMatiral(role, pet, petWuxue);
        }
        NutMap nutMap = role.getPropsStatus();
        int point = nutMap.getInt("role");
        if (nutMap.getInt("roleStatus") == 1 && point >= 4) {
            nutMap.setv("role", point - 4);
            role.save();
            roleService.addExp(role, exp * 2, role.getLevel(), currPetId);//除暴 怪物按照20级算
        } else {
            roleService.addExp(role, exp, role.getLevel(), currPetId);//除暴 怪物按照20级算
        }

        SpringUtils.getRoleService().addRechargeScore(role,2);

        // 奖励装备
        short roleLevel = role.getLevel();
        String temp = roleLevel + "";
        if (temp.length() == 3) {
            roleLevel = Short.parseShort(temp.substring(0, 2) + 0);
        } else {
            roleLevel = Short.parseShort(temp.substring(0, 1) + 0);
        }

        BagService bagService = SpringUtils.getBean(BagService.class);
        EquipService equipService = SpringUtils.getBean(EquipService.class);

        short newPos = bagService.getPos(role, false);
        if (newPos > 0) {
            equipService.getNotIdentifyEquip(roleLevel, role, newPos);
        } else {
            MessagePusher.pushMessage(role, new RespNotifyMiscEx("背包已满，请整理背包"));
            return;
        }

        int fabaoRate = ThreadLocalRandom.current().nextInt(10000);
        if (fabaoRate < 1) {
            Mail mail = SpringUtils.getMailService().createMail("击杀战神", "击杀战神落法宝", 30 * TimeUtil.ONE_DAY);
            String[] strings = {"混元金斗", "番天印", "阴阳镜", "定海珠", "金蛟剪", "九龙神火罩", "卸甲金葫"};
            int index = new Random().nextInt(strings.length);
            ArrayList<NutMap> maps = new ArrayList<>();
            maps.add(new NutMap().setv("data", "#I物品|" + strings[index] + "#r1#I").setv("type", Const.mailFabao).setv("petName", "18级" + strings[index]).setv("level", 18));
            mail.getDatas().addAll(maps);
            SpringUtils.getMailService().sendNewMail(role, mail);
        }
        int wupinRate = ThreadLocalRandom.current().nextInt(100);
        if (wupinRate < 20) {
            Mail mail = SpringUtils.getMailService().createMail("击杀战神", "击杀战神", 30 * TimeUtil.ONE_DAY);
            String[] strings = {"超级女娲石", "天倾石", "10元充值卡", "天星石"};
            int index = new Random().nextInt(strings.length);
            ArrayList<NutMap> maps = new ArrayList<>();
            maps.add(new NutMap().setv("data", "#I物品|" + strings[index] + "#r1#I").setv("type", Const.mailItem).setv("petName", strings[index]).setv("value", 1));

            mail.getDatas().addAll(maps);
            SpringUtils.getMailService().sendNewMail(role, mail);
        }
        if (wupinRate < 5) {
            Mail mail = SpringUtils.getMailService().createMail("击杀战神获得充值卡", "击杀战神获得充值卡", 30 * TimeUtil.ONE_DAY);
            String[] strings = {"1元充值卡"};
            int index = new Random().nextInt(strings.length);
            ArrayList<NutMap> maps = new ArrayList<>();
            maps.add(new NutMap().setv("data", "#I物品|" + strings[index] + "#r1#I").setv("type", Const.mailItem).setv("petName", strings[index]).setv("value", 1));

            mail.getDatas().addAll(maps);
            SpringUtils.getMailService().sendNewMail(role, mail);
        }
    }

    @Override
    protected void clearNpcTimeOut(NPC npc) {
        clearNpc(npc);
    }

    @Override
    public void doFightFail(Role role, FightEndEvent fightEndEvent) {
        super.doFightFail(role, fightEndEvent);

        teamService.memberHandleThreadLocal(role, memberRole -> SpringUtils.getRoleService().punishFightDead(memberRole));
    }
}
