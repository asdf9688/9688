package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

@MessageMeta(module = Modules.MSG_DISAPPEAR)
public class RespDisappear extends Message {
    private int id;
    private short type = 1; //1是玩家 2是队长 4是NPC 32768是跟随宠物或者跟宠

    public RespDisappear(int id,int type) {
        this.id = id;
        this.type = (short) type;
    }
    public RespDisappear() {
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }
}
