package com.kitty.game.activity.message.vo;

import lombok.Setter;

@Setter
public class DailyStatsInfo {
    private int exp;

    private int tao;

    private int taoPoint;

    private int monTao;

    private int monTaoEx;

    private int pot;

    private int death;

    private int onlineTime;

    private int shuaDaoTimes;

    private int orgIcon;

    private short level;

    private String name;

    private String partyName;


    public void setExp(int exp) {
        this.exp = exp;
    }

    public void setTao(int tao) {
        this.tao = tao;
    }

    public void setTaoPoint(int taoPoint) {
        this.taoPoint = taoPoint;
    }

    public void setMonTao(int monTao) {
        this.monTao = monTao;
    }

    public void setMonTaoEx(int monTaoEx) {
        this.monTaoEx = monTaoEx;
    }

    public void setPot(int pot) {
        this.pot = pot;
    }

    public void setDeath(int death) {
        this.death = death;
    }

    public void setOnlineTime(int onlineTime) {
        this.onlineTime = onlineTime;
    }

    public void setShuaDaoTimes(int shuaDaoTimes) {
        this.shuaDaoTimes = shuaDaoTimes;
    }

    public void setOrgIcon(int orgIcon) {
        this.orgIcon = orgIcon;
    }

    public void setLevel(short level) {
        this.level = level;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPartyName(String partyName) {
        this.partyName = partyName;
    }
}
