package com.kitty.game.confirm.model;


import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

public class BuyVipConfirm extends RoleConfirm {

    private int price;
    public BuyVipConfirm(int price) {
        this.price=price;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.BUY_VIP;
    }

    public int getPrice() {
        return price;
    }
}
