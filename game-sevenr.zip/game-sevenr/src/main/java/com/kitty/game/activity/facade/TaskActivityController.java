package com.kitty.game.activity.facade;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.activity.message.ReqFetchShuaDaoScoreItem;
import com.kitty.game.activity.message.ReqLeaveDugeon;
import com.kitty.game.activity.service.ActivityService;
import com.kitty.game.activity.service.task.ShuaDaoTaskHandler;
import com.kitty.game.role.model.Role;
import com.kitty.game.task.service.taskHandler.DugeonTaskHandler;
import com.kitty.listener.EventType;
import com.kitty.listener.annotation.EventHandler;
import com.kitty.listener.event.*;
import com.kitty.mina.annotation.RequestMapping;
import com.kitty.mina.cache.SessionUtils;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
//后加
import com.kitty.listener.event.FightEndEvent;
import com.kitty.listener.event.HeartBeatEvent;
import com.kitty.listener.event.LoginEvent;
import com.kitty.listener.event.LogoutEvent;
import com.kitty.listener.event.RoleExpireEvent;
import com.kitty.listener.event.TalkEndEvent;
import com.kitty.listener.event.TeamChangeLeaderEvent;
import com.kitty.listener.event.TeamLeaveEvent;
import com.kitty.listener.event.TeamLeaveMomentEvent;

@Controller
public class TaskActivityController {
    @Autowired
    ActivityService activityService;

    /**处理战斗结束事件*/
    @EventHandler(EventType.FIGHT_END)
    public void handleFightEndEvent(FightEndEvent fightEndEvent) {
        Logger logger = LoggerFactory.getLogger(getClass());
//        logger.warn("战斗结束uid:{}, fightId:{}", fightEndEvent.getPlayerUid(), fightEndEvent.getFightId());

        activityService.handleFightEnd(fightEndEvent);
    }

    /**处理离开队伍事件*/
    @EventHandler(EventType.TEAM_LEAVE)
    public void handleTeamLeaveEvent(TeamLeaveEvent teamLeaveEvent) {
        Role role = teamLeaveEvent.getRole();
        activityService.handleLeaveTeam(role, teamLeaveEvent.isLeader(), teamLeaveEvent.getMemberList());
    }

    /**处理暂离队伍事件*/
    @EventHandler(EventType.TEAM_LEAVE_MOMENT)
    public void handleTeamLeaveMonmentEvent(TeamLeaveMomentEvent teamLeaveMomentEvent) {
        /**暂离操作事件，只有队员才有*/
        Role role = teamLeaveMomentEvent.getRole();
        activityService.handleTeamLeaveMonment(role);
    }

    /**处理转移队长事件*/
    @EventHandler(EventType.TEAM_CHANGE_LEADER)
    public void handleTeamChangeLeaderEvent(TeamChangeLeaderEvent teamChangeLeaderEvent) {
        Role role = teamChangeLeaderEvent.getRole();
        activityService.handleTeamChangeLeader(role, teamChangeLeaderEvent.getMemberList());
    }

    /**处理登出事件*/
    @EventHandler(EventType.LOGOUT)
    public void handleLogoutEvent(LogoutEvent LogoutEvent) {
        Role role = LogoutEvent.getRole();
        activityService.handleLogout(role);
    }

    @EventHandler(EventType.LOGIN)
    public void handleLoginEvent(LoginEvent loginEvent) {
        Role role = loginEvent.getRole();
        activityService.handleLogin(role);
    }

    /**在心跳事件中处理超时任务*/
    @EventHandler(EventType.HEART_BEAT)
    public void handleHeartBeat(HeartBeatEvent heartBeatEvent) {
        Role role = heartBeatEvent.getRole();
        if (role == null) {return ;}

//        activityService.handleHeartBeat(role, heartBeatEvent.getPrevHeartTime());
    }

    @EventHandler(EventType.TALK_END)
    public void handleTalkEndEvent(TalkEndEvent talkEndEvent) {
        Role role = talkEndEvent.getRole();
        activityService.handleTalkEnd(role);
    }

    @EventHandler(EventType.ROLE_EXPIRE)
    public void handleRoleExpireEvent(RoleExpireEvent roleExpireEvent) {
        Role role = roleExpireEvent.getRole();
        activityService.handleRoleExpire(role);
    }

    @RequestMapping
    public void handleFetchShuaDaoScoreItem(IoSession session, ReqFetchShuaDaoScoreItem reqFetchShuaDaoScoreItem) {
        Role role = SessionUtils.getRoleBySession(session);
        SpringUtils.getBean(ShuaDaoTaskHandler.class).fetchReward(role, reqFetchShuaDaoScoreItem.getType(), reqFetchShuaDaoScoreItem.getIndex());
    }

    @RequestMapping
    public void leaveDegeon(Role role, ReqLeaveDugeon reqLeaveDugeon) {
        SpringUtils.getBean(DugeonTaskHandler.class).leaveDegeon(role);
    }
}
