package com.kitty.game.chat.message;

import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;
import lombok.Setter;

@MessageMeta(module = Modules.MSG_TEMP_FRIEND_STATE)
@Setter
public class RespTempFriendState extends Message {
    private String gid;
    private byte online;

    public void setGid(String gid) {
        this.gid = gid;
    }

    public void setOnline(byte online) {
        this.online = online;
    }
}
