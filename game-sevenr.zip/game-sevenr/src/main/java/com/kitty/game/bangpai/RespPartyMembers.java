package com.kitty.game.bangpai;

import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

import java.util.List;
//后写
import com.kitty.game.bangpai.PartyMember;

@MessageMeta(module = Modules.MSG_PARTY_MEMBERS)
public class RespPartyMembers extends Message {
  
    private short page=0;
  
    private short tail=0;
  
    private List<PartyMember> list;

    public List<PartyMember> getList() {
        return list;
    }

    public void setList(List<PartyMember> list) {
        this.list = list;
    }
}
