package com.kitty.game.activity.service.task;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.ServerService;
import com.kitty.game.activity.service.ActivityHandler;
import com.kitty.game.boss.model.BossNpcParam;
import com.kitty.game.boss.service.NewBossService;
import com.kitty.game.config.NPC;
import com.kitty.game.config.TaskSet;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.fight.bean.Fight;
import com.kitty.game.map.model.GroupMapParam;
import com.kitty.game.map.service.MapService;
import com.kitty.game.npc.message.RespAutoWalk;
import com.kitty.game.role.model.Role;
import com.kitty.game.task.message.RespTasksDel;
import com.kitty.game.task.message.vo.TaskInfo;
import com.kitty.game.task.model.product.TaskType;
import com.kitty.game.task.service.NewTaskService;
import com.kitty.game.team.model.Member;
import com.kitty.game.team.model.Team;
import com.kitty.game.team.service.TeamService;
import com.kitty.listener.event.FightEndEvent;
import com.kitty.logs.LoggerUtils;
import com.kitty.mina.message.MessagePusher;
import com.kitty.mina.task.ThreadLocalUtil;
import org.nutz.json.Json;
import org.nutz.json.JsonFormat;
import org.nutz.lang.util.NutMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

@Component
public abstract class TaskActivityHandler extends ActivityHandler {
    @Autowired
    NewTaskService taskService;
    @Autowired
    TeamService teamService;

    /**在NPC处接取任务*/
    public boolean acceptTaskAtNpc(Role role, NPC npc, boolean auto) {
        TaskSet taskSet = getAcceptingTask(role, npc);

        String content = acceptTask(role, taskSet, auto);
        // content不为空表示不符合条件
        if (content != null) {
            // mod tao 这里的content不能被原有的覆盖，
//            this.sendNpcContent(role, npc, content);
            SpringUtils.getNpcService().sendPurNpcContent(role, npc, content);
            // mod:e
            return false;
        }

        /**不是自动接取时，检测弹出开启驱魔香*/
        if (auto == false) {
            SpringUtils.getFightService().checkOpenAvoidMonster(role);
        }

        return true;
    }

    /**接取任务*/
    public String acceptTask(Role role, TaskSet taskSet, boolean auto) {
        String content = canAcceptTask(role, taskSet, auto);
        if (content != null) {
            return content;
        }

        doBeforeAccept(role, taskSet);

        doAcceptTask(role, taskSet);
        // mod tao 接了任务之后立刻去做，不是2秒后再做
        TaskActivityHandler.this.doAfterAccept(role, taskSet);

//        SpringUtils.getBean(ServerService.class).getScheduledExecutorService().schedule(new Runnable() {
//            @Override
//            public void run() {
//                doAfterAccept(role, taskSet);
//            }
//        },2, TimeUnit.SECONDS);


        return null;
    }

    /**获得要接取的任务*/
    public abstract TaskSet getAcceptingTask(Role role, NPC npc);

    /**检测能否接取任务*/
    public abstract String canAcceptTask(Role role, TaskSet taskSet, boolean auto);

    public void doBeforeAccept(Role role, TaskSet taskSet) {

    }

    public void deleteTask(Role role, TaskSet taskSet) {
        Team team = SpringUtils.getBean(TeamService.class).getTeam(role.getRoleId());
        if (teamService.isInTeam(role)) {
            /**组队*/
            doDeleteTaskForTeam(team, taskSet);
        } else {
            /**个人*/
            deleteTaskForSingle(role, taskSet);
        }
    }

    /**删除队伍中所有成员的任务*/
    private void doDeleteTaskForTeam(Team team, TaskSet taskSet) {
        doDeleteTaskForTeam(team.getList(), team.getLeaderRoleId(), taskSet);
    }

    public void doDeleteTaskForTeam(List<Member> members, int leaderRoleId, TaskSet taskSet) {
        for (Member member : members) {
            /**不知道有没可能出现null的情况*/
            if (member == null) {continue;}
            /**成员暂离时，不对其进行操作*/
            if (member.isInTeam() == false) {continue;}

            /**需要判断当前成员是否已经接取过任务，是的话需要把成员的任务清空，并把对应NPC删除*/
            /**理论上应该把成员自己的操作，发给成员自己的操作线程处理，而不是在队长的线程中处理*/

            /**删除任务*/
            if (leaderRoleId == member.getRoleId()) {
                /**删除队长的*/
                Role role = SpringUtils.getRoleService().getOnlinePlayer(member.getRoleId());
                deleteTaskForSingle(role, taskSet);
            } else {
                /**删除不是队长的*/
                deleteMemberTask(member, taskSet);
            }
        }
    }

    /**是否可以删除任务*/
    public boolean isDeleteTask(Role role, TaskSet taskSet) {
        /**没有接任务时，则返回不用删除*/
        return SpringUtils.getBean(NewTaskService.class).isTaskAccepted(role, taskSet);
    }

    /**删除任务*/
    public void deleteTaskForSingle(Role role, TaskSet taskSet) {
        if (isDeleteTask(role, taskSet) == false) {return ;}

        /**删除对应NPC*/
        int taskNpcId = role.getTask().getTaskNpcId(taskSet.getId());
        MapService mapService = SpringUtils.getBean(MapService.class);
        NPC npc = mapService.getNpc(taskNpcId);
        if (npc != null && role.getUid()==npc.getRoleUid()) {
//            logger.warn("[ACTIVITY]|deleteNpc|{}|{}|{}|{}|{}", role.getUid(), taskSet.getId(), npc.getId(), npc.getName(), npc.getRoleUid());
            NewBossService bossService = SpringUtils.getBean(NewBossService.class);
            bossService.delTaskNpc(npc);

            bossService.broadcastNpcHide(new GroupMapParam(role), npc);
//            try {
//                throw new IllegalArgumentException("删除npc");
//            }catch (Exception e){
//                logger.error("删除npc===={}",e);
//            }
        }

        /**最后才删除任务数据*/
        role.getTask().deleteTask(taskSet.getId());
        role.save();

        /**隐藏显示*/
        RespTasksDel respTasksDel = new RespTasksDel();
        respTasksDel.setList(new ArrayList<>());
        respTasksDel.getList().add(taskSet.getTaskName());
        MessagePusher.pushMessage(role, respTasksDel);

//        try {
//            throw new IllegalArgumentException("刷道删除npc");
//        }catch (Exception e){
//            logger.error("刷道==",e);
//        }
        if (npc != null) {
//            logger.warn("[ACTIVITY]|deleteTask|{}|{}|{}|{}|{}", role.getUid(), taskSet.getId(), npc.getId(), npc.getName(), npc.getRoleUid());
        } else {
//            logger.warn("[ACTIVITY]|deleteTask|{}|{}|{}|{}|{}", role.getUid(), taskSet.getId(), "", "", "");
        }
    }

    /**删除成员的任务*/
    private void deleteMemberTask(Member member, TaskSet taskSet) {
        Role role = SpringUtils.getRoleService().getOnlinePlayer(member.getUid());
        if (role == null) {return ;}
        /**删除对应任务*/
        ThreadLocalUtil.addLocalTask(role, () -> deleteTaskForSingle(role, taskSet));
    }

    /**是否是组队接取任务，默认为true*/
    public boolean isTeamAcceptTask() {
        return  true;
    }

    public void doAcceptTask(Role role, TaskSet taskSet) {
        /**个人接取和组队接取*/
        if (isTeamAcceptTask() && teamService.isInTeam(role)) {
            /**组队接取*/
            Team team = SpringUtils.getBean(TeamService.class).getTeam(role.getRoleId());
            doAcceptTaskForTeam(team, taskSet);
        } else {
            /**个人接取*/
            doAcceptTaskForSingle(role, taskSet);
        }
    }

    /**组队接取*/
    public void doAcceptTaskForTeam(Team team, TaskSet taskSet) {
        /**整队接取，但暂离队员接取不到任务*/
        Role role = SpringUtils.getRoleService().getOnlinePlayer(team.getLeaderUid());

        List<Member> members = team.getList();
        NPC npc = getOrCreateNpc(taskSet, role);

        for (Member member : members) {
            /**不知道有没可能出现null的情况*/
            if (member == null) {continue;}
            /**成员暂离时，不接取任务*/
            if (member.isInTeam() == false) {continue;}

            if (team.isLeader(member.getRoleId())) {
                /**队长*/
                //Role role = SessionUtils.getRoleById(member.getRoleId());
                acceptTask(role, taskSet, npc);
            } else {
                /**不是队长*/
                acceptMemberTask(member, taskSet, npc);
            }
        }

        TeamService teamService = SpringUtils.getBean(TeamService.class);

        /**发提示消息*/
        String prompt = getPrompt(npc);
        teamService.pushMessageToTeam(team, new RespNotifyMiscEx(prompt));
    }

    /**成员是否可以接取任务，默认可以*/
    public boolean isMemberAcceptTask(Role role, TaskSet taskSet) {
        return true;
    }

    private NPC getOrCreateNpc(TaskSet taskSet, Role role) {
//        try {
//            throw new IllegalArgumentException("创建npc");
//        }catch (Exception e){
//            logger.error("",e);
//        }
        if (isCreateNpcForFight(taskSet)) {
            /**生成任务的NPC*/
            return createNpc(role, taskSet);
        } else {
            /**获得任务的NPC*/
            return getNpc(role, taskSet);
        }
    }

    /**个人接取*/
    public void doAcceptTaskForSingle(Role role, TaskSet taskSet) {
        /**生成任务的NPC*/
        NPC npc = getOrCreateNpc(taskSet, role);
        acceptTask(role, taskSet, npc);

        /**发提示消息*/
        String prompt = getPrompt(npc);
        if (prompt != null && prompt.trim().length() != 0) {
            MessagePusher.pushMessage(role, new RespNotifyMiscEx(prompt));
        }
    }

    /**生成NPC对象*/
    private NPC createNpc(Role role, TaskSet taskSet) {
        BossNpcParam bossNpcParam = newBossNpcParam(role, taskSet);
        NewBossService bossService = SpringUtils.getBean(NewBossService.class);
        return bossService.createBossNpc(role, bossNpcParam);
    }

    public NPC getNpc(Role role, TaskSet taskSet) {
        return SpringUtils.getBean(MapService.class).getNpcByName(taskSet.getNpcName());
    }

    /**接取任务操作*/
    public void acceptTask(Role role, TaskSet taskSet, NPC npc) {
        role.getTask().acceptTask(taskSet.getId());
        if (npc != null) {
            role.getTask().addTaskNpcId(taskSet.getId(), npc.getId());
        }
        role.save();

        TaskInfo taskInfo = getTaskInfo(role, taskSet);
        taskService.pushTaskInfo(role, taskInfo);

        if (npc != null) {
            logger.info("[ACTIVITY]|acceptTask|{}|{}|{}|{}|{}", role.getUid(), taskSet.getId(), npc.getId(), npc.getName(), npc.getRoleUid());
        } else {
            logger.info("[ACTIVITY]|acceptTask111111|{}|{}|{}|{}|{}", role.getUid(), taskSet.getId(), "", "", "");
        }
}

    public abstract TaskInfo getTaskInfo(Role role, TaskSet taskSet);

    /**接取成员的任务*/
    public void acceptMemberTask(Member member, TaskSet taskSet, NPC npc) {
        Role role = SpringUtils.getRoleService().getOnlinePlayer(member.getUid());
        if(role==null){
            return;
        }
        if (isMemberAcceptTask(role, taskSet) == false) {return ;}

        ThreadLocalUtil.addLocalTask(role, () -> acceptTask(role, taskSet, npc));
    }

    /**获得接取成功后提示信息内容*/
    public abstract String getPrompt(NPC npc);

    public abstract BossNpcParam newBossNpcParam(Role role, TaskSet taskSet);

    public void doAfterAccept(Role role, TaskSet taskSet) {

    }

    public abstract String getNpcContent(Role role, NPC bossNpc);

    public void sendNpcContent(Role role, NPC bossNpc, String content) {
        SpringUtils.getNpcService().sendNpcContent(role, bossNpc, content);
    }

    /**与任务的NPC战斗*/
    public void startFight(Role role, NPC bossNpc) {
        /**判断是否可以战斗*/
        String content = getNpcContentNotFight(role, bossNpc);
        if (content != null) {
            sendNpcContent(role, bossNpc, content);
            return ;
        }

        TaskSet taskSet = getTaskSetByBossNpc(role, bossNpc);
        /**触发战斗*/
        doStartFight(role, taskSet, bossNpc);
        /**设置NPC为战斗状态*/
        setNpcFightStatus(role, taskSet, true);
    }

    public TaskSet getTaskSetByBossNpc(Role role, NPC bossNpc) {
        List<TaskSet> acceptedTaskListMatchTaskType = SpringUtils.getBean(NewTaskService.class).getAcceptedTaskListMatchTaskType(role, getTaskType());
        for (TaskSet taskSet : acceptedTaskListMatchTaskType) {
            int taskNpcId = role.getTask().getTaskNpcId(taskSet.getId());
            if (taskNpcId == bossNpc.getId()) {
                return taskSet;
            }
        }

        return null;
    }

    public abstract TaskType getTaskType();

    /**获得不能开始战斗的内容*/
    public abstract String getNpcContentNotFight(Role role, NPC bossNpc);

    /**触发战斗*/
    public abstract void doStartFight(Role role, TaskSet taskSet, NPC bossNpc);

    /**获得需要生成boss的数量*/
    public int getBossCount(Role role) {
        /**最多有10个*/
        int allCount = 10;
        int teamCount = SpringUtils.getBean(TeamService.class).getTeamCount(role);
        /**如果没有组队时，数量为1*/
        if (teamCount == 0) {teamCount = 1;}

        /**根据组队数量计算怪的数量*/
        int count = 0;
        if (teamCount == 5) {
            count = allCount;
        } else {
            int minCount = 4 + teamCount;
            count = ThreadLocalRandom.current().nextInt(allCount-minCount+1)  + (minCount);
        }
        return count;
    }

    /**设置NPC是否在战斗状态中*/
    public void setNpcFightStatus(Role role, TaskSet taskSet, boolean isInFight) {
        MapService mapService = SpringUtils.getBean(MapService.class);
        NPC npc = mapService.getNpc(role.getTask ().getTaskNpcId(taskSet.getId()));
        if (npc != null) {
            npc.setInFight(isInFight);
        }
    }

    protected boolean isMatchFightType(Role role, int fightType) {
        return getFightType(role) == fightType;
    }

    protected abstract int getFightType(Role role);

    protected abstract void addActivityFinishCount(Role role, TaskSet taskSet);

    protected abstract void giveReward(Role role, NutMap reward, TaskSet taskSet,int currPetId);

    protected abstract void doBeforeDelete(Role role, TaskSet taskSet);

    protected abstract void doAfterDelete(Role role, TaskSet taskSet);

    public TaskSet getTaskSetByType(Role role) {
        return getTaskSetByType(role, getTaskType());
    }

    public TaskSet getTaskSetByType(Role role, TaskType taskType) {
        List<TaskSet> acceptedTaskListMatchTaskType = taskService.getAcceptedTaskListMatchTaskType(role, taskType);
        if (acceptedTaskListMatchTaskType.isEmpty()) { return null; }
        return acceptedTaskListMatchTaskType.get(0);
    }

    /**战斗是否需要为玩家单独生成个NPC
     * @param taskSet*/
    public abstract boolean isCreateNpcForFight(TaskSet taskSet);

    /**是否队伍改变时删除任务*/
    public boolean isDeleteTaskTeamChange() {return false;}

    /**是否登出时删除任务*/
    public boolean isDeleteTaskLogout() {return false;}

    /**处理玩家离队*/
    public void handleTeamLeave(Role role, boolean isLeader, List<Member> memberList) {
        /**队伍改变时删除任务的才需要处理*/
        if (isDeleteTaskTeamChange() == false) {return ;}

        TaskSet taskSet = getTaskSetByType(role);
        if (taskSet == null) {return ;}

        if (isLeader) {
            /**队长时，删除整个队伍的任务*/
            doDeleteTaskForTeam(memberList, role.getRoleId(), taskSet);
        } else {
            /**不是队长时，只删除自己的任务*/
            deleteTaskForSingle(role, taskSet);
        }
    }

    /**处理暂离队伍*/
    public void handleTeamLeaveMonment(Role role) {
        /**队伍改变时删除任务的才需要处理*/
        if (isDeleteTaskTeamChange() == false) {return ;}

        TaskSet taskSet = getTaskSetByType(role);
        if (taskSet == null) {return ;}

        deleteTaskForSingle(role, taskSet);
    }

    public void handleTeamChangeLeader(Role role, List<Member> memberList) {
        /**队伍改变时删除任务的才需要处理*/
        if (isDeleteTaskTeamChange() == false) {return ;}

        TaskSet taskSet = getTaskSetByType(role);
        if (taskSet == null) {return ;}

        doDeleteTaskForTeam(memberList, role.getRoleId(), taskSet);
    }

    public void handleLogout(Role role) {
        /**登出时删除任务的才需要处理*/
        if (isDeleteTaskLogout() == false) {return ;}

        TaskSet taskSet = getTaskSetByType(role);
        if (taskSet == null) {return ;}

        /**没有在队伍时*/
        if (!teamService.isInTeam(role)) {
            deleteTask(role, taskSet);
        }
    }

    public void handleLogin(Role role) {
        TaskSet taskSet = getTaskSetByType(role);
        if (taskSet == null) {return ;}
        logger.error("uid:{}, 登录任务名称=[{}],任务类型=[{}]", role.getUid(), taskSet.getNpcName(), taskSet.getTaskType());
        /**登出时删除任务的才需要在上线的时候删除，理论下线的时候就处理过的，但是直接停服可能没正常处理*/
        /**同时没有在队伍时*/
        if (isDeleteTaskLogout() && !teamService.isInTeam(role)) {
            deleteTask(role, taskSet);
        } else {
            TaskInfo taskInfo = getTaskInfo(role, taskSet);
            taskService.pushTaskInfo(role, taskInfo);
        }
    }

    public void handleHeartBeat(Role role, long prevHeartTime) {
        TaskSet taskSet = getTaskSetByType(role);
        if (taskSet == null) {return ;}

        /**只有那种需要为玩家单独生成个NPC的才需要处理*/
        if (isCreateNpcForFight(taskSet) == false) {return ;}

        if (!role.getTask().isAccepted(taskSet.getId())) {return ;}

        /**在心跳中刷新一下任务剩余时间*/
        TaskInfo taskInfo = getTaskInfo(role, taskSet);
        taskService.pushTaskInfo(role, taskInfo);

        int npcId = role.getTask().getTaskNpcId(taskSet.getId());
        MapService mapService = SpringUtils.getBean(MapService.class);

        NPC npc = mapService.getNpc(npcId);

        /**结束时间小于当前时间，则删除任务*/
        if (npc == null || npc.getEndTime() < System.currentTimeMillis()) {
            deleteTask(role, taskSet);
        }
    }

    public void handleFightEnd(FightEndEvent fightEndEvent) {
        /**事件应该是在战斗线程触发的，在玩家线程中处理玩家逻辑*/
        ThreadLocalUtil.addLocalTask(fightEndEvent.getRole(), () -> doFightEnd(fightEndEvent.getRole(), fightEndEvent));
    }

    private void doFightEnd(Role role, FightEndEvent fightEndEvent) {
        try {
            /**在组队又不是队长时返回*/
            if (teamService.isInTeam(role) && !teamService.isTeamLeader(role)) {
                return ;
            }

            TaskSet taskSet = getTaskSetByType(role);
            if (taskSet == null) {return ;}
            if (!isMatchFightType(role, fightEndEvent.getFightType())) {
                return ;
            }

            /**取消NPC之前战斗开始时设置的战斗状态*/
            setNpcFightStatus(role, taskSet, false);

            switch (fightEndEvent.getStatus()) {
                case FightEndEvent.WIN:
                    doFightWin(role, taskSet, fightEndEvent);
                    break;
                case FightEndEvent.FAIL:
                    doFightFail(role, taskSet, fightEndEvent);
                    break;
                case FightEndEvent.RUNAWAY:
                    doFightRunAway(role, taskSet, fightEndEvent);
                    break;
                case FightEndEvent.MAXROUND:
                    doFightMaxRound(role, taskSet, fightEndEvent);
                    break;
            }
//            logger.info("[ACTIVITY]|endFight|{}|{}|{}|{}|{}", role.getUid(), taskSet.getId(), fightEndEvent.getNpcId(), fightEndEvent.getFightType(), fightEndEvent.getStatus());
        } catch (Exception e) {
            LoggerUtils.error(role.getUid() +"|" + this.getClass().getSimpleName() +"|" + e.getMessage(), e);
        }
    }

    private void doFightWin(Role role, TaskSet taskSet, FightEndEvent fightEndEvent) {
        Team team = teamService.getTeam(role.getRoleId());
        if (teamService.isInTeam(role)) {
            doFightWinForTeam(team, taskSet, fightEndEvent);
        } else {
            doFightWinForSingle(role, taskSet, fightEndEvent);
        }
    }

    public void doFightWinForTeam(Team team, TaskSet taskSet, FightEndEvent fightEndEvent) {
        int leaderRoleId = team.getLeaderRoleId();
        ArrayList<Member> members = team.getList();
        for (Member member : members) {
            /**不知道有没可能出现null的情况*/
            if (member == null) {continue;}
            /**成员暂离时，不对其进行操作*/
            if (!member.isInTeam()) {continue;}

            if (leaderRoleId != member.getRoleId()) {
                /**其他队员需要加到玩家所在线程中处理*/
//                Role role = SpringUtils.getRoleService().getOnlinePlayer(member.getUid());
                /**不拿在线玩家，防止出现类似通天塔进入战斗退出不完成情况*/
                Role role = SpringUtils.getRoleService().getPlayerBy(member.getUid());
                if(role==null){
                    continue;
                }
                ThreadLocalUtil.addLocalTask(role, () -> doFightWinForSingle(role, taskSet, fightEndEvent));
            }
        }

        /**最后处理队长的*/
        /**现在就是在队长的线程，所以可以直接处理*/
        Role role = SpringUtils.getRoleService().getOnlinePlayer(leaderRoleId);
        doFightWinForSingle(role, taskSet, fightEndEvent);
    }

    public void doFightWinForSingle(Role role, TaskSet taskSet, FightEndEvent fightEndEvent) {
        try {
            if (!isMatchFightType(role, fightEndEvent.getFightType())) {
                return ;
            }
            if (isMemberSubmitTask(role, taskSet) == false) {return ;}

            addActivityFinishCount(role, taskSet);

            int currPetId = role.getTempCache("fight_current_pet_id", 0);
            NPC npc = SpringUtils.getMapService().getNpc(role.getTask ().getTaskNpcId(taskSet.getId()));
            role.pushTempCache("drop_monster_name", npc != null ? npc.getName() : "");
            giveReward(role, fightEndEvent.getReward(), taskSet, currPetId);
            role.popTempCache("drop_monster_name");
            logger.info("[ACTIVITY]|giveReward|{}|{}|{}|{}|{}|{}", role.getUid(), taskSet.getId(), fightEndEvent.getNpcId(), fightEndEvent.getFightType(), fightEndEvent.getStatus(), Json.toJson(fightEndEvent.getReward(), JsonFormat.compact()));

            doBeforeDelete(role, taskSet);

            deleteTaskForSingle(role, taskSet);

            doAfterDelete(role, taskSet);
        } catch (Exception e) {
            LoggerUtils.error(role.getUid() +"|" + this.getClass().getSimpleName() +"|" + e.getMessage(), e);
        }
    }

    /**成员是否可以提交任务，默认可以*/
    public boolean isMemberSubmitTask(Role role, TaskSet taskSet) {
        return true;
    }

    public void doFightFail(Role role, TaskSet taskSet, FightEndEvent fightEndEvent) {
    }

    public void doFightRunAway(Role role, TaskSet taskSet, FightEndEvent fightEndEvent) {
    }

    public void doFightMaxRound(Role role, TaskSet taskSet, FightEndEvent fightEndEvent) {
    }

    @Override
    public void handleRoleExpire(Role role) {
        Fight fight = SpringUtils.getFightService().getFightByRoleId(role.getRoleId());
        if (fight == null) {return ;}
        if (!isMatchFightType(role, fight.getType())) {
            return ;
        }

        super.handleRoleExpire(role);

        TaskSet taskSet = getTaskSetByType(role);

        NPC npc = null;
        if (taskSet != null) {
            npc = SpringUtils.getMapService().getNpc(role.getTask ().getTaskNpcId(taskSet.getId()));
        }

        doRoleExpire(role, fight, npc);
    }

    public void doRoleExpire(Role role, Fight fight, NPC npc) {
        TeamService teamService = SpringUtils.getTeamService();
        /**没组队或者队伍只有1人时*/
        if (teamService.getTeamCount(role) <= 1) {
            if (npc != null) {
                if (npc.isInFight()) {
                    npc.setInFight(false);
                }
            }
        }
    }

    /**自动寻路战斗*/
    public void autoWalk(Role role) {
        TaskSet taskSet = getTaskSetByType(role);
        TaskInfo taskInfo = getTaskInfo(role, taskSet);
        if (taskInfo == null) {return ;}

        RespAutoWalk respAutoWalk = new RespAutoWalk();
        respAutoWalk.setTaskName(taskInfo.getTaskName());
        respAutoWalk.setDest(taskInfo.getTaskZhiyin());
        MessagePusher.pushMessage(role, respAutoWalk);
    }
}
