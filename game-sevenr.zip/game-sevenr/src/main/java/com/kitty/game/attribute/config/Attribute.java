package com.kitty.game.attribute.config;

import lombok.Getter;
import lombok.Setter;
import org.nutz.dao.entity.annotation.*;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

@Table("p_attribute")
@Getter
@Setter
public class Attribute {
    @Column
    private short attrId;
    @Column
    @Comment("属性英文名")
    private String name;
    @Column
    @Comment("中文名")
    private String valuename;
    @Column
    private byte type;
    @Column
    @ColDefine(customType = "TEXT", type = ColType.VARCHAR)
    private String gongmin;
    @Column
    @ColDefine(customType = "TEXT", type = ColType.VARCHAR)
    private String gongmin70;
    @Column
    @ColDefine(customType = "TEXT", type = ColType.VARCHAR)
    private String gongmin80;
    @Column
    @ColDefine(customType = "TEXT", type = ColType.VARCHAR)
    private String gongmin90;
    @Column
    @ColDefine(customType = "TEXT", type = ColType.VARCHAR)
    private String gongmin100;
    @Column
    @ColDefine(customType = "TEXT", type = ColType.VARCHAR)
    private String gongmin110;
    @Column
    @ColDefine(customType = "TEXT", type = ColType.VARCHAR)
    private String gongmin120;
    @Column
    @ColDefine(customType = "TEXT", type = ColType.VARCHAR)
    private String gongmin130;
    @Column
    @ColDefine(customType = "TEXT", type = ColType.VARCHAR)
    private String gongmin140;
    @Column
    @ColDefine(customType = "TEXT", type = ColType.VARCHAR)
    private String gongmin150;
}
