package com.kitty.game.drop.model.product;

import lombok.Getter;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

import java.util.List;

@Table("p_fightdropset")
@Getter
public class FightDropSet {
    @Id
    private int id;
    /**战斗类型*/
    @Column
    private List<Integer> fightTypes;
    /**角色等级*/
    @Column
    private short minRoleLevel;
    /**怪等级比角色可以少的最大值*/
    @Column
    private short maxMonsterLessValue;
    /**掉落组*/
    @Column
    private int dropGroup;
}
