package com.kitty.game.activity.message;


import com.kitty.game.activity.message.vo.Activity;
import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

import java.util.List;

/**
 * 玩家活动的信息
 */
@MessageMeta(module = Modules.MSG_ACTIVITY_DATA_LIST)
public class RespActiviyDataList extends Message {
    private List<Activity> activityList;

    public List<Activity> getActivityList() {
        return activityList;
    }

    public void setActivityList(List<Activity> activityList) {
        this.activityList = activityList;
    }
}
