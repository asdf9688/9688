package com.kitty.game.confirm.model;

import lombok.Getter;
import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

@Getter
public class TowerFlyUpConfirm extends RoleConfirm{
    /**消耗资源类型*/
    private byte flyUpType;
    /**飞升层数*/
    private int flyUpCount;

    public TowerFlyUpConfirm(byte flyUpType, int flyUpCount) {
        this.flyUpType = flyUpType;
        this.flyUpCount = flyUpCount;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.TOWER_FLY_UP;
    }
}
