package com.kitty.game.confirm.service.handler;

import com.kitty.game.role.model.Role;
import com.kitty.game.confirm.model.ChooseAtkConfirm;
import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.listener.EventDispatcher;
import com.kitty.listener.EventType;
import com.kitty.listener.event.ConfirmEvent;
import com.kitty.listener.BaseGameEvent;
import com.kitty.game.team.message.ReqConfirmResult;
import org.springframework.stereotype.Component;
import com.kitty.listener.event.ConfirmEvent;

@Component
public class ChooseAtkConfirmHandler extends ConfirmHandler{

    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
        if(reqConfirmResult.getSelect().equals("0")){
            return;
        }
        ChooseAtkConfirm chooseAtkConfirm = (ChooseAtkConfirm)role.getConfirm();
        /**产生一个确认力法选择的事件*/
        EventDispatcher.getInstance().fireEvent(new ConfirmEvent(EventType.CONFIRM, role, ConfirmType.CHOOSE_ATK, chooseAtkConfirm.getTaskId(), reqConfirmResult.getSelect()));
    }
}
