package com.kitty.game.config;

import lombok.Getter;
import lombok.Setter;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

/**
 * 守护配置
 */
@Setter
@Getter
@Table("p_guardset")
public class GuardSet {
    @Column
    @Comment("守护名称")
    private String name;
    @Column
    @Comment("体质")
    private short tizhi;
    @Column
    @Comment("力量")
    private short liliang;
    @Column
    @Comment("敏捷")
    private short minjie;
    @Column
    @Comment("灵力")
    private short lingli;
    @Column
    @Comment("金")
    private short jin;
    @Column
    @Comment("木")
    private short mu;
    @Column
    @Comment("水")
    private short shui;
    @Column
    @Comment("火")
    private short huo;
    @Column
    @Comment("土")
    private short tu;
    @Column
    @Comment("资质")
    private short type;
    @Column
    @Comment("门派")
    private short menpai;
    @Column
    @Comment("icon")
    private short icon;//6020云霄童子
    @Column
    @Comment("召唤类型")//1金钱 2元宝
    private byte castType;
    @Column
    @Comment("召唤价格")//
    private int castValue;
    @Column
    @Comment("颜色")//
    private short color;

    public void setName(String name) {
        this.name = name;
    }

    public void setTizhi(short tizhi) {
        this.tizhi = tizhi;
    }

    public void setLiliang(short liliang) {
        this.liliang = liliang;
    }

    public void setMinjie(short minjie) {
        this.minjie = minjie;
    }

    public void setLingli(short lingli) {
        this.lingli = lingli;
    }

    public void setJin(short jin) {
        this.jin = jin;
    }

    public void setMu(short mu) {
        this.mu = mu;
    }

    public void setShui(short shui) {
        this.shui = shui;
    }

    public void setHuo(short huo) {
        this.huo = huo;
    }

    public void setTu(short tu) {
        this.tu = tu;
    }

    public void setType(short type) {
        this.type = type;
    }

    public void setMenpai(short menpai) {
        this.menpai = menpai;
    }

    public void setIcon(short icon) {
        this.icon = icon;
    }

    public void setCastType(byte castType) {
        this.castType = castType;
    }

    public void setCastValue(int castValue) {
        this.castValue = castValue;
    }

    public void setColor(short color) {
        this.color = color;
    }

    public String getName() {
        return this.name;
    }

    public short getTizhi() {
        return this.tizhi;
    }

    public short getLiliang() {
        return this.liliang;
    }

    public short getMinjie() {
        return this.minjie;
    }

    public short getLingli() {
        return this.lingli;
    }

    public short getJin() {
        return this.jin;
    }

    public short getMu() {
        return this.mu;
    }

    public short getShui() {
        return this.shui;
    }

    public short getHuo() {
        return this.huo;
    }

    public short getTu() {
        return this.tu;
    }

    public short getType() {
        return this.type;
    }

    public short getMenpai() {
        return this.menpai;
    }

    public short getIcon() {
        return this.icon;
    }

    public byte getCastType() {
        return this.castType;
    }

    public int getCastValue() {
        return this.castValue;
    }

    public short getColor() {
        return this.color;
    }
}
