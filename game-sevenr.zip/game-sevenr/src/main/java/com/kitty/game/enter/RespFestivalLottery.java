package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.ListField;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;
import com.kitty.game.enter.FestivalLottery;

import java.util.List;

@MessageMeta(module = Modules.MSG_FESTIVAL_LOTTERY)
public class RespFestivalLottery extends Message {
    @ListField(1)
    private List<FestivalLottery> FestivalLottery;


    public List<FestivalLottery> getFestivalLottery() {
        return FestivalLottery;
    }

    public void setFestivalLottery(List<FestivalLottery> festivalLottery) {
        FestivalLottery = festivalLottery;
    }
}
