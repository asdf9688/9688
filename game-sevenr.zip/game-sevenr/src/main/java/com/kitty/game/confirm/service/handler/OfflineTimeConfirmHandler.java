package com.kitty.game.confirm.service.handler;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.confirm.service.handler.ConfirmHandler;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.role.model.Role;
import com.kitty.game.team.message.ReqConfirmResult;
import com.kitty.mina.message.MessagePusher;
import org.springframework.stereotype.Component;

@Component
public class OfflineTimeConfirmHandler extends ConfirmHandler {
    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
        /**确认兑换*/
        if ("1".equals(reqConfirmResult.getSelect())) {
            if (role.getOfflineNotice().getOfflineTime() > 1500 * 60){
                MessagePusher.pushMessage(role,new RespNotifyMiscEx("离线时间不能超过#R1500分钟"));
                return;
            }
            SpringUtils.getRoleService().substractChargeScore(role,100);
            int old = role.getOfflineNotice().getOfflineTime();
            role.getOfflineNotice().setOfflineTime(old + 30*60);
            role.save();
            MessagePusher.pushMessage(role,new RespNotifyMiscEx("购买离线时间成功"));
            SpringUtils.getRoleService().sendShuadaoStauts(role);
        }
    }
}
