package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

/**
 * 进入地图
 */
@MessageMeta(module = Modules.MSG_ENTER_ROOM)
public class RespEnterMap extends Message {
    private String mapName;

    private String map_show_name;

    private int mapId;

    private short posX;
    
    private short posY;
    
    private byte dir;//方向
    
    private int map_index = 156;//地图属性
    
    private short compact_map_index = 0;
    
    private byte floor_index = 0;
    
    private byte wall_index = 1;
    
    private boolean safe_zone;//是否是安全区？
    
    private byte is_task_walk = 0;//任务相关？
    
    private byte enter_effect_index;

    public String getMapName() {
        return mapName;
    }

    public void setMapName(String mapName) {
        this.mapName = mapName;
    }

    public String getMap_show_name() {
        return map_show_name;
    }

    public void setMap_show_name(String map_show_name) {
        this.map_show_name = map_show_name;
    }

    public int getMapId() {
        return mapId;
    }

    public void setMapId(int mapId) {
        this.mapId = mapId;
    }

    public short getPosX() {
        return posX;
    }

    public void setPosX(short posX) {
        this.posX = posX;
    }

    public short getPosY() {
        return posY;
    }

    public void setPosY(short posY) {
        this.posY = posY;
    }

    public byte getDir() {
        return dir;
    }

    public void setDir(byte dir) {
        this.dir = dir;
    }

    public int getMap_index() {
        return map_index;
    }

    public void setMap_index(int map_index) {
        this.map_index = map_index;
    }

    public short getCompact_map_index() {
        return compact_map_index;
    }

    public void setCompact_map_index(short compact_map_index) {
        this.compact_map_index = compact_map_index;
    }

    public byte getFloor_index() {
        return floor_index;
    }

    public void setFloor_index(byte floor_index) {
        this.floor_index = floor_index;
    }

    public byte getWall_index() {
        return wall_index;
    }

    public void setWall_index(byte wall_index) {
        this.wall_index = wall_index;
    }

    public boolean isSafe_zone() {
        return safe_zone;
    }

    public void setSafe_zone(boolean safe_zone) {
        this.safe_zone = safe_zone;
    }

    public byte getIs_task_walk() {
        return is_task_walk;
    }

    public void setIs_task_walk(byte is_task_walk) {
        this.is_task_walk = is_task_walk;
    }

    public byte getEnter_effect_index() {
        return enter_effect_index;
    }

    public void setEnter_effect_index(byte enter_effect_index) {
        this.enter_effect_index = enter_effect_index;
    }
}
