package com.kitty.game.activity.model.user;

import lombok.Getter;
import lombok.Setter;

import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import com.kitty.game.activity.model.user.ShiDaoMonsterData;
import com.kitty.game.activity.model.user.ShiDaoPKData;

@Setter
@Getter
public class ShiDaoData {
    /**准备阶段*/
    public static final byte STAGE_READY = 0;
    /**挑战元魔阶段*/
    public static final byte STAGE_MONSTER = 1;
    /**PK阶段*/
    public static final byte STAGE_PK = 2;

    /**试道大会阶段*/
    private byte stage;

    /**报名开始时间*/
    private Calendar signupTime = null;
    /**试道大会开始时间*/
    private Calendar startTime = null;
    /**挑战元魔结束时间*/
    private Calendar monsterEndTime = null;
    /**试道大会结束时间*/
    private Calendar endTime = null;

    /**挑战元魔持续时间*/
    private int monsterDurationTime = 1800;
    /**巅峰对决持续时间*/
    private int pkDurationTime = 5400;

    /**是否是月道行试道*/
    private boolean isMonthTao = false;

    /**key: teamId, value: 对应的试道挑战元魔阶段数据*/
    private Map<Integer, ShiDaoMonsterData> monsterDataMap = new ConcurrentHashMap<>();

    /**key: 等级段, value: 等级段对应的试道挑战元魔阶段数据 列表*/
    private Map<String, List<ShiDaoMonsterData>> monsterDataByLevel = new ConcurrentHashMap<>();

    /**key: teamId, value: 对应的试道队伍pk阶段数据*/
    private Map<Integer, ShiDaoPKData> pkDataMap = new ConcurrentHashMap<>();

    /**key: 等级段, value: 等级段对应的试道队伍pk阶段数据 列表*/
    private Map<String, List<ShiDaoPKData>> pkDataByLevel = new ConcurrentHashMap<>();

    /**配对的队伍*/
    private Map<Integer, Integer> matchTeamIds = new HashMap<>();
    /**已经淘汰的队伍ID列表*/
    private Map<String, List<Integer>> failTeamIds = new HashMap<>();
    /**已经结束的等级段*/
    private Set<String> endLevelRanges = new HashSet<>();
    /**已经结束的等级段*/
    private Set<Integer> rolesLeave = new HashSet<>();


 
    public void setStage(byte stage) {
        this.stage = stage;
    }

    public void setSignupTime(Calendar signupTime) {
        this.signupTime = signupTime;
    }

    public void setStartTime(Calendar startTime) {
        this.startTime = startTime;
    }

    public void setMonsterEndTime(Calendar monsterEndTime) {
        this.monsterEndTime = monsterEndTime;
    }

    public void setEndTime(Calendar endTime) {
        this.endTime = endTime;
    }

    public void setMonsterDurationTime(int monsterDurationTime) {
        this.monsterDurationTime = monsterDurationTime;
    }

    public void setPkDurationTime(int pkDurationTime) {
        this.pkDurationTime = pkDurationTime;
    }

    public void setMonthTao(boolean isMonthTao) {
        this.isMonthTao = isMonthTao;
    }

    public void setMonsterDataMap(Map<Integer, ShiDaoMonsterData> monsterDataMap) {
        this.monsterDataMap = monsterDataMap;
    }

    public void setMonsterDataByLevel(Map<String, List<ShiDaoMonsterData>> monsterDataByLevel) {
        this.monsterDataByLevel = monsterDataByLevel;
    }

    public void setPkDataMap(Map<Integer, ShiDaoPKData> pkDataMap) {
        this.pkDataMap = pkDataMap;
    }

    public void setPkDataByLevel(Map<String, List<ShiDaoPKData>> pkDataByLevel) {
        this.pkDataByLevel = pkDataByLevel;
    }

    public void setMatchTeamIds(Map<Integer, Integer> matchTeamIds) {
        this.matchTeamIds = matchTeamIds;
    }

    public void setFailTeamIds(Map<String, List<Integer>> failTeamIds) {
        this.failTeamIds = failTeamIds;
    }

    public void setEndLevelRanges(Set<String> endLevelRanges) {
        this.endLevelRanges = endLevelRanges;
    }

    public void setRolesLeave(Set<Integer> rolesLeave) {
        this.rolesLeave = rolesLeave;
    }

    public byte getStage() {
        return this.stage;
    }

    public Calendar getSignupTime() {
        return this.signupTime;
    }

    public Calendar getStartTime() {
        return this.startTime;
    }

    public Calendar getMonsterEndTime() {
        return this.monsterEndTime;
    }

    public Calendar getEndTime() {
        return this.endTime;
    }

    public int getMonsterDurationTime() {
        return this.monsterDurationTime;
    }

    public int getPkDurationTime() {
        return this.pkDurationTime;
    }

    public boolean isMonthTao() {
        return this.isMonthTao;
    }

    public Map<Integer, ShiDaoMonsterData> getMonsterDataMap() {
        return this.monsterDataMap;
    }

    public Map<String, List<ShiDaoMonsterData>> getMonsterDataByLevel() {
        return this.monsterDataByLevel;
    }

    public Map<Integer, ShiDaoPKData> getPkDataMap() {
        return this.pkDataMap;
    }

    public Map<String, List<ShiDaoPKData>> getPkDataByLevel() {
        return this.pkDataByLevel;
    }

    public Map<Integer, Integer> getMatchTeamIds() {
        return this.matchTeamIds;
    }

    public Map<String, List<Integer>> getFailTeamIds() {
        return this.failTeamIds;
    }

    public Set<String> getEndLevelRanges() {
        return this.endLevelRanges;
    }

    public Set<Integer> getRolesLeave() {
        return this.rolesLeave;
    }
}
