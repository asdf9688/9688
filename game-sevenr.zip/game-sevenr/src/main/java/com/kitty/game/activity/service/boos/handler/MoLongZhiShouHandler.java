package com.kitty.game.activity.service.boos.handler;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.activity.model.product.ActivityType;
import com.kitty.game.activity.model.product.SuperBoss;
import com.kitty.game.activity.service.boos.service.BoosService;
import com.kitty.game.activity.service.time.FightActivityHandler;
import com.kitty.game.base.service.BagService;
import com.kitty.game.boss.config.BossSet;
import com.kitty.game.boss.model.BossFightParam;
import com.kitty.game.boss.model.BossParam;
import com.kitty.game.boss.model.SuperBossParam;
import com.kitty.game.boss.model.SuperBossZPParam;
import com.kitty.game.chat.service.ChatService;
import com.kitty.game.common.BoosTitleDeal;
import com.kitty.game.config.NPC;
import com.kitty.game.config.OnlineMall;
import com.kitty.game.enter.TitleInfo;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.equip.service.EquipService;
import com.kitty.game.mail.model.Mail;
import com.kitty.game.pet.PetDataPool;
import com.kitty.game.pet.bean.PetObject;
import com.kitty.game.pet.model.Pet;
import com.kitty.game.pet.service.PetService;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.RoleService;
import com.kitty.game.team.model.Team;
import com.kitty.game.utils.Const;
import com.kitty.game.utils.TimeUtil;
import com.kitty.listener.event.FightEndEvent;
import com.kitty.logs.Reason;
import com.kitty.mina.cache.DataCache;
import com.kitty.mina.message.MessagePusher;
import org.nutz.lang.util.NutMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.text.MessageFormat;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

@Component
public class MoLongZhiShouHandler extends FightActivityHandler {

    private Map<String, SuperBoss> superBossMap = new HashMap<>();
    private static final String boy_name[] = {"魔魂·水","魔魂·水","魔魂·水","魔魂·水"};
    @Autowired
    ChatService chatService;

    /**
     * 最少组队人数
     */
    private static final int MIN_TEAM_COUNT = 1;
    private static final String TEAM_COUNT_NOT_ENOUGH = "你还是组队后再来向我挑战吧！[离开]";
    private static final int ACCEPT_MIN_LEVEL = 79;
    private static final String TEAM_LEVEL_NOT_ENOUGH = "#Y{0}#n的等级还没有{1}级。[离开]";

    @PostConstruct
    private void init() {
        SuperBoss superBoss = new SuperBoss("魔龙之首", 6740, 702);
        superBoss.setZPName("魔魂·水");
        superBoss.getArtifactMap().put("混元金斗", 21);
        superBoss.getArtifactMap().put("番天印", 21);
        superBoss.getArtifactMap().put("卸甲金葫", 24);
        superBoss.getArtifactMap().put("定海珠", 13);
        superBoss.setAwardDropGroup(12);
        superBoss.setSmallPolarRandom(true);
        superBoss.setSmallSkillRandom(true);
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_METAL, Arrays.asList(11, 12, 13, 14, 15, 31, 32, 33, 34, 35));
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_WOOD, Arrays.asList(61, 62, 63, 64, 65, 81, 82, 83, 84, 85));
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_WATER, Arrays.asList(110, 111, 112, 113, 114, 131, 132, 133, 134, 135));
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_FIRE, Arrays.asList(161, 162, 163, 164, 165, 181, 182, 183, 184, 185));
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_EARTH, Arrays.asList(210, 211, 212, 213, 214, 231, 232, 233, 234, 235));
        superBossMap.put(superBoss.getName(), superBoss);
    }

    @Override
    protected String getNpcContent(Role role, NPC bossNpc) {
        return null;
    }

    @Override
    protected String getNpcContentNotFight(Role role, NPC bossNpc) {

        /**检测队伍人数*/
        int teamCount = teamService.getTeamCount(role);
        if (teamCount < MIN_TEAM_COUNT) {
            return TEAM_COUNT_NOT_ENOUGH;
        }

        /**检测等级*/
        Team team = teamService.getTeam(role.getRoleId());
        String names = teamService.checkMember(team, memberRole -> memberRole.getLevel() < ACCEPT_MIN_LEVEL);
        if (names != null) {
            return MessageFormat.format(TEAM_LEVEL_NOT_ENOUGH, names, ACCEPT_MIN_LEVEL);
        }

        names = teamService.checkMember(team, memberRole -> getRoleRemainCount(memberRole) <= 0);

        if (names != null) {
            return "#R" + names + "#n没有挑战次数";
        }
        if (getRoleRemainCount(role) <= 0) {
            return "#R" + role.getName() + "#n没有挑战次数";
        }
        return null;

    }

    private byte getRoleRemainCount(Role role) {
        return (byte) SpringUtils.getActivityService().getRemainCount(role, ActivityType.molongzhishou);
    }

    @Override
    protected void doStartFight(Role role, NPC bossNpc) {
        return;
    }
    public void challenge1(Role role, NPC bossNpc){
        bossNpc.setName("魔龙之首");
        /**检测队伍人数*/
        int teamCount = teamService.getTeamCount(role);
        if (teamCount < MIN_TEAM_COUNT) {
            sendNpcContent(role, bossNpc, TEAM_COUNT_NOT_ENOUGH);
            return ;
        }

        /**检测等级*/
        Team team = teamService.getTeam(role.getRoleId());

        String names = teamService.checkMember(team, memberRole -> memberRole.getLevel() < ACCEPT_MIN_LEVEL);

        if (names != null) {
            MessageFormat.format(TEAM_LEVEL_NOT_ENOUGH, names, ACCEPT_MIN_LEVEL);
            return;
        }

        names = teamService.checkMember(team, memberRole -> getRoleRemainCount(memberRole) <= 0);
        if (names != null) {
            sendNpcContent(role, bossNpc, "#R" + names + "#n没有挑战次数");
            return ;
        }
        if (getRoleRemainCount(role) <= 0) {
            sendNpcContent(role, bossNpc,  "#R" + role.getName() + "#n没有挑战次数");
            return ;
        }
        List<BossParam> bossParamList = newBossParamList(role, bossNpc);
        BossFightParam bossFightParam = new BossFightParam(bossParamList, getFightType(role));
        bossFightParam.setNpcId(bossNpc.getId());
        int maxRoleLevel = teamService.getMaxRoleLevelInTeam(role);
        bossFightParam.setNpcLevel((short) maxRoleLevel);
        bossService.startFightToBoss(role, bossFightParam);
    }
    private List<BossParam> newBossParamList(Role role, NPC bossNpc) {
        bossNpc.setName("魔龙之首");
        SuperBoss superBoss = getSuperBoss(bossNpc.getName());
        List<BossParam> bossParamList = new ArrayList<>();
        int count = 5;
        SuperBossParam superBossParam = SpringUtils.getBean(BoosService.class).newSuperBossParam(bossNpc,getSuperBoss("魔龙之首"));
        superBossParam.setMainShowAfterRound(superBoss.getMainShowAfterRound());
        superBossParam.setSmallEscapeAfterRound(superBoss.getSmallEscapeAfterRound());
        if (superBoss.isSmallPolarRandom()) {
            byte polar = 2;
            superBossParam.setPolar(polar);
        }
        if (superBoss.isSmallSkillRandom()) {
            ArrayList<Integer> skillIds = new ArrayList<>(superBoss.getPolarSmallSkills().get((byte) superBossParam.getPolar()));
            superBossParam.setSkillIds(skillIds);
        }
        bossParamList.add(superBossParam);

        /**加count-1个*/
        int smallCount = superBoss.getZPName() != null ? count - 1 : count;
        for (int i = 1; i < smallCount; i++) {
            int index = (int) (Math.random() * boy_name.length);
            BossSet bossSet = bossService.getBossSet(boy_name[index]);
            BossParam bossParam = new BossParam(bossSet, bossSet.getName());
            if (superBoss.isSmallPolarRandom()) {
                byte polar = SpringUtils.getBean(BoosService.class).getRandomPolar();
                bossParam.setPolar(polar);
            }
            if (superBoss.isSmallSkillRandom()) {
                ArrayList<Integer> skillIds = new ArrayList<>(superBoss.getPolarSmallSkills().get((byte) bossParam.getPolar()));
                bossParam.setSkillIds(skillIds);
            }
            bossParamList.add(bossParam);
        }
        if (superBoss.getZPName() != null) {
            BossSet bossSet = bossService.getBossSet(superBoss.getZPName());
            bossParamList.add(new SuperBossZPParam(bossSet, bossSet.getName()));
        }

        return bossParamList;
    }



    private SuperBoss getSuperBoss(String name) {
        return superBossMap.get(name);
    }

    @Override
    protected int getFightType(Role role) {
        return Const.molongzhishou;
    }

    @Override
    protected NPC getBossNpc(int npcId) {
        return SpringUtils.getMapService().getNpc(npcId);
    }

    @Override
    protected void clearNpcAfterWin(Role role, NPC bossNpc) {
        clearNpc(bossNpc);
    }

    private void clearNpc(NPC npc) {
        return;
    }

    @Override
    protected void giveReward(Role role, FightEndEvent fightEndEvent, NPC bossNpc) {
        byte count = getRoleRemainCount(role);
        if (count > 0) {/*次数在npc类 这个0只是取数*/
            if (!teamService.isInTeam(role)) {
                MessagePusher.pushMessage(role, new RespNotifyMiscEx("离队无法获得奖励"));
                return;
            }
            NutMap reward = fightEndEvent.getReward();
            /**道行武学奖励*/
            int exp = role.getLevel() * reward.getInt("rewardExp", 3000000);
            int daohang = fightEndEvent.getReward().getInt("rewardDaohang", 30) * role.getLevel();
            int petWuxue = fightEndEvent.getReward().getInt("petRewardWuxue", 30) * role.getLevel();
            RoleService roleService = SpringUtils.getRoleService();
            roleService.addTao(role, daohang);
            int currPetId = role.getTempCache("fight_current_pet_id", 0);
            Pet pet = SpringUtils.getPetService().getPetById(currPetId, role);
            if (pet != null) {
                roleService.addPetMatiral(role, pet, petWuxue);
            }
            NutMap nutMap = role.getPropsStatus();
            int point = nutMap.getInt("role");
            if (nutMap.getInt("roleStatus") == 1 && point >= 4) {
                nutMap.setv("role", point - 4);
                role.save();
                roleService.addExp(role, exp * 2, role.getLevel(), currPetId);//除暴 怪物按照20级算
            } else {
                roleService.addExp(role, exp, role.getLevel(), currPetId);//除暴 怪物按照20级算
            }
            roleService.addExp(role,30000000,role.getLevel(),currPetId);
            // 奖励装备
            short roleLevel = role.getLevel();
            String temp = roleLevel + "";
            if (temp.length() == 3) {
                roleLevel = Short.parseShort(temp.substring(0, 2) + 0);
            } else {
                roleLevel = Short.parseShort(temp.substring(0, 1) + 0);
            }

            BagService bagService = SpringUtils.getBean(BagService.class);
            EquipService equipService = SpringUtils.getBean(EquipService.class);

            short newPos = bagService.getPos(role, false);
            if (newPos > 0) {
                equipService.getNotIdentifyEquip(roleLevel, role, newPos);
            } else {
                MessagePusher.pushMessage(role, new RespNotifyMiscEx("背包已满，请整理背包"));
                return;
            }
            //掉落超级仙风散
            OnlineMall onlineMall = DataCache.NAME_MALL.get("超级仙风散");
            bagService.addRoleEquip(role, false, 1, onlineMall);
            /**1%概率获得法宝*/
            int fabaoRate = ThreadLocalRandom.current().nextInt(1000);
            if (fabaoRate < 1) {
                Mail mail = SpringUtils.getMailService().createMail("击杀魔龙之首", "击杀魔龙之首", 30 * TimeUtil.ONE_DAY);
                String[] strings = {"混元金斗", "番天印", "阴阳镜", "定海珠", "金蛟剪", "九龙神火罩", "卸甲金葫"};
                int index = new Random().nextInt(strings.length);
                ArrayList<NutMap> maps = new ArrayList<>();
                maps.add(new NutMap().setv("data", "#I物品|" + strings[index] + "#r1#I").setv("type", Const.mailFabao).setv("petName", "18级"+strings[index]).setv("level", 18));
                mail.getDatas().addAll(maps);
                SpringUtils.getMailService().sendNewMail(role, mail);
            }
            int wupinRate = ThreadLocalRandom.current().nextInt(100);
            if (wupinRate < 100) {
                Mail mail = SpringUtils.getMailService().createMail("击杀魔龙之首", "击杀魔龙之首", 30 * TimeUtil.ONE_DAY);
                String[] strings = {"超级女娲石", "天倾石", "10元充值卡", "天星石", "5元充值卡"};
                int index = new Random().nextInt(strings.length);
                ArrayList<NutMap> maps = new ArrayList<>();
                maps.add(new NutMap().setv("data", "#I物品|" + strings[index] + "#r1#I").setv("type", Const.mailItem).setv("petName", strings[index]).setv("value", 1));

                mail.getDatas().addAll(maps);
                SpringUtils.getMailService().sendNewMail(role, mail);
            }
            if (wupinRate < 30) {
                Mail mail = SpringUtils.getMailService().createMail("击杀魔龙之首", "击杀魔龙之首", 30 * TimeUtil.ONE_DAY);
                String[] strings = {"5元充值卡"};
                int index = new Random().nextInt(strings.length);
                ArrayList<NutMap> maps = new ArrayList<>();
                maps.add(new NutMap().setv("data", "#I物品|" + strings[index] + "#r1#I").setv("type", Const.mailItem).setv("petName", strings[index]).setv("value", 1));

                mail.getDatas().addAll(maps);
                SpringUtils.getMailService().sendNewMail(role, mail);
            }

            Random random = new Random();
            int value = random.nextInt(100);
            if (value <100){
                String[] strings =  {"百年黑熊", "赤血幼猿","玄天刺猬", "血幻豪猪"};
                int index = new Random().nextInt(strings.length);
                String name = strings[index];
                PetObject petObject = PetDataPool.getPetObject(name);
                PetService petService = SpringUtils.getPetService();
                Pet newpet = petService.addPet(petObject, role, false);
                petService.loadPet(role, newpet);
                RespNotifyMiscEx respNotifyMiscEx = new RespNotifyMiscEx();
                respNotifyMiscEx.setMsg("你获得了一只#R" + petObject.getName() + "#n。");
                respNotifyMiscEx.setTime(new Long(System.currentTimeMillis() / 1000).intValue());
                MessagePusher.pushMessage(role, respNotifyMiscEx);
            }
            {roleService.addRechargeScore(role, 100);}
            /*增加帮贡*/
            { roleService.addPartyContrib(role, 1000);}
            { roleService.addluoshuExp(role, 10000);}
            { roleService.addYinde(role, 10000, true); }
            SpringUtils.getActivityService().addFinishCount(role, ActivityType.molongzhishou, 1);
        } else{
            MessagePusher.pushMessage(role, new RespNotifyMiscEx("今日挑战次数以达到上限！不会给奖励！每日只能挑战一次"));
            return;
        }
    }

    @Override
    protected void clearNpcTimeOut(NPC npc) {
        clearNpc(npc);
    }

    @Override
    public void doFightFail(Role role, FightEndEvent fightEndEvent) {
        super.doFightFail(role, fightEndEvent);

        teamService.memberHandleThreadLocal(role, memberRole -> SpringUtils.getRoleService().punishFightDead(memberRole));
    }
    /**
     * 首杀BOOS奖励称号
     */
    @Override
    public void doFightWinForTeam(Team team, FightEndEvent fightEndEvent, NPC bossNpc) {
        String title = "横扫乾坤·魔龙之首";
        final Boolean[] flag = {false};
        List<Map<String, String>> list = SpringUtils.getBean(BoosTitleDeal.class).boos_title_map.get("mlzs");
        teamService.memberHandleThreadLocal(team, role -> {
            /**发称号*/
            if (list.size() <= 0) {
                SpringUtils.getRoleService().addTitle(role, new TitleInfo(title, title));
                SpringUtils.getBean(BoosTitleDeal.class).addBoosTitle(role.getName(), "mlzs", title);
                flag[0] = true;
            }
            giveReward(role, fightEndEvent, bossNpc);
        });
        // 更新数据库首次称号奖励
        if (flag[0]) {
            SpringUtils.getBean(BoosTitleDeal.class).updateBoosTitle();
        }

    }
}
