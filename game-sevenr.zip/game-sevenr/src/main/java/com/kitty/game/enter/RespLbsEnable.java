package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

/**
 * 同城功能开关
 */
@MessageMeta(module = Modules.MSG_LBS_ENABLE)
public class RespLbsEnable extends Message {

    private byte enable= 1;

    public byte getEnable() {
        return enable;
    }

    public void setEnable(byte enable) {
        this.enable = enable;
    }
}
