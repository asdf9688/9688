package com.kitty.game.activity.model.product;

import lombok.Getter;
import lombok.Setter;

/**活动活跃度奖励配置*/
@Getter
@Setter
public class ActivityLivenessRewardSet {
    /**已经领取*/
    public static final byte FETCHED = 1;
    /**可以领取*/
    public static final byte CAN_FETCH = 2;

    /**需要活跃度数量*/
    private int livenessCount;
    /**奖励的名称*/
    private String rewardName;
    /**奖励的数量*/
    private int rewardCount;

    public ActivityLivenessRewardSet() {}

    public ActivityLivenessRewardSet(int livenessCount, String rewardName, int rewardCount) {
        this.livenessCount = livenessCount;
        this.rewardName = rewardName;
        this.rewardCount = rewardCount;
    }
}
