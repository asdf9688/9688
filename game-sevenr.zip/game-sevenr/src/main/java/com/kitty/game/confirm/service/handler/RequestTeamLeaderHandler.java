package com.kitty.game.confirm.service.handler;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.confirm.model.RequestTeamLeaderConfirm;
import com.kitty.game.confirm.service.handler.ConfirmHandler;
import com.kitty.game.role.model.Role;
import com.kitty.game.team.message.ReqConfirmResult;
import com.kitty.game.team.message.RespMsg;
import com.kitty.mina.message.MessagePusher;
import org.springframework.stereotype.Component;

@Component
public class RequestTeamLeaderHandler extends ConfirmHandler {

    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
        RequestTeamLeaderConfirm requestTeamLeaderConfirm = ((RequestTeamLeaderConfirm)role.getConfirm());
        int requestId =requestTeamLeaderConfirm.getRequestId();
        requestTeamLeaderConfirm.setAgree(true);
        if(reqConfirmResult.getSelect().equals("1")){//同意  转让队长给申请人 并提示全队人
            SpringUtils.getTeamService().acceptRequestTeamLeader(role,requestId);
        }else {//拒绝 给申请人提示
            Role request = SpringUtils.getRoleService().getOnlinePlayer(requestId);
            MessagePusher.pushMessage(request,new RespMsg("队长拒绝了你的带队申请。"));
        }
    }




}
