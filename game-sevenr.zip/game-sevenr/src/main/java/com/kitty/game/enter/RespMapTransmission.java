package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;
import com.kitty.game.enter.MapTransmission;

import java.util.List;

@MessageMeta(module = Modules.MSG_EXITS)
public class RespMapTransmission extends Message {
    private byte add_exit = 1;//
    private List<MapTransmission> list;

    public byte getAdd_exit() {
        return add_exit;
    }

    public void setAdd_exit(byte add_exit) {
        this.add_exit = add_exit;
    }

    public List<MapTransmission> getList() {
        return list;
    }

    public void setList(List<MapTransmission> list) {
        this.list = list;
    }
}
