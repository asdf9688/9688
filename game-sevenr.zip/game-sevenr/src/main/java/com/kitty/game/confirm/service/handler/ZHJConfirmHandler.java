package com.kitty.game.confirm.service.handler;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.confirm.service.handler.ConfirmHandler;
import com.kitty.game.equip.service.ZHJService;
import com.kitty.game.role.model.Role;
import com.kitty.game.team.message.ReqConfirmResult;
import com.kitty.game.team.service.TeamService;
import org.springframework.stereotype.Component;

@Component
public class ZHJConfirmHandler extends ConfirmHandler {
    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
        /**确认兑换*/
        if ("1".equals(reqConfirmResult.getSelect())) {
            SpringUtils.getBean(ZHJService.class).besureBuy(role);
        }
    }
}
