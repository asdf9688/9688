package com.kitty.game.confirm.model;

import lombok.Getter;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

@Getter
public class AcceptKillTaskConfirm extends RoleConfirm {

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.ACCEPT_KILL_TASK;
    }
}
