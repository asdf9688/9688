package com.kitty.game.bag.service.giftHandler;

import com.alibaba.fastjson.JSONObject;
import com.kitty.common.spring.SpringUtils;
import com.kitty.common.utils.EquipUtil;
import com.kitty.game.FieldValuePosConst;
import com.kitty.game.attribute.AttrService;
import com.kitty.game.attribute.config.Attribute;
import com.kitty.game.bag.message.RespIconCartoon;
import com.kitty.game.bag.model.GiftBagData;
import com.kitty.game.base.service.BagService;
import com.kitty.game.config.Equip;
import com.kitty.game.enter.FiedValue;
import com.kitty.game.equip.EquipDataPool;
import com.kitty.game.equip.model.*;
import com.kitty.game.i18n.I18nId;
import com.kitty.game.i18n.I18nIdDataPool;
import com.kitty.game.onlinemall.service.MallService;
import com.kitty.game.role.model.Role;
import com.kitty.game.team.message.RespMsg;
import com.kitty.game.utils.Const;
import com.kitty.mina.message.MessagePusher;
import org.nutz.json.Json;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * 开启礼包得到 自定义/随机 首饰奖励
 */
@Component
public class JewelryGiftHandler extends GiftHandler {
    @Autowired
    AttrService attrService;
    @Autowired
    BagService bagService;
    @Autowired
    MallService mallService;

    @Override
    public void getReward(Role role, GiftBagData giftBagData) {
        for (int i = 0; i < giftBagData.getCount(); i ++) {
            short pos = bagService.getPos(role, false);
            if (pos <= 0) {
                return;
            }
            this.getJewelry(role, giftBagData, pos);
        }
    }

    private boolean getJewelry(Role role, GiftBagData giftBagData, short newPos) {
        Equip equip = EquipDataPool.getByName(giftBagData.getName());
        short pos = SpringUtils.getBean(BagService.class).getPos(role, false);
        if (pos <= 0) {
            MessagePusher.pushMessage(role, new RespMsg("你的包裹已满，无法获得#R" + equip.getName() + "#n。"));
            return false;
        }
        CustomEquip customEquip = JSONObject.parseObject(giftBagData.getContent(), CustomEquip.class);

        RoleEquip roleEquip = new RoleEquip();
        roleEquip.setId(mallService.getRoleEquipId());

        roleEquip.setName(equip.getKey_name());
        roleEquip.setRoleId(role.getRoleId());
        roleEquip.setPosition(pos);

        if (equip.getReq_level() >= 80) {
            roleEquip.setType("高级首饰");
            if (!Objects.isNull(customEquip) && !Objects.isNull(customEquip.getFieldList())) {
                for (CustomEquipAttribute data : customEquip.getFieldList()) {
                    RoleEquipField equipField = new RoleEquipField();
                    equipField.setType((short) data.getColor().getValue());
                    LinkedHashMap<Short, FiedValue> linkedHashMap = new LinkedHashMap<>();

                    // 属性允许多条
                    if (roleEquip.getFields().containsKey(equipField.getType())) {
                        linkedHashMap.putAll(roleEquip.getFields().get(equipField.getType()).getField());
                    }

                    FiedValue fiedValue = new FiedValue();
                    fiedValue.setValue(data.getType());
                    fiedValue.setType((short) data.getValue());
                    fiedValue.setVT((byte) 2);
                    linkedHashMap.put(fiedValue.getType(), fiedValue);

                    equipField.setField(linkedHashMap);
                    roleEquip.getFields().put(equipField.getType(), equipField);
                }
            }
        } else {
            /**小于80的首饰可以叠加10个*/
            roleEquip.setType("低级首饰");
            EquipBox equipBox = role.getEquipBox();
            Set<RoleEquip> equips = new HashSet<>(equipBox.getEquips().values());
            for (RoleEquip tmpRoleEquip : equips) {
                if (tmpRoleEquip == null) {
                    continue;
                }
                if (!tmpRoleEquip.getName().equals(equip.getKey_name())) {
                    continue;
                }
                if (tmpRoleEquip.getPosition() < 41 || tmpRoleEquip.getPosition() > 165) {
                    continue;
                }
                /**物品限制相同的才让叠加*/
                int num = 1;
                if (false == tmpRoleEquip.isEverLimit()) {
                    num = bagService.mergeItem(role, roleEquip, 10, num);
                }
                if (num <= 0) {
                    return false;
                }
            }
        }

        if (!Objects.isNull(customEquip.getLimitTime())) {
            roleEquip.addLimitTime(customEquip.getLimitTime());
        }
        EquipUtil.add(role, roleEquip);
        EquipUtil.refreshRoleEquip(role, roleEquip);
        RespIconCartoon respIconCartoon = new RespIconCartoon();
        respIconCartoon.setName(roleEquip.getName());
        respIconCartoon.setParam(roleEquip.getId() + "");
        MessagePusher.pushMessage(role, respIconCartoon);
        return true;
    }

}
