package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;
import com.kitty.game.enter.LineInfo;

import java.util.List;

@MessageMeta(module = Modules.MSG_REQUEST_SERVER_STATUS)
public class RespChangeLineList extends Message {
    private List<LineInfo> linelist;

    public List<LineInfo> getLinelist() {
        return linelist;
    }

    public void setLinelist(List<LineInfo> linelist) {
        this.linelist = linelist;
    }
}
