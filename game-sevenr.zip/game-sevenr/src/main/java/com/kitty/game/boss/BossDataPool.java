package com.kitty.game.boss;

import com.kitty.game.boss.config.BossSet;
import com.kitty.game.config.MapBossPos;
import com.kitty.game.config.XinJun;

import java.util.Map;

/**boss产品数据*/
public class BossDataPool {
    // TODO 后面再看是否需要改成id 为key值来加快索引
    /**BossSet 的集合 key: BossSet的name value: BossSet对象*/
    public static Map<String , BossSet> bossSetMap;

    /**MapBossPos的集合 key: MapBossPos的mapId, MapBossPos对象*/
    public static Map<Integer, MapBossPos> mapBossPosMap;

    /**星君的配置 key :id value:星君对象*/
    public static  Map<String, XinJun> name2XingJun;
}
