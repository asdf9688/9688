package com.kitty.game.chat.model;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Getter
@Setter
public class RoleOfflineMessage {
    private Map<Long, List<OfflineMessage>> messageMap = new ConcurrentHashMap<>();

    public void add(long sendUid, int sendTime, String msg, String token, int voiceTime) {
        List<OfflineMessage> messageList = messageMap.computeIfAbsent(sendUid, k -> new ArrayList<>());
        messageList.add(new OfflineMessage(sendTime, msg, token, voiceTime));

    }
    public void setMessageMap(Map<Long, List<OfflineMessage>> messageMap) {
        this.messageMap = messageMap;
    }

    public Map<Long, List<OfflineMessage>> getMessageMap() {
        return this.messageMap;
    }
}
