package com.kitty.game.confirm.model;

import com.kitty.game.config.Fasion;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

public class BuyFashionConfirm extends RoleConfirm {

    /**
     * 购买的时装
     */
    private Fasion fasion;

    public BuyFashionConfirm(Fasion fasion) {

        this.fasion = fasion;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.BUY_FASHION;
    }

    public Fasion getFasion() {
        return fasion;
    }
}
