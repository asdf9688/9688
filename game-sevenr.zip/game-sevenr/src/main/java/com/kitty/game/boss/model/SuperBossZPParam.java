package com.kitty.game.boss.model;

import com.kitty.game.boss.config.BossSet;
import com.kitty.game.boss.model.BossParam;

public class SuperBossZPParam extends BossParam {
    public SuperBossZPParam(BossSet bossSet, String name) {
        super(bossSet, name);
    }
}
