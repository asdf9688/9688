package com.kitty.game.boss.model;

import com.kitty.game.enter.Position;
import lombok.Getter;
import lombok.Setter;

/**创建Boss对应NPC的参数对象*/
@Setter
@Getter
public class BossNpcParam {
    /**显示的ICON*/
    private int npcIcon;
    /**显示的npc名称*/
    private String npcName;
    /**对应BossSet表的名字*/
    private String bossSetName;
    private int mapId;
    private Position position;
    /**方向*/
    private short direction;
    /**持续显示时间(单位秒)*/
    private int showTimeSec;
    private String content;
    private String content1;
    /**是否需要广播*/
    private boolean isBroad;

    /**NPC 类型*/
    private byte npcType;
    /**由哪个玩家触发产生*/
    private long roleUid;
    /**NPC 等级*/
    private int level;
    /**用于区分奖励乱七八糟的*/
    private byte fujia_type;


    //后写
    public void setNpcIcon(int npcIcon) {
        this.npcIcon = npcIcon;
    }

    public void setNpcName(String npcName) {
        this.npcName = npcName;
    }

    public void setBossSetName(String bossSetName) {
        this.bossSetName = bossSetName;
    }

    public void setMapId(int mapId) {
        this.mapId = mapId;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public void setDirection(short direction) {
        this.direction = direction;
    }

    public void setShowTimeSec(int showTimeSec) {
        this.showTimeSec = showTimeSec;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setContent1(String content1) {
        this.content1 = content1;
    }

    public void setBroad(boolean isBroad) {
        this.isBroad = isBroad;
    }

    public void setNpcType(byte npcType) {
        this.npcType = npcType;
    }

    public void setRoleUid(long roleUid) {
        this.roleUid = roleUid;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getNpcIcon() {
        return this.npcIcon;
    }

    public String getNpcName() {
        return this.npcName;
    }

    public String getBossSetName() {
        return this.bossSetName;
    }

    public int getMapId() {
        return this.mapId;
    }

    public Position getPosition() {
        return this.position;
    }

    public short getDirection() {
        return this.direction;
    }

    public int getShowTimeSec() {
        return this.showTimeSec;
    }

    public String getContent() {
        return this.content;
    }

    public String getContent1() {
        return this.content1;
    }

    public boolean isBroad() {
        return this.isBroad;
    }

    public byte getNpcType() {
        return this.npcType;
    }

    public long getRoleUid() {
        return this.roleUid;
    }

    public int getLevel() {
        return this.level;
    }

    public byte getfujia_type() {
        return this.fujia_type;
    }
    public void setfujia_type(byte fujia_type) {
        this.fujia_type = fujia_type;
    }

}
