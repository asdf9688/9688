package com.kitty.game.chat.message;


import com.kitty.game.equip.model.EquipField;
import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

import java.util.List;

/**
 * 处理角色发言
 */
@MessageMeta(module = Modules.MSG_EQUIP_CARD)
public class RespEquipInfo extends Message {
    private byte pos=1;
    private List<EquipField> list;

    public byte getPos() {
        return pos;
    }

    public void setPos(byte pos) {
        this.pos = pos;
    }

    public List<EquipField> getList() {
        return list;
    }

    public void setList(List<EquipField> list) {
        this.list = list;
    }
}
