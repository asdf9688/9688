package com.kitty.game.config;

import lombok.Data;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

@Data
@Table("p_petexp")
public class PetExp {
    @Id(auto = false)
    private short level;
    @Column
    private int nextLevelExp;
    @Column
    private int expDan;
    @Column
    private int HighExpDan;
}
