package com.kitty.game.activity.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import com.kitty.game.chat.message.RespMessage;
import com.kitty.game.team.message.RespMsg;
import org.apache.commons.lang3.StringUtils;
import org.nutz.dao.Dao;
import org.nutz.json.Json;
import org.nutz.json.JsonFormat;
import org.nutz.lang.util.NutMap;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.config.NPC;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.equip.model.ChargeData;
import com.kitty.game.equip.model.RoleData;
import com.kitty.game.equip.service.DWDRService;
import com.kitty.game.mail.model.Mail;
import com.kitty.game.npc.service.NewNpcService;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.RoleService;
import com.kitty.game.utils.Const;
import com.kitty.game.utils.DateUtils;
import com.kitty.game.utils.TimeUtil;
import com.kitty.game.welfare.model.CommonFetchedData;
import com.kitty.logs.LoggerFunction;
import com.kitty.logs.Reason;
import com.kitty.mina.message.MessagePusher;
import org.apache.commons.lang3.StringUtils;
import org.nutz.dao.Dao;
import org.nutz.json.Json;
import org.nutz.json.JsonFormat;
import org.nutz.lang.util.NutMap;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
/*抽奖设置*/
@Service
public class ChouJiangService {

    @Autowired
    private RoleService roleService;
    @Autowired
    private NewNpcService newNpcService;

    @Autowired
    private Dao dao;

    Logger logger = LoggerFunction.ACTIVITY.getLogger();

    private static int once = 20;
    private static int tenTimes = 200;
    private static int daoheng = 0; //一年道行点 1300*360，boss掉落道行最多400，万年*50
    private static int exp = 500; //boss掉落经验最多3600
    private static int pot = 2000; //boss掉落经验最多3600
    // 抽奖奖励 元宝抽奖得豪礼！一次消耗10W金元宝！十次仅消耗90W金元宝！掉落物品：海量道行、海量经验、魔化神兽、极品道具、神兽、八速、变异等！每个新区当晚12点准时结束此活动！快来参加吧！

    /**
     * 抽奖概率
     */
    // private static String choujiangGifts = "daoheng=5000,exp=7000,items=2000,bianyi=500,basu=150,shenshou=5,mochong=5";
    private static String choujiangGifts = "daoheng=0,exp=0,items=3200,bianyi=10,basu=2,shenshou=1,mochong=0,pot=0";

    //抽奖活动排名
    CommonFetchedData choujiangData; //抽奖次数数据
    CommonFetchedData choujiangDay;  //抽奖活动开启时间

    HashMap<String, HashMap<String, String>> rewardData = new HashMap<>();

    public void init() {
        choujiangData = dao.fetch(CommonFetchedData.class, "choujiang_rank");
        if (choujiangData == null) {
            choujiangData = new CommonFetchedData();
            choujiangData.setData(Json.toJson(new ChargeData()));
            choujiangData.setType("choujiang_rank");
            dao.insertOrUpdate(choujiangData);
        }

        choujiangDay = dao.fetch(CommonFetchedData.class, "choujiang_day");
        if (choujiangDay == null) {
            choujiangDay = new CommonFetchedData();
            choujiangDay.setData(DateUtils.formatDate(new Date(System.currentTimeMillis() - TimeUtil.ONE_DAY)));
            choujiangDay.setType("choujiang_day");
            dao.insertOrUpdate(choujiangDay);
        }
        //奖励数据
        {
            {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("type", "法宝");
                hashMap.put("count", "1");
                hashMap.put("name", "24级指定法宝");
                rewardData.put("1", hashMap);
            }
            {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("type", "法宝");
                hashMap.put("count", "1");
                hashMap.put("name", "18级随机法宝");
                rewardData.put("2", hashMap);
            }
            {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("type", "神兽");
                hashMap.put("count", "1");
                hashMap.put("name", "魔化东山");
                rewardData.put("3", hashMap);
            }
        }
    }

    public CommonFetchedData getChoujiangDay() {
        return choujiangDay;
    }

    public void setChoujiangDay(CommonFetchedData choujiangDay) {
        this.choujiangDay = choujiangDay;
        dao.insertOrUpdate(this.choujiangDay); //重置活动开启时间

        choujiangData.setData(Json.toJson(new ChargeData())); //重置活动抽奖次数数据
//        choujiangData.setType("choujiang_rank");
        dao.insertOrUpdate(choujiangData);
    }

    /**
     * 随机获取奖品
     */
    public String getRandom(String giftStr) {
        String[] strings1 = giftStr.split(",");
        int total = 0;
        for (String ss : strings1) {
            String[] strings = ss.split("=");
            total += Integer.parseInt(strings[1]);
        }
        int result = ThreadLocalRandom.current().nextInt(total) + 1;
        int temp = 0;
        for (String ss : strings1) {
            String[] strings = ss.split("=");
            temp += Integer.parseInt(strings[1]);
            if (result <= temp) {
                return strings[0];
            }
        }
        return null;
    }

    //抽一次
    public void getOnce(Role role) {
        String gift = getRandom(choujiangGifts);
        if ("pot".equals(gift)) {
            roleService.addPot(role, ThreadLocalRandom.current().nextInt(1, 4) * role.getLevel() * daoheng / 5);
        } else if ("exp".equals(gift)) {
         //   roleService.addExp(role, ThreadLocalRandom.current().nextInt(1000000, 3000000), role.getLevel(), 0);
        } else if ("items".equals(gift)) {
            Mail mail = SpringUtils.getMailService().createMail("抽奖活动", "恭喜你抽中道具,抽奖包含神兽,经验,极品道具,宠物,神兽,坐骑", 30 * TimeUtil.ONE_DAY);
            ArrayList<NutMap> maps = new ArrayList<>();
            String[] string = {"超级百花羞卡","天神护佑","超级牛魔王卡","超级东山神灵卡","道行盛典礼包","1元充值卡","天神护佑","超级朱雀卡","3元充值卡","超级玄武卡","天神护佑","超级九尾狐卡","超级白骨精卡","天星石","天倾石","道行盛典礼包","道行盛典礼包","彩凤之魂","喇叭"};
            int index = new Random().nextInt(string.length);
            int count = 1;
            maps.add(new NutMap().setv("data", "#I普通道具|" + string[index] + "#r" + count + "#I").setv("type", Const.mailItem).setv("petName", string[index]).setv("value", count));
            mail.getDatas().addAll(maps);
            SpringUtils.getMailService().sendNewMail(role, mail);
            MessagePusher.pushMessage(role, new RespNotifyMiscEx("恭喜你，抽中道具#R" + string[index] + "#n，请在邮件中领取"));
        } else if ("basu".equals(gift)) {
            Mail mail = SpringUtils.getMailService().createMail("抽奖活动", "八速坐骑", 30 * TimeUtil.ONE_DAY);
            String[] strings = {"太极熊"};
            int index = new Random().nextInt(strings.length);
            ArrayList<NutMap> maps = new ArrayList<>();
            maps.add(new NutMap().setv("data", "#I宠物|" + strings[index] + "(精怪)#r1#I").setv("type", Const.mailPet)
                    .setv("petName", strings[index]).setv("value", 1));
            mail.getDatas().addAll(maps);
            SpringUtils.getMailService().sendNewMail(role, mail);
            MessagePusher.pushMessage(role, new RespNotifyMiscEx("恭喜你，抽中八速#R" + strings[index] + "#n，请在邮件中领取"));
            String content = "惊闻玩家#R" + role.getName() + "#n在#R抽奖活动#n中，获得#R" + strings[index] + "#n！真是可喜可贺！#51 #82";
            SpringUtils.getChatService().sendAdnotice(content);
        } else if ("shenshou".equals(gift)) {
            Mail mail = SpringUtils.getMailService().createMail("抽奖活动", "神兽", 30 * TimeUtil.ONE_DAY);
            String[] strings = {"朱雀", "九尾狐", "东山神灵", "白矖", "玄武", "疆良"};
            int index = new Random().nextInt(strings.length);
            ArrayList<NutMap> maps = new ArrayList<>();
            maps.add(new NutMap().setv("data", "#I宠物|" + strings[index] + "(神兽)#r1#I")
                    .setv("type", Const.mailPet).setv("petName", strings[index]).setv("value", 1));
            mail.getDatas().addAll(maps);
            SpringUtils.getMailService().sendNewMail(role, mail);
            MessagePusher.pushMessage(role, new RespNotifyMiscEx("恭喜你，抽中神兽#R" + strings[index] + "#n，请在邮件中领取"));
            String content = "惊闻玩家#R" + role.getName() + "#n在#R抽奖活动#n中，获得#R" + strings[index] + "#n！真是可喜可贺！#51 #82";
            SpringUtils.getChatService().sendAdnotice(content);
        } else if ("bianyi".equals(gift)) {
            Mail mail = SpringUtils.getMailService().createMail("抽奖活动", "变异", 30 * TimeUtil.ONE_DAY);
            String[] strings = {"伶俐鼠", "笨笨牛", "威威虎", "跳跳兔", "酷酷龙", "花花蛇", "溜溜马", "咩咩羊", "帅帅猴", "蛋蛋鸡", "乖乖狗", "招财猪"};
            int index = new Random().nextInt(strings.length);
            ArrayList<NutMap> maps = new ArrayList<>();
            maps.add(new NutMap().setv("data", "#I宠物|" + strings[index] + "(变异)#r1#I")
                    .setv("type", Const.mailPet).setv("petName", strings[index]).setv("value", 1));
            mail.getDatas().addAll(maps);
            SpringUtils.getMailService().sendNewMail(role, mail);
            MessagePusher.pushMessage(role, new RespNotifyMiscEx("恭喜你，抽中变异#R" + strings[index] + "#n，请在邮件中领取"));
            String content = "惊闻玩家#R" + role.getName() + "#n在#R抽奖活动#n中，获得#R" + strings[index] + "#n！真是可喜可贺！#51 #82";
            SpringUtils.getChatService().sendAdnotice(content);
        } else if ("mochong".equals(gift)) {
            Mail mail = SpringUtils.getMailService().createMail("抽奖活动", "魔化宠物", 30 * TimeUtil.ONE_DAY);
            String[] strings = {"魔化朱雀", "魔化疆良"};
            int index = new Random().nextInt(strings.length);
            ArrayList<NutMap> maps = new ArrayList<>();
            maps.add(new NutMap().setv("data", "#I宠物|" + strings[index] + "(魔宠)#r1#I").setv("type", Const.mailPet).setv("petName", strings[index]).setv("value", 1));
            mail.getDatas().addAll(maps);
            SpringUtils.getMailService().sendNewMail(role, mail);
            MessagePusher.pushMessage(role, new RespNotifyMiscEx("恭喜你，抽中魔化宠物#R" + strings[index] + "#n，请在邮件中领取"));
            String content = "惊闻玩家#R" + role.getName() + "#n在#R抽奖活动#n中，获得#R" + strings[index] + "#n！真是可喜可贺！#51 #82";
            SpringUtils.getChatService().sendAdnotice(content);
        }
    }

    public synchronized void npcButton(Role role, String msg, NPC npc) {
        if (StringUtils.isBlank(msg)) {
            return;
        }
        if ("抽奖一次".equals(msg)) {
            roleService.substractChargeScore(role, once);
            getOnce(role);
            addChoujiangRecored(role, 1);
        } else if ("抽奖十次".equals(msg)) {
            roleService.substractChargeScore(role, tenTimes);
            for (int i = 0; i < 10; i++) {
                getOnce(role);
            }
            addChoujiangRecored(role, 10);
        } else if ("抽奖排名".equals(msg)) {
            newNpcService.sendNpcContent(role, npc, getShow(role));
        }
    }

    public void addChoujiangRecored(Role role, int count) {
        String content = choujiangData.getData();
        ChargeData chargeData = Json.fromJson(ChargeData.class, content);
        String curr = DateUtils.formatDate(new Date());

        if (choujiangDay.getData().startsWith(curr) && choujiangDay.getData().endsWith("1")) {
            if (chargeData.getTime() <= 0) {
                chargeData.setTime(System.currentTimeMillis());
                chargeData.setHashMap(new HashMap<>());
            } else {
                String old = DateUtils.formatDate(new Date(chargeData.getTime()));
                if (!old.equals(curr)) {
                    chargeData.setTime(System.currentTimeMillis());
                    chargeData.setHashMap(new HashMap<>());
                }
            }
            if (chargeData.getHashMap().get(role.getUid()) == null) {
                RoleData roleData = new RoleData();
                roleData.setCharge(count);
                roleData.setName(role.getName());
                roleData.setUid(role.getUid());
                chargeData.getHashMap().put(role.getUid(), roleData);
            } else {
                RoleData roleData = chargeData.getHashMap().get(role.getUid());
                roleData.setCharge(count + roleData.getCharge());
            }
            choujiangData.setData(Json.toJson(chargeData));
            dao.update(choujiangData);
        }
    }

    //查看抽奖排行榜
    public String getShow(Role role) {
        String today = DateUtils.formatDate(new Date());
        String yesterday = DateUtils.formatDate(new Date(System.currentTimeMillis() - TimeUtil.ONE_DAY));
        if (!choujiangDay.getData().equals(today) && !choujiangDay.getData().equals(yesterday)) {
            return "今日或者昨日都没有充值排行榜活动 [离开]";
        }

        StringBuilder stringBuilder = new StringBuilder("抽奖次数排名奖励，24点自动发放。" +
                "第一名：24级指定法宝（多闻道人处领取）" +
                "第二名：24级随机法宝（邮件发放）" +
                "第三名：魔化朱雀（自动发放）" +
                "");
        int rank = getRank(role);
        if (rank == -1) {
            stringBuilder.append("#R当前没上榜，请道友再接再厉#n");
        } else {
            stringBuilder.append("当前第#R" + getRank(role) + "#n名");
        }
        stringBuilder.append("[离开]");
        return stringBuilder.toString();
    }

    public int getRank(Role tempRole) {
        String content = choujiangData.getData();
        ChargeData chargeData = Json.fromJson(ChargeData.class, content);
        if (chargeData.getHashMap() == null) {
            return -1;
        }
        String today = DateUtils.formatDate(new Date());
        String yesterday = DateUtils.formatDate(new Date(System.currentTimeMillis() - TimeUtil.ONE_DAY));
        if (!choujiangDay.getData().equals(today) && !choujiangDay.getData().equals(yesterday)) {
            return -1;
        }
        ArrayList<RoleData> arrayList = new ArrayList<>(chargeData.getHashMap().values());
        Collections.sort(arrayList, new Comparator<RoleData>() {
            @Override
            public int compare(RoleData o1, RoleData o2) {
                if (o1.getCharge() > o2.getCharge()) {
                    return -1;
                } else {
                    if (o1.getCharge() == o2.getCharge()) {
                        if (o1.getUid() > o2.getUid()) {
                            return -1;
                        }
                    }
                }
                return 1;
            }
        });
        // 获取奖励数据
        for (int i = 0; i < arrayList.size(); i++) {
            if (i >= 5) {
                break;
            }
            RoleData roleData = arrayList.get(i);
            Role role = SpringUtils.getPlayerService().getPlayerBy(roleData.getUid());
            if (role == null) {
                continue;
            }
            if (role.getRoleId() == tempRole.getRoleId()) {
                return i + 1;
            }
        }
        return -1;
    }

    public void notice() {
        String curr = DateUtils.formatDate(new Date());
        if (!choujiangDay.getData().equals(curr)) {
            return;
        }
        notice111(true);
    }

    public void notice111(boolean boo) {
        String content = choujiangData.getData();
        ChargeData chargeData = Json.fromJson(ChargeData.class, content);
        if (chargeData.getHashMap() == null) {
            return;
        }
        if (chargeData.getHashMap().size() <= 0) {
            return;
        }
        boo = false;

        ArrayList<RoleData> arrayList = new ArrayList<>(chargeData.getHashMap().values());
        Collections.sort(arrayList, new Comparator<RoleData>() {
            @Override
            public int compare(RoleData o1, RoleData o2) {
                if (o1.getCharge() > o2.getCharge()) {
                    return -1;
                } else {
                    if (o1.getCharge() == o2.getCharge()) {
                        if (o1.getUid() > o2.getUid()) {
                            return -1;
                        }
                    }
                }
                return 1;
            }
        });
        StringBuilder notice = new StringBuilder("当前抽奖排行榜：");
        String[] strings = {"一", "二", "三",};
        for (int i = 0; i < arrayList.size(); i++) {
            if (i >= 3) {
                break;
            }
            RoleData roleData = arrayList.get(i);
            if (boo) {
                notice.append("第" + strings[i] + "名：#R" + roleData.getName() + "#n ");
            } else {
                notice.append("第" + strings[i] + "名：#R" + roleData.getName() + "#n 抽奖次数#R" + roleData.getCharge() + " #n");
            }
        }
        SpringUtils.getChatService().sendAdnotice(notice.toString());
        notice = new StringBuilder("抽奖活动 开始当天-晚上23:59:59秒"
                + "第一名：24级指定法宝（多闻道人处领取）" +
                " 第二名：18级指定法宝（邮件发放）" +
                " 第三名：魔化朱雀（自动发放） ");

        SpringUtils.getChatService().sendAdnotice(notice.toString());
    }

    public void sendReward() {
        String content = choujiangData.getData();
        ChargeData chargeData = Json.fromJson(ChargeData.class, content);
        if (chargeData.getHashMap() == null) {
            return;
        }
        ArrayList<RoleData> roleDataArrayList = new ArrayList<>(chargeData.getHashMap().values());
        Collections.sort(roleDataArrayList, new Comparator<RoleData>() {
            @Override
            public int compare(RoleData o1, RoleData o2) {
                if (o1.getCharge() > o2.getCharge()) {
                    return -1;
                } else {
                    if (o1.getCharge() == o2.getCharge()) {
                        if (o1.getUid() > o2.getUid()) {
                            return -1;
                        }
                    }
                }
                return 1;
            }
        });

        // 获取奖励数据
        for (int i = 0; i < roleDataArrayList.size(); i++) {
            if (i >= 3) {
                break;
            }
            RoleData roleData = roleDataArrayList.get(i);
            Role role = SpringUtils.getPlayerService().getPlayerBy(roleData.getUid());
            if (role == null) {
                continue;
            }
            HashMap<String, String> hashMap = rewardData.get(i + 1 + "");
            if (hashMap == null) {
                continue;
            }
            Mail mail = SpringUtils.getMailService().createMail("抽奖活动", "抽奖活动", 30 * TimeUtil.ONE_DAY);
            if (hashMap.get("type").equals("法宝")) {
                if (hashMap.get("name").contains("24级指定法宝")) {
                    SpringUtils.getBean(DWDRService.class).add(role);
                } else if (hashMap.get("name").contains("24级随机法宝")) {
                    String[] strings = {"混元金斗", "番天印", "阴阳镜", "定海珠", "金蛟剪", "九龙神火罩", "卸甲金葫"};
                    int index = new Random().nextInt(strings.length);
                    ArrayList<NutMap> maps = new ArrayList<>();
                    maps.add(new NutMap().setv("data", "#I物品|" + strings[index] + "#r24#I").setv("type", Const.mailFabao).setv("petName", "24级" + strings[index]).setv("value", 24));
                    mail.getDatas().addAll(maps);
                    SpringUtils.getMailService().sendNewMail(role, mail);
                }
            } else if (hashMap.get("type").equals("物品")) {
                ArrayList<NutMap> maps = new ArrayList<>();
                int value = Integer.parseInt(hashMap.get("count"));
                String name = hashMap.get("name");
                maps.add(new NutMap().setv("data", "#I物品|" + name + "#r" + value + "#I").setv("type", Const.mailItem).setv("petName", name).setv("value", value));
                mail.getDatas().addAll(maps);
                SpringUtils.getMailService().sendNewMail(role, mail);
            } else if (hashMap.get("type").equals("召唤令")) {
                ArrayList<NutMap> maps = new ArrayList<>();
                int value = Integer.parseInt(hashMap.get("count"));
                String name = hashMap.get("name");
                maps.add(new NutMap().setv("data", "#I物品|" + name + "#r" + value + "#I").setv("type", Const.mailItem).setv("petName", name).setv("value", value));
                mail.getDatas().addAll(maps);
                SpringUtils.getMailService().sendNewMail(role, mail);
            } else if (hashMap.get("type").equals("神兽")) {
                String name = hashMap.get("name");
                mail.getDatas().add(new NutMap().setv("data", "#I宠物|" + name + "(神兽)#r1#I").setv("type", Const.mailPet).setv("petName", name));
                SpringUtils.getMailService().sendNewMail(role, mail);
            } else if (hashMap.get("type").equals("积分")) {
                int value = Integer.parseInt(hashMap.get("count"));
                mail.getDatas().add(new NutMap().setv("data", "#I积分|积分#r" + value + "#I").setv("type", Const.jifen).setv("value", value));
                SpringUtils.getMailService().sendNewMail(role, mail);
            }
            logger.error("充值排行榜奖励发放=={}=={}=={}=={}", role.getRoleId(), role.getName(), i, Json.toJson(hashMap, JsonFormat.compact()));
        }
    }
}
