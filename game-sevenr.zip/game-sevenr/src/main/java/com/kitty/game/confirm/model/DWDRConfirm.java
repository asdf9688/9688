package com.kitty.game.confirm.model;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

public class DWDRConfirm extends RoleConfirm {
    String msg;
    public DWDRConfirm(String msg){
        this.msg = msg;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.dwdr_leiji;
    }
}
