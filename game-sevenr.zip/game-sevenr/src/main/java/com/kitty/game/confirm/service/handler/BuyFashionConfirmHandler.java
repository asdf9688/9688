package com.kitty.game.confirm.service.handler;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.bag.message.RespIconCartoon;
import com.kitty.game.config.Fasion;
import com.kitty.game.confirm.model.BuyFashionConfirm;
import com.kitty.game.confirm.service.handler.ConfirmHandler;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.equip.model.RoleEquip;
import com.kitty.game.equip.service.EquipService;
import com.kitty.game.function.service.FasionService;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.RoleService;
import com.kitty.game.team.message.ReqConfirmResult;
import com.kitty.game.waiguan.RespFasionCustomBegin;
import com.kitty.game.waiguan.RespFasionCustomEnd;
import com.kitty.logs.Reason;
import com.kitty.mina.message.MessagePusher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**处理购买时装*/
@Component
public class BuyFashionConfirmHandler extends ConfirmHandler {
    @Autowired
    RoleService roleService;
    @Autowired
    EquipService equipService;
    @Autowired
    FasionService fasionService;
    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
        if ("1".equals(reqConfirmResult.getSelect())) {
            buyFasion(role);
        }
    }

    /**
     * 购买自定义时装
     */
    private void buyFasion(Role role) {
        BuyFashionConfirm confirm = (BuyFashionConfirm) role.getConfirm();
        Fasion fasion =confirm.getFasion();
        int needGold =fasion.getPrice();
        if (role.getGold() < needGold || needGold < 0) {
            return;
        }

        RespFasionCustomBegin respFasionCustomBegin = new RespFasionCustomBegin();
        respFasionCustomBegin.setLabel("buy_fasion");
        MessagePusher.pushMessage(role, respFasionCustomBegin);
        SpringUtils.getRoleService().subtractGold(role, fasion.getPrice(), Reason.BUY_EFFECT);
        roleService.updateRoleGoldAndSiver( role);

        short pos = fasionService.getFasionPos(role, "fasion_store");
        RoleEquip roleEquip = fasionService.getFasion(role, fasion.getName(), 1, true);
        roleEquip.setPosition(pos);
        equipService.add(role, roleEquip);

        MessagePusher.pushMessage(role, new RespIconCartoon(fasion.getName()));
        roleService.updateRoleGoldAndSiver( role);
        fasionService.sendFasionStore(roleEquip.getPosition(), role, roleEquip, "fasion_store");

        MessagePusher.pushMessage(role, new RespNotifyMiscEx("你花费#R" + fasion.getPrice() + "#n个金元宝购买了#R" + fasion.getName() + "#n。"));

        roleService.updateRoleGoldAndSiver( role);
        RespFasionCustomEnd respFasionCustomEnd = new RespFasionCustomEnd();
        respFasionCustomEnd.setLabel("buy_fasion");
        MessagePusher.pushMessage(role, respFasionCustomEnd);
    }

}
