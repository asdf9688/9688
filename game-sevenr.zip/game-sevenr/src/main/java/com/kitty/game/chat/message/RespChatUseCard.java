package com.kitty.game.chat.message;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

/**
 * 处理角色发言
 */
@MessageMeta(module = Modules.MSG_MESSAGE_EX_card)
public class RespChatUseCard extends Message {
    private int flag=1488315600;
    private int  type =0;

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
