package com.kitty.game.bangpai;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

/**
 * 打开帮派成员
 */
@MessageMeta(module = Modules.CMD_PARTY_MEMBERS)
public class ReqPartyMembers extends Message {
    private short page;
    private String roleName;
    private String gid;

    public short getPage() {
        return page;
    }

    public void setPage(short page) {
        this.page = page;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getGid() {
        return gid;
    }

    public void setGid(String gid) {
        this.gid = gid;
    }
}
