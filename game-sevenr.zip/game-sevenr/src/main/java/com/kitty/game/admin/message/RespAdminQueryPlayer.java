package com.kitty.game.admin.message;

import com.kitty.game.admin.message.vo.QueryPlayer;
import com.kitty.mina.NewModules;
import com.kitty.mina.annotation.ListField;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;
import lombok.Setter;

import java.util.List;

/**返回帐号查询结果*/
@Setter
@MessageMeta(module = NewModules.MSG_ADMIN_QUERY_PLAYER)
public class RespAdminQueryPlayer extends Message {
    @ListField(3)
    private List<QueryPlayer> players;

}
