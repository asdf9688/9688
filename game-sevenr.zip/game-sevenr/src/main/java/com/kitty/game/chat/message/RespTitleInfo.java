package com.kitty.game.chat.message;


import com.kitty.game.chat.message.vo.Title;
import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

/**
 * 处理角色发言
 */
@MessageMeta(module = Modules.MSG_CARD_INFO, cmd = 4)
public class RespTitleInfo extends Message {
    private String uuId;
    private String type;
    private Title title;

    public String getUuId() {
        return uuId;
    }

    public void setUuId(String uuId) {
        this.uuId = uuId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Title getTitle() {
        return title;
    }

    public void setTitle(Title title) {
        this.title = title;
    }
}
