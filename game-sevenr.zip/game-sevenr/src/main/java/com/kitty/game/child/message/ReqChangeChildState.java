package com.kitty.game.child.message;

import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

/**
 * 切换元婴的状态*/
@MessageMeta(module = Modules.CMD_CHANGE_CHAR_UPGRADE_STATE)
public class ReqChangeChildState extends Message {
    private byte state;

    public byte getState() {
        return state;
    }

    public void setState(byte state) {
        this.state = state;
    }
}
