package com.kitty.game.activity.model.product.shuadao;

import com.kitty.game.activity.model.product.ActivityType;
import com.kitty.game.activity.model.product.RandomNpcParam;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public abstract class ShuaDaoSet {
    /**出现的地图ID列表*/
    private List<Integer> mapIds = Arrays.asList(13000, 14000, 15000, 16000/*, 10100*/, 10200, 10300, 10400, 10500, 16100, 18000, 17000/*, 36000*/, 17100,
            17200/*, 17300*/, 17400, 17500, 17600, 17700/*, 21000*//*, 20002*/, 22000, 19002);
    /**显示的秒数，15分钟*/
    private int showTimeSecond = 15 * 60;

    /**获得接取刷道任务所在的NPC id*/
    public abstract int getAcceptNpcId();

    /**获得刷道名称*/
    public abstract String getShuaDaoName();

    /**获得接取最低等级*/
    public abstract int getMinLevel();

    /**获得等级不足时的提示语*/
    public abstract String getLevelNotEnoughDesc();

    /**获得刷道战斗对应任务ID*/
    public abstract int getFightTaskId();

    /**获得刷道引导对应任务ID*/
    public abstract int getGuideTaskId();

    public abstract String getContent();

    public abstract RandomNpcParam getRandomNpcParam();

    /**获得随机地图ID*/
    public int getRandomMapId() {
        int mapIdIndex = ThreadLocalRandom.current().nextInt(mapIds.size());
        return mapIds.get(mapIdIndex);
    }

    public short getDirection() {
        return 6;
    }

    public int getShowTimeSecond() {
        return showTimeSecond;
    }

    public abstract ActivityType getActivityType();

    /**获得NPC对应生成的BossSet数量*/
    public abstract int getNpcBossCount();

    /**获得小怪对应在bossSet表的名字列表*/
    public abstract List<String> getSmallBossNames();

    /**获得小怪生成后显示的名字*/
    public abstract String getSmallAlias();
    /**获得生成怪的总数量*/
    public abstract int getBossTotalCount();

    /**发奖或者扣除道具时，完成1次按多少次刷道计算*/
    public abstract int getCountRate();

    public abstract String getRankKey();
}
