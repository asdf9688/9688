package com.kitty.game.confirm.facade;

import com.kitty.game.role.model.Role;
import com.kitty.common.spring.SpringUtils;
import com.kitty.game.confirm.service.ConfirmService;
import com.kitty.mina.annotation.RequestMapping;
import com.kitty.mina.cache.SessionUtils;
import com.kitty.game.team.message.ReqConfirmResult;
import org.apache.mina.core.session.IoSession;
import org.springframework.stereotype.Controller;

/**处理确认框相关的Controller*/
@Controller
public class ConfirmController {

    /**处理确认框结果*/
    @RequestMapping
    public void reqConfirmResult(IoSession session, ReqConfirmResult reqConfirmResult) {
        Role role = SessionUtils.getRoleBySession(session);
        SpringUtils.getBean(ConfirmService.class).handleConfirmResult(role, reqConfirmResult);
    }
}
