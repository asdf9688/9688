package com.kitty.game.confirm.service.handler;

import com.kitty.game.role.model.Role;
import com.kitty.common.spring.SpringUtils;
import com.kitty.game.confirm.model.CreatePartyConfirm;
import com.kitty.game.confirm.service.handler.ConfirmHandler;
import com.kitty.game.party.service.PartyService;
import com.kitty.game.team.message.ReqConfirmResult;
import org.springframework.stereotype.Component;

@Component
public class CreatePartyConfrimHandler extends ConfirmHandler {
    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
        if ("1".equals(reqConfirmResult.getSelect())) {
            CreatePartyConfirm createPartyConfirm = (CreatePartyConfirm)role.getConfirm();
            SpringUtils.getBean(PartyService.class).confirmCreateParty(role, createPartyConfirm.getPartyName());
        }
    }
}
