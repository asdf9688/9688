package com.kitty.game.bag.model;

import com.kitty.game.equip.model.EquipField;

import com.kitty.game.equip.model.RoleHunQiField;
import com.kitty.mina.annotation.ListField;
import java.util.List;

public class StoreEquipInfo {
    private byte index = 1;
    private short pos = 201;//仓库中的位置
    private short size;

    @ListField(2)
    private List<EquipField> equipFields;
    @ListField(2)
    private List<RoleHunQiField> hunQiFields;

    public byte getIndex() {
        return index;
    }

    public void setIndex(byte index) {
        this.index = index;
    }

    public short getPos() {
        return pos;
    }

    public void setPos(short pos) {
        this.pos = pos;
    }

    public short getSize() {
        return (short) ((equipFields == null ? 0 : equipFields.size()) + (hunQiFields == null ? 0
                : hunQiFields.size()));
    }

    public void setSize(short size) {
        this.size = size;
    }

    public List<EquipField> getEquipFields() {
        return equipFields;
    }

    public void setEquipFields(List<EquipField> equipFields, List<RoleHunQiField> hunQiFields) {
        this.equipFields = equipFields;
        this.hunQiFields = hunQiFields;
        setSize(getSize());
    }

    public List<RoleHunQiField> getHunQiFields() {
        return hunQiFields;
    }

    public void setHunQiFields(List<RoleHunQiField> hunQiFields) {
        this.hunQiFields = hunQiFields;
        setSize(getSize());
    }
}
