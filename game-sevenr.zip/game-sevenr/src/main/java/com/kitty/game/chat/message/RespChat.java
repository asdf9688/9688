package com.kitty.game.chat.message;


import com.kitty.game.enter.FiedValue;
import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.annotation.StringField;
import com.kitty.mina.message.Message;

import java.util.List;

/**
 * 处理角色发言
 */
@MessageMeta(module = Modules.MSG_MESSAGE_EX)
public class RespChat extends Message {
    private short type;//消息类型
    private int roleId;//角色ID
    private String roleName;//角色名称
    @StringField(value = 1)
    private String msg;//消息内容
    private int time;//时间戳
    private short privilege = 0;// 权限
    private String lineName;//角色所在线路
    private short msgType = 1;//语音1 文字0 特殊表情也是1
    private short compress = 0;//压缩？
    private short orgLength = -1;
    private short cardCount = 0;//

    private int voiceTime;
    @StringField(value = 1)
    private String token;//
    private int checkSum = 0;//
    private short count = 0;//临时用不上
   private List<FiedValue> list;//

    private int friendId;
    private String partyName;

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public int getRoleId() {
        return roleId;
    }

    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public short getPrivilege() {
        return privilege;
    }

    public void setPrivilege(short privilege) {
        this.privilege = privilege;
    }

    public String getLineName() {
        return lineName;
    }

    public void setLineName(String lineName) {
        this.lineName = lineName;
    }

    public short getMsgType() {
        return msgType;
    }

    public void setMsgType(short msgType) {
        this.msgType = msgType;
    }

    public short getCompress() {
        return compress;
    }

    public void setCompress(short compress) {
        this.compress = compress;
    }

    public short getOrgLength() {
        return orgLength;
    }

    public void setOrgLength(short orgLength) {
        this.orgLength = orgLength;
    }

    public short getCardCount() {
        return cardCount;
    }

    public void setCardCount(short cardCount) {
        this.cardCount = cardCount;
    }

    public int getVoiceTime() {
        return voiceTime;
    }

    public void setVoiceTime(int voiceTime) {
        this.voiceTime = voiceTime;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public int getCheckSum() {
        return checkSum;
    }

    public void setCheckSum(int checkSum) {
        this.checkSum = checkSum;
    }

    public List<FiedValue> getList() {
        return list;
    }

    public void setList(List<FiedValue> list) {
        this.list = list;
    }

    public int getFriendId() {
        return friendId;
    }

    public void setFriendId(int friendId) {
        this.friendId = friendId;
    }

    public String getPartyName() {
       return partyName;
    }

    public void setPartyName(String partyName) {
        this.partyName = partyName;
    }
}
