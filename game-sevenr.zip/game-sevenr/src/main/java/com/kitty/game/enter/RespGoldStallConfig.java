package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

@MessageMeta(module = Modules.MSG_GOLD_STALL_CONFIG)
public class RespGoldStallConfig extends Message {

    
    private byte is_enable;
    
    private byte enable_gold_stall_cash;
    
    private byte sell_cash_aft_days;
    
    private byte start_gold_stall_cash;
    
    private byte enable_appoint;
    
    private byte enable_autcion;
    
    private int close_time;

    public byte getIs_enable() {
        return is_enable;
    }

    public void setIs_enable(byte is_enable) {
        this.is_enable = is_enable;
    }

    public byte getEnable_gold_stall_cash() {
        return enable_gold_stall_cash;
    }

    public void setEnable_gold_stall_cash(byte enable_gold_stall_cash) {
        this.enable_gold_stall_cash = enable_gold_stall_cash;
    }

    public byte getSell_cash_aft_days() {
        return sell_cash_aft_days;
    }

    public void setSell_cash_aft_days(byte sell_cash_aft_days) {
        this.sell_cash_aft_days = sell_cash_aft_days;
    }

    public byte getStart_gold_stall_cash() {
        return start_gold_stall_cash;
    }

    public void setStart_gold_stall_cash(byte start_gold_stall_cash) {
        this.start_gold_stall_cash = start_gold_stall_cash;
    }

    public byte getEnable_appoint() {
        return enable_appoint;
    }

    public void setEnable_appoint(byte enable_appoint) {
        this.enable_appoint = enable_appoint;
    }

    public byte getEnable_autcion() {
        return enable_autcion;
    }

    public void setEnable_autcion(byte enable_autcion) {
        this.enable_autcion = enable_autcion;
    }

    public int getClose_time() {
        return close_time;
    }

    public void setClose_time(int close_time) {
        this.close_time = close_time;
    }
}
