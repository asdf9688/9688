package com.kitty.game.enter;

import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

import static com.kitty.mina.NewModules.CMD_REFRESH_USER_DATA;

@MessageMeta(module = CMD_REFRESH_USER_DATA)
public class ReqRefreshUserData extends Message {
}
