package com.kitty.game.confirm.service.handler;

import com.kitty.game.role.model.Role;
import com.kitty.game.team.message.ReqConfirmResult;

/**确认框处理器抽象类*/
public abstract class ConfirmHandler {

    public abstract void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult);
}
