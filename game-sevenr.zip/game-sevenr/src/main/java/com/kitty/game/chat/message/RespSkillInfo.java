package com.kitty.game.chat.message;


import com.kitty.game.skill.message.vo.SkillInfo;
import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

import java.util.List;

/**
 * 处理角色发言
 */
@MessageMeta(module = Modules.MSG_CARD_INFO, cmd = 3)
public class RespSkillInfo extends Message {
    private String uuId;
    private String type;
    private List<SkillInfo> list;


    public String getUuId() {
        return uuId;
    }

    public void setUuId(String uuId) {
        this.uuId = uuId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<SkillInfo> getList() {
        return list;
    }

    public void setList(List<SkillInfo> list) {
        this.list = list;
    }
}
