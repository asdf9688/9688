package com.kitty.game.bag.service.giftHandler;

import com.alibaba.fastjson.JSONObject;
import com.kitty.common.spring.SpringUtils;
import com.kitty.common.utils.EquipUtil;
import com.kitty.game.admin.message.ReqAdminMakeEquip;
import com.kitty.game.admin.service.AdminService;
import com.kitty.game.attribute.AttrService;
import com.kitty.game.attribute.config.Attribute;
import com.kitty.game.bag.message.RespIconCartoon;
import com.kitty.game.bag.model.GiftBagData;
import com.kitty.game.base.service.BagService;
import com.kitty.game.config.Equip;
import com.kitty.game.enter.FiedValue;
import com.kitty.game.equip.EquipDataPool;
import com.kitty.game.equip.handler.EquipProduceHandler;
import com.kitty.game.equip.message.ReqUpgradeEquip;
import com.kitty.game.equip.model.*;
import com.kitty.game.equip.service.EquipService;
import com.kitty.game.equip.util.EquipProductUtil;
import com.kitty.game.onlinemall.service.MallService;
import com.kitty.game.role.model.Role;
import com.kitty.listener.EventDispatcher;
import com.kitty.listener.EventType;
import com.kitty.listener.event.EquipUpgradeLevelChangeEvent;
import com.kitty.listener.event.UpgradeEquipEvent;
import com.kitty.mina.message.MessagePusher;
import com.kitty.mina.task.ThreadLocalUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * 开启礼包得到 自定义/随机 装备奖励
 */
@Component
public class EquipGiftHandler extends GiftHandler {

    @Autowired
    private BagService bagService;
    @Autowired
    private AttrService attrService;
    @Autowired
    MallService mallService;

    @Override
    public void getReward(Role role, GiftBagData giftBagData) {
        // 获得装备
        for (int i = 0; i < giftBagData.getCount(); i ++) {
            short pos = bagService.getPos(role, false);
            if (pos <= 0) {
                return;
            }
            this.getEquip(role, giftBagData, pos);
        }
    }

    private Boolean getEquip(Role role, GiftBagData giftBagData, short newPos) {
        RoleEquip roleEquip = new RoleEquip();
        Equip equip = EquipDataPool.getByName(giftBagData.getName());
        CustomEquip customEquip = JSONObject.parseObject(giftBagData.getContent(), CustomEquip.class);

        roleEquip.setType("装备");
        int id = mallService.getRoleEquipId();
        roleEquip.setId(id);

        roleEquip.setName(giftBagData.getName());
        roleEquip.setRoleId(role.getRoleId());
        roleEquip.setPosition(newPos);

        RoleEquipField roleEquipField = new RoleEquipField();
        roleEquipField.setType((short) 1);
        String color = customEquip.getColor().name();
        LinkedHashMap<Short, FiedValue> basicAttrNew = EquipUtil.getBasicAttrNew(equip, roleEquip, color, true);
        roleEquipField.setField(basicAttrNew);
        roleEquip.getFields().put(roleEquipField.getType(), roleEquipField);
        RoleEquipField basicAttNew = EquipUtil.getBasicAttNew(equip);
        roleEquip.getFields().put(basicAttNew.getType(), basicAttNew);
        if (!Objects.isNull(customEquip.getPolar())) {
            // 套装属性是否生效
//            roleEquip.alterSuitEnabled(0);
            roleEquip.alterSuitPolar(customEquip.getPolar().getPolar());
        }

        if (!Objects.isNull(customEquip) && !Objects.isNull(customEquip.getFieldList())) {
            for (CustomEquipAttribute data : customEquip.getFieldList()) {
                logger.info("data={}", JSONObject.toJSONString(data));
                RoleEquipField equipField = new RoleEquipField();
                equipField.setType((short) data.getColor().getValue());
                LinkedHashMap<Short, FiedValue> linkedHashMap = new LinkedHashMap<>();
                // 仅蓝色属性允许多条
//                if (data.getColor() == Color.蓝色 && roleEquip.getFields().containsKey(equipField.getType())) {
//                    linkedHashMap.putAll(roleEquip.getFields().get(equipField.getType()).getField());
//                }
                // 全部属性允许多条
                if (roleEquip.getFields().containsKey(equipField.getType())) {
                    linkedHashMap.putAll(roleEquip.getFields().get(equipField.getType()).getField());
                }
                {//基础气血
                    FiedValue fiedValue = new FiedValue();
                    fiedValue.setType((short) data.getType().getId());
                    Attribute attribute = attrService.getAttr(data.getType().getId());
                    fiedValue.setVT(attribute.getType());
                    int value = data.getValue();
                    fiedValue.setValue(value);
                    linkedHashMap.put(fiedValue.getType(), fiedValue);
                }
                equipField.setField(linkedHashMap);
                roleEquip.getFields().put(equipField.getType(), equipField);
            }
        }
        roleEquip.alterUpgradeLevel(customEquip.getBuildLevel());
        RespIconCartoon respIconCartoon = new RespIconCartoon();
        respIconCartoon.setName(roleEquip.getName());
        respIconCartoon.setParam(roleEquip.getId() + "");
        MessagePusher.pushMessage(role, respIconCartoon);
        EquipUtil.addUpgradeField(equip, roleEquip);
        EquipUtil.add(role, roleEquip);
        EquipUtil.refreshRoleEquip(role, roleEquip);

        /**产生一个装备改造等级改变事件*/
        EventDispatcher.getInstance().fireEvent(new EquipUpgradeLevelChangeEvent(EventType.EQUIP_UPGRADE_LEVEL_CHANGE, role, roleEquip, (short) customEquip.getBuildLevel()));

        return true;
    }
}
