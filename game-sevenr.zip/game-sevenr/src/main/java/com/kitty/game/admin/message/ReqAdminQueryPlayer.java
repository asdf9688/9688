package com.kitty.game.admin.message;

import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

import static com.kitty.mina.NewModules.CMD_ADMIN_QUERY_PLAYER;

@MessageMeta(module = CMD_ADMIN_QUERY_PLAYER)
public class ReqAdminQueryPlayer extends Message {
    private String name;
    private String type;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
