package com.kitty.game.activity.service.task;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.activity.model.product.ActivityType;
import com.kitty.game.activity.service.ActivityService;
import com.kitty.game.artifact.ArtifactService;
import com.kitty.game.base.service.BagService;
import com.kitty.game.boss.config.BossSet;
import com.kitty.game.boss.model.BossFightParam;
import com.kitty.game.boss.model.BossNpcParam;
import com.kitty.game.boss.model.BossParam;
import com.kitty.game.boss.service.NewBossService;
import com.kitty.game.config.GameMap;
import com.kitty.game.config.MapBossPos;
import com.kitty.game.config.NPC;
import com.kitty.game.config.TaskSet;
import com.kitty.game.enter.Position;
import com.kitty.game.equip.service.EquipService;
import com.kitty.game.map.service.MapService;
import com.kitty.game.npc.model.NpcButton;
import com.kitty.game.npc.service.NewNpcService;
import com.kitty.game.pet.model.Pet;
import com.kitty.game.pet.service.PetService;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.RoleService;
import com.kitty.game.task.message.RespDemandWantedTask;
import com.kitty.game.task.message.vo.TaskInfo;
import com.kitty.game.task.message.vo.WantedTaskInfo;
import com.kitty.game.task.model.product.TaskType;
import com.kitty.game.team.message.RespMsg;
import com.kitty.game.team.model.Team;
import com.kitty.game.utils.Const;
import com.kitty.game.utils.TimeUtil;
import com.kitty.listener.event.FightEndEvent;
import com.kitty.mina.message.MessagePusher;
import org.nutz.lang.util.NutMap;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
//后加
import com.kitty.game.activity.service.task.TaskActivityHandler;

/**
 * 悬赏任务(仙界神捕)处理类
 */
@Component
public class XuanShangTaskHandler extends TaskActivityHandler {
    /**
     * 出现的地图ID列表
     */
    private static final List<Integer> MAPIDS = Arrays.asList(13000, 14000, 15000, 16000, 10200, 10300, 10400, 10500, 16100, 18000, 17000, 17100,
            17200, 17400, 17500, 17600, 17700, 22000, 19002);
    private static final String NAME = "{0}通缉的仙界叛逆";
    private static final String FIHGT_NAME = "仙界叛逆";
    private static final List<String> BOSS_NAMES = Arrays.asList("仙界叛逆1", "仙界叛逆2", "仙界叛逆3", "仙界叛逆4", "仙界叛逆5");
    /**
     * 战斗对应任务ID
     */
    private static final int FIHGT_TASK_ID = 112;
    /**
     * 领取奖励对应任务ID
     */
    private static final int REWARD_TASK_ID = 113;
    private static final int ACCEPT_MIN_LEVEL = 30;
    /**
     * 出现的方向
     */
    private static final short DIRECTION = 6;
    /**
     * 持续显示的秒数
     */
    private static final int SHOW_TIME_SEC = 120 * 60;
    private static final String MESSAGE_TEMPLATE = "前往#R#Z{0}#Z#n捉拿#R{1}#n。";
    private static final String ACCEPTED = "你已经领取过悬赏任务了，赶快去完成吧。";
    private static final String TIME_NOT_ACCEPT = "每个半点发布一次悬赏任务，发布后的10分钟内可领取。";
    private static final String LEVEL_NOT_ENOUGH = "你修行尚浅，还是不要冒险行事了(等级不足#R{0}级#n)";
    private static final String REMAIN_COUNT_NOT_ENOUGH = "你已经没有领取悬赏任务的次数，还是给其他人一些机会吧！";

    /**
     * Boss从属于别的玩家时的提示
     */
    private static final String NOT_YOU = "看什么看，没见过这么帅的通缉犯啊！[离开]";
    private static final String CONTENT = "那天杀的仙界臭捕，爷爷逃到凡人的地盘还穷追不舍！#R战斗结束时死亡的角色会受到惩罚。#n[追拿通缉犯/" + NpcButton.DO_XUANSHANG.getKey() + "][离开]";
    private static final String MEMBER_LEVEL_NOT_ENOUGH = "队伍里的#Y{0}#n这么弱，也想打败我？再修炼100年吧。（等级不足#R{1}级#n）[离开]";
    private static final String FIRST_FETCH_CONTENT = "你还有奖励没有领取，领取奖励后方可获得新任务。[我要经验奖励/" + NpcButton.CHOOSE_XUANSHANG_REWARD_EXP.getKey() + "][我要道行奖励/" + NpcButton.CHOOSE_XUANSHANG_REWARD_DAOHANG.getKey() + "][离开]";
    private static final String FETCH_REWARD_CONTENT = "很好，你出色的完成了任务，为仙界立下一功，决定你想要的奖赏吧！[我要经验奖励/" + NpcButton.CHOOSE_XUANSHANG_REWARD_EXP.getKey() + "][我要道行奖励/" + NpcButton.CHOOSE_XUANSHANG_REWARD_DAOHANG.getKey() + "][离开]";
    private static final String NOT_FETCH_REWARD = "请先完成悬赏任务！[离开]";
    /**
     * 可以开始接取悬赏任务的系统消息
     */
    private static final String START_ACCEPT_SYSTEM = "本#Y仙界神捕#n奉命追拿仙界逃亡人间的#Y仙界叛逆#n，有识之士均可到#R无名小镇#n找#P仙界神捕#P报名，为追拿#Y仙界叛逆#n出一份力，凡有功之人定会获得#R丰厚奖赏#n！";


    @Override
    public TaskSet getAcceptingTask(Role role, NPC npc) {
        return taskService.getTaskSet(FIHGT_TASK_ID, role);
    }

    @Override
    public boolean isTeamAcceptTask() {
        return false;
    }

    @Override
    public String canAcceptTask(Role role, TaskSet taskSet, boolean auto) {
        /**即使组队了也只接取队长个人的*/


        /**是否在接取时间内*/
        if (isInAcceptTime() == false) {
            String msg = TIME_NOT_ACCEPT;
            MessagePusher.pushMessage(role, new RespMsg(msg));
            return "";
        }

        /**等级不足*/
        if (role.getLevel() < ACCEPT_MIN_LEVEL) {
            String msg = MessageFormat.format(LEVEL_NOT_ENOUGH, role.getName(), ACCEPT_MIN_LEVEL);
            MessagePusher.pushMessage(role, new RespMsg(msg));
            return "";
        }
        ActivityService activityService = SpringUtils.getActivityService();
        int remainCount = activityService.getRemainCount(role, ActivityType.XUAN_SHANG);
        /**剩余次数没有了*/
        if (remainCount <= 0) {
            String msg = REMAIN_COUNT_NOT_ENOUGH;
            MessagePusher.pushMessage(role, new RespMsg(msg));
            return "";
        }

        /**已经接取了*/
        int taskId = FIHGT_TASK_ID;
        if (role.getTask().isAccepted(taskId)) {
            String msg = ACCEPTED;
            MessagePusher.pushMessage(role, new RespMsg(msg));
            return "";
        }

        if (isCanFetchReward(role)) {
            return FIRST_FETCH_CONTENT;
        }

        return null;
    }

    /**
     * 当前时间是否在可接任务范围内
     */
    private boolean isInAcceptTime() {
        Calendar calendar = Calendar.getInstance();
        int minute = calendar.get(Calendar.MINUTE);
        if (minute >= 30 && minute < 40) {
            return true;
        }
        return false;
    }

    @Override
    public TaskInfo getTaskInfo(Role role, TaskSet taskSet) {
        int taskNpcId = role.getTask().getTaskNpcId(taskSet.getId());
        if (taskNpcId > 0) {
            MapService mapService = SpringUtils.getMapService();
            ActivityService activityService = SpringUtils.getActivityService();

            NPC npc = mapService.getNpc(taskNpcId);
            /**NPC可能过期删除了*/
            if (npc == null) {return null;}

            GameMap gameMap = mapService.getMap(npc.getMapId());
            String jieshao = taskSet.getTaskJieshao();
            /**剩余分钟数*/
            long remainMinute = (npc.getEndTime() > System.currentTimeMillis() ? ((npc.getEndTime() - System.currentTimeMillis()) / Const.MINUTE) : 0);
            jieshao = jieshao.replace("#剩余时间", String.valueOf(remainMinute));
            /**获得战斗奖励次数*/
            int fightRewardCount = activityService.getFinishCount(role, ActivityType.XUAN_SHANG_FIHGT);
            jieshao = jieshao.replace("#次数", String.valueOf(fightRewardCount));
            TaskInfo taskInfo = new TaskInfo();
            taskInfo.setQuit((short) taskSet.getGiveUp());// 是否可以放弃
            taskInfo.setTaskName(taskSet.getTaskName());
            taskInfo.setShow_name(taskSet.getTaskName());
            taskInfo.setTaskInfo(jieshao);

            taskInfo.setTaskZhiyin(MessageFormat.format(taskSet.getTaskZhiyin(), gameMap.getName(), npc.getX(), npc.getY(), npc.getName()));
            taskInfo.setTaskJiangli(taskSet.getTaskGift());
            return taskInfo;
        }

        return taskService.getTaskInfo(role, taskSet);
    }

    @Override
    public String getPrompt(NPC npc) {
        GameMap map = SpringUtils.getMapService().getMap(npc.getMapId());
        return MessageFormat.format(MESSAGE_TEMPLATE, map.getName(), npc.getName());
    }

    @Override
    public BossNpcParam newBossNpcParam(Role role, TaskSet taskSet) {
        BossNpcParam bossNpcParam = new BossNpcParam();

        NewBossService bossService = SpringUtils.getBean(NewBossService.class);
        String randomBossName = getRandomBossName();
        BossSet bossSet = bossService.getBossSet(randomBossName);
        bossNpcParam.setNpcIcon(bossSet.getIcon());
        bossNpcParam.setBossSetName(bossSet.getName());


        int randomMapId = getRandomMapId();
        MapBossPos mapBossPos = bossService.getMapBossPos(randomMapId);
        Position position = bossService.getRandomPosition(mapBossPos);
        bossNpcParam.setMapId(mapBossPos.getMapId());
        bossNpcParam.setPosition(position);

        bossNpcParam.setDirection(DIRECTION);
        bossNpcParam.setShowTimeSec(SHOW_TIME_SEC);

        String npcName = MessageFormat.format(NAME, role.getName());

        bossNpcParam.setNpcName(npcName);

        bossNpcParam.setNpcType(NPC.TYPE_XUAN_SHANG);
        /**属于哪个玩家*/
        bossNpcParam.setRoleUid(role.getUid());

        bossNpcParam.setBroad(true);

        return bossNpcParam;
    }

    /**
     * 获得随机的对应BossSet的name
     */
    private String getRandomBossName() {
        int index = ThreadLocalRandom.current().nextInt(BOSS_NAMES.size());
        return BOSS_NAMES.get(index);
    }

    /**
     * 获得随机出现的地图ID
     */
    private int getRandomMapId() {
        int index = ThreadLocalRandom.current().nextInt(MAPIDS.size());
        return MAPIDS.get(index);
    }

    @Override
    public String getNpcContent(Role role, NPC bossNpc) {
        String contentNotStart = getNpcContentNotFight(role, bossNpc);
        if (contentNotStart != null) {
            return contentNotStart;
        }
        return CONTENT;
    }

    @Override
    public TaskType getTaskType() {
        return TaskType.XUAN_SHANG;
    }

    @Override
    public String getNpcContentNotFight(Role role, NPC bossNpc) {
        /**挑战玩家 不是对应玩家时*/
        if (bossNpc.getRoleUid() != role.getUid()) {
            return NOT_YOU;
        }

        if (teamService.isInTeam(role)) {
            if (teamService.isTeamLeader(role) == false) {
                return "";
            }

            Team team = teamService.getTeam(role.getRoleId());

            String names = teamService.checkMember(team, memberRole -> memberRole.getLevel() < ACCEPT_MIN_LEVEL);
            if (names != null) {
                return MessageFormat.format(MEMBER_LEVEL_NOT_ENOUGH, names, ACCEPT_MIN_LEVEL);
            }
        }

        return null;
    }

    @Override
    public void doStartFight(Role role, TaskSet taskSet, NPC bossNpc) {
        List<BossParam> bossParamList = newBossParamList(role, bossNpc);
        BossFightParam bossFightParam = new BossFightParam(bossParamList, getFightType(role), taskSet.getId(), bossNpc.getId());
        NewBossService bossService = SpringUtils.getBean(NewBossService.class);
        bossService.startFightToBoss(role, bossFightParam);
    }

    private List<BossParam> newBossParamList(Role role, NPC npc) {
        List<BossParam> bossParamList = new ArrayList<>();
        int count = 5;

        /**npc对应的加在第1个*/
        NewBossService bossService = SpringUtils.getBean(NewBossService.class);
        BossSet bossSet = bossService.getBossSet(npc.getBossSetName());
        bossParamList.add(new BossParam(bossSet, FIHGT_NAME));

        /**加count-1个*/
        for (int i = 1; i < count; i++) {
            bossSet = bossService.getBossSet(npc.getBossSetName());
            bossParamList.add(new BossParam(bossSet, FIHGT_NAME));
        }

        return bossParamList;
    }

    @Override
    protected int getFightType(Role role) {
        return Const.fightType_xuanshang;
    }

    @Override
    protected void addActivityFinishCount(Role role, TaskSet taskSet) {
        /**战斗奖励次数+1*/
        SpringUtils.getActivityService().addFinishCount(role, ActivityType.XUAN_SHANG_FIHGT, 1);
    }

    @Override
    protected void giveReward(Role role, NutMap reward, TaskSet taskSet, int currPetId) {
        /**给战斗奖励*/


        BagService bagService = SpringUtils.getBean(BagService.class);
        EquipService equipService = SpringUtils.getBean(EquipService.class);
        PetService petService = SpringUtils.getBean(PetService.class);
        RoleService roleService = SpringUtils.getRoleService();
        ActivityService activityService = SpringUtils.getBean(ActivityService.class);
        int finishCount = activityService.getFinishCount(role, ActivityType.XUAN_SHANG_FIHGT);

        int step = ((finishCount - 1) % 10 + 1);
        /**第10轮时*/
        if ((step) == 10) {
            // 奖励装备
            short roleLevel = role.getLevel();
            String temp = roleLevel + "";
            if (temp.length() == 3) {
                roleLevel = Short.parseShort(temp.substring(0, 2) + 0);
            } else {
                roleLevel = Short.parseShort(temp.substring(0, 1) + 0);
            }
            short newPos = bagService.getPos(role, false);
            if (newPos > 0) {
                equipService.getNotIdentifyEquip(roleLevel, role, newPos);
            }
        }
        int daohang = new Double(reward.getInt("rewardDaohang", 0)
                * ((step * 0.1 + 1))).intValue();
        int qianneng = new Double(reward.getInt("rewardQianneng", 0)
                * ((step * 0.1 + 1))).intValue();
        int money = new Double(reward.getInt("rewardMoney", 0)
                * ((step * 0.1 + 1))).intValue();

        Pet pet = petService.getPetById(role.getPetBox().getFightPetId(), role);
        if (pet != null) {
            int petWuxue = new Double(reward.getInt("petRewardWuxue")
                    * ((step * 0.1 + 1))).intValue();
            NutMap doubleStatus = role.getPropsStatus();
            int point = doubleStatus.getInt("pet");
            if (doubleStatus.getInt("petStatus") == 1 && point >= 4) {
                doubleStatus.setv("pet", point - 4);
                role.save();
                petWuxue = petWuxue * 2;
            }
            roleService.addPetMatiral(role, pet, petWuxue);
        }

        int jijirulvling = role.getPropsStatus().getInt("manguaiStatus", 0);
        int kaiqi = role.getPropsStatus().getInt("manguai", 0);
        // 如果有急急如律令，奖励双倍
        if (jijirulvling > 0 && kaiqi > 0) {
            kaiqi = kaiqi - 1;
            int size = reward.getInt("size", 1);
            role.getPropsStatus().setv("manguai", kaiqi);
            role.save();
            money = money / size * 10;
            daohang = daohang / size * 10;
            qianneng = qianneng / size * 10;
        }
        NutMap nutMap = role.getPropsStatus();
        int point = nutMap.getInt("role");

        ArtifactService artifactService = SpringUtils.getBean(ArtifactService.class);
        if (nutMap.getInt("roleStatus") == 1 && point >= 4) {
            nutMap.setv("role", point - 4);
            role.save();
            money = money * 2;
            daohang = daohang * 2;
            qianneng = qianneng * 2;
            artifactService.addArtifactExp(true, role);
        } else {
            artifactService.addArtifactExp(false, role);
        }
        roleService.addTao(role, daohang);
        roleService.addMoney(role, money);
        roleService.addPot(role, qianneng);
    }

    @Override
    protected void doBeforeDelete(Role role, TaskSet taskSet) {

    }

    @Override
    public void doFightWinForSingle(Role role, TaskSet taskSet, FightEndEvent fightEndEvent) {
        /**根据是否要删除战斗任务，来判断是否要接取奖励任务*/
        boolean isAcceptedReward = taskSet.getId() == FIHGT_TASK_ID && isDeleteTask(role, taskSet);

        super.doFightWinForSingle(role, taskSet, fightEndEvent);

        /**接取领奖任务*/
        if (isAcceptedReward) {
            TaskSet rewardTaskSet = taskService.getTaskSet(REWARD_TASK_ID, role);
            acceptTask(role, rewardTaskSet, null);
        }
    }

    @Override
    public boolean isDeleteTask(Role role, TaskSet taskSet) {
        if (teamService.isInTeam(role) && !teamService.isTeamLeader(role)) {
            /**在组队却不是队长时，返回false*/
            return false;
        }
        return super.isDeleteTask(role, taskSet);
    }

    @Override
    protected void doAfterDelete(Role role, TaskSet taskSet) {

    }

    @Override
    public boolean isCreateNpcForFight(TaskSet taskSet) {
        if (taskSet.getId() == FIHGT_TASK_ID) {
            return true;
        }

        return false;
    }

    /**
     * 领取悬赏任务奖励
     */
    public void fetchXuanShangReward(Role role, NPC npc) {
        String check = checkFetchReward(role);
        if (check != null) {
            SpringUtils.getBean(NewNpcService.class).sendNpcContent(role, npc, check);
            return;
        }

        SpringUtils.getBean(NewNpcService.class).sendNpcContent(role, npc, FETCH_REWARD_CONTENT);
    }

    /**
     * 选择领取悬赏任务经验奖励
     */
    public void chooseXuanShangRewardExp(Role role, NPC npc) {
        boolean canFetch = doBeforeFetchXuanShangReward(role, npc);
        /**可以领奖*/
        if (canFetch) {
            /**暂时奖励，后面再调整。5个怪，10倍除暴经验奖励*/
            int exp =  4000 * role.getLevel();
            NutMap nutMap = role.getPropsStatus();
            int point = nutMap.getInt("role");
            if (nutMap.getInt("roleStatus") == 1 && point >= 4) {
                nutMap.setv("role", point - 4);
                role.save();
                exp = exp * 2;
            }

            RoleService roleService = SpringUtils.getRoleService();
            roleService.addExp(role, exp, 20, role.getPetBox().getFightPetId());
        }
    }

    /**
     * 选择领取悬赏任务道行奖励
     */
    public void chooseXuanShangRewardDaohang(Role role, NPC npc) {
        boolean canFetch = doBeforeFetchXuanShangReward(role, npc);
        /**可以领奖*/
        if (canFetch) {
            /**暂时奖励，后面再调整。5个怪，10倍刷道奖励*/
            int daohang = 200*10;
            SpringUtils.getRoleService().addTao(role, daohang);

            Pet pet = SpringUtils.getPetService().getPetById(role.getPetBox().getFightPetId(), role);
            if (pet != null) {
                /**暂时奖励，后面再调整。5个怪，10倍刷道奖励*/
                int petWuxue = 5 * 5 * 10;
                NutMap doubleStatus = role.getPropsStatus();
                int point = doubleStatus.getInt("pet");
                if (doubleStatus.getInt("petStatus") == 1 && point >= 4) {
                    doubleStatus.setv("pet", point - 4);
                    role.save();
                    petWuxue = petWuxue * 2;
                }
                SpringUtils.getRoleService().addPetMatiral(role, pet, petWuxue);
            }
        }
    }

    /**
     * 领取奖励前做些事情
     */
    private boolean doBeforeFetchXuanShangReward(Role role, NPC npc) {
        String check = checkFetchReward(role);
        if (check != null) {
            SpringUtils.getBean(NewNpcService.class).sendNpcContent(role, npc, check);
            return false;
        }

        /**删除任务*/
        TaskSet rewardTaskSet = taskService.getTaskSet(REWARD_TASK_ID, role);
        super.deleteTaskForSingle(role, rewardTaskSet);

        /**增加次数*/
        SpringUtils.getActivityService().addFinishCount(role, ActivityType.XUAN_SHANG, 3);

        return true;
    }

    /**
     * 检测能否领取奖励
     */
    private String checkFetchReward(Role role) {
        if (isCanFetchReward(role) == false) {
            return NOT_FETCH_REWARD;
        }

        int remainCount = SpringUtils.getActivityService().getRemainCount(role, ActivityType.XUAN_SHANG);
        if (remainCount <= 0) {
            MessagePusher.pushMessage(role, new RespMsg(REMAIN_COUNT_NOT_ENOUGH));
            return "";
        }

        return null;
    }

    /**
     * 是否可以领取奖励
     */
    private boolean isCanFetchReward(Role role) {
        TaskSet rewardTaskSet = taskService.getTaskSet(REWARD_TASK_ID, role);
        return taskService.isTaskAccepted(role, rewardTaskSet);
    }

    @Override
    public void doFightFail(Role role, TaskSet taskSet, FightEndEvent fightEndEvent) {
        super.doFightFail(role, taskSet, fightEndEvent);
        teamService.memberHandleThreadLocal(role, memberRole -> SpringUtils.getRoleService().punishFightDead(memberRole));
    }

    /**
     * 推送开始可以接取任务的系统消息
     */
    public void pushStartAcceptSystem() {
        SpringUtils.getChatService().sendSystem(START_ACCEPT_SYSTEM, Const.BRODCAST_MSG_TYPE_ROLE);
    }

    public void sendNpcContent(Role role, NPC bossNpc) {
        String content = getNpcContent(role, bossNpc);
        SpringUtils.getNpcService().sendNpcContent(role, bossNpc, content);
    }

    @Override
    public void handleLogin(Role role) {
        checkTaskTime(role);

        super.handleLogin(role);
    }

    private void checkTaskTime(Role role) {
        /**检测任务对应的NPC是否存在*/
        TaskSet taskSet = getTaskSetByType(role);
        if (taskSet == null || isCreateNpcForFight(taskSet) == false) {
            return;
        }

        long acceptTime = role.getTask().getAcceptTime(taskSet.getId());
        int remainSec = (int) (SHOW_TIME_SEC - ((System.currentTimeMillis() - acceptTime) / TimeUtil.ONE_SECOND));

        /**已经超过时间，删除任务*/
        if (remainSec <= 0) {
            super.deleteTaskForSingle(role, taskSet);
        }

        int taskNpcId = role.getTask().getTaskNpcId(taskSet.getId());
        /**悬赏任务对应的NPC找不到时，重新生成1个NPC*/
        if (taskNpcId > 0 && SpringUtils.getMapService().getNpc(taskNpcId) == null) {
            BossNpcParam bossNpcParam = newBossNpcParam(role, taskSet);
            bossNpcParam.setShowTimeSec(remainSec);
            NPC bossNpc = SpringUtils.getBean(NewBossService.class).createBossNpc(role, bossNpcParam);
            acceptTask(role, taskSet, bossNpc);
        }
    }

    /**
     * 查询悬赏任务次数
     */
    public void viewXuanShangCount(Role role, String msg, NPC npc) {
        RespDemandWantedTask respDemandWantedTask = getRespDemandWantedTask(role);
        teamService.pushMessage(role, respDemandWantedTask);
    }

    private RespDemandWantedTask getRespDemandWantedTask(Role role) {
        RespDemandWantedTask respDemandWantedTask = new RespDemandWantedTask();
        List<WantedTaskInfo> taskInfoList = new ArrayList<>();
        respDemandWantedTask.setTaskInfoList(taskInfoList);

        if (teamService.isInTeam(role)) {
            Team team = teamService.getTeam(role.getRoleId());
            teamService.memberHandle(team, memberRole -> taskInfoList.add(getWantedTaskInfo(memberRole)));
        } else {
            taskInfoList.add(getWantedTaskInfo(role));
        }

        return respDemandWantedTask;
    }

    private WantedTaskInfo getWantedTaskInfo(Role role) {
        WantedTaskInfo wantedTaskInfo = new WantedTaskInfo();
        wantedTaskInfo.setIcon(role.getRoleIcon());
        wantedTaskInfo.setLevel(role.getLevel());
        wantedTaskInfo.setName(role.getName());
        wantedTaskInfo.setVipType(role.getVipType());
        wantedTaskInfo.setTimes((byte) SpringUtils.getActivityService().getRemainCount(role, ActivityType.XUAN_SHANG));
        wantedTaskInfo.setStatus((byte) (taskService.isTaskAccepted(role, taskService.getTaskSet(FIHGT_TASK_ID, role)) ? 2 : 1));
        return wantedTaskInfo;
    }
}
