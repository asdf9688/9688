package com.kitty.game.confirm.service.handler;

import com.kitty.game.confirm.service.handler.ConfirmHandler;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.RoleService;
import com.kitty.game.team.message.ReqConfirmResult;
import com.kitty.game.team.message.RespMsg;
import com.kitty.game.team.model.Member;
import com.kitty.game.team.model.Team;
import com.kitty.game.team.service.TeamService;
import com.kitty.mina.message.Message;
import com.kitty.mina.message.MessagePusher;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LihunConfirmHandler extends ConfirmHandler {
  @Autowired
  RoleService roleService;
  
  @Autowired
  TeamService teamService;
  
  public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
    if ("1".equals(reqConfirmResult.getSelect()))
      if (role.getActivity().getRechargeScore() >= 200) {
        this.roleService.substractChargeScore(role, 200);
        String msg2 = "离婚成功，扣除200积分";
        MessagePusher.pushMessage(role, (Message)new RespMsg(msg2));
        Team team = this.teamService.getTeam(role.getRoleId());
        List<Member> list = team.getList();
        int leaderId = team.getLeaderRoleId();
        Member leader = null;
        Member other = null;
        for (Member member : list) {
          if (member.getRoleId() == leaderId) {
            leader = member;
            continue;
          } 
          other = member;
        } 
        Role leaderRole = this.roleService.getOnlinePlayer(leader.getUid());
        Role otherRole = this.roleService.getOnlinePlayer(other.getUid());
        leaderRole.setLoverId(0);
        otherRole.setLoverId(0);
        this.roleService.delTitle(leaderRole, "结婚");
        this.roleService.delTitle(otherRole, "结婚");
        leaderRole.getFriendBox().getFriendByGid(otherRole.getGid()).setFriendliness(0);
        otherRole.getFriendBox().getFriendByGid(leaderRole.getGid()).setFriendliness(0);
        leaderRole.save();
        otherRole.save();
      } else {
        String msg2 = "积分不足, 离婚失败";
        MessagePusher.pushMessage(role, new RespMsg(msg2));
      }  
  }
}
