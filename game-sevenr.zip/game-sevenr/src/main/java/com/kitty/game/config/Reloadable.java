package com.kitty.game.config;

public interface Reloadable {


    /**
     * 重载数据
     */
    void reload();
}
