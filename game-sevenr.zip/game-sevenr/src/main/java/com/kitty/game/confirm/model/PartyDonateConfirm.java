package com.kitty.game.confirm.model;

import lombok.Getter;
import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;


@Getter
public class PartyDonateConfirm extends RoleConfirm {
    /**捐献的金钱*/
    private int money;

    public PartyDonateConfirm(int money) {
        this.money = money;
    }

    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.PARTY_DONATE;
    }
}
