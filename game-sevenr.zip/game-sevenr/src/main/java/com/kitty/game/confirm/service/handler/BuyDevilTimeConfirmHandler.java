package com.kitty.game.confirm.service.handler;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.activity.service.other.DevilActivityHandler;
import com.kitty.game.confirm.model.BuyDevilTimeConfirm;
import com.kitty.game.confirm.service.handler.ConfirmHandler;
import com.kitty.game.role.model.Role;
import com.kitty.game.team.message.ReqConfirmResult;
import org.springframework.stereotype.Component;

@Component
public class BuyDevilTimeConfirmHandler extends ConfirmHandler {
    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
        if ("1".equals(reqConfirmResult.getSelect())) {
            BuyDevilTimeConfirm buyDevilTimeConfirm = (BuyDevilTimeConfirm)role.getConfirm();
            SpringUtils.getBean(DevilActivityHandler.class).confirmBuyTime(role, buyDevilTimeConfirm.getType());
        }
    }
}
