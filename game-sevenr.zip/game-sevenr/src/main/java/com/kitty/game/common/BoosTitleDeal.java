package com.kitty.game.common;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.kitty.common.spring.SpringUtils;
import com.kitty.game.enter.TitleInfo;
import com.kitty.game.equip.model.RoleEquip;
import com.kitty.game.party.model.Party;
import com.kitty.game.pet.model.Pet;
import com.kitty.game.player.serializer.PlayerSerializerUtil;
import com.kitty.game.rank.message.ReqCrossRankView;
import com.kitty.game.rank.model.record.*;
import com.kitty.game.rank.service.RankService;
import com.kitty.game.rank.service.handler.*;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.PayService;
import com.kitty.game.utils.Const;
import com.kitty.game.utils.ObjectCastUtils;
import com.kitty.game.utils.TimeUtil;
import com.kitty.game.welfare.model.CommonFetchedData;
import com.kitty.listener.EventType;
import com.kitty.listener.annotation.EventHandler;
import com.kitty.listener.event.*;
import com.kitty.mina.annotation.RequestMapping;
import com.kitty.mina.cache.SessionUtils;
import groovyjarjarantlr.collections.impl.LList;
import org.apache.mina.core.session.IoSession;
import org.nutz.dao.Chain;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import javax.annotation.PostConstruct;
import java.text.SimpleDateFormat;
import java.util.*;

import static org.springframework.util.ObjectUtils.isEmpty;

/**
 * BOOS称号处理
 */
@Component
public class BoosTitleDeal {

    @Autowired
    private Dao dao;

    public Map<String, List<Map<String, String>>> boos_title_map = new HashMap<>();

    /**
     * 初始化
     **/
    @PostConstruct
    public void init() {
        CommonFetchedData commonFetchedData = dao.fetch(CommonFetchedData.class, "first_titles_boos");
        //初始化
        if (commonFetchedData == null) {
            commonFetchedData = new CommonFetchedData("first_titles_boos", "{}");
            dao.insert(commonFetchedData);
        } else {
            String data = commonFetchedData.getData();
            Map map = JSON.parseObject(data, HashMap.class);
            for (Object o : map.keySet()) {
                String key = String.valueOf(o);
                Object value = map.get(key);
                List<Map<String, String>> list = boos_title_map.get(key);
                if (list == null) {
                    list = new ArrayList<>();
                }


                if (!isEmpty(value)) {
                    List<Map> maps = ObjectCastUtils.castList(value, Map.class);
                    for (Map m : maps) {
                        Map<String, String> map_data = new HashMap<>();
                        String name = String.valueOf(m.get("name"));
                        String time = String.valueOf(m.get("time"));
                        String title = String.valueOf(m.get("title"));
                        map_data.put("name", name);
                        map_data.put("time", time);
                        map_data.put("title", title);
                        list.add(map_data);
                    }
                }
                boos_title_map.put(key, list);
            }
        }
    }

    /**
     * 添加称号数据
     */
    public void addBoosTitle(String name, String key, String title) {
        if (boos_title_map.get(key) != null) {
            List<Map<String, String>> list = boos_title_map.get(key);

            Map<String, String> map_data = new HashMap<>();
            map_data.put("name", name);
            map_data.put("time", TimeUtil.formatDate(new Date(), TimeUtil.DEFAULT_DATE_FORMAT));
            map_data.put("title", title);
            list.add(map_data);
            boos_title_map.put(key, list);
        }

    }


    /**
     * 称号已获得状态 存到数据库
     */
    public void updateBoosTitle() {
        String data = JSONObject.toJSONString(boos_title_map);
        dao.update(CommonFetchedData.class, Chain.make("data", data), Cnd.where("type", "=", "first_titles_boos"));
    }

    /**
     * 清理称号数据
     *
     * @param key
     */
    public void clearKeyBoosTitle(String key) {
        if (boos_title_map.get(key) != null) {
            List<Map<String, String>> list = new ArrayList<>();
            boos_title_map.put(key, list);
            updateBoosTitle();
        }
    }

    /**
     * 清理称号数据
     *
     * @param key
     */
    public void clearKeyAndTitleBoosTitle(String key, String title) {
        if (boos_title_map.get(key) != null) {
            List<Map<String, String>> list = new ArrayList<>();
            Iterator<Map<String, String>> iterator = list.iterator();
            while (iterator.hasNext()) {
                Map<String, String> next = iterator.next();
                if (String.valueOf(next.get("title")).equals(title)) {
                    iterator.remove();
                }
            }
            boos_title_map.put(key, list);
            updateBoosTitle();
        }
    }

    /**
     * 清理称号数据
     *
     * @param key
     */
    public void clearKeyAndTitleAndRoleBoosTitle(String key) {
        if (boos_title_map.get(key) != null) {
            List<Map<String, String>> list = boos_title_map.get(key);
            for (Map<String, String> map : list) {
                Role role = dao.query(Role.class, Cnd.where("name", "=", map.get("name"))).get(0);
                PlayerSerializerUtil.deserialize(role);
                SpringUtils.getRoleService().delTitle(role, map.get("title"));
                role.save();
            }
            clearKeyBoosTitle(key);
        }
    }


}
