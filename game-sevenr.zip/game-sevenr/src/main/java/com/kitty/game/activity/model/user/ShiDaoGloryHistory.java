package com.kitty.game.activity.model.user;


import com.kitty.common.db.BaseEntity;
import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

import java.util.List;
//后加
import com.kitty.game.activity.model.user.ShiDaoGloryRecord;


@Table("t_shidaohistory")
public class ShiDaoGloryHistory extends BaseEntity<Long> {
    @Id
    private Long id;
    @Column
    private short level;
    @Column
    private int time;
    @Column
    @ColDefine(width = 512)
    private List<ShiDaoGloryRecord> records;

    public ShiDaoGloryHistory() {}

    public ShiDaoGloryHistory(long id, short level, int time, List<ShiDaoGloryRecord> records) {
        this.id = id;
        this.level = level;
        this.time = time;
        this.records = records;
    }

    @Override
    public Long getId() {
        return id;
    }

    public short getLevel() {
        return level;
    }

    public void setLevel(short level) {
        this.level = level;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public List<ShiDaoGloryRecord> getRecords() {
        return records;
    }

    public void setRecords(List<ShiDaoGloryRecord> records) {
        this.records = records;
    }
}
