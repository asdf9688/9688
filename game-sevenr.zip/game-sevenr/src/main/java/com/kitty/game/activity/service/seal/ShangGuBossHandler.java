package com.kitty.game.activity.service.seal;


import com.kitty.game.role.model.Role;
import com.kitty.game.config.NPC;
import com.kitty.common.spring.SpringUtils;
import com.kitty.game.npc.message.RespNpcContent;
import com.kitty.game.npc.model.NpcButton;
import com.kitty.game.utils.Const;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
//后加
import com.kitty.game.activity.service.seal.SealBossHandler;

/**上古妖王处理类*/
@Component
public class ShangGuBossHandler extends SealBossHandler {
    private final String ownerNpcName = "{0}的上古妖王";
    private final String npcName = "上古妖王";
    private final String bossName = "上古妖王";
    private final List<String> smallBossNames = Arrays.asList("上古妖王1","上古妖王2","上古妖王3","上古妖王4");
    private final String smallName = "小妖";
    private final String fightTag = NpcButton.FIGHT_TO_SHANGGU.getKey();
    private int firstTalkId = 1220;

    @Override
    public String getOwnerNpcName() {
        return ownerNpcName;
    }

    @Override
    public String getNpcName() {
        return npcName;
    }

    @Override
    public String getBossName() {
        return bossName;
    }

    @Override
    public List<String> getSmallBossNames() {
        return smallBossNames;
    }

    @Override
    public String getSmallName() {
        return smallName;
    }

    @Override
    public String getFightTag() {
        return fightTag;
    }

    @Override
    public int getFirstTalkId() {
        return firstTalkId;
    }

    @Override
    public byte getNpcType() {
        return NPC.TYPE_SHANG_GU;
    }

    @Override
    protected int getFightType(Role role) {
        return Const.fightType_shanggu;
    }

    public void sendNpcContent(Role role, NPC bossNpc, String content) {
        RespNpcContent respNpcContent = SpringUtils.getNpcService().getRespNpcContent(role, bossNpc, content);
        respNpcContent.setNpcName(getNpcName());
        SpringUtils.getNpcService().sendRespNpcContent(role, respNpcContent);
    }
}
