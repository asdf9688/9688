package com.kitty.game.config;

import lombok.Getter;
import org.nutz.dao.entity.annotation.*;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Default;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

@Table("p_server")
@Getter
public class Server {
    @Id
    private int id;
    @Column
    @Comment("大区名称")
    private String name;
    @Column
    @Comment("大区端口号")
    private int port;
    @Column
    @Comment("大区ip")
    private String ip;
    @Column
    @Comment("线名称")
    private String sonName;
    @Column
    @Comment("线端口号")
    private int sonPort;
    @Column
    @Comment("线ip")
    private String sonIp;
    @Column
    @Comment("多少人为绿色")
    private int green;
    @Column
    @Comment("多少人为黄色")
    private int orange;
    @Column
    @Comment("多少人为红色")
    private int red;
    @Column
    @Comment("满人")
    private int full;
    @Column
    @Comment("满人")
    @Default("0")
    private boolean open;
    @Column
    private String payUrl;
    @Column
    @Default("1")
    private boolean payEnable;
    @Column
    private int gmPort;

    private int state = 0;



    public int getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public int getPort() {
        return this.port;
    }

    public String getIp() {
        return this.ip;
    }

    public String getSonName() {
        return this.sonName;
    }

    public int getSonPort() {
        return this.sonPort;
    }

    public String getSonIp() {
        return this.sonIp;
    }

    public int getGreen() {
        return this.green;
    }

    public int getOrange() {
        return this.orange;
    }

    public int getRed() {
        return this.red;
    }

    public int getFull() {
        return this.full;
    }

    public boolean isOpen() {
        return this.open;
    }

    public String getPayUrl() {
        return this.payUrl;
    }

    public boolean isPayEnable() {
        return this.payEnable;
    }

    public int getGmPort() {
        return this.gmPort;
    }
    public void setOpen(boolean open) {
        this.open = open;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }


}
