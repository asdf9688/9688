package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

/**
 * 实名认证
 */
@MessageMeta(module = Modules.CMD_REQUEST_FUZZY_IDENTITY)
public class ReqRealNameAuth extends Message {
    private byte force_request;

    public byte getForce_request() {
        return force_request;
    }

    public void setForce_request(byte force_request) {
        this.force_request = force_request;
    }
}
