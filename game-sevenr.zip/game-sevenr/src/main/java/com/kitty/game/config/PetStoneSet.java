package com.kitty.game.config;

import lombok.Getter;
import lombok.Setter;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Table;

@Table("p_petstone")
@Getter
@Setter
public class PetStoneSet {
    @Column
    private String name;
    @Column
    private short level;
    @Column
    private short value;
    @Column
    private short nimbus;
    @Column
    private short icon;
    @Column
    private short fieldId;
    @Column
    private short setIndex;

    public void setName(String name) {
        this.name = name;
    }

    public void setLevel(short level) {
        this.level = level;
    }

    public void setValue(short value) {
        this.value = value;
    }

    public void setNimbus(short nimbus) {
        this.nimbus = nimbus;
    }

    public void setIcon(short icon) {
        this.icon = icon;
    }

    public void setFieldId(short fieldId) {
        this.fieldId = fieldId;
    }

    public void setSetIndex(short setIndex) {
        this.setIndex = setIndex;
    }

    public String getName() {
        return this.name;
    }

    public short getLevel() {
        return this.level;
    }

    public short getValue() {
        return this.value;
    }

    public short getNimbus() {
        return this.nimbus;
    }

    public short getIcon() {
        return this.icon;
    }

    public short getFieldId() {
        return this.fieldId;
    }

    public short getSetIndex() {
        return this.setIndex;
    }
}
