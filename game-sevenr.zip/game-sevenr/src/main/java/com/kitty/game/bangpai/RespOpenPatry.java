package com.kitty.game.bangpai;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.annotation.StringField;
import com.kitty.mina.message.Message;

import java.util.List;
//后写
import com.kitty.game.bangpai.PartyMemberInfo;
import com.kitty.game.bangpai.PartySkillInfo;

/**
 * 打开帮派
 */
@MessageMeta(module = Modules.MSG_PARTY_INFO)
public class RespOpenPatry extends Message {
    private String partyId="57579202AD2C5000D600";
    private String partyName;
    private String partyBaseInfo;
    @StringField(value = 1)
    private String partyNotice="公告在这里111"; //帮派公告
    private short rights = 1;
    private int jianshe;//建设度

    private int bangpaizhanli = 1;//建设度
    private int zijin;//帮派资金
    private int createTime;
    private int fenglu;//俸禄
    private int autoAcceptLevel = 9999;//自动加入等级
    private int autoMinTao;
    private String creator;//创始人
    private List<PartySkillInfo> skillInfoList;
    private short totalMember;
    private short onlineMember;
    private short partyLevel;
    private short partyMap=1;
    private String heir;
    private int lastAutoJoinTime;
    private String icon_md5="default003.png";//帮派Icon
    private String review_icon_md5;
    private List<PartyMemberInfo> memberInfos;

    public int getAutoMinTao() {
        return autoMinTao;
    }

    public void setAutoMinTao(int autoMinTao) {
        this.autoMinTao = autoMinTao;
    }

    public String getPartyId() {
        return partyId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }

    public String getPartyName() {
        return partyName;
    }

    public void setPartyName(String partyName) {
        this.partyName = partyName;
    }

    public String getPartyBaseInfo() {
        return partyBaseInfo;
    }

    public void setPartyBaseInfo(String partyBaseInfo) {
        this.partyBaseInfo = partyBaseInfo;
    }

    public String getPartyNotice() {
        return partyNotice;
    }

    public void setPartyNotice(String partyNotice) {
        this.partyNotice = partyNotice;
    }

    public short getRights() {
        return rights;
    }
    public int getBangpaizhanli () {
        return bangpaizhanli;
    }
    public void setRights(short rights) {
        this.rights = rights;
    }
    public void setBangpaizhanli (int bangpaizhanli) {
        this.bangpaizhanli = bangpaizhanli;
    }
    public int getJianshe() {
        return jianshe;
    }

    public void setJianshe(int jianshe) {
        this.jianshe = jianshe;
    }

    public int getZijin() {
        return zijin;
    }

    public void setZijin(int zijin) {
        this.zijin = zijin;
    }

    public int getCreateTime() {
        return createTime;
    }

    public void setCreateTime(int createTime) {
        this.createTime = createTime;
    }

    public int getFenglu() {
        return fenglu;
    }

    public void setFenglu(int fenglu) {
        this.fenglu = fenglu;
    }

    public int getAutoAcceptLevel() {
        return autoAcceptLevel;
    }

    public void setAutoAcceptLevel(int autoAcceptLevel) {
        this.autoAcceptLevel = autoAcceptLevel;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public List<PartySkillInfo> getSkillInfoList() {
        return skillInfoList;
    }

    public void setSkillInfoList(List<PartySkillInfo> skillInfoList) {
        this.skillInfoList = skillInfoList;
    }

    public short getTotalMember() {
        return totalMember;
    }

    public void setTotalMember(short totalMember) {
        this.totalMember = totalMember;
    }

    public short getOnlineMember() {
        return onlineMember;
    }

    public void setOnlineMember(short onlineMember) {
        this.onlineMember = onlineMember;
    }

    public short getPartyLevel() {
        return partyLevel;
    }

    public void setPartyLevel(short partyLevel) {
        this.partyLevel = partyLevel;
    }

    public short getPartyMap() {
        return partyMap;
    }

    public void setPartyMap(short partyMap) {
        this.partyMap = partyMap;
    }

    public String getHeir() {
        return heir;
    }

    public void setHeir(String heir) {
        this.heir = heir;
    }

    public int getLastAutoJoinTime() {
        return lastAutoJoinTime;
    }

    public void setLastAutoJoinTime(int lastAutoJoinTime) {
        this.lastAutoJoinTime = lastAutoJoinTime;
    }

    public String getIcon_md5() {
        return icon_md5;
    }

    public void setIcon_md5(String icon_md5) {
        this.icon_md5 = icon_md5;
    }

    public String getReview_icon_md5() {
        return review_icon_md5;
    }

    public void setReview_icon_md5(String review_icon_md5) {
        this.review_icon_md5 = review_icon_md5;
    }

    public List<PartyMemberInfo> getMemberInfos() {
        return memberInfos;
    }

    public void setMemberInfos(List<PartyMemberInfo> memberInfos) {
        this.memberInfos = memberInfos;
    }
}
