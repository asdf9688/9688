package com.kitty.game.drop.model.product;

import lombok.Getter;
import lombok.Setter;
import org.nutz.dao.entity.annotation.Table;

/**物品对应的掉落*/
@Table("p_itemdropset")
@Setter
@Getter
public class ItemDropSet {
    /**物品*/
    private String itemName;
    /**掉落组*/
    private int dropGroup;
}
