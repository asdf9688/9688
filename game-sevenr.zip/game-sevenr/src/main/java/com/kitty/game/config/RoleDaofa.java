package com.kitty.game.config;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

@Table("p_fabao_daofa")
public class RoleDaofa {
    @Id
    private int id;
    @Column
    private int level;
    @Column
    private int daofa;
    @Column
    private int rate;
    @Column
    private int maxLinqi;

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getDaofa() {
        return daofa;
    }

    public void setDaofa(int daofa) {
        this.daofa = daofa;
    }

    public int getMaxLinqi() {
        return maxLinqi;
    }

    public void setMaxLinqi(int maxLinqi) {
        this.maxLinqi = maxLinqi;
    }
}
