package com.kitty.game.confirm.model;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

public class DoReplenishSignConfirm extends RoleConfirm {
    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.DO_REPLENISH_SIGN;
    }

}
