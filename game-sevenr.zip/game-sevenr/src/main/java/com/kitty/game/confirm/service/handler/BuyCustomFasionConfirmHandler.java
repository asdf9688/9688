package com.kitty.game.confirm.service.handler;

import com.kitty.game.config.CustomFasion;
import com.kitty.game.config.Fasion;
import com.kitty.game.confirm.model.BuyCustomFashionConfirm;
import com.kitty.game.confirm.service.handler.ConfirmHandler;
import com.kitty.game.enter.RespNotifyMisc;
import com.kitty.game.equip.model.RoleEquip;
import com.kitty.game.equip.service.EquipService;
import com.kitty.game.fight.service.BroadcastService;
import com.kitty.game.function.service.FasionService;
import com.kitty.game.onlinemall.service.MallService;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.RoleService;
import com.kitty.game.team.message.ReqConfirmResult;
import com.kitty.game.team.message.RespMsg;
import com.kitty.game.waiguan.RespFasionCustomBegin;
import com.kitty.game.waiguan.RespFasionCustomEnd;
import com.kitty.logs.Reason;
import com.kitty.mina.message.MessagePusher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**处理购买自定义时装*/
@Component
public class BuyCustomFasionConfirmHandler extends ConfirmHandler {
    @Autowired
    RoleService roleService;
    @Autowired
    MallService mallService;
    @Autowired
    EquipService equipService;
    @Autowired
    FasionService fasionService;
    @Autowired
    BroadcastService broadcastService;
    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {
        if ("1".equals(reqConfirmResult.getSelect())) {
            buyFasion(role);
        }
    }

    /**
     * 购买自定义时装
     */
    private void buyFasion(Role role) {
        BuyCustomFashionConfirm confirm = (BuyCustomFashionConfirm) role.getConfirm();
        int needGold = confirm.getPrice();
        List<Fasion> list = confirm.getList();
        if (role.getGold() < needGold || needGold < 0) {
            return;
        }
        roleService.subtractGold(role,needGold, Reason.BUY_FASHION);
        RespFasionCustomBegin respFasionCustomBegin = new RespFasionCustomBegin();
        respFasionCustomBegin.setLabel("buy_multi_fasion");
        MessagePusher.pushMessage(role, respFasionCustomBegin);

        StringBuilder msg = new StringBuilder();
        for (Fasion fasion : list) {
            RoleEquip roleEquip = fasionService.getCustomFasion(role, fasion.getName(), 1, true);
            msg.append("#R").append(fasion.getName()).append("#n、");
            CustomFasion customFasion = mallService.getCustomFashion(fasion.getName());
            fasionService.unEquipCustomFasion(role, customFasion.getPos(), false);
            roleEquip.setPosition(customFasion.getPos());
            equipService.add(role, roleEquip);
            equipService.refreshRoleEquip(role, roleEquip);
        }
        ArrayList<CustomFasion> arrayList = new ArrayList<>();
        List<Integer> posArr = Arrays.asList(33,34,35,36,38);
        posArr.forEach(pos->{
            RoleEquip roleEquip = equipService.getRoleEquipByPos(role, pos);
            if (roleEquip != null) {
                CustomFasion customFasion = mallService.getCustomFashion(roleEquip.getName());
                arrayList.add(customFasion);
            }
        });

        String customFasionIcon = fasionService.getCustomFasionIcon(arrayList);
        role.setCustomFasion(customFasionIcon);
        broadcastService.sendUpdateAppear(role);
        MessagePusher.pushMessage(role, new RespNotifyMisc("你花费#R" + needGold + "#n个金元宝购买了" + msg.substring(0, msg.length() - 1) + "#n。"));
        MessagePusher.pushMessage(role, new RespMsg("换装成功！"));

        RespFasionCustomEnd respFasionCustomEnd = new RespFasionCustomEnd();
        respFasionCustomEnd.setLabel("buy_multi_fasion");
        MessagePusher.pushMessage(role, respFasionCustomEnd);
    }

}
