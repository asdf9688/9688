package com.kitty.game.enter;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

@MessageMeta(module = Modules.MSG_NEW_LOTTERY_OPEN)
public class RespNewLotteryOpen extends Message {

}
