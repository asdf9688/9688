package com.kitty.game.confirm.service.handler;

import com.kitty.game.pet.model.Pet;
import com.kitty.game.role.model.Role;
import com.kitty.game.fight.bean.Fight;
import com.kitty.common.spring.SpringUtils;
import com.kitty.game.confirm.model.PetFightConfirm;
import com.kitty.game.equip.model.EquipField;
import com.kitty.game.fight.message.*;
import com.kitty.game.fight.message.vo.RefreshPet;
import com.kitty.game.fight.service.FightExecutorService;
import com.kitty.game.fight.service.FightService;
import com.kitty.game.pet.message.RespPetInfo;
import com.kitty.game.pet.message.vo.PetInfo;
import com.kitty.game.pet.service.PetService;
import com.kitty.game.team.message.ReqConfirmResult;
import com.kitty.game.utils.AsktaoUtil;
import com.kitty.mina.message.MessagePusher;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
//后加
import com.kitty.game.confirm.service.handler.ConfirmHandler;
import com.kitty.game.fight.message.ReqFightDoAction;
import com.kitty.game.fight.message.RespCombatCommandAccepted;
import com.kitty.game.fight.message.RespRefreshPetList;
import com.kitty.game.fight.message.RespSetFightPetStatus;
import com.kitty.game.fight.message.RespSyncMessage;

@Component
public class PetFightConfirmHandler extends ConfirmHandler {

    @Override
    public void handleConfirmResult(Role role, ReqConfirmResult reqConfirmResult) {

        FightService fightService = SpringUtils.getFightService();
        System.out.println(reqConfirmResult);
        if ("1".equals(reqConfirmResult.getSelect())) {
            Fight fight = fightService.getFightByRoleId(role.getRoleId());
            if (fight == null) {
                return;
            }
            PetFightConfirm roleConfirm = (PetFightConfirm) role.getConfirm();
            SpringUtils.getBean(FightExecutorService.class).addFightTask(fight ,()-> selectPet(role, roleConfirm.getPetId(), roleConfirm.getOldPetId()));
        }else {
            RespCombatCommandAccepted respCombatCommandAccepted = new RespCombatCommandAccepted();
            respCombatCommandAccepted.setId(role.getRoleId());
            MessagePusher.pushMessage(role, respCombatCommandAccepted);
        }
    }

    private void selectPet(Role role, int selectPetId, int oldPetId) {
        FightService fightService = SpringUtils.getBean(FightService.class);
        PetService petService = SpringUtils.getBean(PetService.class);
        Fight fight = fightService.getFightByRoleId(role.getRoleId());
        if (fight != null) {
            Pet pet = role.getPetBox().getPetByPetId(selectPetId);
            RespSetFightPetStatus respSetFightPetStatus = new RespSetFightPetStatus();
            respSetFightPetStatus.setRoleId(pet.getId());
            respSetFightPetStatus.setType((short) 1);
            MessagePusher.pushMessage(role, respSetFightPetStatus);

            RespRefreshPetList respRefreshPetList = new RespRefreshPetList();
            RefreshPet refreshPet = new RefreshPet();
            ArrayList<RefreshPet> refreshPets = new ArrayList<>();
            refreshPets.add(refreshPet);
            refreshPet.setPetId(pet.getId());
            respRefreshPetList.setPetList(refreshPets);
            MessagePusher.pushMessage(role, respRefreshPetList);


            MessagePusher.pushMessage(role, respSetFightPetStatus);

            RespPetInfo respPetInfo = new RespPetInfo();
            ArrayList<EquipField> list = new ArrayList<>();
            ArrayList<PetInfo> petInfos = new ArrayList<>();
            PetInfo petInfo = new PetInfo();
            petInfos.add(petInfo);
            petInfo.setPosition(pet.getPosition());
            petInfo.setPetId(pet.getId());
            list.addAll(pet.getAllFields());
            petInfo.setList(list);
            respPetInfo.setPetInfos(petInfos);
            byte[] body = AsktaoUtil.getMessageBody(respPetInfo);
            RespSyncMessage respSyncMessage = new RespSyncMessage();
            respSyncMessage.setCode((short) 65507);
            respSyncMessage.setMsg(body);
            MessagePusher.pushMessage(role, respSyncMessage);

            ReqFightDoAction ReqFightDoAction = new ReqFightDoAction();
            ReqFightDoAction.setType(8);
            ReqFightDoAction.setSkillId(oldPetId > 0 ? oldPetId : 1);
            ReqFightDoAction.setAttackerId(role.getRoleId());
            ReqFightDoAction.setTargetId(pet.getId());
            SpringUtils.getFightService().doAction(ReqFightDoAction);
        }
    }
}
