package com.kitty.game.bangpai;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

/**
 * 帮派成员操作
 */
@MessageMeta(module = Modules.CMD_PARTY_MODIFY_MEMBER)
public class ReqPartyModifyMember extends Message {
    private String name;
    private String gid;
    private String partyDesc;
    private short job;
    private short changeBangZhu;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGid() {
        return gid;
    }

    public void setGid(String gid) {
        this.gid = gid;
    }

    public String getPartyDesc() {
        return partyDesc;
    }

    public void setPartyDesc(String partyDesc) {
        this.partyDesc = partyDesc;
    }

    public short getJob() {
        return job;
    }

    public void setJob(short job) {
        this.job = job;
    }

    public short getChangeBangZhu() {
        return changeBangZhu;
    }

    public void setChangeBangZhu(short changeBangZhu) {
        this.changeBangZhu = changeBangZhu;
    }
}
