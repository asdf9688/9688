package com.kitty.game.enter;

import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;


/**
 * 历史角色名
 */
@MessageMeta(module = Modules.CMD_FORMER_NAME)
public class ReqHistoryName extends Message {
}
