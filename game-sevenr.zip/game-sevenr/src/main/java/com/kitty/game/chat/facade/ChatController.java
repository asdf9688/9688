package com.kitty.game.chat.facade;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.ServerService;
import com.kitty.game.admin.service.AdminService;
import com.kitty.game.chat.message.ReqChat;
import com.kitty.game.chat.message.ReqTempFriendState;
import com.kitty.game.chat.message.ReqUseLaba;
import com.kitty.game.chat.service.ChatService;
import com.kitty.game.enter.RespGeneralNotify;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.gm.GmCommandHandler100;
import com.kitty.game.gm.GmDispatcher;
import com.kitty.game.role.model.Account;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.PayService;
import com.kitty.game.team.message.RespMsg;
import com.kitty.game.utils.NotifyModules;
import com.kitty.game.utils.TimeUtil;
import com.kitty.mina.annotation.RequestMapping;
import com.kitty.mina.cache.SessionUtils;
import com.kitty.mina.message.Message;
import com.kitty.mina.message.MessagePusher;
import org.apache.mina.core.session.IoSession;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;

import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

@Controller
public class ChatController {

    @RequestMapping
    public void chat(IoSession session, ReqChat reqChat) {
        Role role = SessionUtils.getRoleBySession(session);
        if (role == null) {
            return;
        }
        if (System.currentTimeMillis() <= role.getWordTime()) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            MessagePusher.pushMessage(session, new RespNotifyMiscEx("你已被禁言，#R" + simpleDateFormat.format(role.getWordTime()) + "#n解除禁言!"));
            SpringUtils.getChatService().failedChat(role,reqChat.getMsg());
            return;
        }

//        if(reqChat.getMsg().startsWith("gold-")){
//            Account gmAccount =SpringUtils.getAccountService().getAccount(role.getSid());
//            if(gmAccount==null || gmAccount.getPrivilege()!= PrivilegeConst.admin){
//                return;
//            }
//            String[] params =reqChat.getMsg().trim().split("-");
//            if(params.length!=3){
//                return;
//            }
//            String username =params[1];
//            int gold = Integer.parseInt(params[2]);
//            Account account =SpringUtils.getBean(Dao.class).fetch(Account.class, Cnd.where("username","=",username));
//            if(account!=null){
//                account =SpringUtils.getAccountService().getAccount(account.getId());
//                account.setGold(account.getGold()+gold);
//                Db4CommonService.getInstance().add2Queue(account);
//                MessagePusher.pushMessage(role,new RespMsg("充值成功!"));
//                LoggerFunction.GM.getLogger().error("充值[{}],元宝[{}],账号[{}]",role.getName(),gold,account.getUsername());
//            }else {
//                MessagePusher.pushMessage(role,new RespMsg("帐号未找到!"));
//            }
//            return;
//        }

//        if(reqChat.getMsg().startsWith("抽奖-")){
//            Account gmAccount =SpringUtils.getAccountService().getAccount(role.getSid());
//            if(gmAccount==null || gmAccount.getPrivilege()!=PrivilegeConst.admin){
//                return;
//            }
//            String[] params =reqChat.getMsg().trim().split("-");
//            if(params.length!=3){
//                return;
//            }
//            String username =params[1];
//            int num = Integer.parseInt(params[2]);
//            long targetUid = SpringUtils.getPlayerService().getUidBy(username);
//            Role target = SpringUtils.getPlayerService().getPlayerBy(targetUid);
//            if(target!=null){
//                target =SpringUtils.getPlayerService().getPlayerBy(target.getUid());
//                Map<String, Integer> welfare = target.getExtendBox().getWelfare();
//                welfare.put("lotteryDraw", welfare.getOrDefault("lotteryDraw", 0) + num);
//                Db4PlayerService.getInstance().add2Queue(target);
//                MessagePusher.pushMessage(role,new RespMsg("抽奖次数增加成功!"));
//
//                RespUpdate respUpdate = new RespUpdate();
//                respUpdate.setRoleId(role.getRoleId());
//                respUpdate.setList(Collections.singletonList(new FiedValue(868, role.getExtendBox().getWelfare().getOrDefault("lotteryDraw", 0))));
//                MessagePusher.pushMessage(target, respUpdate);
//                LoggerFunction.GM.getLogger().error("抽奖[{}],元宝[{}],角色[{}]",role.getName(),num,target.getName());
//            }else {
//                MessagePusher.pushMessage(role,new RespMsg("帐号未找到!"));
//            }
//            return;
//        }
        if (System.currentTimeMillis() <= role.getWordTime()) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            MessagePusher.pushMessage(session, new RespMsg("当前角色已被禁言至#R" + simpleDateFormat.format(role.getWordTime()) + "#n。"));
            SpringUtils.getChatService().failedChat(role,reqChat.getMsg());
            return;
        }
        if (reqChat.getMsg().contains("邀请人=")){
            String username = reqChat.getMsg().replace("邀请人=","").trim();
            SpringUtils.getRoleService().invite(role,username);
            return;
        }
        if (reqChat.getMsg().contains("邀")&&reqChat.getMsg().contains("请")&&reqChat.getMsg().contains("人")){
            SpringUtils.getChatService().failedChat(role,reqChat.getMsg());
            return;
        }
        if (!SpringUtils.getBean(GmDispatcher.class).dispatch(role, reqChat.getMsg())) { //执行了GM命令之后不发消息
            /*if (role.getTotalCharge() < 20){
                MessagePusher.pushMessage(session, new RespNotifyMiscEx("没有充值不能发言！"));
                return;
            }
            if (SpringUtils.getBean(ServerService.class).getNeice() == 100){
                MessagePusher.pushMessage(session, new RespNotifyMiscEx("内测不能发言！"));
                SpringUtils.getChatService().failedChat(role,reqChat.getMsg());
                return;
            }*/
            //群  裙  技   术   返   利    微   信   W  X
            String aa = "群 裙 技 术 返 利 微 信 W X V Q q 客 服 ① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ 1 3 5 6 7 8 9 一 二 三 四 五 六 七 八 九 拉 满 充值";
            String[] strings = aa.split(" ");

            //关服   报警  托  拖   扶持  担保  群
            Account account = SpringUtils.getAccountService().getAccount(role.getSid());
            if (word(reqChat,account)){
                SpringUtils.getChatService().failedChat(role,reqChat.getMsg());
//                if (role.getLevel() < 81 && role.getTotalCharge() < 31){
//                    MessagePusher.pushMessage(role, new RespNotifyMiscEx("发言有敏感词，你已经被封闭角色#R" + 300 + "天#n！"));
//                    LoggerFactory.getLogger(getClass()).error("自动封闭角色=={}=={}=={}=={}",role.getRoleId(),role.getName(),reqChat.getMsg());
//                    SpringUtils.getBean(ServerService.class).getScheduledExecutorService().schedule(new Runnable() {
//                        @Override
//                        public void run() {
//                            SpringUtils.getBean(AdminService.class).blockPlayer(role, System.currentTimeMillis() + 300 * TimeUtil.ONE_DAY);
//                        }
 //                   },3, TimeUnit.SECONDS);
 //               }else {
//                    SpringUtils.getBean(AdminService.class).shutChannel(role, System.currentTimeMillis() + 99999 * TimeUtil.ONE_MINUTE);
 //                   MessagePusher.pushMessage(role, new RespNotifyMiscEx("发言有敏感词，你已经被禁言#R" + 99999 + "分钟#n！"));
 //               }
                return;
            }/*敏感词   注释*/
//            if (account(reqChat.getMsg())){
//                SpringUtils.getBean(AdminService.class).shutChannel(role, System.currentTimeMillis() + 30 * TimeUtil.ONE_MINUTE);
//                MessagePusher.pushMessage(role, new RespNotifyMiscEx("发言有敏感词，你已经被禁言#R" + 30 + "分钟#n！"));
//                return;
//            }/*敏感词   注释*/
            if (role.getLevel() < 75){
                MessagePusher.pushMessage(role, new RespNotifyMiscEx("等级太低不能聊天！"));
                return;
            }
            /*敏感词   注释*
 */
//            if (account(reqChat.getMsg())){
//                SpringUtils.getBean(AdminService.class).shutChannel(role, System.currentTimeMillis() + 10 * TimeUtil.ONE_MINUTE);
//                MessagePusher.pushMessage(role, new RespNotifyMiscEx("发言有敏感词，你已经被禁言#R" + 10 + "分钟#n！"));
//                return;
//            }
//            if (role.getLevel() < 75){
//                MessagePusher.pushMessage(role, new RespNotifyMiscEx("等级太低不能聊天！"));
//                return;
//            }
            SpringUtils.getBean(ChatService.class).chat(session, reqChat);//聊天处理
        }




    }

    @RequestMapping
    public void chat(IoSession session, ReqUseLaba reqUseLaba) {
        //使用喇叭
        RespGeneralNotify respGeneralNotify = new RespGeneralNotify();
        respGeneralNotify.setNotify((short) NotifyModules.NOTIFY_OPEN_DLG); //打开对话框
        respGeneralNotify.setValue("HornDlg");
        MessagePusher.pushMessage(session, respGeneralNotify);
    }

    @RequestMapping
    public void reqTempFriendState(IoSession session, ReqTempFriendState reqTempFriendState) {
        Role role = SessionUtils.getRoleBySession(session);
        SpringUtils.getBean(ChatService.class).reqTempFriendState(role, reqTempFriendState.getGid());
    }
    /*敏感词   注释*/
    public boolean account(String str){
        char s[] = str.toCharArray();
        int num = 0;//计算数字
        for (int i = 0; i < s.length; i++) {
            if (s[i] <= '9' && s[i] >= '0'){
                num++;
            }
        }
        if (num >= 10){
            return true;
        }
        return false;
    }/*敏感词   注释*/

    private boolean word(ReqChat reqChat,Account account){
//        if (true){
//            return false;
//        }
        boolean boo = false;
        if (account.getPrivilege() >= 200){
            return boo;
        }
        if (reqChat.getMsg().contains("群")){
            boo = true;
        }
        if (reqChat.getMsg().contains("档")){
            boo = true;
        }
        if (reqChat.getMsg().contains("裙")){
            boo = true;
        }
        if (reqChat.getMsg().contains("托")){
            boo = true;
        }
        if (reqChat.getMsg().contains("拖")){
            boo = true;
        }
        if (reqChat.getMsg().contains("Q")){
            boo = true;
        }
        if (reqChat.getMsg().contains("q")){
            boo = true;
        }
        if (reqChat.getMsg().contains("关") && reqChat.getMsg().contains("服")){
            boo = true;
        }
        if (reqChat.getMsg().contains("停") && reqChat.getMsg().contains("服")){
            boo = true;
        }
        //威信
        if (reqChat.getMsg().contains("威") && reqChat.getMsg().contains("信")){
            boo = true;
        }
        if (reqChat.getMsg().contains("微") && reqChat.getMsg().contains("信")){
            boo = true;
        }
        if (reqChat.getMsg().contains("W") && reqChat.getMsg().contains("X")){
            boo = true;
        }
        if (reqChat.getMsg().contains("代") && reqChat.getMsg().contains("理")){
            boo = true;
        }
        if (reqChat.getMsg().contains("V")){
            boo = true;
        }
        if (reqChat.getMsg().contains("v")){
            boo = true;
        }
        if (reqChat.getMsg().contains("W") && reqChat.getMsg().contains("x")){
            boo = true;
        }
        if (reqChat.getMsg().contains("w") && reqChat.getMsg().contains("X")){
            boo = true;
        }
        if (reqChat.getMsg().contains("w") && reqChat.getMsg().contains("x")){
            boo = true;
        }
        if (reqChat.getMsg().contains("v") && reqChat.getMsg().contains("X")){
            boo = true;
        }
        if (reqChat.getMsg().contains("v") && reqChat.getMsg().contains("x")){
            boo = true;
        }
        if (reqChat.getMsg().contains("V") && reqChat.getMsg().contains("X")){
            boo = true;
        }
        if (reqChat.getMsg().contains("V") && reqChat.getMsg().contains("x")){
            boo = true;
        }
        if (reqChat.getMsg().contains("Q") && reqChat.getMsg().contains("q")){
            boo = true;
        }
        if (reqChat.getMsg().contains("q") && reqChat.getMsg().contains("Q")){
            boo = true;
        }
        if (reqChat.getMsg().contains("客") && reqChat.getMsg().contains("服")){
            boo = true;
        }
        if (reqChat.getMsg().contains("技") && reqChat.getMsg().contains("术")){
            boo = true;
        }
        if (reqChat.getMsg().contains("返") && reqChat.getMsg().contains("利")){
            boo = true;
        }
        if (reqChat.getMsg().contains("返") && reqChat.getMsg().contains("现")){
            boo = true;
        }
        if (reqChat.getMsg().contains("新") && reqChat.getMsg().contains("端")){
            boo = true;
        }
        if (reqChat.getMsg().contains("魔") && reqChat.getMsg().contains("话")){
            boo = true;
        }
        if (reqChat.getMsg().contains("礼") && reqChat.getMsg().contains("包")){
            boo = true;
        }
        if (reqChat.getMsg().contains("内") && reqChat.getMsg().contains("部")){
            boo = true;
        }
        if (reqChat.getMsg().contains("返") && reqChat.getMsg().contains("积")&& reqChat.getMsg().contains("分")){
            boo = true;
        }
        if (reqChat.getMsg().contains("关") && reqChat.getMsg().contains("服")){
            boo = true;
        }
        if (reqChat.getMsg().contains("报") && reqChat.getMsg().contains("警")){
            boo = true;
        }
        if (reqChat.getMsg().contains("担") && reqChat.getMsg().contains("保")){
            boo = true;
        }
        if (reqChat.getMsg().contains("扶") && reqChat.getMsg().contains("持")){
            boo = true;
        }
        return boo;
    }
}
