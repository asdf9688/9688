package com.kitty.game.activity.service.seal;

import com.kitty.game.config.NPC;
import com.kitty.game.npc.model.NpcButton;
import com.kitty.game.role.model.Role;
import com.kitty.game.utils.Const;
import org.apache.ibatis.jdbc.Null;
import org.springframework.stereotype.Component;
import com.kitty.game.activity.service.seal.SealBossHandler;

import java.util.Arrays;
import java.util.List;

/**烟花年兽处理类*/
@Component
public class  YhuaNianshouBossHandler extends SealBossHandler {
    private final String ownerNpcName = "{0}的逃跑的年兽";
    private final String npcName = "逃跑的年兽";
    private final String bossName = "逃跑的年兽";
    private final List<String> smallBossNames = Arrays.asList("逃跑的年兽1");
    private final String smallName = "小妖";
    private final String fightTag = NpcButton.FIGHT_TO_NIANSHOU.getKey();
    private int firstTalkId = 1228;

    @Override
    public String getOwnerNpcName() {
        return ownerNpcName;
    }

    @Override
    public String getNpcName() {
        return npcName;
    }

    @Override
    public String getBossName() {
        return bossName;
    }

    @Override
    public List<String> getSmallBossNames() {
        return smallBossNames;
    }

    @Override
    public String getSmallName() {
        return smallName;
    }

    @Override
    public String getFightTag() {
        return fightTag;
    }

    @Override
    public int getFirstTalkId() {
        return firstTalkId;
    }

    @Override
    public byte getNpcType() {
        return NPC.TYPE_BIANYI_YHNS;
    }

    @Override
    protected int getFightType(Role role) {
        return Const.fightType_yanhuan_nianshou;
    }



}
