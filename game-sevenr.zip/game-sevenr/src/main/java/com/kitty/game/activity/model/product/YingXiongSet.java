package com.kitty.game.activity.model.product;

import lombok.Getter;

/**英雄会英雄配置*/
@Getter
public class YingXiongSet {
    /**对应NPC id*/
    private int npcId;
    /**挑战最小等级*/
    private short minLevel;
    /**挑战最大等级*/
    private short maxLevel;
    /**称谓*/
    private String title;
    /**内容*/
    private String content;
    //后加
    public int getNpcId() {
        return this.npcId;
    }

    public short getMinLevel() {
        return this.minLevel;
    }

    public short getMaxLevel() {
        return this.maxLevel;
    }

    public String getTitle() {
        return this.title;
    }

    public String getContent() {
        return this.content;
    }
}
