package com.kitty.game.bangpai;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.annotation.StringField;
import com.kitty.mina.message.Message;
//后写
import com.kitty.game.bangpai.PartyMemberInfo;
import com.kitty.game.bangpai.PartySkillInfo;

import java.util.List;

/**
 * 返回帮派信息
 */
@MessageMeta(module = Modules.MSG_PARTY_BRIEF_INFO)
public class RespCheckPartyInfo extends Message {
    private String partyId;
    private String partyName;
    private String creator;
    private short level;
    private short population;//总人口
    private int construct;//建设度

    private int bangpaizhanli;//战力
    private String partyIcon;
    private int money;
    private int createTime;
    @StringField(value = 1)
    private String notice;
    private List<PartySkillInfo> skillInfoList;
    private List<PartyMemberInfo> memberInfos;

    public String getPartyId() {
        return partyId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }

    public String getPartyName() {
        return partyName;
    }

    public void setPartyName(String partyName) {
        this.partyName = partyName;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public short getLevel() {
        return level;
    }

    public void setLevel(short level) {
        this.level = level;
    }

    public short getPopulation() {
        return population;
    }

    public void setPopulation(short population) {
        this.population = population;
    }

    public int getConstruct() {
        return construct;
    }
    public int getBangpaizhanli () {
        return 0 ;
    }
    public void setConstruct(int construct) {
        this.construct = construct;
    }
    public void setBangpaizhanli (int bangpaizhanli ) {
        this.bangpaizhanli  = bangpaizhanli ;
    }
    public String getPartyIcon() {
        return partyIcon;
    }

    public void setPartyIcon(String partyIcon) {
        this.partyIcon = partyIcon;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public int getCreateTime() {
        return createTime;
    }

    public void setCreateTime(int createTime) {
        this.createTime = createTime;
    }

    public String getNotice() {
        return notice;
    }

    public void setNotice(String notice) {
        this.notice = notice;
    }

    public List<PartySkillInfo> getSkillInfoList() {
        return skillInfoList;
    }

    public void setSkillInfoList(List<PartySkillInfo> skillInfoList) {
        this.skillInfoList = skillInfoList;
    }

    public List<PartyMemberInfo> getMemberInfos() {
        return memberInfos;
    }

    public void setMemberInfos(List<PartyMemberInfo> memberInfos) {
        this.memberInfos = memberInfos;
    }
}
