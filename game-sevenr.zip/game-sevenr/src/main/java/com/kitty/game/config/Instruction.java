package com.kitty.game.config;

import lombok.Getter;
import lombok.Setter;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**指引数据的配置表*/
@Setter
@Getter
@Table("p_instruction")
public class Instruction {
    @Id(auto = false)
    @Comment("指引的ID")
    private short instructionId;
    @Column
    @Comment("指引弹出的要求 1为等级提升 2为任务完成 3为对话完成")
    private byte type;
    @Column
    @Comment("指引弹出的要求的值  跟上面的type对应 如果type是1 req的值就是等级")
    private int req;


    public void setInstructionId(short instructionId) {
        this.instructionId = instructionId;
    }

    public void setType(byte type) {
        this.type = type;
    }

    public void setReq(int req) {
        this.req = req;
    }

    public short getInstructionId() {
        return this.instructionId;
    }

    public byte getType() {
        return this.type;
    }

    public int getReq() {
        return this.req;
    }



}
