package com.kitty.game.activity.message;

import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@MessageMeta(module = Modules.CMD_LEAVE_DUNGEON)
public class ReqLeaveDugeon extends Message {
}
