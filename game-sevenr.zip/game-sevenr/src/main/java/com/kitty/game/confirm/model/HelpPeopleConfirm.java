package com.kitty.game.confirm.model;

import com.kitty.game.confirm.model.ConfirmType;
import com.kitty.game.confirm.model.RoleConfirm;

/**助人为乐领取更多奖励确认类*/
public class HelpPeopleConfirm extends RoleConfirm{
    @Override
    public ConfirmType getConfirmType() {
        return ConfirmType.HELP_PEOPLE_REWARD_MORE;
    }
}
