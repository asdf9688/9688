package com.kitty.game.bangpai;

public class PartyInfo {
    private String partyId;
    private String partyName;
    private short level;
    private short members;//总人口
    private int construct;//建设度

    private int bangpaizhanli;//建设度

    public String getPartyId() {
        return partyId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }

    public String getPartyName() {
        return partyName;
    }

    public void setPartyName(String partyName) {
        this.partyName = partyName;
    }

    public short getLevel() {
        return level;
    }

    public void setLevel(short level) {
        this.level = level;
    }

    public short getmembers() {
        return members;
    }

    public void setmembers(short members) {
        this.members = members;
    }

    public int getConstruct() {
        return construct;
    }
    public int getBangpaizhanli () {
        return bangpaizhanli;
    }
    public void setConstruct(int construct) {
        this.construct = construct;
    }
    public void setBangpaizhanli (int bangpaizhanli) {
        this.bangpaizhanli = bangpaizhanli;
    }
}
