package com.kitty.game.activity;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.Qisha.QishaController;
import com.kitty.game.activity.model.product.shuadao.FeiXianDuXieShuaDaoSet;
import com.kitty.game.activity.model.product.shuadao.FuMoShuaDaoSet;
import com.kitty.game.activity.model.product.shuadao.ShuaDaoSet;
import com.kitty.game.activity.model.product.shuadao.XiangYaoShuaDaoSet;
import com.kitty.game.activity.service.ActivityHandler;
import com.kitty.game.activity.service.boos.handler.*;
import com.kitty.game.activity.service.other.*;
import com.kitty.game.activity.service.seal.ShangGuBossHandler;
import com.kitty.game.activity.service.seal.WanNianBossHandler;
import com.kitty.game.activity.service.seal.YhuaNianshouBossHandler;
import com.kitty.game.activity.service.shidao.ShiDaoHandler;
import com.kitty.game.activity.service.shidao.ShiDaoMonsterHandler;
import com.kitty.game.activity.service.shidao.ShiDaoPKHandler;
import com.kitty.game.activity.service.task.xiulian.ShiJueZhenTaskHandler;
import com.kitty.game.activity.service.task.xiulian.XiuXingTaskHandler;
import com.kitty.game.activity.service.time.PirateHandler;
import com.kitty.game.activity.service.time.XingGuanHandler;
import com.kitty.game.activity.service.time.ZhanShenHandler;
import com.kitty.game.jiutian.JiuTianController;
import com.kitty.game.pk.service.PkService;

import com.kitty.game.activity.model.product.ActivityLivenessRewardSet;
import com.kitty.game.activity.model.product.ActivityLivenessSet;
import com.kitty.game.activity.model.product.ActivityType;
import com.kitty.game.activity.model.product.DugeonSet;
import com.kitty.game.activity.model.product.MapGuardianSet;
import com.kitty.game.activity.model.product.NewHelpActivitySet;
import com.kitty.game.activity.model.product.ShiDaoReward;
import com.kitty.game.activity.model.product.ShuaDaoRewardSet;
import com.kitty.game.activity.model.product.YingXiongSet;
import com.kitty.game.activity.model.product.ZDHuFaSet;
import com.kitty.game.activity.service.other.DevilActivityHandler;
import com.kitty.game.activity.service.other.MapGuardianHandler;
import com.kitty.game.activity.service.other.SuperBossHandler;
import com.kitty.game.activity.service.other.YingXiongHuiHandler;
import com.kitty.game.activity.service.other.ZhangMenHandler;
import com.kitty.game.activity.service.other.ZhengDaoDianHandler;
import com.kitty.game.activity.service.task.ChuBaoTaskHandler;
import com.kitty.game.activity.service.task.PartyDailyTaskHandler;
import com.kitty.game.activity.service.task.ShuaDaoTaskHandler;
import com.kitty.game.activity.service.task.TowerTaskHandler;
import com.kitty.game.activity.service.task.XuanShangTaskHandler;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
//import java.util.Iterator;
import java.util.List;
import java.util.Map;


public class ActivityDataPool {
    /**刷道任务 key: npcId, value: 对应的刷道*/
    public static Map<Integer, ShuaDaoSet> shuaDaoMap = new HashMap<>();

    /**key: 任务id, value: 对应的刷道*/
    public static Map<Integer, ShuaDaoSet> shuaDaoMapByTask = new HashMap<>();

    /**刷道奖励，按积分从少到多排序*/
    public static List<ShuaDaoRewardSet> shuaDaoRewardSets = new ArrayList<>();

    /**key: npcId, value: 对应的英雄会的英雄配置*/
    public static Map<Integer, YingXiongSet> yingXiongSetMap = new HashMap<>();

    /**key: npcId, value: 对应的证道殿的护法配置*/
    public static Map<Integer, ZDHuFaSet> zdHuFaSetMap = new HashMap<>();

    public static Map<Byte, ShiDaoReward> shiDaoRewardMap;

    public static List<ActivityHandler> activityHandlers = new ArrayList<>();

    /**key: 活动名称，value: 活动活跃度配置*/
    public static Map<String, ActivityLivenessSet> activityLivenessSetMapByName = new HashMap<>();
    /**key: 活动类型，value: 活动活跃度配置*/
    public static Map<ActivityType, ActivityLivenessSet> activityLivenessSetMapByType = new HashMap<>();

    /**活跃度奖励列表*/
    public static List<ActivityLivenessRewardSet> activityLivenessRewardSets = new ArrayList<>();
    public static Map<Integer, ActivityLivenessRewardSet> activityLivenessRewardSetMap = new HashMap<>();

    /**新服助力活动配置*/
    public static NewHelpActivitySet newHelpActivitySet = new NewHelpActivitySet();

    public static DugeonSet dugeonSet = new DugeonSet();

    /**key: npcId, value: 对应的地图守护神配置*/
    public static Map<Integer, MapGuardianSet> mapGuardianSets = new HashMap<>();

    /**客户端显示与实际活跃度之间的系数*/
    public static final int LIVENESS_RATIO = 100;

    static {
        /**降妖*/
        addShuaDaoSet(new XiangYaoShuaDaoSet());
        /**伏魔*/
        addShuaDaoSet(new FuMoShuaDaoSet());
        /**飞仙渡邪*/
        addShuaDaoSet(new FeiXianDuXieShuaDaoSet());

        activityHandlers.add(SpringUtils.getBean(ChuBaoTaskHandler.class));
        activityHandlers.add(SpringUtils.getBean(ShuaDaoTaskHandler.class));
        activityHandlers.add(SpringUtils.getBean(XiuXingTaskHandler.class));
        activityHandlers.add(SpringUtils.getBean(ShiJueZhenTaskHandler.class));
        activityHandlers.add(SpringUtils.getBean(TowerTaskHandler.class));
        activityHandlers.add(SpringUtils.getBean(PirateHandler.class));
        activityHandlers.add(SpringUtils.getBean(XingGuanHandler.class));
        activityHandlers.add(SpringUtils.getBean(XuanShangTaskHandler.class));
        activityHandlers.add(SpringUtils.getBean(ShangGuBossHandler.class));
        activityHandlers.add(SpringUtils.getBean(WanNianBossHandler.class));
        activityHandlers.add(SpringUtils.getBean(ZhangMenHandler.class));
        activityHandlers.add(SpringUtils.getBean(YingXiongHuiHandler.class));
        activityHandlers.add(SpringUtils.getBean(ZhengDaoDianHandler.class));
        activityHandlers.add(SpringUtils.getBean(ShiDaoMonsterHandler.class));
        activityHandlers.add(SpringUtils.getBean(ShiDaoPKHandler.class));
        activityHandlers.add(SpringUtils.getBean(ShiDaoHandler.class));
        activityHandlers.add(SpringUtils.getBean(PartyDailyTaskHandler.class));
        activityHandlers.add(SpringUtils.getBean(SuperBossHandler.class));
        activityHandlers.add(SpringUtils.getBean(PkService.class));
        activityHandlers.add(SpringUtils.getBean(DevilActivityHandler.class));
        activityHandlers.add(SpringUtils.getBean(MapGuardianHandler.class));
        activityHandlers.add(SpringUtils.getBean(ZhanShenHandler.class));
        activityHandlers.add(SpringUtils.getBean(QishaController.class));
        activityHandlers.add(SpringUtils.getBean(JiuTianController.class));
        /*升级幻境*/
      //  activityHandlers.add(SpringUtils.getBean(UpLevelJlHandler.class));
        /**魔龙吞天*/
        activityHandlers.add(SpringUtils.getBean(MoLongHandler.class));
        /**魔龙之尾*/
        activityHandlers.add(SpringUtils.getBean(MoLongZhiWeiHandler.class));
        /**魔龙之眼*/
        activityHandlers.add(SpringUtils.getBean(MoLongZhiYanHandler.class));
        /**魔龙之首*/
        activityHandlers.add(SpringUtils.getBean(MoLongZhiShouHandler.class));
        /**魔龙之爪*/
        activityHandlers.add(SpringUtils.getBean(MoLongZhiZhuaHandler.class));
        /*九幽大帝*/
        activityHandlers.add(SpringUtils.getBean(JiuYouHandler.class));
        /*真武大帝*/
        activityHandlers.add(SpringUtils.getBean(ZhenWuHandler.class));
        /*邪灵大帝*/
        activityHandlers.add(SpringUtils.getBean(XieLingHandler.class));
        /*杀戮大帝*/
        activityHandlers.add(SpringUtils.getBean(ShaluHandler.class));
        /*大日金乌*/
        activityHandlers.add(SpringUtils.getBean(DaRiJinWuHandlr.class));
        /*天界叛逆*/
        activityHandlers.add(SpringUtils.getBean(GodsDescendToEarthHandler.class));
        /*地府叛逆*/
        activityHandlers.add(SpringUtils.getBean(UndergroundRebelsHandler.class));
        /*异族入侵*/
        activityHandlers.add(SpringUtils.getBean(AlienIntrusionDandler.class));
        /*天界杨戬*/
        activityHandlers.add(SpringUtils.getBean(TianYangJianHandler.class));
        /*天界哪吒*/
        activityHandlers.add(SpringUtils.getBean(TiannezhaHandler.class));
        /*天界孔宣*/
        activityHandlers.add(SpringUtils.getBean(TianKongXuanHandler.class));
        /*天界太白*/
        activityHandlers.add(SpringUtils.getBean(TianTaiBaiJinXingHandler.class));
        /*天界李靖*/
        activityHandlers.add(SpringUtils.getBean(TianLiJjingHandler.class));
        /*天界雷震子*/
        activityHandlers.add(SpringUtils.getBean(TianLeiZhenZiHandler.class));
        /*天界天帝*/
        activityHandlers.add(SpringUtils.getBean(TianTianDiHandler.class));
        /*镇妖塔*/
        activityHandlers.add(SpringUtils.getBean(ZhenYaoPagodaHandler.class));
        /*桃柳林杀鬼*/
        activityHandlers.add(SpringUtils.getBean(PeachWillowForestHander.class));
       /*变异星君*/
        activityHandlers.add(SpringUtils.getBean(VariantStarHandler.class));
        /*烟花爆竹年兽*/
        activityHandlers.add(SpringUtils.getBean(YhuaNianshouBossHandler.class));


        addActivityLivenessSet(new ActivityLivenessSet("师门任务", ActivityType.SCHOOL_TASK, 2, 20));
        addActivityLivenessSet(new ActivityLivenessSet("除暴任务", ActivityType.CHU_BAO_TASK, 1, 20));
        addActivityLivenessSet(new ActivityLivenessSet("【修炼】修行", ActivityType.XIU_XING_TASK, (float)0.5, 40));
        addActivityLivenessSet(new ActivityLivenessSet("【修炼】十绝阵", ActivityType.XIU_XING_TASK, (float)0.5, 20));
        addActivityLivenessSet(new ActivityLivenessSet("助人为乐", ActivityType.HELP_PEOPLE_TASK, 10, 10));
        addActivityLivenessSet(new ActivityLivenessSet("刷道", Arrays.asList(ActivityType.SHUA_DAO_XIANGYAO_TASK, ActivityType.SHUA_DAO_FUMO_TASK, ActivityType.SHUA_DAO_FEIXIANDUXIE_TASK), (float) 0.5, 50));
        addActivityLivenessSet(new ActivityLivenessSet("通天塔", ActivityType.TOWER_TASK, 20, 20));
        addActivityLivenessSet(new ActivityLivenessSet("悬赏任务", ActivityType.XUAN_SHANG, 5, 10));
        addActivityLivenessSet(new ActivityLivenessSet("挑战掌门", ActivityType.ZHANG_MEN, 1, 1));
        addActivityLivenessSet(new ActivityLivenessSet("英雄会", ActivityType.YING_XIONG_HUI, 1, 1));
        addActivityLivenessSet(new ActivityLivenessSet("证道殿", Arrays.asList(ActivityType.ZHENG_DAO_DIAN_WIN, ActivityType.ZHENG_DAO_DIAN_FAIL), 1, 1));
        addActivityLivenessSet(new ActivityLivenessSet("副本",ActivityType.DUGEON_TASK, 10, 10));
        addActivityLivenessSet(new ActivityLivenessSet("修法任务", ActivityType.XIUFA_TASK, (float)2.0, 10));
        addActivityLivenessRewardSet(new ActivityLivenessRewardSet((short) 20, "血池", 1));
        addActivityLivenessRewardSet(new ActivityLivenessRewardSet((short) 40, "灵池", 1));
        addActivityLivenessRewardSet(new ActivityLivenessRewardSet((short) 60, "超级仙风散", 1));
        addActivityLivenessRewardSet(new ActivityLivenessRewardSet((short) 80, "活跃度宝箱", 1));
        addActivityLivenessRewardSet(new ActivityLivenessRewardSet((short) 100, "积分", 10));
    }

    private static void addShuaDaoSet(ShuaDaoSet shuaDaoSet) {
        shuaDaoMap.put(shuaDaoSet.getAcceptNpcId(), shuaDaoSet);
        shuaDaoMapByTask.put(shuaDaoSet.getFightTaskId(), shuaDaoSet);
        shuaDaoMapByTask.put(shuaDaoSet.getGuideTaskId(), shuaDaoSet);
    }

    private static void addActivityLivenessSet(ActivityLivenessSet activityLivenessSet) {
        activityLivenessSetMapByName.put(activityLivenessSet.getName(), activityLivenessSet);

        List<ActivityType> activityTypeList = activityLivenessSet.getActivityTypeList();
        for (ActivityType activityType : activityTypeList) {
            activityLivenessSetMapByType.put(activityType, activityLivenessSet);
        }
    }

    private static void addActivityLivenessRewardSet(ActivityLivenessRewardSet activityLivenessRewardSet) {
        activityLivenessRewardSets.add(activityLivenessRewardSet);
        activityLivenessRewardSetMap.put(activityLivenessRewardSet.getLivenessCount(), activityLivenessRewardSet);
    }
}
