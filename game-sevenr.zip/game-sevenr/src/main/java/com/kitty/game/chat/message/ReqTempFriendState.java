package com.kitty.game.chat.message;

import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;
import lombok.Getter;

@MessageMeta(module = Modules.CMD_REQUEST_TEMP_FRIEND_STATE)
@Getter
public class ReqTempFriendState extends Message {
    private String gid;
    private String distName;

    public String getGid() {
        return this.gid;
    }

    public String getDistName() {
        return this.distName;
    }
}
