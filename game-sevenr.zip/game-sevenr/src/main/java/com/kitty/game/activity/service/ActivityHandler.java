package com.kitty.game.activity.service;

import com.kitty.game.role.model.Role;
import com.kitty.game.team.model.Member;
import com.kitty.listener.event.FightEndEvent;
import com.kitty.logs.LoggerFunction;
import org.slf4j.Logger;

import java.util.List;

public abstract class ActivityHandler {
    protected Logger logger = LoggerFunction.ACTIVITY.getLogger();

    public abstract void handleFightEnd(FightEndEvent fightEndEvent);

    public void handleTeamLeave(Role role, boolean leader, List<Member> memberList){}

    public void handleTeamLeaveMonment(Role role){}

    public void handleTeamChangeLeader(Role role, List<Member> memberList){}

    public void handleLogout(Role role){}

    public void handleLogin(Role role){}

    public void handleHeartBeat(Role role, long prevHeartTime){}

    public void handleRoleExpire(Role role){}
}
