package com.kitty.game.config;

import lombok.Getter;
import lombok.Setter;
import org.nutz.dao.entity.annotation.Table;

/**
 * 宝石合成需要用到的配置
 */
@Setter
@Getter
@Table("p_gemset")
public class GemSet {
    private short index_;
    private String name;
    private String needName;

    public void setIndex_(short index_) {
        this.index_ = index_;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNeedName(String needName) {
        this.needName = needName;
    }

    public short getIndex_() {
        return this.index_;
    }

    public String getName() {
        return this.name;
    }

    public String getNeedName() {
        return this.needName;
    }
}
