package com.kitty.game.boss.model;

import com.kitty.game.boss.config.BossSet;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;

/**创建战斗用的Boss的参数对象*/
@Setter
@Getter
public class BossParam {
    private BossSet bossSet;
    private String name;
    /**相性*/
    private short polar;
    /**技能ID列表*/
    private ArrayList<Integer> skillIds;
    short icon;
    /**套装icon*/
    int suitIcon;
    /**套装光效*/
    int suitLightEffect;
    /**weaponIcon*/
    short weaponIcon;
    /**血量*/
    int life;

    public BossParam() {}

    public BossParam(BossSet bossSet, String name) {
        this.bossSet = bossSet;
        this.name = name;

        this.polar = (short)bossSet.getXiangxin();
        this.skillIds = bossSet.getSkills();
        this.icon = (short) bossSet.getIcon();
    }

    /**是否是超级boss*/
    public boolean isSuperBoss() {
        return this instanceof SuperBossParam;
    }

    /**是否是超级boss阵魄*/
    public boolean isSuperBossZP() {
        return this instanceof SuperBossZPParam;
    }


    //后写
    public void setBossSet(BossSet bossSet) {
        this.bossSet = bossSet;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPolar(short polar) {
        this.polar = polar;
    }

    public void setSkillIds(ArrayList<Integer> skillIds) {
        this.skillIds = skillIds;
    }

    public void setIcon(short icon) {
        this.icon = icon;
    }

    public void setSuitIcon(int suitIcon) {
        this.suitIcon = suitIcon;
    }

    public void setSuitLightEffect(int suitLightEffect) {
        this.suitLightEffect = suitLightEffect;
    }

    public void setWeaponIcon(short weaponIcon) {
        this.weaponIcon = weaponIcon;
    }

    public void setLife(int life) {
        this.life = life;
    }

    public BossSet getBossSet() {
        return this.bossSet;
    }

    public String getName() {
        return this.name;
    }

    public short getPolar() {
        return this.polar;
    }

    public ArrayList<Integer> getSkillIds() {
        return this.skillIds;
    }

    public short getIcon() {
        return this.icon;
    }

    public int getSuitIcon() {
        return this.suitIcon;
    }

    public int getSuitLightEffect() {
        return this.suitLightEffect;
    }

    public short getWeaponIcon() {
        return this.weaponIcon;
    }

    public int getLife() {
        return this.life;
    }
}
