package com.kitty.game.activity.model.product;

import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Getter
@Setter
public class SuperBoss {
    private String name;
    private int icon;
    /**小怪*/
    private String smallBossName;
    /**特殊技能*/
    private int skillId;
    /**法宝*/
    Map<String, Integer> artifactMap = new HashMap<>();
    /**阵魄*/
    private String ZPName;
    /**多少回合后(或者所有怪死亡后)才显示主怪*/
    private byte mainShowAfterRound;
    private boolean smallPolarRandom;
    private boolean smallSkillRandom;
    private Map<Byte, List<Integer>> polarSmallSkills = new HashMap<>();
    /**小怪多少回合后逃跑*/
    private byte smallEscapeAfterRound;
    /**胜利掉落组*/
    private int awardDropGroup;


    /**出现的地图id*/
    private int mapId;
    /**击杀的次数*/
    private int winCount;
    /**挑战的次数(进入战斗时增加，未胜利时减去)*/
    private int fightCount;

    public SuperBoss(String name, int icon, int skillId) {
        this.name = name;
        this.icon = icon;
        this.skillId = skillId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public void setSmallBossName(String smallBossName) {
        this.smallBossName = smallBossName;
    }

    public void setSkillId(int skillId) {
        this.skillId = skillId;
    }

    public void setArtifactMap(Map<String, Integer> artifactMap) {
        this.artifactMap = artifactMap;
    }

    public void setZPName(String ZPName) {
        this.ZPName = ZPName;
    }

    public void setMainShowAfterRound(byte mainShowAfterRound) {
        this.mainShowAfterRound = mainShowAfterRound;
    }

    public void setSmallPolarRandom(boolean smallPolarRandom) {
        this.smallPolarRandom = smallPolarRandom;
    }

    public void setSmallSkillRandom(boolean smallSkillRandom) {
        this.smallSkillRandom = smallSkillRandom;
    }

    public void setPolarSmallSkills(Map<Byte, List<Integer>> polarSmallSkills) {
        this.polarSmallSkills = polarSmallSkills;
    }

    public void setSmallEscapeAfterRound(byte smallEscapeAfterRound) {
        this.smallEscapeAfterRound = smallEscapeAfterRound;
    }

    public void setAwardDropGroup(int awardDropGroup) {
        this.awardDropGroup = awardDropGroup;
    }

    public void setMapId(int mapId) {
        this.mapId = mapId;
    }

    public void setWinCount(int winCount) {
        this.winCount = winCount;
    }

    public void setFightCount(int fightCount) {
        this.fightCount = fightCount;
    }

    public String getName() {
        return this.name;
    }

    public int getIcon() {
        return this.icon;
    }

    public String getSmallBossName() {
        return this.smallBossName;
    }

    public int getSkillId() {
        return this.skillId;
    }

    public Map<String, Integer> getArtifactMap() {
        return this.artifactMap;
    }

    public String getZPName() {
        return this.ZPName;
    }

    public byte getMainShowAfterRound() {
        return this.mainShowAfterRound;
    }

    public boolean isSmallPolarRandom() {
        return this.smallPolarRandom;
    }

    public boolean isSmallSkillRandom() {
        return this.smallSkillRandom;
    }

    public Map<Byte, List<Integer>> getPolarSmallSkills() {
        return this.polarSmallSkills;
    }

    public byte getSmallEscapeAfterRound() {
        return this.smallEscapeAfterRound;
    }

    public int getAwardDropGroup() {
        return this.awardDropGroup;
    }

    public int getMapId() {
        return this.mapId;
    }

    public int getWinCount() {
        return this.winCount;
    }

    public int getFightCount() {
        return this.fightCount;
    }
}
