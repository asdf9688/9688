package com.kitty.game.bangpai;


import com.kitty.mina.Modules;
import com.kitty.mina.annotation.MessageMeta;
import com.kitty.mina.message.Message;

import java.util.List;

/**
 * 帮派消息拒绝列表
 */
@MessageMeta(module = Modules.MSG_PARTY_CHANNEL_DENY_LIST)
public class RespOpenPlayerInfo extends Message {
    private byte flag =3;
    private List<PartyDeny> denyList;

    public byte getFlag() {
        return flag;
    }

    public void setFlag(byte flag) {
        this.flag = flag;
    }

    public List<PartyDeny> getDenyList() {
        return denyList;
    }

    public void setDenyList(List<PartyDeny> denyList) {
        this.denyList = denyList;
    }
}
