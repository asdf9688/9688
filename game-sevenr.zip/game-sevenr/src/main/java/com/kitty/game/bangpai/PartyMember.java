package com.kitty.game.bangpai;

/**
 * 帮派成员
 */
public class PartyMember {
    private String gid;
    private String roleName;
    private short olineStatus=0;//在线状态  0不在线 1在线
    private short portrait=0;
    private String job;//帮派职位
    private short level;
    private String family;//门派名字
    private int contrib=0;
    private int vitality;//活力
    private short polor;//相性 门怕派
    private short gender=0;//性别
    private int lastWeekVitality;//上周活力
    private int currWeekVitality;//本周活力
    private int joinTime;
    private int tao =100;//道行
    private short totalCurWarTimes=0;//帮战总次数
    private int lastOnlineTime;
    private int curWarTimes=0;//本届帮战次数


    public String getGid() {
        return gid;
    }

    public void setGid(String gid) {
        this.gid = gid;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public short getOlineStatus() {
        return olineStatus;
    }

    public void setOlineStatus(short olineStatus) {
        this.olineStatus = olineStatus;
    }

    public short getPortrait() {
        return portrait;
    }

    public void setPortrait(short portrait) {
        this.portrait = portrait;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public short getLevel() {
        return level;
    }

    public void setLevel(short level) {
        this.level = level;
    }

    public String getFamily() {
        return family;
    }

    public void setFamily(String family) {
        this.family = family;
    }

    public int getContrib() {
        return contrib;
    }

    public void setContrib(int contrib) {
        this.contrib = contrib;
    }

    public int getVitality() {
        return vitality;
    }

    public void setVitality(int vitality) {
        this.vitality = vitality;
    }

    public short getPolor() {
        return polor;
    }

    public void setPolor(short polor) {
        this.polor = polor;
    }

    public short getGender() {
        return gender;
    }

    public void setGender(short gender) {
        this.gender = gender;
    }

    public int getLastWeekVitality() {
        return lastWeekVitality;
    }

    public void setLastWeekVitality(int lastWeekVitality) {
        this.lastWeekVitality = lastWeekVitality;
    }

    public int getCurrWeekVitality() {
        return currWeekVitality;
    }

    public void setCurrWeekVitality(int currWeekVitality) {
        this.currWeekVitality = currWeekVitality;
    }

    public int getJoinTime() {
        return joinTime;
    }

    public void setJoinTime(int joinTime) {
        this.joinTime = joinTime;
    }

    public int getTao() {
        return tao;
    }

    public void setTao(int tao) {
        this.tao = tao;
    }

    public short getTotalCurWarTimes() {
        return totalCurWarTimes;
    }

    public void setTotalCurWarTimes(short totalCurWarTimes) {
        this.totalCurWarTimes = totalCurWarTimes;
    }

    public int getLastOnlineTime() {
        return lastOnlineTime;
    }

    public void setLastOnlineTime(int lastOnlineTime) {
        this.lastOnlineTime = lastOnlineTime;
    }

    public int getCurWarTimes() {
        return curWarTimes;
    }

    public void setCurWarTimes(int curWarTimes) {
        this.curWarTimes = curWarTimes;
    }
}
