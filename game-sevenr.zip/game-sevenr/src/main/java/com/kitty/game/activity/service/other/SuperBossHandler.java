package com.kitty.game.activity.service.other;

import com.kitty.common.spring.SpringUtils;
import com.kitty.core.SchedulerManager;
import com.kitty.game.ServerService;
import com.kitty.game.activity.model.product.ActivityType;
import com.kitty.game.activity.model.product.SuperBoss;
import com.kitty.game.activity.service.time.FightActivityHandler;
import com.kitty.game.base.service.BagService;
import com.kitty.game.boss.config.BossSet;
import com.kitty.game.boss.model.BossFightParam;
import com.kitty.game.boss.model.BossParam;
import com.kitty.game.boss.model.SuperBossParam;
import com.kitty.game.boss.model.SuperBossZPParam;
import com.kitty.game.chat.service.ChatService;
import com.kitty.game.common.BoosTitleDeal;
import com.kitty.game.config.GameMap;
import com.kitty.game.config.NPC;
import com.kitty.game.config.OnlineMall;
import com.kitty.game.enter.Position;
import com.kitty.game.enter.TitleInfo;
import com.kitty.game.equip.message.RespNotifyMiscEx;
import com.kitty.game.equip.service.EquipService;
import com.kitty.game.fight.ai.model.RoundSkillUnit;
import com.kitty.game.fight.bean.Fight;
import com.kitty.game.fight.bean.FightObject;
import com.kitty.game.fight.factory.model.NewBossFight;
import com.kitty.game.fight.message.RespCombatAddOpponent;
import com.kitty.game.fight.message.vo.CombatAddObject;
import com.kitty.game.fight.message.vo.FightMember;
import com.kitty.game.fight.service.FightMessageService;
import com.kitty.game.fight.util.FightAction;
import com.kitty.game.fight.util.FightMessageUtil;
import com.kitty.game.i18n.I18nId;
import com.kitty.game.i18n.I18nIdDataPool;
import com.kitty.game.mail.model.Mail;
import com.kitty.game.map.service.MapService;
import com.kitty.game.npc.message.RespAutoWalk;
import com.kitty.game.npc.model.NpcButton;
import com.kitty.game.pet.PetDataPool;
import com.kitty.game.pet.bean.PetObject;
import com.kitty.game.pet.model.Pet;
import com.kitty.game.pet.service.PetService;
import com.kitty.game.role.model.Role;
import com.kitty.game.role.service.RoleService;
import com.kitty.game.task.message.RespDemandWantedTask;
import com.kitty.game.task.message.vo.WantedTaskInfo;
import com.kitty.game.team.model.Team;
import com.kitty.game.utils.Const;
import com.kitty.game.utils.TimeUtil;
import com.kitty.listener.event.FightEndEvent;
import com.kitty.mina.cache.DataCache;
import com.kitty.mina.cache.SessionUtils;
import com.kitty.mina.message.MessagePusher;
import org.apache.mina.core.session.IoSession;
import org.nutz.lang.util.NutMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.text.MessageFormat;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**超级Boss处理类*/
@Component
public class SuperBossHandler extends FightActivityHandler {
    /**
     * 出现的地图ID列表
     */
    private static final List<Integer> MAPIDS = Arrays.asList(13000, 14000, 15000, 16000, 10200, 10300, 10400, 10500, 16100, 18000, 17000, 17100,
            17200, 17400, 17500, 17600, 17700, 22000, 19002);
    private static final List<Byte> POLARS = Arrays.asList(Const.SCHOOL_METAL, Const.SCHOOL_WOOD, Const.SCHOOL_WATER, Const.SCHOOL_FIRE, Const.SCHOOL_EARTH);
    /**各门派的攻击技能*/
    private static final Map<Byte, Integer> POLAR_SKILLS = new HashMap<>();
    /**各门派的障碍技能*/
    private static final Map<Byte, Integer> POLAR_HELP_SKILLS = new HashMap<>();

    private static final List<String> SUPER_BOSS_LIST = Arrays.asList("炼狱冥炎","黑熊妖皇", "血炼魔猪", "魅影蝎后", "赤血鬼猿", "紫衣妖凰");

    /**
     * 挑战最小等级
     */
    private static final int MIN_LEVEL = 79;
    /**
     * 队员之间最大等级差
     */
    private static final int MAX_LEVEL_DIFF = 100;
    /**
     * 最少组队人数
     */
    private static final int MIN_TEAM_COUNT = 1;
    /**
     * 最大战胜次数
     */
    private static final short MAX_WIN_COUNT = 30;

    private static int jishuId=0;


    @Autowired
    private MapService mapService;
    @Autowired
    ChatService chatService;


    private Map<String, SuperBoss> superBossMap = new HashMap<>();
//    private List<String> willSuperBossList = new ArrayList<>();

    @PostConstruct
    private void init() {
        /**各门派的5阶攻击技能*/
        POLAR_SKILLS.put(Const.SCHOOL_METAL, 15);
        POLAR_SKILLS.put(Const.SCHOOL_WOOD, 65);
        POLAR_SKILLS.put(Const.SCHOOL_WATER, 114);
        POLAR_SKILLS.put(Const.SCHOOL_FIRE, 165);
        POLAR_SKILLS.put(Const.SCHOOL_EARTH, 214);

        /**各门派的5阶障碍技能*/
        POLAR_HELP_SKILLS.put(Const.SCHOOL_METAL, 25);
        POLAR_HELP_SKILLS.put(Const.SCHOOL_WOOD, 75);
        POLAR_HELP_SKILLS.put(Const.SCHOOL_WATER, 125);
        POLAR_HELP_SKILLS.put(Const.SCHOOL_FIRE, 175);
        POLAR_HELP_SKILLS.put(Const.SCHOOL_EARTH, 225);

        SuperBoss superBoss = new SuperBoss("黑熊妖皇", 6600, 701);
        superBoss.setSmallBossName("百年黑熊");
        superBoss.getArtifactMap().put("混元金斗", 21);
        superBoss.getArtifactMap().put("番天印", 21);
        superBoss.getArtifactMap().put("卸甲金葫", 24);
//        superBoss.getArtifactMap().put("定海珠", 5);
//       superBoss.setAwardDropGroup(11);
        superBossMap.put(superBoss.getName(), superBoss);


        superBoss = new SuperBoss("血炼魔猪", 6603, 702);
        superBoss.setZPName("阵魄");
        superBoss.getArtifactMap().put("混元金斗", 21);
        superBoss.getArtifactMap().put("番天印", 21);
        superBoss.getArtifactMap().put("卸甲金葫", 24);
//        superBoss.getArtifactMap().put("定海珠", 5);
//        superBoss.setAwardDropGroup(12);
        superBossMap.put(superBoss.getName(), superBoss);


        superBoss = new SuperBoss("魅影蝎后", 6605, 704);
        superBoss.setSmallBossName("魅影毒蝎");
        superBoss.getArtifactMap().put("混元金斗", 21);
        superBoss.getArtifactMap().put("番天印", 21);
        superBoss.getArtifactMap().put("卸甲金葫", 24);
//        superBoss.getArtifactMap().put("定海珠", 5);
//        superBoss.setAwardDropGroup(13);
        superBoss.setMainShowAfterRound((byte) 10);
        superBoss.setSmallPolarRandom(true);
        superBoss.setSmallSkillRandom(true);
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_METAL,Arrays.asList(501,11,12,13,14,15,31,32,33,34,35) );
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_WOOD,Arrays.asList(501,61,62,63,64,65,81,82,83,84,85) );
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_WATER,Arrays.asList(501,110,111,112,113,114,131,132,133,134,135) );
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_FIRE,Arrays.asList(501,161,162,163,164,165,181,182,183,184,185) );
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_EARTH,Arrays.asList(501,210,211,212,213,214,231,232,233,234,235) );
        superBossMap.put(superBoss.getName(), superBoss);

        superBoss = new SuperBoss("赤血鬼猿", 6600, 703);
        superBoss.setSmallBossName("赤血幼猿");
        superBoss.getArtifactMap().put("混元金斗", 21);
        superBoss.getArtifactMap().put("番天印", 21);
        superBoss.getArtifactMap().put("阴阳镜", 5);
        superBoss.getArtifactMap().put("卸甲金葫", 24);
//        superBoss.setAwardDropGroup(14);
        superBoss.setSmallPolarRandom(true);
        superBoss.setSmallSkillRandom(true);
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_METAL,Arrays.asList(11,12,13,14,15,31,32,33,34,35) );
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_WOOD,Arrays.asList(61,62,63,64,65,81,82,83,84,85) );
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_WATER,Arrays.asList(110,111,112,113,114,131,132,133,134,135) );
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_FIRE,Arrays.asList(161,162,163,164,165,181,182,183,184,185) );
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_EARTH,Arrays.asList(210,211,212,213,214,231,232,233,234,235) );
        superBoss.setSmallEscapeAfterRound((byte) 5);
        superBossMap.put(superBoss.getName(), superBoss);


        superBoss = new SuperBoss("炼狱冥炎", 6510, 702);
        superBoss.setZPName("烈焰滔天");
        superBoss.getArtifactMap().put("混元金斗", 21);
        superBoss.getArtifactMap().put("番天印", 21);
        superBoss.getArtifactMap().put("卸甲金葫", 24);
//        superBoss.getArtifactMap().put("定海珠", 13);
//        superBoss.setAwardDropGroup(12);
        superBoss.setSmallPolarRandom(true);
        superBoss.setSmallSkillRandom(true);
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_METAL,Arrays.asList(11,12,13,14,15,31,32,33,34,35) );
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_WOOD,Arrays.asList(61,62,63,64,65,81,82,83,84,85) );
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_WATER,Arrays.asList(110,111,112,113,114,131,132,133,134,135) );
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_FIRE,Arrays.asList(161,162,163,164,165,181,182,183,184,185) );
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_EARTH,Arrays.asList(210,211,212,213,214,231,232,233,234,235) );
        superBossMap.put(superBoss.getName(), superBoss);


        superBoss = new SuperBoss("紫衣妖凰", 6310, 701);
        superBoss.setSmallBossName("紫衣妖凰");
        superBoss.getArtifactMap().put("番天印", 24);
        superBoss.setSmallPolarRandom(true);
        superBoss.setSmallSkillRandom(true);
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_METAL,Arrays.asList(11,12,13,14,15,31,32,33,34,35) );
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_WOOD,Arrays.asList(61,62,63,64,65,81,82,83,84,85) );
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_WATER,Arrays.asList(110,111,112,113,114,131,132,133,134,135) );
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_FIRE,Arrays.asList(161,162,163,164,165,181,182,183,184,185) );
        superBoss.getPolarSmallSkills().put(Const.SCHOOL_EARTH,Arrays.asList(210,211,212,213,214,231,232,233,234,235) );
        superBossMap.put(superBoss.getName(), superBoss);
    }

    @Override
    protected String getNpcContent(Role role, NPC bossNpc) {
        return null;
    }

    @Override
    protected String getNpcContentNotFight(Role role, NPC bossNpc) {
        int teamCount = teamService.getTeamCount(role);
        if (teamCount < MIN_TEAM_COUNT) {
            return I18nIdDataPool.getI18nContent(I18nId.PMT_1004, MIN_TEAM_COUNT) + Const.LEAVE_BUTTON;
        }
        if (role.getLevel() < MIN_LEVEL) {
            return I18nIdDataPool.getI18nContent(I18nId.PMT_1005, MIN_LEVEL) + Const.LEAVE_BUTTON;
        }
        Team team = teamService.getTeam(role.getRoleId());
        String names = teamService.checkMember(team, memberRole -> memberRole.getLevel() < MIN_LEVEL);
        if (names != null) {
            return I18nIdDataPool.getI18nContent(I18nId.PMT_1006, names, bossNpc.getName()) + Const.LEAVE_BUTTON;
        }
        SuperBoss superBoss = getSuperBoss(bossNpc.getName());
        if (superBoss.getFightCount() >= MAX_WIN_COUNT) {
            return I18nIdDataPool.getI18nContent(I18nId.PMT_1007) + Const.LEAVE_BUTTON;
        }
        names = teamService.checkMember(team, memberRole -> getRoleRemainCount(memberRole) <= 0);
        if (names != null) {
            return I18nIdDataPool.getI18nContent(I18nId.PMT_1011, names) + Const.LEAVE_BUTTON;
        }
        names = teamService.checkMember(team, memberRole -> teamService.checkMember(team, mRole -> memberRole.getLevel() - mRole.getLevel() > MAX_LEVEL_DIFF) != null);
        if (names != null) {
            return I18nIdDataPool.getI18nContent(I18nId.PMT_1017, MAX_LEVEL_DIFF);
        }

        return null;
    }

    @Override
    protected void doStartFight(Role role, NPC bossNpc) {
        int teamCount = teamService.getTeamCount(role);
        if (teamCount < MIN_TEAM_COUNT) {
            MessagePusher.pushMessage(role,new RespNotifyMiscEx(I18nIdDataPool.getI18nContent(I18nId.PMT_1004, MIN_TEAM_COUNT) + Const.LEAVE_BUTTON));
            return ;
        }
        SuperBoss superBoss = getSuperBoss(bossNpc.getName());
        superBoss.setFightCount(superBoss.getFightCount()+1);
        List<BossParam> bossParamList = newBossParamList(role, bossNpc);
//        for (BossParam bossParam:bossParamList){
//            BossSet bossSet = bossParam.getBossSet();
//            bossSet.setQixue((int) (bossSet.getQixue()*3));
//            bossSet.setWugong((int) (bossSet.getWugong()*1.3));
//            bossSet.setFagong((int) (bossSet.getFagong()*1.3));
//        }
        BossFightParam bossFightParam = new BossFightParam(bossParamList, getFightType(role));
        bossFightParam.setNpcId(bossNpc.getId());
        Fight fight = bossService.startFightToBoss(role, bossFightParam);
        fight.setMaxRound(150);


        if (superBoss.getMainShowAfterRound() <= 0) {
            addShouting(fight);
        }
    }

    private void addShouting(Fight fight) {
        if (fight.getData() == null) {
            fight.setData(NutMap.NEW());
        }
        String content = I18nIdDataPool.getI18nContent(I18nId.PMT_1008);
        fight.getData().setv("fight_round_start_shouting", Arrays.asList(content));
        fight.getData().setv("fight_round_start_shouting_period", 5);
    }

    private List<BossParam> newBossParamList(Role role, NPC bossNpc) {
        SuperBoss superBoss = getSuperBoss(bossNpc.getName());
        List<BossParam> bossParamList = new ArrayList<>();
        int count = 6;
        SuperBossParam superBossParam = newSuperBossParam(bossNpc);
        superBossParam.setMainShowAfterRound(superBoss.getMainShowAfterRound());
        superBossParam.setSmallEscapeAfterRound(superBoss.getSmallEscapeAfterRound());
        if (superBoss.isSmallPolarRandom()) {
            byte polar = 2;
            superBossParam.setPolar(polar);
        }
        if (superBoss.isSmallSkillRandom()) {
            ArrayList<Integer> skillIds = new ArrayList<>(superBoss.getPolarSmallSkills().get((byte)superBossParam.getPolar()));
            superBossParam.setSkillIds(skillIds);
        }
        bossParamList.add(superBossParam);
        String name = bossNpc.getName();
        if (name.equals("紫衣妖凰")){
            for (int i = 1; i < 3; i++) {
                superBossParam = newSuperBossParam(bossNpc);
                superBossParam.setMainShowAfterRound(superBoss.getMainShowAfterRound());
                superBossParam.setSmallEscapeAfterRound(superBoss.getSmallEscapeAfterRound());
                if (superBoss.isSmallPolarRandom()) {
                    byte polar = getRandomPolar();
                    superBossParam.setPolar(polar);
                }
                if (superBoss.isSmallSkillRandom()) {
                    ArrayList<Integer> skillIds = new ArrayList<>(superBoss.getPolarSmallSkills().get((byte)superBossParam.getPolar()));
                    superBossParam.setSkillIds(skillIds);
                }
                bossParamList.add(superBossParam);
            }
        }else {
            if (superBoss.getSmallBossName() != null) {
                /**加count-1个*/
                int smallCount = superBoss.getZPName() != null ? count -1 : count;
                for (int i = 1; i < smallCount; i++) {
                    BossSet bossSet = bossService.getBossSet(superBoss.getSmallBossName());
                    BossParam bossParam = new BossParam(bossSet, bossSet.getName());
                    if (superBoss.isSmallPolarRandom()) {
                        byte polar = getRandomPolar();
                        bossParam.setPolar(polar);
                    }
                    if (superBoss.isSmallSkillRandom()) {
                        ArrayList<Integer> skillIds = new ArrayList<>(superBoss.getPolarSmallSkills().get((byte)bossParam.getPolar()));
                        bossParam.setSkillIds(skillIds);
                    }
                    bossParamList.add(bossParam);
                }
            }
            if (superBoss.getZPName() != null) {
                BossSet bossSet = bossService.getBossSet(superBoss.getZPName());
                bossParamList.add(new SuperBossZPParam(bossSet, bossSet.getName()));
            }
        }


        return bossParamList;
    }

    private SuperBossParam newSuperBossParam(NPC bossNpc) {
        SuperBoss superBoss = getSuperBoss(bossNpc.getName());
        BossSet bossSet = bossService.getBossSet(bossNpc.getBossSetName());
        SuperBossParam bossParam = new SuperBossParam(bossSet, bossNpc.getName());
        /**随机相性*/
        byte polar = getRandomPolar();
        bossParam.setPolar(polar);
        /**获得对应的技能*/
        ArrayList<Integer> skillIds = getSkillIdsMatchPolar(polar);
        bossParam.setSkillIds(skillIds);
        bossParam.setRoundSkills(getRoundSkills(polar, superBoss));

        /**对应的法宝*/
        bossParam.setArtifactMap(superBoss.getArtifactMap());



        return bossParam;
    }

    /**获得随机相性*/
    private byte getRandomPolar() {
        int index = ThreadLocalRandom.current().nextInt(POLARS.size());
        return POLARS.get(index);
    }

    /**获得匹配相性的技能ID列表*/
    private ArrayList<Integer> getSkillIdsMatchPolar(byte polar) {
        ArrayList<Integer> skilIds = new ArrayList<>();
        /**相性的技能*/
        Integer skillId = POLAR_SKILLS.get(polar);
        skilIds.add(skillId);

        /**力破千钧*/
        skilIds.add(501);
        /**普通攻击*/
        skilIds.add(2);

        return skilIds;
    }

    private List<RoundSkillUnit> getRoundSkills(byte polar, SuperBoss superBoss) {
        List<RoundSkillUnit> list = new ArrayList<>();
        /**妖皇天怒*/
        list.add(new RoundSkillUnit(5, 5, superBoss.getSkillId()));
        Integer skillId = POLAR_HELP_SKILLS.get(polar);
        list.add(new RoundSkillUnit(6, 5, skillId));

        return list;
    }

    @Override
    protected int getFightType(Role role) {
        return Const.fightType_superboss;
    }

    @Override
    protected NPC getBossNpc(int npcId) {
        return mapService.getNpc(npcId);
    }

    @Override
    protected void clearNpcAfterWin(Role role, NPC bossNpc) {

    }

    @Override
    protected void giveReward(Role role, FightEndEvent fightEndEvent, NPC bossNpc) {
        if (!teamService.isInTeam(role)){
            MessagePusher.pushMessage(role,new RespNotifyMiscEx("离队无法获得奖励"));
            logger.error("世界boss结束，角色暂离，没有获得奖励=={}=={}=={}",role.getRoleId(),role.getName(),bossNpc.getName());
            return;
        }
        if (role.getLastDead() == 0){
            MessagePusher.pushMessage(role,new RespNotifyMiscEx("战斗中死亡，无法获得奖励"));
            logger.error("世界boss结束，角色死亡，没有获得奖励=={}=={}=={}",role.getRoleId(),role.getName(),bossNpc.getName());
            return;
        }
        IoSession session = SessionUtils.getSession(role.getRoleId());
        if (session == null) {
            MessagePusher.pushMessage(role,new RespNotifyMiscEx("离线状态，无法获得奖励"));
            logger.error("世界boss结束，角色离线，没有获得奖励=={}=={}=={}",role.getRoleId(),role.getName(),bossNpc.getName());
            return;
        }
        Role tempRole = SessionUtils.getRoleBySession(session);
        if (tempRole == null) {
            MessagePusher.pushMessage(role,new RespNotifyMiscEx("离线状态，无法获得奖励"));
            logger.error("世界boss结束，角色离线，没有获得奖励=={}=={}=={}=={}",role.getRoleId(),role.getName(),bossNpc.getName());
            return;
        }
        {
            int daohang = fightEndEvent.getReward().getInt("rewardDaohang", 0) * role.getLevel();
            int petWuxue = fightEndEvent.getReward().getInt("petRewardWuxue", 0) * role.getLevel();
            RoleService roleService = SpringUtils.getRoleService();
            roleService.addTao(role, daohang);
            int currPetId = role.getTempCache("fight_current_pet_id", 0);
            Pet pet = SpringUtils.getPetService().getPetById(currPetId, role);
            if (pet != null) {
                roleService.addPetMatiral(role, pet, petWuxue);
            }
        }
        RoleService roleService = SpringUtils.getRoleService();
        logger.error("世界boss结束，角色获得奖励，没有获得奖励=={}=={}=={}=={}",role.getRoleId(),role.getName(),bossNpc.getName());

        // 世界boss奖励
        //roleService.addGold(role,100000,Reason.FIGHT);
        roleService.addRechargeScore(role,50);

        /**1%概率获得法宝*/
        int fabaoRate = ThreadLocalRandom.current().nextInt(1000);
        if (fabaoRate < 5) {
            Mail mail = SpringUtils.getMailService().createMail("世界boss", "世界boss", 30 * TimeUtil.ONE_DAY);
            String[] strings = {"混元金斗", "番天印", "阴阳镜", "定海珠", "金蛟剪", "九龙神火罩", "卸甲金葫"};
            int index = new Random().nextInt(strings.length);
            ArrayList<NutMap> maps = new ArrayList<>();
            maps.add(new NutMap().setv("data", "#I物品|" + strings[index] + "#r1#I").setv("type", Const.mailFabao).setv("petName", "18级"+strings[index]).setv("level", 18));
            mail.getDatas().addAll(maps);
            SpringUtils.getMailService().sendNewMail(role, mail);
        }

        {
            Mail mail = SpringUtils.getMailService().createMail("击杀世界BOSS", "击杀世界BOSS", 30 * TimeUtil.ONE_DAY);
            ArrayList<NutMap> maps = new ArrayList<>();
            String name = "天倾石";
            int count = 1;
            maps.add(new NutMap().setv("data", "#I物品|"+name+"#r"+count+"#I").setv("type", Const.mailItem).setv("petName", name).setv("value",count));
            mail.getDatas().addAll(maps);
            SpringUtils.getMailService().sendNewMail(role,mail);
            String content = "惊闻玩家" + role.getName() + "在消灭" + bossNpc.getName() + "后，获得了#R3个天倾石#n，真是可喜可贺！#51 #82";
            chatService.sendAdnotice(content);
        }
        {
            Mail mail = SpringUtils.getMailService().createMail("击杀世界BOSS", "击杀世界BOSS", 30 * TimeUtil.ONE_DAY);
            ArrayList<NutMap> maps = new ArrayList<>();
            String name = "超级女娲石";
            int count = 1;
            maps.add(new NutMap().setv("data", "#I物品|"+name+"#r"+count+"#I").setv("type", Const.mailItem).setv("petName", name).setv("value",count));
            mail.getDatas().addAll(maps);
            SpringUtils.getMailService().sendNewMail(role,mail);
            String content = "惊闻玩家" + role.getName() + "在消灭" + bossNpc.getName() + "后，获得了#R3个天倾石#n，真是可喜可贺！#51 #82";
            chatService.sendAdnotice(content);
        }
        {
            Mail mail = SpringUtils.getMailService().createMail("击杀世界BOSS", "击杀世界BOSS", 30 * TimeUtil.ONE_DAY);
            ArrayList<NutMap> maps = new ArrayList<>();
            String name = "冥海霞光";
            int count = 2;
            maps.add(new NutMap().setv("data", "#I物品|"+name+"#r"+count+"#I").setv("type", Const.mailItem).setv("petName", name).setv("value",count));
            mail.getDatas().addAll(maps);
            SpringUtils.getMailService().sendNewMail(role,mail);
            String content = "惊闻玩家" + role.getName() + "在消灭" + bossNpc.getName() + "后，获得了#R3个天倾石#n，真是可喜可贺！#51 #82";
            chatService.sendAdnotice(content);
        }
        {
            int currPetId = role.getTempCache("fight_current_pet_id", 0);
            roleService.addExp(role,3000000,role.getLevel(),currPetId);
        }

        Random random = new Random();
        int value = random.nextInt(100);
        if (value <10){
            String[] strings =  {"百年黑熊", "笨笨牛","赤血幼猿","玄天刺猬", "血幻豪猪"};
            int index = new Random().nextInt(strings.length);
            String name = strings[index];
            PetObject petObject = PetDataPool.getPetObject(name);
            PetService petService = SpringUtils.getPetService();
            Pet newpet = petService.addPet(petObject, role, false);
            petService.loadPet(role, newpet);
            RespNotifyMiscEx respNotifyMiscEx = new RespNotifyMiscEx();
            respNotifyMiscEx.setMsg("你获得了一只#R" + petObject.getName() + "#n。");
            respNotifyMiscEx.setTime(new Long(System.currentTimeMillis() / 1000).intValue());
            MessagePusher.pushMessage(role, respNotifyMiscEx);
        }
        value = random.nextInt(100);
        if (value <5){
            String[] strings = {"至尊太极熊"};
            int index = new Random().nextInt(strings.length);
            String name = strings[index];
            PetObject petObject = PetDataPool.getPetObject(name);
            PetService petService = SpringUtils.getPetService();
            Pet newpet = petService.addPet(petObject, role, false);
            petService.loadPet(role, newpet);
            RespNotifyMiscEx respNotifyMiscEx = new RespNotifyMiscEx();
            respNotifyMiscEx.setMsg("你获得了一只#R" + petObject.getName() + "#n。");
            respNotifyMiscEx.setTime(new Long(System.currentTimeMillis() / 1000).intValue());
            MessagePusher.pushMessage(role, respNotifyMiscEx);
        }
        value = random.nextInt(100);
        if (value <30){
            SpringUtils.getEquipService().getRandomJewelry(35, role, false);
            SpringUtils.getEquipService().getRandomJewelry(35, role, false);
        }
        { roleService.addluoshuExp(role, 20000);}
        { roleService.addYinde(role, 20000, true); }

    }

    @Override
    protected void clearNpcTimeOut(NPC npc) {
        timeOut(npc);
    }

    @Override
    public void doFightWin(Role role, FightEndEvent fightEndEvent) {
        NPC npc = mapService.getNpc(fightEndEvent.getNpcId());
        if (npc != null){
            SuperBoss superBoss = getSuperBoss(npc.getName());
            superBoss.setWinCount(superBoss.getWinCount() + 1);
            /**胜利次数达到最大值*/
            if (superBoss.getWinCount() >= MAX_WIN_COUNT) {
                if (npc != null) {
                    clearSuperBoss(npc);
                }
            }
        }
        super.doFightWin(role, fightEndEvent);
        teamService.memberHandleThreadLocal(role, memberRole -> SpringUtils.getActivityService().addFinishCount(memberRole, ActivityType.SUPER_BOSS, 1));
    }

    @Override
    public void doFightFail(Role role, FightEndEvent fightEndEvent) {
        super.doFightFail(role, fightEndEvent);
        NPC npc = mapService.getNpc(fightEndEvent.getNpcId());
        if (npc != null){
            SuperBoss superBoss = getSuperBoss(npc.getName());
            superBoss.setFightCount(superBoss.getFightCount() - 1);
        }
        teamService.memberHandleThreadLocal(role, memberRole -> SpringUtils.getRoleService().punishFightDead(memberRole));
    }

    @Override
    public void doFightRunAway(Role role, FightEndEvent fightEndEvent) {
        super.doFightRunAway(role, fightEndEvent);
        NPC npc = mapService.getNpc(fightEndEvent.getNpcId());
        if (npc != null){
            SuperBoss superBoss = getSuperBoss(npc.getName());
            superBoss.setFightCount(superBoss.getFightCount() - 1);
        }

        teamService.memberHandleThreadLocal(role, memberRole -> SpringUtils.getRoleService().punishFightDead(memberRole));
    }

    @Override
    public void doFightMaxRound(Role role, FightEndEvent fightEndEvent) {
        super.doFightMaxRound(role, fightEndEvent);
        NPC npc = mapService.getNpc(fightEndEvent.getNpcId());
        SuperBoss superBoss = getSuperBoss(npc.getName());
        superBoss.setFightCount(superBoss.getFightCount() - 1);
    }

    @Override
    public boolean isSetInFight() {
        /**不需要设置进入战斗状态，可以同时进入战斗*/
        return false;
    }

    public void flushSuperBoss() {

//        willSuperBossList.clear();

        willCome();
    }

    /**即将到来*/
    public void willCome() {
        String name = getWillComeBoss();
        if (name == null) {return ;}

//        willSuperBossList.add(name);
        SuperBoss superBoss = getSuperBoss(name);

        /**随机出现的地图*/
        int mapId = randomMap();
        superBoss.setMapId(mapId);

        /**系统消息*/
        ServerService serverService = SpringUtils.getBean(ServerService.class);
        GameMap map = mapService.getMap(mapId);
        String mapName = map.getName();
        int delayMinute = 10;  /*boos几分钟到达战场*/
        String content = I18nIdDataPool.getI18nContent(I18nId.PMT_1000, name, delayMinute, serverService.getServer().getSonName(), mapName);
        SpringUtils.getChatService().sendAdnotice(content);

        SchedulerManager.getInstance().schedule(() -> hasCome(superBoss), delayMinute* TimeUtil.ONE_MINUTE);

//        /**间隔一段时间，刷新下一个*/
//        SchedulerManager.getInstance().schedule(() -> willCome(), 60 * TimeUtil.ONE_MINUTE);
    }
    private String getWillComeBoss() {
        int i = new Random().nextInt(SUPER_BOSS_LIST.size());
        return SUPER_BOSS_LIST.get(i);
//        for (String name : SUPER_BOSS_LIST) {
////            if (!willSuperBossList.contains(name)) {
//                return name;
////            }
//        }
//        return null;
    }

    private SuperBoss getSuperBoss(String name) {
        return superBossMap.get(name);
    }

    private int randomMap() {
        int index = ThreadLocalRandom.current().nextInt(MAPIDS.size());
        return MAPIDS.get(index);
    }

    /**已经到来*/
    public void hasCome(SuperBoss superBoss) {
        NPC npc = createSuperBoss(superBoss);
        superBoss.setWinCount(0);
        superBoss.setFightCount(0);

        /**系统消息*/
        ServerService serverService = SpringUtils.getBean(ServerService.class);
        GameMap map = mapService.getMap(superBoss.getMapId());
        String mapName = map.getName();
        String content = I18nIdDataPool.getI18nContent(I18nId.PMT_1001, superBoss.getName(), serverService.getServer().getSonName(), mapName);
        SpringUtils.getChatService().sendAdnotice(content);

        SchedulerManager.getInstance().schedule(() -> willTimeOut(npc), 20 * TimeUtil.ONE_MINUTE);
        SchedulerManager.getInstance().schedule(() -> timeOut(npc), 30 * TimeUtil.ONE_MINUTE);
    }

    private NPC createSuperBoss(SuperBoss superBoss) {
        int mapId = superBoss.getMapId();
        String name = superBoss.getName();
        Position position = getRandomPosition(mapId);
        NPC npc = new NPC();
        npc.setId(SpringUtils.getBossService().getTempNpcId());
        npc.setX(position.getX());
        npc.setY(position.getY());
        npc.setFangxiang((short) new Random().nextInt(8));
        npc.setMapId(mapId);
        npc.setCreateTime(System.currentTimeMillis());
        npc.setEndTime(npc.getCreateTime() + 30 * TimeUtil.ONE_MINUTE);
        npc.setType(NPC.TYPE_SUPER_BOSS);
        npc.setName(name);
        npc.setBossSetName(name);
        npc.setContent(I18nIdDataPool.getI18nContent(I18nId.PMT_1003));
        npc.setIcon(superBoss.getIcon());

        bossService.addTaskNpc(npc);

        bossService.broadcastNpcShow(null, npc);
        return npc;
    }

    /**即将过期*/
    private void willTimeOut(NPC npc) {
        /**已经消失*/
        if (mapService.getNpc(npc.getId()) == null) {return ;}

        /**系统消息*/
        ServerService serverService = SpringUtils.getBean(ServerService.class);
        GameMap map = mapService.getMap(npc.getMapId());
        String mapName = map.getName();
        String content = I18nIdDataPool.getI18nContent(I18nId.PMT_1002, npc.getName(), serverService.getServer().getSonName(), mapName);
        SpringUtils.getChatService().sendAdnotice(content);
    }

    private void timeOut(NPC npc) {
        /**已经消失*/
        if (mapService.getNpc(npc.getId()) == null) {return ;}

        clearSuperBoss(npc);
    }

    private void clearSuperBoss(NPC npc) {
        if (npc == null) {
            return;
        }

        SuperBoss superBoss = getSuperBoss(npc.getName());
        superBoss.setMapId(0);

        bossService.delTaskNpc(npc);
        bossService.broadcastNpcHide(null, npc);

        removeUsedPosition(npc.getMapId(), npc.getX(), npc.getY());
    }

    /**超级大BOSS*/
    public void superBossButton(Role role, NPC npc) {
        if (npc == null) {
            return;
        }

        String content = I18nIdDataPool.getI18nContent(I18nId.PMT_1009);
        SpringUtils.getNpcService().sendNpcContent(role, npc, content);
    }

    /**查看BOSS图鉴*/
    public void viewSuperBossIntroduce(Role role, NPC npc) {
        SpringUtils.getNpcService().openDlg(role, "SuperBossIntroduceDlg");
    }

    /**查询BOSS击杀次数*/
    public void viewSuperBossRoleKillCount(Role role, NPC npc) {
        RespDemandWantedTask respDemandWantedTask = getRespDemandWantedTask(role);
        teamService.pushMessage(role, respDemandWantedTask);
    }

    private RespDemandWantedTask getRespDemandWantedTask(Role role) {
        RespDemandWantedTask respDemandWantedTask = new RespDemandWantedTask();
        List<WantedTaskInfo> taskInfoList = new ArrayList<>();
        respDemandWantedTask.setTaskInfoList(taskInfoList);

        if (teamService.isInTeam(role)) {
            Team team = teamService.getTeam(role.getRoleId());
            teamService.memberHandle(team, memberRole -> taskInfoList.add(getWantedTaskInfo(memberRole)));
        } else {
            taskInfoList.add(getWantedTaskInfo(role));
        }

        return respDemandWantedTask;
    }

    private WantedTaskInfo getWantedTaskInfo(Role role) {
        WantedTaskInfo wantedTaskInfo = new WantedTaskInfo();
        wantedTaskInfo.setIcon(role.getRoleIcon());
        wantedTaskInfo.setLevel(role.getLevel());
        wantedTaskInfo.setName(role.getName());
        wantedTaskInfo.setVipType(role.getVipType());
        wantedTaskInfo.setTimes(getRoleRemainCount(role));
        wantedTaskInfo.setStatus((byte) 0);
        return wantedTaskInfo;
    }

    private byte getRoleRemainCount(Role role) {
        if (!isSuperBossHasCome()) {
            return 0;
        }

        return (byte) SpringUtils.getActivityService().getRemainCount(role, ActivityType.SUPER_BOSS);
    }

    /**是否有超级boss到来了*/
    private boolean isSuperBossHasCome() {
        for (SuperBoss superBoss : superBossMap.values()) {
            if (superBoss.getMapId() > 0) {
                return true;
            }
        }

        return false;
    }

    /**查询BOSS位置*/
    public void viewSuperBossPosition(Role role, NPC npc) {
        String content;
        if (isSuperBossHasCome()) {
            StringBuilder buttons = new StringBuilder();
            StringBuilder positions = new StringBuilder();
            for (SuperBoss superBoss : superBossMap.values()) {
                if (superBoss.getMapId() <= 0) {continue;}

                buttons.append(I18nIdDataPool.getI18nContent(I18nId.PMT_1014, superBoss.getName()));

                if (positions.length() > 0) {positions.append("、");}
                positions.append(getSuperBossPosition(superBoss));
            }
            content = I18nIdDataPool.getI18nContent(I18nId.PMT_1015, positions.toString(), buttons.toString());
        } else {
            content = I18nIdDataPool.getI18nContent(I18nId.PMT_1013);
        }
        SpringUtils.getNpcService().sendNpcContent(role, npc, content);
    }

    private String getSuperBossPosition(SuperBoss superBoss) {
        ServerService serverService = SpringUtils.getBean(ServerService.class);
        GameMap map = mapService.getMap(superBoss.getMapId());
        String mapName = map.getName();
        String content = I18nIdDataPool.getI18nContent(I18nId.PMT_1012, superBoss.getName(), serverService.getServer().getSonName(), mapName);
        return content;
    }

    /**前往超级boss地图*/
    public void gotoSuperBossPosition(Role role, NPC npc, String msg) {
        String name = msg.replace(NpcButton.GOTO_SUPER_BOSS_PREFIX.getKey(), "");
        SuperBoss superBoss = getSuperBoss(name);

        RespAutoWalk respAutoWalk = new RespAutoWalk();
        respAutoWalk.setTaskName("");
        GameMap map = mapService.getMap(superBoss.getMapId());
        respAutoWalk.setDest(MessageFormat.format("#Z{0}#Z", map.getName()));
        MessagePusher.pushMessage(role, respAutoWalk);
    }

    /**查询超级boss挑战次数*/
    public void viewSuperBossKillCount(Role role, NPC npc) {
        SuperBoss superBoss = getSuperBoss(npc.getName());
        int remainCount = superBoss != null ? MAX_WIN_COUNT - superBoss.getWinCount() : 0;
        remainCount=1;
        String content = I18nIdDataPool.getI18nContent(I18nId.PMT_1010, remainCount);
        SpringUtils.getNpcService().sendNpcContent(role, npc, content);
    }

    /**
     * 所有怪物死亡或者每回合检查
     */
    public void checkFight(Fight fight) {
        if (fight.getData() != null && fight.getData().get("fight_super_boss_param") != null) {
            if (!fight.isSideOver(fight.getListB()) && fight.getRound() < fight.getData().getInt("fight_main_show_after_round")) {
                return ;
            }
            BossParam bossParam = fight.getData().getAs("fight_super_boss_param", SuperBossParam.class);
            fight.getData().remove("fight_super_boss_param");

            double lifeRate = 1;
            if (fight.getRound() >= fight.getData().getInt("fight_main_show_after_round")) {
                lifeRate = 1.2;
            } else if (fight.isSideOver(fight.getListB())) {
                lifeRate = 0.8;
            }

            NewBossFight bossFight = (NewBossFight)fight;
            if (fight.getListB() != null) {
                List<FightObject> list = new ArrayList<>(fight.getListB());
                for (FightObject fightObject : list) {
                    FightMessageUtil.sendFightPackage(fight, SpringUtils.getFightMessageService().disappear(fightObject.getId()));
                    fight.removeFightObject(fightObject);
                }
            }

            RespCombatAddOpponent respCombatAddOpponent = new RespCombatAddOpponent();
            respCombatAddOpponent.setList(new ArrayList<>());
            CombatAddObject combatAddObject = new CombatAddObject();
            respCombatAddOpponent.getList().add(combatAddObject);

            FightObject fightObject = bossFight.addFightObject(bossParam, (byte) 0);
            fightObject.setMaxLife((int) (fightObject.getCurrLife()*lifeRate));
            fightObject.setCurrLife(fightObject.getMaxLife());
            FightMember fightMember = null;
            for (FightMember member : bossFight.getFightMemberB()) {
                if (fightObject.getId() == member.getId()) {
                    fightMember = member;
                    break;
                }
            }

            combatAddObject.setId(fightMember.getId());
            combatAddObject.setLeader(fightMember.getLeader());
            combatAddObject.setWeapon_icon(fightMember.getWeapon_icon());
            combatAddObject.setPosition(fightMember.getPosition());
            combatAddObject.setColor(fightMember.getColor());
            combatAddObject.setVip_type(fightMember.getVipStatus());
            combatAddObject.setList(fightMember.getList());
            combatAddObject.setIcon(fightMember.getIcon());
            combatAddObject.setSuit_icon(fightMember.getSuit_icon());
            combatAddObject.setSuit_light_effect(fightMember.getSuit_light_effect());
            combatAddObject.setSpecial_icon(fightMember.getSpecial_icon());

            FightMessageUtil.sendFightPackage(fight, respCombatAddOpponent, true);

            addShouting(fight);
        }

        if (fight.getData() != null && fight.getData().get("fight_small_escape_after_round") != null
                && fight.getRound() >= fight.getData().getInt("fight_small_escape_after_round")) {
            fight.getData().remove("fight_small_escape_after_round");

            if (fight.getListB() != null) {
                FightMessageService fightMessageService = SpringUtils.getFightMessageService();
                List<FightObject> list = new ArrayList<>(fight.getListB());
                for (FightObject fightObject : list) {
                    if (fightObject.isMonster() && !fightObject.isSuperBoss()) {
                        fightObject.setType(FightAction.FLEE);
                        fightObject.setSkillId(0);
                        FightMessageUtil.sendFightPackage(fight, fightMessageService.doActionStart(fight.getRound(), fightObject));
                        FightMessageUtil.sendFightPackage(fight, fightMessageService.disappear(fightObject.getId()));
                        logger.warn("逃跑id:{}, round:{}", fightObject.getId(), fight.getRound());
                        FightMessageUtil.sendFightPackage(fight, fightMessageService.doActionEnd(fightObject.getId()));
                        fight.removeFightObject(fightObject);
                    }
                }
            }
        }
    }
}
