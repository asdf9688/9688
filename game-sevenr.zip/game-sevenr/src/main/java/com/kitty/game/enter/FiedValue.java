package com.kitty.game.enter;

import com.kitty.common.spring.SpringUtils;
import com.kitty.game.attribute.AttrService;
import org.nutz.lang.Lang;
import org.slf4j.LoggerFactory;

public class FiedValue {
    private short type;
    private byte VT;
    private Object value;

    public FiedValue(int fieldId, int type, Object value) {
        this.type = (short) fieldId;
        this.VT = (byte) type;
        this.value = value;
    }


    public FiedValue(int fieldId, Object value) {
        this.type = (short) fieldId;
        byte fieldType = SpringUtils.getBean(AttrService.class).getAttrType(fieldId);
        if (fieldType == 0) {//等于0说明配置不对 抛出异常看看是什么属性
            try {
                throw new Exception(String.format("属性ID[%d]的类型不正确!!!", fieldId));
            } catch (Exception e) {
                LoggerFactory.getLogger(this.getClass()).error("属性ID={}没有设置类型={}",fieldId, Lang.getStackTrace(e));
            }
        }
        this.VT = fieldType;
        this.value = value;
    }

    public FiedValue() {
    }

    public byte getVT() {
        return VT;
    }

    public void setVT(byte VT) {
        this.VT = VT;
    }

    public short getType() {
        return type;
    }

    public void setType(int type) {
        this.type = (short) type;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }
}
