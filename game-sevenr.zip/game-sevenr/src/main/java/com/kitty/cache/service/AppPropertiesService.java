//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.kitty.cache.service;

import com.kitty.cache.entity.AppProperties;
import java.util.List;
import org.nutz.dao.Cnd;
import org.nutz.dao.Dao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class AppPropertiesService {
    private static final Logger log = LoggerFactory.getLogger(AppPropertiesService.class);
    @Autowired
    Dao dao;
    @Autowired
    JdbcTemplate jdbcTemplate;

    public AppPropertiesService() {
    }

    public List<AppProperties> findAll() {
        return this.dao.query(AppProperties.class, Cnd.NEW());
    }

    public List<AppProperties> findByKey(String key) {
        return this.dao.query(AppProperties.class, Cnd.where("key_", "=", key));
    }
}
