//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.kitty.cache.entity;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

@Table("p_redis_cache")
public class AppProperties {
    @Id
    private Long id;
    @Column
    private String key_;
    @Column
    private String value_;
    @Column
    private String type_;

    public AppProperties() {
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setKey_(String key_) {
        this.key_ = key_;
    }

    public void setValue_(String value_) {
        this.value_ = value_;
    }

    public void setType_(String type_) {
        this.type_ = type_;
    }

    public Long getId() {
        return this.id;
    }

    public String getKey_() {
        return this.key_;
    }

    public String getValue_() {
        return this.value_;
    }

    public String getType_() {
        return this.type_;
    }
}
