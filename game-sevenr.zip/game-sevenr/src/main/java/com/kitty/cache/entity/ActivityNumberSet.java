package com.kitty.cache.entity;

import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

@Table("p_bosscount")
public class ActivityNumberSet {
    @Id
    private Long id;

    @Column
    private String name;

    @Column
    private int cishu;

    @Column
    private String bossType;

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCishu(int cishu) {
        this.cishu = cishu;
    }

    public void setBossType(String bossType) {
        this.bossType = bossType;
    }

    public Long getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public int getCishu() {
        return this.cishu;
    }

    public String getBossType() {
        return this.bossType;
    }
}
