package com.kitty.doctor;

import com.kitty.game.role.model.Role;
import com.kitty.common.spring.SpringUtils;
import com.kitty.game.market.MarketService;
import com.kitty.mina.cache.SessionUtils;
import org.apache.mina.core.session.IoSession;

import com.kitty.doctor.IScript;

/**
 * 业务逻辑代码热更，代码写在构造方法，每次调用都是不同的类加载器
 *
 */
public class CommonScript implements IScript {

    public CommonScript() {

/*       Role role = SpringUtils.getPlayerService().getPlayerBy("aaa");
        role.level = 111;
       System.err.println("---CommonScript---");
       LoggerUtils.error("玩家当前等级{}", role.getLevel());*/

        Role role = SpringUtils.getPlayerService().getPlayerBy(3198663572914176L);
/*        role.setMoney(100000000);
       role.save();*/
        role.setLevel((short) 62);

        IoSession session = SessionUtils.getSessionBy(role.getId());
        MarketService marketService = SpringUtils.getBean(MarketService.class);
    }

}