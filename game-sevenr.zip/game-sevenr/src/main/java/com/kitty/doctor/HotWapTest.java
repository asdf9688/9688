package com.kitty.doctor;

public class HotWapTest {

    public static String sayHello() {
        return "before hotSwap, say hello";
    }
}
