package com.kitty.doctor;

/**
 * 热更脚本接口
 *
 *
 */
public interface IScript {

}