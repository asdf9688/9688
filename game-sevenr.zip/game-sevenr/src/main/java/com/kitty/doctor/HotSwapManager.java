package com.kitty.doctor;

import com.sun.tools.attach.VirtualMachine;
import com.kitty.game.utils.FileUtils;
import com.kitty.logs.LoggerUtils;
import groovy.lang.GroovyClassLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.File;
import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 * 热更类
 */

@Component
public class HotSwapManager {

    private Logger logger = LoggerFactory.getLogger(HotSwapManager.class);

    private static HotSwapManager self;

    public static volatile Exception exception;

    public static volatile String log;

    @PostConstruct
    private void init() {
        self = new HotSwapManager();
    }

    /**
     * 拓展参数，例如避免重复补偿
     */
    public Map<String, Object> params = new HashMap<>();

    public static HotSwapManager getInstance() {
        return self;
    }

    /**
     * load java source file and creates a new instance of the class
     *
     * @param classFullName
     * @return
     */
    public String loadJavaFile(String classFullName) {
        /* 类的名字，*/
        String simpleName = classFullName.substring(classFullName.lastIndexOf(".") + 1, classFullName.length());
        try {
            String filePath = "hotswap/" + simpleName + ".java";
            String clazzFile = FileUtils.readText(filePath);
            @SuppressWarnings("resource")
            Class<?> clazz = new GroovyClassLoader().parseClass(clazzFile, classFullName);
            clazz.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
            return "load class failed ," + e.getMessage();
        }

        return "load class succ";
    }

    /**
     * use jdk instrument to hotswap a loaded class you can only modify a class's
     * method!!
     *
     * @param path 热更目录
     * @return
     */
    public String reloadClass(String path) {
        try {
            /* 拿到当前jvm的进程id*/
            String pid = ManagementFactory.getRuntimeMXBean().getName().split("@")[0];
            VirtualMachine vm = VirtualMachine.attach(pid);
            path = "hotswap" + File.separator + path;
            List<File> files = FileUtils.listFiles(path);
            List<String> succFiles = new ArrayList<>();
            log = "empty";
            exception = null;
            LoggerUtils.error("热更目录[{}]，总共有{}个文件", path, files.size());
            for (File file : files) {
                String classPath = path + File.separator + file.getName();
                LoggerUtils.error("reload path ==" + classPath);
                /* path参数即agentmain()方法的第一个参数*/
                vm.loadAgent("agent/hotswap-agent.jar", classPath);
                succFiles.add(file.getName());
                logger.error("热更日志{}", log);
                logger.error("热更异常{}", exception);
            }
        /*    return "热更的文件有 " + String.join(",", succFiles);*/
            return log;
        } catch (Throwable e) {
            logger.error("", e);
            return "热更失败";
        }
    }


}